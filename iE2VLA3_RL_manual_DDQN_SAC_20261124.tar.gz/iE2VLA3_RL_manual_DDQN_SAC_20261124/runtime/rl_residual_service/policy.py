"""Existing no-speed wire interface with optional chunk residual correction."""
from dataclasses import asdict, replace
import torch
from rl_chunk_service.execution import saved_semantics
from dataset.lerobot_original import LeRobotOriginalCollator
from e2vla_compat.policy import Policy as WirePolicy
from rl_chunk_service.policy import Policy as ChunkPolicy
from rl_factor_sac.config import SACConfig
from rl_factor_sac.reward import RewardConfig
from .artifacts import ResidualSAC, SEMANTICS, artifact_bindings
from .foundation import NoSpeedFoundation
from .session import ResidualSession


class Policy(ChunkPolicy):
    @classmethod
    def load(cls, settings, token=None, sac=None, *, mode="zero", source="robot", journal=None,
             reward=RewardConfig(), sac_config=None, probe_mm=.25, probe_arm="left", probe_axis="x", dump_path=None,
             execution=None):
        if mode not in ("zero", "probe", "inference", "collect", "train"):
            raise ValueError("Unknown residual mode")
        diagnostic = mode in ("zero", "probe")
        if diagnostic and (token is not None or sac is not None):
            raise ValueError("Diagnostic zero/probe modes use an explicitly untrained actor, not saved policies")
        if not diagnostic and (token is None or sac is None):
            raise ValueError("inference/collect/train need a no-speed RL token and residual SAC checkpoint")
        device = settings.device
        if device == "auto":
            device = "cuda:0" if torch.cuda.is_available() else "cpu"
        if not diagnostic:
            bindings, _ = artifact_bindings(settings.checkpoint, token, reward)
            learner = ResidualSAC.load(sac, device, bindings)
            if sac_config and sac_config != learner.config:
                raise ValueError("SAC config differs from checkpoint")
        foundation = NoSpeedFoundation.load(settings.checkpoint, device, token)
        if diagnostic:
            config = sac_config or replace(SACConfig(), token_dim=foundation.token.config.token_dim)
            learner = ResidualSAC(config, device, probe_only=True)
            bindings = dict(base_sha256=foundation.base_sha256, token_sha256="0"*64, reward_config=asdict(reward))
        session = ResidualSession(foundation, learner, bindings, mode="inference" if diagnostic else mode,
            source=source, journal=journal, probe_mode=mode if diagnostic else None,
            probe_mm=probe_mm, probe_arm=probe_arm, probe_axis=probe_axis, dump_path=dump_path,
            execution=execution)
        return cls(settings, session, foundation.native_info, LeRobotOriginalCollator(foundation.base.vlm.processor))

    def get_info(self):
        result = WirePolicy.get_info(self)
        result.update(backend="iE2VLA3_no_speed_residual_SAC", rl=dict(saved_semantics(SEMANTICS, self.session.execution.asdict()),
            mode=self.session.probe_mode or self.session.mode, enabled_branches=["residual"],
            diagnostic_only=bool(self.session.probe_mode), bindings=self.session.bindings,
            feedback="configured_execution_v2", execution=self.session.execution.asdict(),
            token_and_wrench="explicit zero placeholders; cannot train" if self.session.probe_mode else "trained token; wrench follows configured missing-data policy",
            batch_timestamp="receipt time; legacy batch has no acquisition timestamp"))
        return result
