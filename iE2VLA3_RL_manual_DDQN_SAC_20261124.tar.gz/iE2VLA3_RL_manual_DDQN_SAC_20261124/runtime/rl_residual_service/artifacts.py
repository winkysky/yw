"""Residual-only checkpoint/replay formats, bound to a no-speed base and token."""
import copy
from dataclasses import asdict
import threading
import torch
from torch import nn
from models.m0512_fm.lerobot_inference import load_checkpoint
from rl_factor_sac.config import SACConfig
from rl_factor_sac.io import atomic_save, file_sha256, validate_bindings
from rl_factor_sac.sac import SACBranch
from rl_factor_sac.replay import ReplayBuffer
from rl_chunk_service.execution import ExecutionConfig, saved_semantics
from rl_factor_sac.token import TokenConfig, RLToken
from .foundation import TOKEN_FORMAT

SEMANTICS = dict(base="no_speed", decisions="one_residual_per_vla_chunk",
                 residual="constant_local_tcp_offset_per_chunk", factor="disabled_fixed_identity",
                 feedback="measured_wrench_and_explicit_execution_v1", reference_hz=30)


def artifact_bindings(base, token, reward):
    _, path = load_checkpoint(base)
    base_hash = file_sha256(path)
    saved = torch.load(token, map_location="cpu", weights_only=False)
    if saved.get("format") != TOKEN_FORMAT or saved["base_sha256"] != base_hash:
        raise ValueError("Requires a no-speed RL token trained against this exact base")
    c = TokenConfig(**saved["token_config"])
    with torch.random.fork_rng(devices=[]):
        RLToken(c).load_state_dict(saved["token"], strict=True)
    bindings = dict(base_sha256=base_hash, token_sha256=file_sha256(token), reward_config=asdict(reward))
    validate_bindings(bindings)
    return bindings, c.token_dim


class IdentityFactor(nn.Module):
    """An interface adapter, not a policy network, critic or optimizer."""
    def __init__(self, device):
        super().__init__()
        self.device_marker = nn.Parameter(torch.empty(0, device=device), requires_grad=False)

    def act(self, obs, deterministic=False):
        return torch.ones(len(obs["state"]), 1, device=obs["state"].device, dtype=torch.long)


class ResidualSAC:
    def __init__(self, config=SACConfig(), device="cpu", *, probe_only=False):
        from types import SimpleNamespace
        self.config, self.probe_only = config, probe_only
        self.residual = SACBranch(config, "residual", device)
        # Reuse the chunk execution machinery without constructing a factor SAC.
        self.factor = SimpleNamespace(actor=IdentityFactor(device))
        self.lock = threading.RLock()

    @property
    def versions(self):
        return dict(factor=0, residual=self.residual.updates)

    def actor_snapshot(self):
        with self.lock:
            return dict(versions=self.versions, factor=self.factor.actor,
                residual=copy.deepcopy(self.residual.actor).eval().requires_grad_(False))

    def update(self, residual_batch=None, factor_batch=None):
        if self.probe_only or factor_batch is not None or residual_batch is None:
            raise ValueError("Only measured residual replay can train this learner; probes cannot train")
        with self.lock:
            return dict(residual=self.residual.update(residual_batch))

    def save(self, path, bindings):
        if self.probe_only:
            raise ValueError("Diagnostic probes cannot be saved as trained policies")
        validate_bindings(bindings)
        with self.lock:
            execution = getattr(self, "execution", None)
            atomic_save(dict(format="ie2vla_no_speed_residual_sac_v2" if execution else "ie2vla_no_speed_residual_sac_v1",
                semantics=saved_semantics(SEMANTICS, execution), execution=execution,
                config=self.config.asdict(), bindings=bindings, residual=self.residual.state_dict(),
                rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all()
                if torch.cuda.is_available() else None), path)

    @classmethod
    def load(cls, path, device="cpu", bindings=None, restore_rng=False):
        saved = torch.load(path, map_location=device, weights_only=False)
        execution = saved.get("execution")
        expected_format = "ie2vla_no_speed_residual_sac_v2" if execution else "ie2vla_no_speed_residual_sac_v1"
        if (saved.get("format") != expected_format or saved.get("semantics") != saved_semantics(SEMANTICS, execution)
                or (bindings is not None and saved["bindings"] != bindings)):
            raise ValueError("Residual-only format/semantics/base/token/reward mismatch")
        validate_bindings(saved["bindings"])
        result = cls(SACConfig(**saved["config"]), device)
        result.residual.load_state_dict(saved["residual"])
        result.execution = execution
        if restore_rng:
            torch.set_rng_state(saved["rng"].cpu())
            if torch.cuda.is_available() and saved["cuda_rng"] is not None:
                torch.cuda.set_rng_state_all([x.cpu() for x in saved["cuda_rng"]])
        return result


def save_replay(path, buffers, bindings, *, execution=None, quality=None):
    validate_bindings(bindings)
    if set(buffers) != {"residual"}:
        raise ValueError("Expected residual replay only")
    atomic_save(dict(format="ie2vla_no_speed_residual_replay_v2" if execution else "ie2vla_no_speed_residual_replay_v1",
        semantics=saved_semantics(SEMANTICS, execution), execution=execution, quality=quality or [],
        config=buffers["residual"].config.asdict(), bindings=bindings,
        rows=buffers["residual"].snapshot()), path)


def load_replay(path, config, bindings):
    saved = torch.load(path, map_location="cpu", weights_only=False)
    validate_bindings(bindings)
    execution = saved.get("execution")
    expected_format = "ie2vla_no_speed_residual_replay_v2" if execution else "ie2vla_no_speed_residual_replay_v1"
    if (saved.get("format") != expected_format or saved.get("semantics") != saved_semantics(SEMANTICS, execution)
            or saved["config"] != config.asdict() or saved["bindings"] != bindings):
        raise ValueError("Residual-only replay mismatch")
    buffer = ReplayBuffer(config, "residual", max(1, len(saved["rows"])))
    buffer.execution = execution or ExecutionConfig.legacy().asdict()
    buffer.quality = saved.get("quality", [])
    if execution and len(buffer.quality) != len(saved["rows"]):
        raise ValueError("Replay quality metadata is incomplete")
    for row, meta in saved["rows"]:
        if meta["versions"]["factor"] != 0:
            raise ValueError("Factor policy must be disabled")
        buffer.add(row, **meta)
    return {"residual": buffer}
