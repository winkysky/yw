"""Export reviewed ORIGINAL rows to the 98/iE2VLA3 handoff contract.

Standard library only. Source data is opened only for reading. No interpolation,
numeric repair, Parquet writing, video cutting, or frame renumbering is used.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import io
import json
import zipfile

HERE = Path(__file__).resolve().parent


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def safe_source(root, name):
    path = (root / name).resolve()
    require(path.is_relative_to(root), '来源路径越出数据目录')
    return path


def source_files(contract, dataset_root):
    for d in contract['datasets']:
        root = safe_source(dataset_root, d['name'])
        for rel, expected in d['metadata_files'].items():
            yield safe_source(root, rel), expected
        for e in d['episodes']:
            yield safe_source(root, e['parquet_path']), e['parquet_sha256']
            for media in e['media'].values():
                yield safe_source(root, media['path']), media['sha256']


def validate_sources(contract, dataset_root):
    require(contract.get('scan_status') == 'complete', '缺少完整的来源只读检查')
    stamps = {}
    for path, expected in source_files(contract, dataset_root):
        before = path.stat()
        require(sha(path) == expected, '源文件与审核版本不一致：' + str(path))
        after = path.stat()
        stamp = (after.st_size, after.st_mtime_ns)
        require(stamp == (before.st_size, before.st_mtime_ns), '源文件在校验期间发生变化')
        stamps[path] = stamp
    return stamps


def review_records(review, contract):
    require(review.get('schemaVersion') == 1 and review.get('datasetId') == contract['dataset_id'], '审核 JSON 不属于当前数据集')
    expected = {e['id']: e for d in contract['datasets'] for e in d['episodes']}
    rows = review.get('episodes')
    require(isinstance(rows, list) and len(rows) == len(expected), '必须包含全部轨迹的审核状态')
    result = {}
    for r in rows:
        key = r.get('id')
        require(key in expected and key not in result, '未知或重复轨迹编号')
        e = expected[key]
        require(r.get('frames') == e['frames'] and r.get('sourceSHA256') == e['parquet_sha256'], '审核帧数或源文件指纹不匹配：' + key)
        require(r.get('status') in ('pending', 'approved', 'rejected'), '审核状态无效')
        items = r.get('proposedIntervals')
        require(isinstance(items, list), '缺少审核区间')
        last = 0
        for item in items:
            a, b = item.get('start'), item.get('end')
            require(type(a) is int and type(b) is int and last <= a < b <= e['frames'], '区间重叠、越界或非整数：' + key)
            require(item.get('kind') in ('transient', 'wait', 'manual'), '未知区间类型')
            last = b
        result[key] = r
    return result


def intervals_from_steps(steps):
    result = []
    for i in sorted(steps):
        if result and result[-1][1] == i:
            result[-1][1] = i + 1
        else:
            result.append([i, i + 1])
    return result


def build_bundle(review, dataset_root, export_root=None):
    """Return filename->bytes. Does not write files, even for HTTP export."""
    contract = json.loads((HERE / 'source_contract.json').read_text(encoding='utf-8'))
    records = review_records(review, contract)
    dataset_root = Path(dataset_root).expanduser().resolve(strict=True)
    stamps = validate_sources(contract, dataset_root)
    files = {}
    def put(name, value): files[name] = encoded(value)
    def lines(name, values):
        files[name] = ''.join(json.dumps(v, ensure_ascii=False, allow_nan=False) + '\n' for v in values).encode('utf-8')
    def file_sha(name): return hashlib.sha256(files[name]).hexdigest()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    revision = 'dagger_human_review_' + stamp
    binding = {'schema_version': 'lerobot_human_review_v1', 'root': str(dataset_root),
               'datasets': {d['dataset_id']: d['metadata_sha256'] for d in contract['datasets']},
               'baseline_inputs': {}, 'scope': 'selected_all_datasets'}
    summary = {'datasets': len(contract['datasets']), 'episodes': len(records), 'pending': 0,
               'kept_episodes': 0, 'excluded_episodes': 0, 'training_segments': 0,
               'retained_transitions': 0, 'unlabeled_retained_frames': 0, 'baseline_complete': True,
               'baseline_scope': 'dagger_source_integrity_and_full_video_decode',
               'baseline_checks': contract['checks'], 'filtered_values': 0, 'smoothing': False,
               'gripper_modified': False, 'selection': 'all_split_only', 'scope': 'selected_datasets',
               'selected_datasets': [d['name'] for d in contract['datasets']], 'duplicate_candidates': []}
    annotations, segments, sources, source_hashes = [], [], [], {}
    excluded_count = 0
    for d in contract['datasets']:
        ds = d['dataset_id']; source_root = safe_source(dataset_root, d['name']); decisions = []
        for e in d['episodes']:
            r = records[e['id']]; n = e['frames']; idx = e['episode_index']
            # 'rejected' means reject the proposed deletion, NOT exclude episode.
            proposed = r['proposedIntervals'] if r['status'] == 'approved' else []
            manual = [{'start_frame': x['start'], 'stop_frame': x['end'],
                       'reason': str(x.get('reason') or x.get('label') or '人工审核排除')} for x in proposed]
            cuts = {i for x in proposed for i in range(x['start'], x['end'])}
            decision = 'pending' if r['status'] == 'pending' else ('exclude' if len(cuts) == n else 'keep')
            excluded = set(range(n)) if decision != 'keep' else cuts
            kept = intervals_from_steps(set(range(n)) - excluded)
            instruction = e['instruction'].strip()
            require(instruction or decision != 'keep', '源任务文本为空，不能导出训练片段')
            views = [{'start_frame': a, 'stop_frame': b, 'task_name': d['name'].split('/')[0], 'instruction': instruction} for a, b in kept]
            media = {k: m['sha256'] for k, m in e['media'].items()}
            note = str(r.get('note') or ('人工确认排除整条轨迹' if decision == 'exclude' else ''))
            ann = {'dataset_id': ds, 'dataset_name': d['name'], 'episode_index': idx, 'revision': 1,
                   'decision': decision, 'task_name': d['name'].split('/')[0], 'instruction': instruction,
                   'segments': views, 'excluded_intervals': manual, 'restored_intervals': [], 'note': note,
                   'trim_start_frame': 0, 'trim_stop_frame': n, 'trim_reason': '', 'boundary_reviewed': False,
                   'automatic_reviews': [], 'manual_corrections': [], 'parquet_sha256': e['parquet_sha256'],
                   'media_sha256': media, 'updated_at': r.get('updatedAt'), 'dagger_review_status': r['status']}
            annotations.append(ann)
            summary[{'pending': 'pending', 'keep': 'kept_episodes', 'exclude': 'excluded_episodes'}[decision]] += 1
            summary['retained_transitions'] += n - len(excluded)
            excluded_count += len(excluded)
            parquet = safe_source(source_root, e['parquet_path'])
            source_hashes[str(parquet)] = e['parquet_sha256']
            decisions.append({'episode_index': idx, 'parquet_sha256': e['parquet_sha256'], 'media_sha256': media,
                              'excluded_steps': sorted(excluded), 'kept_steps': n - len(excluded), 'quarantine': len(excluded) == n,
                              'invalid_intervals': intervals_from_steps(excluded), 'original_invalid_steps': [], 'restored_steps': [],
                              'non_restorable_steps': [], 'action_relation': 'unknown', 'manual_reason': note,
                              'human_decision': decision, 'manual_excluded_intervals': manual, 'manual_restored_intervals': [],
                              'manual_trim': {'start_frame': 0, 'stop_frame': n, 'reason': ''},
                              'manual_boundary_override_intervals': [], 'ignored_new_settling_intervals': [],
                              'automatic_reviews': [], 'manual_corrections': [], 'automatic_baseline_evidence': {},
                              'dagger_review_status': r['status']})
            for i, v in enumerate(views):
                segments.append({**v, 'segment_id': f'{ds}:{idx}:{i}', 'dataset_id': ds, 'dataset_name': d['name'],
                                 'source_root': str(source_root), 'episode_index': idx, 'parquet_path': e['parquet_path'],
                                 'parquet_sha256': e['parquet_sha256'], 'metadata_sha256': d['metadata_sha256'],
                                 'media_sha256': media, 'action_relation': 'unknown', 'split_group': e['parquet_sha256'],
                                 'excluded_intervals': [], 'task_id': 'task_' + digest(['instruction', instruction])[:16],
                                 'usable_frames': v['stop_frame'] - v['start_frame'],
                                 'boundary_policy': 'all_accessed_rows_within_segment_and_valid',
                                 'episode_task': {'name': ann['task_name'], 'instruction': instruction}})
        prefix = 'raw/sources/' + ds + '/'
        lines(prefix + 'cleaning_decisions.jsonl', decisions)
        put(prefix + 'robotmanip_exclusions.json', {
            'excluded_episodes': [r['episode_index'] for r in decisions if r['quarantine']],
            'excluded_steps': {str(r['episode_index']): r['excluded_steps'] for r in decisions if r['excluded_steps'] and not r['quarantine']}})
        sources.append({'group': ds, 'root': str(source_root), 'episode_count': len(decisions), 'metadata_sha256': d['metadata_sha256'],
                        'decisions': f'sources/{ds}/cleaning_decisions.jsonl', 'exclusions': f'sources/{ds}/robotmanip_exclusions.json',
                        'decisions_sha256': file_sha(prefix + 'cleaning_decisions.jsonl'),
                        'exclusions_sha256': file_sha(prefix + 'robotmanip_exclusions.json')})
    status = 'pilot' if summary['pending'] else 'complete'
    summary.update(status=status, training_segments=len(segments))
    put('raw/cleaning_manifest.json', {'schema_version': 'lerobot_grouped_cleaning_view_v1', 'status': status, 'revision': revision,
        'source_root': str(dataset_root), 'sources': sources, 'retained_transitions': summary['retained_transitions'],
        'excluded_transitions': excluded_count, 'raw_data_mutated': False, 'overrides_source_transition_valid': True,
        'excluded_source_groups': [], 'human_review': True, 'decision_authority': 'human_review',
        'automatic_policy_calibrated': False, 'geometric_calibration_validated': False,
        'consumption': 'Use final exclusions on original rows; never bridge task segment boundaries.',
        'baseline_scope': summary['baseline_scope']})
    lines('task_segments.jsonl', segments)
    lines('human_annotations.jsonl', annotations)
    put('task_manifest.json', {'schema_version': 'lerobot_task_view_v1', 'status': status,
        'segments': 'task_segments.jsonl', 'segments_sha256': file_sha('task_segments.jsonl'),
        'task_identity': 'trimmed_instruction_v1', 'source_binding': binding,
        'split_policy': 'Group all segments and duplicate trajectories by split_group before train/validation splitting',
        'sampling_policy': 'Never bridge excluded rows or sample an action chunk beyond stop_frame'})
    put('summary.json', summary)
    put('latest_results.json', {'revision': revision, 'task_view': 'task_manifest.json', 'review_summary': 'summary.json',
                                'raw_manifest': 'raw/cleaning_manifest.json'})
    put('review.json', review)
    files['source_contract.json'] = (HERE / 'source_contract.json').read_bytes()
    for name in ['read_training.py', 'export_98.py', 'data_config.template.json', '98格式使用说明.txt']:
        files[name] = (HERE / name).read_bytes()
    for path in (HERE / 'training_runtime').rglob('*.py'):
        files[path.relative_to(HERE).as_posix()] = path.read_bytes()
    files['filtered_data/README.txt'] = b'Compatibility entry directory for iE2VLA3. No numeric copies: task_segments.jsonl binds original Parquet files.\n'
    if export_root is not None:
        config = json.loads(files['data_config.template.json'])
        config['root'] = str(Path(export_root).resolve() / 'filtered_data')
        put('data_config.json', config)
    put('run_manifest.json', {'schema_version': 'lerobot_human_review_v1', 'raw_data_mutated': False,
        'binding': binding, 'source_parquet_sha256': source_hashes, 'artifacts_sha256': {name: file_sha(name) for name in files},
        'producer': 'dagger_local_review_98_export_v1', 'smoothing': False, 'gripper_modified': False})
    for path, stamp_before in stamps.items():
        stat = path.stat()
        require((stat.st_size, stat.st_mtime_ns) == stamp_before, '导出期间源文件发生变化：' + str(path))
    return files, summary


def bundle_zip(review, dataset_root):
    files, summary = build_bundle(review, dataset_root)
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name, content in files.items():
            z.writestr(name, content)
    return stream.getvalue(), summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review', type=Path, default=HERE / 'review.json')
    parser.add_argument('--dataset-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True, help='A new output directory outside the source dataset')
    args = parser.parse_args()
    source = args.dataset_root.expanduser().resolve(strict=True)
    output = args.output.expanduser().resolve()
    require(not output.exists(), '输出目录已存在，请选择新目录以保留历史导出')
    require(not output.is_relative_to(source) and not source.is_relative_to(output), '输出目录必须独立于原始数据目录')
    review = json.loads(args.review.read_text(encoding='utf-8-sig'))
    files, summary = build_bundle(review, source, output)
    output.mkdir(parents=True, exist_ok=False)
    for name, data in files.items():
        dest = output / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    print(json.dumps({'output': str(output), 'data_config': str(output / 'data_config.json'), 'summary': summary}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
