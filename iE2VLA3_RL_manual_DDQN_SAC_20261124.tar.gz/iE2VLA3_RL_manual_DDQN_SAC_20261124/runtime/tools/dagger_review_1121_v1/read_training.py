"""Load only confirmed training segments from this review handoff.

The full snapshot can be pilot because other episodes remain pending. This
entry point explicitly accepts that case only with a complete technical baseline
and verifies that every exported segment belongs to a saved keep decision.
"""

from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "training_runtime"))

from data_cleaner.data_processing.lerobot_review import (  # noqa: E402
    inside, read_json, read_jsonl, sha256,
)
from data_cleaner.data_processing.task_view import (  # noqa: E402
    load_task_view, sample_rows_valid,
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_reviewed_segments(export_dir=HERE):
    """Return validated segments; parquet_path already selects corrected data.

    Run once at dataset initialization, before distributing segments to workers.
    Video/Parquet verification can take time. Do not call once per sample.
    """
    root = Path(export_dir).resolve()
    run = read_json(root / "run_manifest.json")
    hashes = run["artifacts_sha256"]
    for name in ("task_manifest.json", "task_segments.jsonl",
                 "human_annotations.jsonl", "summary.json"):
        require(name in hashes, "Missing snapshot binding: " + name)
    for name, expected in hashes.items():
        require(sha256(inside(root, name)) == expected,
                "Snapshot checksum mismatch: " + name)
    summary = read_json(root / "summary.json")
    manifest = read_json(root / "task_manifest.json")
    require(summary["baseline_complete"] is True,
            "A complete technical cleaning baseline is required")
    require(manifest["status"] == summary["status"]
            and manifest["status"] in {"pilot", "complete"},
            "Unexpected snapshot status")
    annotations = read_jsonl(root / "human_annotations.jsonl")
    reviews = {(r["dataset_id"], r["episode_index"]): r for r in annotations}
    require(len(reviews) == len(annotations) == summary["episodes"],
            "Duplicate/missing review records")
    for decision, field in (("keep", "kept_episodes"), ("exclude", "excluded_episodes"),
                            ("pending", "pending")):
        require(sum(r["decision"] == decision for r in annotations) == summary[field],
                "Review count mismatch: " + decision)
    raw_segments = read_jsonl(inside(root, manifest["segments"]))
    require(len(raw_segments) == summary["training_segments"] and raw_segments,
            "Missing or empty training segments")
    seen = set()
    for segment in raw_segments:
        review = reviews[(segment["dataset_id"], segment["episode_index"])]
        require(review["decision"] == "keep", "Unconfirmed episode in training")
        require(segment["segment_id"] not in seen, "Duplicate segment")
        seen.add(segment["segment_id"])
        require(segment["parquet_sha256"] == review["parquet_sha256"]
                and segment["split_group"] == review["parquet_sha256"],
                "Source/split group mismatch")
        views = review["segments"] or [{
            "start_frame": review["trim_start_frame"],
            "stop_frame": review["trim_stop_frame"],
            "instruction": review["instruction"],
        }]
        require(any(
            segment["start_frame"] == max(v["start_frame"], review["trim_start_frame"])
            and segment["stop_frame"] == min(v["stop_frame"], review["trim_stop_frame"])
            and segment["instruction"] == v["instruction"]
            for v in views
        ), "Segment bounds/prompt differ from the confirmed task/subtask")
        require(bool(segment["instruction"].strip()) and segment["usable_frames"] > 0,
                "Empty task prompt or segment")
    # Intentional, guarded partial-review consumption: pending/excluded episodes
    # were checked above and cannot enter this training list. Keep status=pilot.
    return load_task_view(root / "task_manifest.json", allow_pilot=True)


def valid_windows(segment, history=1, horizon=16):
    """Example: history ends at t; action chunk starts at t, no padding.

    Use your model's real offsets instead if its alignment differs. All accessed
    rows, including interpolation support, must go to sample_rows_valid.
    """
    require(type(history) is int and history > 0, "history must be positive")
    require(type(horizon) is int and horizon > 0, "horizon must be positive")
    for t in range(segment["start_frame"], segment["stop_frame"]):
        observation_rows = list(range(t - history + 1, t + 1))
        action_rows = list(range(t, t + horizon))
        if sample_rows_valid(segment, observation_rows, action_rows):
            yield observation_rows, action_rows


if __name__ == "__main__":
    segments = load_reviewed_segments()
    print(json.dumps({
        "training_episodes": len({(s["dataset_id"], s["episode_index"]) for s in segments}),
        "training_segments": len(segments),
        "usable_frames_before_window_sampling": sum(s["usable_frames"] for s in segments),
        "prompts": sorted({s["instruction"] for s in segments}),
    }, ensure_ascii=False, indent=2))
