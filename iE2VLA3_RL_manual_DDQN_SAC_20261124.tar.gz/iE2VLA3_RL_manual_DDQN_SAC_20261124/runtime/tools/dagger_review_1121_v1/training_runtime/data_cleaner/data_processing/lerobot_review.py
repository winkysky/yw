"""Local LeRobot task annotation and human quality review, without source edits."""

import argparse
from collections import defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import tempfile
import threading


SCHEMA = "lerobot_human_review_v1"
GROUP_SCHEMA = "lerobot_grouped_cleaning_view_v1"


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    with Path(path).open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def digest_json(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def inside(root, relative):
    path = (Path(root) / relative).resolve()
    try:
        path.relative_to(Path(root).resolve())
    except ValueError:
        raise ValueError("文件路径越出数据集目录") from None
    return path


def safe_output(path, protected):
    path = Path(path).expanduser().resolve()
    for root in protected:
        root = Path(root).resolve()
        if path == root or root in path.parents or path in root.parents:
            raise ValueError("输出必须独立于原始数据和输入清单目录")
    return path


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def ranges(indices):
    result = []
    for value in sorted(set(indices)):
        if result and result[-1][1] == value:
            result[-1][1] += 1
        else:
            result.append([value, value + 1])
    return result


def expand(intervals):
    return {i for interval in intervals for i in range(interval["start_frame"], interval["stop_frame"])}


EDGE_EXCLUSION_RULES = frozenset({"huawei_boundary", "huawei_settling"})
SLOWDOWN_RULE_VERSION = "huawei_settling_slowdown_v21"
SLOWDOWN_CUTOVER_KEY = "huawei_settling_slowdown_v21_cutover"


def is_new_slowdown_card(card):
    """Recognize the newer edge detector in current and earlier v21 reports."""
    return card['rule']=='huawei_settling' and any(
        item.get('detection')=='slowdown' or 'weak_force_events' in item
        for item in card.get('details', []))


def effective_row_exclusions(prior, review, n, *, human_boundary_priority=False, ignore_new_slowdown=False):
    """Combine rule-level exclusions and explicit human decisions on original rows."""
    from .review_reasons import decision_cards
    old_excluded = set(prior.get("excluded_steps", [])) if prior else set()
    cards = decision_cards(prior)
    revoked = {item['id'] for item in review['automatic_reviews'] if item['decision'] == 'restore'}
    trim_start, trim_stop = review['trim_start_frame'], review['trim_stop_frame']
    boundary_range = set(range(trim_start, trim_stop)) if human_boundary_priority else set()
    covered, still_active, boundary_override, ignored_slowdown = set(), set(), set(), set()
    for card in cards:
        if not card['applied'] or card.get('operation') in {'hold_previous', 'hold_mode'}:
            continue
        rows = set(range(card['start_frame'], card['stop_frame']))
        covered |= rows
        if card['id'] in revoked:
            continue
        if ignore_new_slowdown and review['decision']=='keep' and is_new_slowdown_card(card):
            previous = {i for detail in card.get('details', [])
                        for start, stop in detail.get('previous_edge_intervals', []) for i in range(start, stop)}
            ignored_slowdown |= rows - previous
            rows &= previous
        if card['rule'] in EDGE_EXCLUSION_RULES:
            boundary_override |= rows & boundary_range
            rows -= boundary_range
        still_active |= rows
    # Unknown inherited exclusions and integrity errors are never implicitly
    # overridden by a manual boundary.
    still_active |= old_excluded - covered
    still_active |= set((prior or {}).get('non_restorable_steps', []))
    manual_excluded = expand(review['excluded_intervals'])
    unscoped = expand([item for item in review['restored_intervals'] if not item.get('automatic_id')])
    scoped = expand([item for item in review['restored_intervals'] if item.get('automatic_id')])
    boundary_override = (boundary_override - still_active - manual_excluded) & old_excluded
    ignored_slowdown = (ignored_slowdown - still_active) & old_excluded
    restored = (unscoped | (scoped - still_active) | boundary_override | ignored_slowdown) & old_excluded
    excluded = (old_excluded - restored) | manual_excluded
    trimmed = set(range(trim_start)) | set(range(trim_stop, n))
    excluded |= trimmed
    restored -= trimmed | manual_excluded
    boundary_override -= trimmed | manual_excluded
    if review['decision'] != 'keep':
        return old_excluded, set(range(n)), set(), set(), set()
    return old_excluded, excluded, restored, boundary_override, ignored_slowdown


def discover(root, success_only=False):
    """Find nested v2 datasets, recording discovery failures rather than hiding them."""
    root = Path(root).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise ValueError("扫描根目录不是文件夹")
    datasets, errors = {}, []
    def walk_error(error):
        errors.append({"path": str(error.filename), "error": str(error)})
    for directory, subdirs, files in os.walk(root, onerror=walk_error):
        subdirs[:] = sorted(d for d in subdirs if d not in {".git", "__pycache__"}
                            and not (success_only and d.lower() == "all"))
        if Path(directory).name != "meta" or "info.json" not in files:
            continue
        dataset_root = Path(directory).parent.resolve()
        name = dataset_root.relative_to(root).as_posix()
        if name == ".":
            name = root.name
        if success_only and "all" in {part.lower() for part in Path(name).parts}:
            continue
        try:
            info_path, episodes_path = Path(directory) / "info.json", Path(directory) / "episodes.jsonl"
            info, episodes = read_json(info_path), read_jsonl(episodes_path)
            if not str(info.get("codebase_version", "")).startswith("v2"):
                raise ValueError("目前仅支持 LeRobot v2 按 episode 存储的布局")
            ids = [e["episode_index"] for e in episodes]
            if (len(ids) != len(set(ids)) or len(episodes) != info["total_episodes"]
                    or any(type(i) is not int or i < 0 for i in ids)
                    or any(type(e["length"]) is not int or e["length"] < 1 for e in episodes)):
                raise ValueError("episode 清单重复、长度无效或数量不符")
            if sum(e["length"] for e in episodes) != info["total_frames"] or info["fps"] <= 0:
                raise ValueError("总帧数或采样率不符")
            if success_only and "success" not in {part.lower() for part in Path(name).parts}:
                successful = [e.get("is_success") == 1 for e in episodes]
                if any(successful) and not all(successful):
                    raise ValueError("散装目录混合成功与失败轨迹，需先建立 episode 级成功样本选择清单")
                if not all(successful):
                    continue
            dataset_id = "ds_" + hashlib.sha256(name.encode()).hexdigest()[:16]
            metadata_sha = digest_json({"info": sha256(info_path), "episodes": sha256(episodes_path)})
            datasets[dataset_id] = {
                "id": dataset_id, "name": name, "root": str(dataset_root), "info": info,
                "episodes": {e["episode_index"]: e for e in episodes}, "metadata_sha256": metadata_sha,
                "cameras": [k for k, v in info.get("features", {}).items() if v.get("dtype") == "video"],
            }
        except (ValueError, KeyError, OSError, TypeError) as error:
            errors.append({"path": str(dataset_root), "error": str(error)})
    if not datasets and not errors:
        raise ValueError("没有发现含 meta/info.json 和 meta/episodes.jsonl 的 LeRobot 数据集")
    return root, datasets, errors


class ReviewConflict(ValueError):
    pass


class ReviewStore:
    def __init__(self, root, workspace, cleaning_entry=None, success_only=False):
        self.root, self.datasets, self.discovery_errors = discover(root, success_only)
        self.success_only = success_only
        self.workspace = safe_output(workspace, [self.root])
        self.cleaning_entry = Path(cleaning_entry).expanduser().resolve() if cleaning_entry else None
        self.baseline = {}
        self.baseline_inputs = {}
        self.lock = threading.RLock()
        if self.cleaning_entry:
            safe_output(self.workspace, [self.cleaning_entry.parent])
            self._load_baseline()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.db_path = self.workspace / "review.sqlite3"
        binding = {"schema_version": SCHEMA, "root": str(self.root),
                   "datasets": {key: d["metadata_sha256"] for key, d in self.datasets.items()},
                   "baseline_inputs": self.baseline_inputs}
        if success_only:
            binding["scope"] = "success_only"
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS reviews (dataset TEXT, episode INTEGER, revision INTEGER, "
                       "payload TEXT NOT NULL, PRIMARY KEY(dataset, episode))")
            old = db.execute("SELECT value FROM meta WHERE key='binding'").fetchone()
            if old and json.loads(old[0]) != binding:
                raise ValueError("原始目录、元数据或导入的清洗结果已变化。请使用新的 --workspace，保留旧复核记录。")
            db.execute("INSERT OR IGNORE INTO meta VALUES ('binding', ?)", (json.dumps(binding, sort_keys=True),))
            db.execute("CREATE TABLE IF NOT EXISTS prompt_candidates ("
                       "id INTEGER PRIMARY KEY AUTOINCREMENT, prompt TEXT NOT NULL UNIQUE)")
            db.execute("CREATE TABLE IF NOT EXISTS automatic_rule_exemptions ("
                       "dataset TEXT NOT NULL, episode INTEGER NOT NULL, rule TEXT NOT NULL, "
                       "PRIMARY KEY(dataset, episode, rule))")
            if not db.execute("SELECT 1 FROM meta WHERE key=?", (SLOWDOWN_CUTOVER_KEY,)).fetchone():
                kept = [(dataset, episode, SLOWDOWN_RULE_VERSION) for dataset, episode, payload in
                        db.execute("SELECT dataset, episode, payload FROM reviews")
                        if json.loads(payload).get("decision") == "keep"]
                db.executemany("INSERT OR IGNORE INTO automatic_rule_exemptions VALUES (?, ?, ?)", kept)
                cutover = {"at": datetime.now(timezone.utc).isoformat(), "already_kept": len(kept)}
                db.execute("INSERT INTO meta VALUES (?, ?)", (SLOWDOWN_CUTOVER_KEY, json.dumps(cutover)))
        self.binding = binding

    @contextmanager
    def connect(self):
        db = sqlite3.connect(str(self.db_path), timeout=30)
        try:
            with db:
                yield db
        finally:
            db.close()

    def prompt_candidates(self):
        with self.connect() as db:
            return [{"id": item_id, "prompt": prompt} for item_id, prompt in
                    db.execute("SELECT id, prompt FROM prompt_candidates ORDER BY id")]

    def add_prompt_candidate(self, prompt):
        if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 10000:
            raise ValueError("候选 prompt 不能为空，且不能超过 10000 个字符")
        prompt = prompt.strip()
        with self.lock, self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM prompt_candidates WHERE prompt=?", (prompt,)).fetchone():
                return False
            if db.execute("SELECT COUNT(*) FROM prompt_candidates").fetchone()[0] >= 1000:
                raise ValueError("候选 prompt 最多保存 1000 条")
            db.execute("INSERT INTO prompt_candidates (prompt) VALUES (?)", (prompt,))
        return True

    def remove_prompt_candidate(self, item_id):
        if type(item_id) is not int or item_id < 1:
            raise ValueError("候选 prompt 编号无效")
        with self.lock, self.connect() as db:
            return bool(db.execute("DELETE FROM prompt_candidates WHERE id=?", (item_id,)).rowcount)

    def apply_dataset_prompt(self, dataset_id, episode, expected_revision, prompt):
        """Update only episode-level instructions in one dataset atomically."""
        if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 10000:
            raise ValueError("训练 prompt 不能为空，且不能超过 10000 个字符")
        if type(episode) is not int:
            raise ValueError("episode_index 必须是整数")
        dataset, _ = self.lookup(dataset_id, episode)
        prompt = prompt.strip()
        with self.lock:
            self.check_inputs()
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                stored = {ep: (revision, json.loads(payload)) for ep, revision, payload in db.execute(
                    "SELECT episode, revision, payload FROM reviews WHERE dataset=?", (dataset_id,))}
                current_revision = stored[episode][0] if episode in stored else 0
                if type(expected_revision) is not int or current_revision != expected_revision:
                    raise ReviewConflict("当前轨迹已被其他页面更新，请重新加载后再批量应用")
                updated, current = 0, None
                now = datetime.now(timezone.utc).isoformat()
                for ep in sorted(dataset["episodes"]):
                    revision, record = stored.get(ep, (0, None))
                    record = record if record is not None else self.default_review(dataset_id, ep)
                    if record["instruction"] != prompt:
                        record = {**record, "instruction": prompt, "revision": revision + 1, "updated_at": now}
                        db.execute("INSERT OR REPLACE INTO reviews VALUES (?, ?, ?, ?)",
                                   (dataset_id, ep, record["revision"], json.dumps(record, ensure_ascii=False)))
                        updated += 1
                    if ep == episode:
                        current = record
            return {"updated": updated, "total": len(dataset["episodes"]), "review": current}

    def _load_baseline(self):
        by_root = {Path(d["root"]): key for key, d in self.datasets.items()}
        index = read_json(self.cleaning_entry)
        self.baseline_inputs[str(self.cleaning_entry)] = sha256(self.cleaning_entry)
        found = False
        for key, relative in index.items():
            if not key.endswith("_manifest") or not isinstance(relative, str):
                continue
            corpus = key[:-9]
            if not re.fullmatch(r"[A-Za-z0-9_-]+", corpus):
                raise ValueError("清洗入口的 corpus 名称不安全")
            manifest_path = inside(self.cleaning_entry.parent, relative)
            manifest = read_json(manifest_path)
            self.baseline_inputs[str(manifest_path)] = sha256(manifest_path)
            if manifest.get("schema_version") != GROUP_SCHEMA:
                raise ValueError("导入入口必须使用 LeRobot grouped cleaning view 合同")
            for source in manifest["sources"]:
                dataset_id = by_root.get(Path(source["root"]).resolve())
                if dataset_id is None:
                    continue
                if dataset_id in self.baseline:
                    raise ValueError("清洗入口重复引用同一个数据集")
                if not re.fullmatch(r"[A-Za-z0-9_-]+", source["group"]):
                    raise ValueError("清洗来源 group 名称不安全")
                paths = {field: inside(manifest_path.parent, source[field]) for field in ("decisions", "exclusions")}
                for field, path in paths.items():
                    actual = sha256(path)
                    if actual != source[field + "_sha256"]:
                        raise ValueError("导入清洗决定的哈希不符")
                    self.baseline_inputs[str(path)] = actual
                for relative, expected in source.get("metadata_sha256", {}).items():
                    path = inside(source["root"], relative)
                    if sha256(path) != expected:
                        raise ValueError("数据集元数据与首轮清洗时的版本不同")
                    self.baseline_inputs[str(path)] = expected
                records = read_jsonl(paths["decisions"])
                decisions = {r["episode_index"]: r for r in records}
                exclusions = read_json(paths["exclusions"])
                dataset = self.datasets[dataset_id]
                if (len(decisions) != len(records) or set(decisions) != set(dataset["episodes"])
                        or source["episode_count"] != len(decisions)
                        or set(exclusions["excluded_episodes"]) - set(decisions)
                        or {int(k) for k in exclusions["excluded_steps"]} - set(decisions)):
                    raise ValueError("导入清洗结果未完整覆盖来源的 episode")
                for ep, decision in decisions.items():
                    n = dataset["episodes"][ep]["length"]
                    steps = exclusions["excluded_steps"].get(str(ep), [])
                    if any(type(i) is not int or not 0 <= i < n for i in steps):
                        raise ValueError("导入清洗结果含越界排除位置")
                    expected = set(range(n)) if ep in exclusions["excluded_episodes"] else set(steps)
                    if expected != set(decision["excluded_steps"]):
                        raise ValueError("导入的排除文件与逐段决定不一致")
                    non_restorable = decision.get("non_restorable_steps", [])
                    if (any(type(i) is not int or not 0 <= i < n for i in non_restorable)
                            or not set(non_restorable) <= expected):
                        raise ValueError("不可恢复的完整性错误必须属于基线排除位置")
                    filtered=decision.get('automatic_filtered_parquet')
                    if filtered:
                        copy=inside(manifest_path.parent,filtered['path'])
                        if sha256(copy)!=filtered['sha256']:
                            raise ValueError('自动修正副本哈希不符')
                self.baseline[dataset_id] = {"corpus": corpus, "source": source, "manifest": manifest,
                                             "decisions": decisions}
                found = True
        if not found:
            raise ValueError("清洗入口中没有本次根目录下的数据集")

    def check_inputs(self):
        for path, expected in self.baseline_inputs.items():
            if sha256(path) != expected:
                raise ValueError("导入清洗结果在复核期间发生变化，请使用新的工作目录")
        for dataset in self.datasets.values():
            root = Path(dataset["root"])
            actual = digest_json({"info": sha256(root / "meta/info.json"),
                                  "episodes": sha256(root / "meta/episodes.jsonl")})
            if actual != dataset["metadata_sha256"]:
                raise ValueError("数据集元数据在复核期间发生变化")

    def lookup(self, dataset_id, episode):
        if dataset_id not in self.datasets or episode not in self.datasets[dataset_id]["episodes"]:
            raise ValueError("未知数据集或 episode")
        return self.datasets[dataset_id], self.datasets[dataset_id]["episodes"][episode]

    def parquet_path(self, dataset_id, episode):
        dataset, _ = self.lookup(dataset_id, episode)
        info = dataset["info"]
        relative = info["data_path"].format(episode_chunk=episode // info["chunks_size"], episode_index=episode)
        return inside(dataset["root"], relative)

    def video_path(self, dataset_id, episode, camera):
        dataset, _ = self.lookup(dataset_id, episode)
        if camera not in dataset["cameras"]:
            raise ValueError("未知相机")
        info = dataset["info"]
        relative = info["video_path"].format(episode_chunk=episode // info["chunks_size"],
                                            episode_index=episode, video_key=camera)
        return inside(dataset["root"], relative)

    def _stored(self, dataset_id, episode):
        with self.connect() as db:
            row = db.execute("SELECT payload FROM reviews WHERE dataset=? AND episode=?", (dataset_id, episode)).fetchone()
        return json.loads(row[0]) if row else None

    def baseline_record(self, dataset_id, episode):
        return self.baseline.get(dataset_id, {}).get("decisions", {}).get(episode)

    def baseline_ready(self, dataset_id):
        baseline = self.baseline.get(dataset_id)
        if not baseline:
            return False
        manifest = baseline["manifest"]
        return manifest.get("status") == "complete" or (
            manifest.get("status") == "pilot" and manifest.get("scan_status") == "complete"
            and manifest.get("scan_scope") in {"all_discovered_episodes_and_all_video_frames", "all_selected_success_episodes_and_all_video_frames"}
            and manifest.get("human_acceptance_allowed") is True
            and bool(baseline["source"].get("metadata_sha256")))

    def default_review(self, dataset_id, episode):
        dataset, ep = self.lookup(dataset_id, episode)
        return {"dataset_id": dataset_id, "episode_index": episode, "revision": 0, "decision": "pending",
                "task_name": dataset["name"].split("/")[0], "instruction": " ".join(ep.get("tasks", [])),
                "segments": [], "excluded_intervals": [], "restored_intervals": [], "note": "",
                "trim_start_frame": 0, "trim_stop_frame": ep["length"], "trim_reason": "", "boundary_reviewed": False,
                "automatic_reviews": [],
                "manual_corrections": (self.baseline_record(dataset_id,episode) or {}).get('manual_corrections',[])}

    def review(self, dataset_id, episode):
        self.lookup(dataset_id, episode)
        return self._stored(dataset_id, episode) or self.default_review(dataset_id, episode)

    def new_settling_exempt(self, dataset_id, episode):
        with self.connect() as db:
            return bool(db.execute(
                "SELECT 1 FROM automatic_rule_exemptions WHERE dataset=? AND episode=? AND rule=?",
                (dataset_id, episode, SLOWDOWN_RULE_VERSION)).fetchone())

    def media_hashes(self, dataset_id, episode):
        dataset, _ = self.lookup(dataset_id, episode)
        result = {}
        for camera in dataset["cameras"]:
            path = self.video_path(dataset_id, episode, camera)
            result[camera] = sha256(path) if path.is_file() else None
        return result

    def catalog(self):
        counts = defaultdict(lambda: defaultdict(int))
        with self.connect() as db:
            for dataset_id, payload in db.execute("SELECT dataset, payload FROM reviews"):
                counts[dataset_id][json.loads(payload)["decision"]] += 1
        fingerprints = defaultdict(list)
        for dataset in self.datasets.values():
            fingerprints[dataset["metadata_sha256"]].append(dataset["name"])
        datasets = []
        for dataset in self.datasets.values():
            c = counts[dataset["id"]]
            reviewed = c["keep"] + c["exclude"]
            datasets.append({key: dataset[key] for key in ("id", "name", "metadata_sha256")})
            datasets[-1].update(episodes=len(dataset["episodes"]), frames=dataset["info"]["total_frames"],
                                fps=dataset["info"]["fps"], cameras=len(dataset["cameras"]), reviewed=reviewed,
                                kept=c["keep"], excluded=c["exclude"], pending=len(dataset["episodes"]) - reviewed,
                                has_baseline=dataset["id"] in self.baseline,
                                duplicate_candidates=[name for name in fingerprints[dataset["metadata_sha256"]]
                                                      if name != dataset["name"]])
        return {"schema_version": SCHEMA, "root": str(self.root), "workspace": str(self.workspace),
                "scope": "success_only" if self.success_only else "all_discovered",
                "datasets": datasets, "discovery_errors": self.discovery_errors,
                "cleaning_entry": str(self.cleaning_entry) if self.cleaning_entry else None}

    def episode_list(self, dataset_id):
        if dataset_id not in self.datasets:
            raise ValueError("未知数据集")
        with self.connect() as db:
            stored = {ep: json.loads(payload) for ep, payload in db.execute(
                "SELECT episode, payload FROM reviews WHERE dataset=?", (dataset_id,))}
        result = []
        for ep, metadata in sorted(self.datasets[dataset_id]["episodes"].items()):
            review = stored.get(ep, {})
            baseline = self.baseline_record(dataset_id, ep) or {}
            result.append({"episode_index": ep, "length": metadata["length"],
                           "decision": review.get("decision", "pending"), "revision": review.get("revision", 0),
                           "segments": len(review.get("segments", [])), "baseline_excluded": len(baseline.get("excluded_steps", [])),
                           "baseline_filter_values": sum(d.get('changed_values',d['interval'][1]-d['interval'][0])
                               for d in ([d for role in ('state','action') for d in baseline.get('gripper_spike_check',{}).get(role+'_filter_details',[])]
                                         + baseline.get('gripper_spike_check',{}).get('mode_filter_details',[]))),
                           "baseline_candidate_types": len(baseline.get("review_candidates", {}))})
        return result

    def detail(self, dataset_id, episode):
        from .review_reasons import decision_cards
        dataset, ep = self.lookup(dataset_id, episode)
        path = self.parquet_path(dataset_id, episode)
        actual = sha256(path)
        baseline = self.baseline_record(dataset_id, episode)
        review = self.review(dataset_id, episode)
        if baseline and baseline["parquet_sha256"] != actual:
            raise ValueError("轨迹已不同于自动清洗所使用的版本")
        if review.get("parquet_sha256", actual) != actual:
            raise ValueError("轨迹已不同于人工标注时的版本")
        if "media_sha256" in review and review["media_sha256"] != self.media_hashes(dataset_id, episode):
            raise ValueError("视频已不同于人工标注时的版本")
        if baseline and "media_sha256" in baseline and baseline["media_sha256"] != self.media_hashes(dataset_id, episode):
            raise ValueError("视频已不同于自动清洗时的版本")
        cameras = []
        for camera in dataset["cameras"]:
            media = self.video_path(dataset_id, episode, camera)
            cameras.append({"key": camera, "exists": media.is_file()})
        return {"dataset_id": dataset_id, "dataset_name": dataset["name"], "episode": ep,
                "fps": dataset["info"]["fps"], "cameras": cameras, "review": review,
                "baseline": {"present": baseline is not None,
                             "new_settling_exempt": self.new_settling_exempt(dataset_id, episode),
                             "excluded_intervals": ranges(baseline.get("excluded_steps", [])) if baseline else [],
                             "rule_exclusions": baseline.get("rule_exclusions", {}) if baseline else {},
                             "review_candidates": baseline.get("review_candidates", {}) if baseline else {},
                             "action_relation": baseline.get("action_relation", "unknown") if baseline else "unknown",
                             "check_status": baseline.get("check_status", {}) if baseline else {},
                             "boundary": baseline.get("boundary", {}) if baseline else {},
                             "decisions": decision_cards(baseline),
                             "issues": baseline.get("issues", []) if baseline else [],
                             "non_restorable_intervals": ranges(baseline.get("non_restorable_steps", [])) if baseline else [],
                             "ready_for_human_acceptance": self.baseline_ready(dataset_id),
                             "quarantine": baseline.get("quarantine", False) if baseline else False}}

    def signals(self, dataset_id, episode):
        import pyarrow.parquet as pq
        from .review_signals import signal_payload
        dataset, ep = self.lookup(dataset_id, episode)
        path = self.parquet_path(dataset_id, episode)
        names = pq.read_schema(path).names
        fields = [f for f in names if (f=='action' or f.startswith(('observation.', 'state.', 'action.')))
                  and not f.startswith('observation.images.')]
        table = pq.read_table(path, columns=fields)
        if table.num_rows != ep["length"]:
            raise ValueError("Parquet 行数与元数据不一致")
        baseline = self.baseline_record(dataset_id, episode) or {}
        if baseline and sha256(path)!=baseline['parquet_sha256']:
            raise ValueError('信号数据已不同于自动清洗版本')
        force_check = baseline.get('force_check', {})
        from .review_signals import DEFAULT_FORCE_DEADBAND_N, DEFAULT_TORQUE_DEADBAND_NM
        payload = signal_payload(table, dataset['info'],
                                 deadband_n=force_check.get('deadband_n', DEFAULT_FORCE_DEADBAND_N),
                                 torque_deadband_nm=force_check.get('torque_deadband_nm', DEFAULT_TORQUE_DEADBAND_NM))
        payload['highlights'] = baseline.get('signal_highlights', {})
        from .gripper_spikes import active_gripper_filters, apply_gripper_filters, gripper_filter_id
        filters=active_gripper_filters(baseline)
        filtered=apply_gripper_filters(table,filters)
        for channel in payload['channels']:
            for field in ('observation.state','action.joint'):
                patches=[d for d in filters if channel['id'] in d['channels'] and d['field']==field]
                if patches:
                    index=patches[0]['index']
                    channel['traces'].append({'label':patches[0]['role']+' 过滤后','field':field,'index':index,
                        'values':[row[index] for row in filtered[field].to_pylist()],
                        'filter_patches':[{**d,'id':gripper_filter_id(d)} for d in patches]})
        return payload

    def gripper_suggestions(self, dataset_id, episode, start, stop, index, tolerance=20.):
        import pyarrow.parquet as pq
        from .manual_corrections import suggest_mode_corrections
        if type(episode) is not int: raise ValueError('episode_index 必须是整数')
        self.lookup(dataset_id,episode);self.check_inputs()
        path=self.parquet_path(dataset_id,episode);before=sha256(path)
        baseline=self.baseline_record(dataset_id,episode) or {};review=self.review(dataset_id,episode)
        if before!=baseline.get('parquet_sha256',before) or before!=review.get('parquet_sha256',before):
            raise ValueError('原始轨迹已不同于复核版本')
        table=pq.read_table(path)
        # Suggestions are automated too: require the selected arm's interval
        # to stay clear of the same step guard as the cleaning pipeline.
        from .gripper_steps import screen_step_guards, step_guard_mask
        import numpy as np
        valid=np.ones(len(table),bool);valid[baseline.get('non_restorable_steps',[])]=False
        saved_guard=baseline.get('gripper_spike_check',{}).get('step_guard_check',{})
        guard=screen_step_guards(table,valid,saved_guard.get('policy'))
        if guard['status'] not in ('evaluated','disabled'):
            raise ValueError('阶跃保护证据不足，无法生成众数建议')
        if type(start) is int and type(stop) is int and type(index) is int and index in (6,13) and 0<=start<stop<=len(table):
            if step_guard_mask(guard,'left' if index==6 else 'right',len(table))[start:stop].any():
                raise ValueError('所选区间包含夹爪阶跃保护范围，请缩小区间')
        result=suggest_mode_corrections(table,start,stop,index,tolerance,baseline.get('non_restorable_steps',[]))
        if sha256(path)!=before: raise ValueError('轨迹在计算建议期间发生变化')
        return result

    def validate_review(self, dataset_id, episode, payload):
        _, ep = self.lookup(dataset_id, episode)
        if not isinstance(payload, dict):
            raise ValueError("复核记录必须是 JSON 对象")
        decision = payload.get("decision", "pending")
        if decision not in {"pending", "keep", "exclude"}:
            raise ValueError("决定必须是 pending / keep / exclude")
        result = {"dataset_id": dataset_id, "episode_index": episode, "decision": decision}
        start, stop = payload.get('trim_start_frame', 0), payload.get('trim_stop_frame', ep['length'])
        if type(start) is not int or type(stop) is not int or not 0 <= start < stop <= ep['length']:
            raise ValueError('首尾保留区间必须满足 0 ≤ 起始帧 < 结束帧 ≤ 总帧数')
        reason = payload.get('trim_reason', '')
        if not isinstance(reason, str) or len(reason)>10000 or (decision!='exclude' and (start or stop!=ep['length']) and not reason.strip()):
            raise ValueError('手动删减首尾需要填写理由')
        # Historical records did not have an explicit confirmation flag;
        # a changed boundary or a saved reason proves manual boundary review.
        boundary_reviewed=payload.get('boundary_reviewed', False)
        if type(boundary_reviewed) is not bool: raise ValueError('首尾人工复核标记无效')
        boundary_reviewed=boundary_reviewed or bool(start or stop!=ep['length'] or reason.strip())
        result.update(trim_start_frame=start, trim_stop_frame=stop, trim_reason=reason.strip(),
                      boundary_reviewed=boundary_reviewed)
        automatic_reviews = payload.get('automatic_reviews', [])
        if not isinstance(automatic_reviews, list) or len(automatic_reviews)>2000:
            raise ValueError('自动规则复核记录无效')
        result['automatic_reviews'] = []
        seen=set()
        for record in automatic_reviews:
            if (not isinstance(record,dict) or not isinstance(record.get('id'),str) or len(record['id'])>300
                    or record['id'] in seen or record.get('decision') not in {'confirm','restore','accept','dismiss'}
                    or not isinstance(record.get('reason',''),str) or len(record.get('reason',''))>10000):
                raise ValueError('自动规则复核决定无效或重复')
            seen.add(record['id']); result['automatic_reviews'].append({k:record.get(k,'') for k in ('id','decision','reason')})
        for key in ("task_name", "instruction", "note"):
            value = payload.get(key, "")
            if not isinstance(value, str) or len(value) > 10000:
                raise ValueError("任务名称、指令和备注必须是长度有限的文本")
            result[key] = value.strip()
        for key in ("segments", "excluded_intervals", "restored_intervals"):
            records = payload.get(key, [])
            if not isinstance(records, list) or len(records) > 1000:
                raise ValueError("区间列表格式无效或过长")
            result[key] = []
            for record in records:
                if not isinstance(record, dict):
                    raise ValueError("区间必须是 JSON 对象")
                start, stop = record.get("start_frame"), record.get("stop_frame")
                if type(start) is not int or type(stop) is not int or not 0 <= start < stop <= ep["length"]:
                    raise ValueError("区间必须满足 0 ≤ 起始帧 < 结束帧 ≤ 原始总帧数")
                item = {"start_frame": start, "stop_frame": stop}
                required = ("instruction",) if key == "segments" else ("reason",)
                for field in required:
                    value = record.get(field)
                    if not isinstance(value, str) or not value.strip() or len(value) > 10000:
                        raise ValueError("子任务必须填写 prompt；排除或恢复区间必须填写理由")
                    item[field] = value.strip()
                if key == 'segments':
                    name=record.get('task_name','')
                    if not isinstance(name,str) or len(name)>10000:
                        raise ValueError('子任务名称必须是长度有限的文本')
                    item['task_name']=name.strip()
                if key != 'segments' and 'automatic_id' in record:
                    if not isinstance(record['automatic_id'],str) or len(record['automatic_id'])>300:
                        raise ValueError('自动区间引用无效')
                    item['automatic_id']=record['automatic_id']
                result[key].append(item)
            result[key].sort(key=lambda item: (item["start_frame"], item["stop_frame"]))
        if any(a["stop_frame"] > b["start_frame"] for a, b in zip(result["segments"], result["segments"][1:])):
            raise ValueError("同一训练视图内的子任务区间不能重叠")
        if expand(result["excluded_intervals"]) & expand(result["restored_intervals"]):
            raise ValueError("人工排除与人工恢复区间不能重叠")
        if decision == "keep" and not result["segments"] and not result["instruction"]:
            raise ValueError("确认保留前需填写整段任务指令或至少一个子任务")
        if decision == "exclude" and not result["note"]:
            raise ValueError("整段排除需要填写复核备注作为理由")
        if result["restored_intervals"] and not self.baseline_record(dataset_id, episode):
            raise ValueError("没有自动清洗基线，不存在可恢复的清洗排除位置")
        baseline = self.baseline_record(dataset_id, episode) or {}
        from .review_reasons import decision_cards
        cards={c['id']:c for c in decision_cards(baseline)}
        valid_ids=set(cards)
        if any(r['id'] not in valid_ids for r in result['automatic_reviews']):
            raise ValueError('复核记录引用了当前基线中不存在的自动规则区间')
        for key in ('excluded_intervals','restored_intervals'):
            for span in result[key]:
                if 'automatic_id' in span:
                    card=cards.get(span['automatic_id'])
                    if not card or (span['start_frame'],span['stop_frame'])!=(card['start_frame'],card['stop_frame']):
                        raise ValueError('自动规则复核区间与基线不一致')
                    if card.get('operation') in {'hold_previous','hold_mode'}:
                        raise ValueError('过滤撤销使用自动复核决定，不改变行排除区间')
        for item in result['automatic_reviews']:
            card=cards[item['id']]; decision_type=item['decision']
            if (decision_type in {'confirm','restore'}) != card['applied']:
                raise ValueError('自动规则的复核类型与是否已排除不一致')
            if decision_type in {'restore','accept'}:
                key='restored_intervals' if decision_type=='restore' else 'excluded_intervals'
                if card.get('operation') in {'hold_previous','hold_mode'}:
                    if not item['reason'].strip(): raise ValueError('撤销过滤需要填写理由')
                    continue
                if not item['reason'].strip() or not any(s.get('automatic_id')==item['id'] for s in result[key]):
                    raise ValueError('自动规则恢复或候选排除需要对应的带理由区间')
        if expand(result["restored_intervals"]) & set(baseline.get("non_restorable_steps", [])):
            raise ValueError("所选区间含 NaN、时间/行索引或媒体完整性错误；需修复原始数据并重新扫描，不能用人工恢复跳过")
        from .manual_corrections import manual_gripper_filters
        corrections=payload.get('manual_corrections',[])
        if corrections:
            import pyarrow.parquet as pq
            table=pq.read_table(self.parquet_path(dataset_id,episode))
            manual_gripper_filters(table,corrections,baseline.get('non_restorable_steps',[]))
        elif not isinstance(corrections,list): raise ValueError('手动修正必须是列表')
        result['manual_corrections']=[{**c,'reason':c['reason'].strip()} for c in corrections]
        return result

    def save(self, dataset_id, episode, payload, expected_revision):
        with self.lock:
            self.check_inputs()
            current = self.review(dataset_id, episode)
            if type(expected_revision) is not int or current["revision"] != expected_revision:
                raise ReviewConflict("记录已被其他页面更新，请重新加载后再修改")
            record = self.validate_review(dataset_id, episode, payload)
            actual = sha256(self.parquet_path(dataset_id, episode))
            media = self.media_hashes(dataset_id, episode)
            baseline = self.baseline_record(dataset_id, episode)
            if (baseline and baseline["parquet_sha256"] != actual) or current.get("parquet_sha256", actual) != actual:
                raise ValueError("原始轨迹已变化，不能沿用旧复核决定")
            if "media_sha256" in current and current["media_sha256"] != media:
                raise ValueError("原始视频已变化，不能沿用旧复核决定")
            if baseline and "media_sha256" in baseline and baseline["media_sha256"] != media:
                raise ValueError("原始视频已不同于自动清洗时的版本")
            record.update(revision=expected_revision + 1, parquet_sha256=actual,
                          media_sha256=media,
                          updated_at=datetime.now(timezone.utc).isoformat())
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                row = db.execute("SELECT revision FROM reviews WHERE dataset=? AND episode=?", (dataset_id, episode)).fetchone()
                if (row[0] if row else 0) != expected_revision:
                    raise ReviewConflict("记录已更新，请重新加载")
                db.execute("INSERT OR REPLACE INTO reviews VALUES (?, ?, ?, ?)",
                           (dataset_id, episode, record["revision"], json.dumps(record, ensure_ascii=False)))
                if current['decision'] == 'keep' and record['decision'] != 'keep':
                    db.execute("DELETE FROM automatic_rule_exemptions WHERE dataset=? AND episode=? AND rule=?",
                               (dataset_id, episode, SLOWDOWN_RULE_VERSION))
            return record

    def export(self, dataset_ids=None, output=None):
        """Export one frozen snapshot. Unreviewed episodes remain quarantined in pilots."""
        with self.lock:
            return self._export(dataset_ids, output)

    def _export(self, dataset_ids, output):
        import pyarrow.parquet as pq
        self.check_inputs()
        selected = list(self.datasets) if dataset_ids is None else dataset_ids
        if not isinstance(selected, list) or not selected or len(selected) != len(set(selected)) or set(selected) - set(self.datasets):
            raise ValueError("导出范围必须是非空且不重复的数据集列表")
        if self.discovery_errors:
            raise ValueError("扫描发现未能读取的数据集，请先处理错误再导出，避免遗漏数据")
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        protected = [self.root, self.db_path]
        if self.cleaning_entry:
            protected.append(self.cleaning_entry.parent)
        destination = safe_output(output or self.workspace / "exports" / stamp, protected)
        if destination.exists():
            raise ValueError("导出目录必须不存在，历史导出不可覆盖")
        destination.parent.mkdir(parents=True, exist_ok=True)
        staging = Path(tempfile.mkdtemp(prefix=".review-export-", dir=destination.parent))
        summary = {"datasets": len(selected), "episodes": 0, "pending": 0, "kept_episodes": 0,
                   "excluded_episodes": 0, "training_segments": 0, "retained_transitions": 0,
                   "unlabeled_retained_frames": 0, "baseline_complete": True, "filtered_values":0}
        annotations, training, manifests, source_hashes = [], [], {}, {}
        with self.connect() as db:
            db.execute("BEGIN")
            snapshot = {(dataset, episode): json.loads(payload)
                        for dataset, episode, payload in db.execute("SELECT dataset, episode, payload FROM reviews")}
            slowdown_exemptions = {(dataset, episode) for dataset, episode in db.execute(
                "SELECT dataset, episode FROM automatic_rule_exemptions WHERE rule=?", (SLOWDOWN_RULE_VERSION,))}
        try:
            for dataset_id in selected:
                dataset = self.datasets[dataset_id]
                baseline = self.baseline.get(dataset_id)
                corpus = baseline["corpus"] if baseline else "raw"
                group = baseline["source"]["group"] if baseline else dataset_id
                baseline_complete = self.baseline_ready(dataset_id)
                summary["baseline_complete"] &= baseline_complete
                records = []
                for episode, metadata in sorted(dataset["episodes"].items()):
                    n = metadata["length"]
                    review = snapshot.get((dataset_id, episode)) or self.default_review(dataset_id, episode)
                    review = {**self.validate_review(dataset_id, episode, review),
                              **{k: review[k] for k in ("revision", "parquet_sha256", "media_sha256", "updated_at") if k in review}}
                    parquet = self.parquet_path(dataset_id, episode)
                    actual = sha256(parquet)
                    source_hashes[str(parquet)] = actual
                    prior = self.baseline_record(dataset_id, episode)
                    if review.get("parquet_sha256", actual) != actual or (prior and prior["parquet_sha256"] != actual):
                        raise ValueError("导出时发现轨迹不同于复核或清洗基线")
                    if pq.read_metadata(parquet).num_rows != n:
                        raise ValueError("Parquet 行数与 episode 清单不符")
                    if "media_sha256" in review and review["media_sha256"] != self.media_hashes(dataset_id, episode):
                        raise ValueError("导出时发现视频不同于人工复核版本")
                    if prior and "media_sha256" in prior and prior["media_sha256"] != self.media_hashes(dataset_id, episode):
                        raise ValueError("导出时发现视频不同于自动清洗版本")
                    trim_start, trim_stop = review['trim_start_frame'], review['trim_stop_frame']
                    old_excluded, excluded, restored, boundary_override, ignored_slowdown = effective_row_exclusions(
                        prior, review, n, human_boundary_priority=review['decision']=='keep' and review['boundary_reviewed'],
                        ignore_new_slowdown=(dataset_id, episode) in slowdown_exemptions)
                    kept = n - len(excluded)
                    record = {"episode_index": episode, "parquet_sha256": actual,
                              "excluded_steps": sorted(excluded), "kept_steps": kept,
                              "quarantine": kept == 0, "invalid_intervals": ranges(excluded),
                              "original_invalid_steps": sorted(old_excluded), "restored_steps": sorted(restored),
                              "non_restorable_steps": prior.get("non_restorable_steps", []) if prior else [],
                              "action_relation": prior.get("action_relation", "unknown") if prior else "unknown",
                              "manual_reason": review["note"], "human_decision": review["decision"],
                              "manual_excluded_intervals": review["excluded_intervals"],
                              "manual_restored_intervals": review["restored_intervals"],
                              "manual_trim": {"start_frame":trim_start,"stop_frame":trim_stop,"reason":review['trim_reason']},
                              "manual_boundary_override_intervals": ranges(boundary_override),
                              "ignored_new_settling_intervals": ranges(ignored_slowdown),
                              "automatic_reviews":review['automatic_reviews'],
                              "manual_corrections":review['manual_corrections'],
                              "automatic_baseline_evidence": {'rule_exclusions':prior.get('rule_exclusions',{}),
                                  'rule_reports':prior.get('rule_reports',[]),'signal_highlights':prior.get('signal_highlights',{})} if prior else {}}
                    records.append(record)
                    from .gripper_spikes import active_gripper_filters, apply_gripper_filters
                    from .manual_corrections import manual_gripper_filters
                    automatic_filters=active_gripper_filters(prior,review)
                    original_table=pq.read_table(parquet) if automatic_filters or review['manual_corrections'] else None
                    filters=automatic_filters+manual_gripper_filters(original_table,review['manual_corrections'],
                        (prior or {}).get('non_restorable_steps',[]))
                    filtered_reference={}
                    if filters and kept:
                        # A standalone numeric copy keeps original media/metadata
                        # bindings and original split groups; never rewrite source.
                        filtered_table=apply_gripper_filters(original_table,filters)
                        relative_filtered=Path('filtered_data')/dataset_id/f'episode_{episode:06d}.parquet'
                        filtered_path=staging/relative_filtered
                        filtered_path.parent.mkdir(parents=True,exist_ok=True)
                        pq.write_table(filtered_table,filtered_path)
                        filtered_reference={'filtered_parquet':str(relative_filtered),
                            'filtered_parquet_sha256':sha256(filtered_path),'gripper_filters':filters}
                        summary['filtered_values']+=len({(d['field'],d['index'],i) for d in filters for i in range(*d['interval'])})
                    # Preserve correction evidence on re-import, including any
                    # explicit revocations already reflected in the active list.
                    if prior and prior.get('gripper_spike_check'):
                        record['gripper_spike_check']={role+'_filter_details':[d for d in automatic_filters if d['role']==role and d['operation']=='hold_previous']
                                                      for role in ('state','action')}
                        record['gripper_spike_check']['mode_filter_details']=[d for d in automatic_filters if d['operation']=='hold_mode']
                        record['rule_reports']=[{'rule':f'huawei_gripper_{role}_filter',
                            'operation':'hold_previous','applied':True,'intervals':[d['interval'] for d in automatic_filters if d['role']==role and d['operation']=='hold_previous'],
                            'details':[d for d in automatic_filters if d['role']==role and d['operation']=='hold_previous']} for role in ('state','action') if any(d['role']==role and d['operation']=='hold_previous' for d in automatic_filters)]
                        for rule in sorted({d['rule'] for d in automatic_filters if d['operation']=='hold_mode'}):
                            items=[d for d in automatic_filters if d.get('rule')==rule]
                            record['rule_reports'].append({'rule':rule,'operation':'hold_mode','applied':True,
                                                           'intervals':[d['interval'] for d in items],'details':items})
                        if excluded: record['rule_reports'].append({'rule':'baseline_exclusion','applied':True,
                                                                  'intervals':ranges(excluded)})
                    annotations.append({**review, "dataset_name": dataset["name"], "parquet_sha256": actual})
                    summary["episodes"] += 1
                    summary["pending"] += review["decision"] == "pending"
                    summary["kept_episodes"] += review["decision"] == "keep"
                    summary["excluded_episodes"] += review["decision"] == "exclude"
                    summary["retained_transitions"] += kept
                    views = review["segments"] or [{"start_frame": 0, "stop_frame": n,
                                                    "task_name": review["task_name"], "instruction": review["instruction"]}]
                    labeled = set()
                    if review["decision"] == "keep":
                        for i, segment in enumerate(views):
                            start, stop = segment["start_frame"], segment["stop_frame"]
                            start, stop = max(start, trim_start), min(stop, trim_stop)
                            if start>=stop: continue
                            usable = set(range(start, stop)) - excluded
                            labeled |= usable
                            if not usable:
                                continue
                            task_id = "task_" + digest_json(["instruction", segment["instruction"]])[:16]
                            training.append({**filtered_reference,"segment_id": f"{dataset_id}:{episode}:{i}", "dataset_id": dataset_id,
                                             "dataset_name": dataset["name"], "source_root": dataset["root"],
                                             "episode_index": episode, "parquet_path": str(parquet), "parquet_sha256": actual,
                                             "metadata_sha256": dataset["metadata_sha256"],
                                             "media_sha256": review.get("media_sha256", {}),
                                             "action_relation": prior.get("action_relation", "unknown") if prior else "unknown",
                                             "split_group": actual, "start_frame": start, "stop_frame": stop,
                                             "excluded_intervals": ranges(excluded & set(range(start, stop))),
                                             "task_id": task_id, "task_name": segment["task_name"] or segment["instruction"],
                                             "instruction": segment["instruction"], "usable_frames": len(usable),
                                             "boundary_policy": "all_accessed_rows_within_segment_and_valid",
                                             "episode_task": {"name": review["task_name"], "instruction": review["instruction"]}})
                    summary["unlabeled_retained_frames"] += kept - len(labeled)
                relative = Path(corpus) / "sources" / group
                decisions_path = relative / "cleaning_decisions.jsonl"
                exclusions_path = relative / "robotmanip_exclusions.json"
                write_jsonl(staging / decisions_path, records)
                write_json(staging / exclusions_path, {
                    "excluded_episodes": [r["episode_index"] for r in records if r["quarantine"]],
                    "excluded_steps": {str(r["episode_index"]): r["excluded_steps"] for r in records
                                       if r["excluded_steps"] and not r["quarantine"]}})
                source = {"group": group, "root": dataset["root"], "episode_count": len(records),
                          "decisions": str(Path("sources") / group / decisions_path.name),
                          "exclusions": str(Path("sources") / group / exclusions_path.name),
                          "decisions_sha256": sha256(staging / decisions_path),
                          "exclusions_sha256": sha256(staging / exclusions_path)}
                manifest = manifests.setdefault(corpus, {"sources": [], "retained": 0, "excluded": 0})
                if any(s["group"] == group for s in manifest["sources"]):
                    raise ValueError("同一 corpus 中有重复的 source group")
                manifest["sources"].append(source)
                manifest["retained"] += sum(r["kept_steps"] for r in records)
                manifest["excluded"] += sum(len(r["excluded_steps"]) for r in records)
            status = "complete" if summary["pending"] == 0 and summary["baseline_complete"] else "pilot"
            summary.update(status=status, training_segments=len(training),
                           selection="success_only" if self.success_only else "all_discovered",
                           scope="all_discovered_datasets" if set(selected) == set(self.datasets) else "selected_datasets",
                           selected_datasets=[self.datasets[key]["name"] for key in selected],
                           duplicate_candidates=[{"dataset": d["name"], "candidates": d["duplicate_candidates"]}
                                                 for d in self.catalog()["datasets"] if d["id"] in selected and d["duplicate_candidates"]])
            index = {"revision": "human_review_" + stamp, "task_view": "task_manifest.json",
                     "review_summary": "summary.json"}
            for corpus, m in manifests.items():
                relative = Path(corpus) / "cleaning_manifest.json"
                write_json(staging / relative, {"schema_version": GROUP_SCHEMA, "status": status,
                           "revision": index["revision"], "source_root": str(self.root), "sources": m["sources"],
                           "retained_transitions": m["retained"], "excluded_transitions": m["excluded"],
                           "raw_data_mutated": False, "overrides_source_transition_valid": True,
                           "excluded_source_groups": [], "human_review": True,
                           "decision_authority": "human_review", "automatic_policy_calibrated": False,
                           "geometric_calibration_validated": False,
                           "consumption": "Use final exclusions on original rows. Task boundaries remain authoritative."})
                index[corpus + "_manifest"] = str(relative)
            write_jsonl(staging / "task_segments.jsonl", training)
            write_jsonl(staging / "human_annotations.jsonl", annotations)
            write_json(staging / "task_manifest.json", {"schema_version": "lerobot_task_view_v2" if any(s.get('filtered_parquet') for s in training) else "lerobot_task_view_v1", "status": status,
                       "segments": "task_segments.jsonl", "segments_sha256": sha256(staging / "task_segments.jsonl"),
                       "task_identity": "trimmed_instruction_v1",
                       "source_binding": self.binding,
                       "split_policy": "Group all segments and duplicate trajectories by split_group before train/validation splitting",
                       "sampling_policy": "Never bridge excluded rows or sample an action chunk beyond stop_frame"})
            write_json(staging / "summary.json", summary)
            write_json(staging / "latest_results.json", index)
            self.check_inputs()
            for path, expected in source_hashes.items():
                if sha256(path) != expected:
                    raise ValueError("轨迹在导出期间发生变化")
            write_json(staging / "run_manifest.json", {"schema_version": SCHEMA, "raw_data_mutated": False,
                       "binding": self.binding, "source_parquet_sha256": source_hashes,
                       "artifacts_sha256": {str(p.relative_to(staging)): sha256(p) for p in staging.rglob("*") if p.is_file()}})
            staging.rename(destination)
            return {"output_dir": str(destination), "entry": str(destination / "latest_results.json"), "summary": summary}
        except BaseException:
            shutil.rmtree(staging, ignore_errors=True)
            raise


def main(argv=None):
    parser = argparse.ArgumentParser(description="LeRobot 本地任务标注与人工清洗复核")
    parser.add_argument("--root", type=Path, required=True, help="递归扫描的原始数据根目录，只读")
    parser.add_argument("--workspace", type=Path, default=Path("artifacts/lerobot_review"), help="独立保存草稿和导出")
    parser.add_argument("--cleaning-entry", type=Path, help="可选：已有 LeRobot latest_results.json")
    parser.add_argument("--success-only", action="store_true", help="跳过 all，只显示 success 目录或整组标记成功的散装数据")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8767)
    parser.add_argument("--export-only", action="store_true", help="导出已保存的复核记录，不启动网页")
    parser.add_argument("--output-dir", type=Path, help="--export-only 的新输出目录")
    args = parser.parse_args(argv)
    store = ReviewStore(args.root, args.workspace, args.cleaning_entry, args.success_only)
    if args.export_only:
        print(json.dumps(store.export(output=args.output_dir), ensure_ascii=False, indent=2))
        return 0
    from .lerobot_review_server import serve
    # During a local live reload, preserve the existing request token so open
    # tabs can save their in-progress edits before they refresh the UI.
    serve(store, args.host, args.port, mutation_token=os.environ.pop('DATA_CLEANER_REVIEW_RESTART_TOKEN',None))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
