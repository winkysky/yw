"""Consumption helpers for task manifests; training code owns temporal sampling."""

from pathlib import Path

from .lerobot_review import digest_json, inside, read_json, read_jsonl, sha256


def load_task_view(path, allow_pilot=False):
    """Verify a task snapshot and return original-row segments with instructions.

    A training Dataset should call ``sample_rows_valid`` on *every* actual row
    supporting observation and action sampling, including interpolation brackets.
    ``allow_pilot`` is for inspection and smoke tests, not final training.
    """
    path = Path(path).expanduser().resolve()
    manifest = read_json(path)
    if manifest.get("schema_version") not in {"lerobot_task_view_v1","lerobot_task_view_v2"}:
        raise ValueError("不支持的任务清单格式")
    if manifest.get("status") != "complete" and not (allow_pilot and manifest.get("status") == "pilot"):
        raise ValueError("任务清单尚未完成全量复核或缺少完整清洗基线")
    segments_path = inside(path.parent, manifest["segments"])
    if sha256(segments_path) != manifest["segments_sha256"]:
        raise ValueError("任务片段清单哈希不符")
    segments = read_jsonl(segments_path)
    checked_paths, checked_roots, checked_media, checked_filtered = {}, {}, {}, {}
    for segment in segments:
        root = Path(segment["source_root"]).resolve()
        if root not in checked_roots:
            checked_roots[root] = digest_json({"info": sha256(root / "meta/info.json"),
                                              "episodes": sha256(root / "meta/episodes.jsonl")})
        if checked_roots[root] != segment["metadata_sha256"]:
            raise ValueError("数据集元数据与标注版本不同")
        parquet = inside(root, segment["parquet_path"])
        if parquet not in checked_paths:
            checked_paths[parquet] = sha256(parquet)
        if checked_paths[parquet] != segment["parquet_sha256"]:
            raise ValueError("轨迹与标注版本不同")
        if segment.get('filtered_parquet'):
            if manifest['schema_version']!='lerobot_task_view_v2':
                raise ValueError('过滤副本要求 v2 任务清单')
            filtered=inside(path.parent,segment['filtered_parquet'])
            if filtered not in checked_filtered:
                import pyarrow.parquet as pq
                from .gripper_spikes import apply_gripper_filters, filtered_tables_equal
                expected=apply_gripper_filters(pq.read_table(parquet),segment['gripper_filters'])
                if not filtered_tables_equal(expected,pq.read_table(filtered)):
                    raise ValueError('过滤副本与逐分量修复证据不一致')
                checked_filtered[filtered]=(sha256(filtered),parquet,digest_json(segment['gripper_filters']))
            if checked_filtered[filtered]!=(segment['filtered_parquet_sha256'],parquet,digest_json(segment['gripper_filters'])):
                raise ValueError('过滤副本哈希或来源不符')
            segment['source_parquet_path']=segment['parquet_path']
            segment['source_parquet_sha256']=segment['parquet_sha256']
            segment['parquet_path']=str(filtered)
            segment['parquet_sha256']=segment['filtered_parquet_sha256']
        info = read_json(root / "meta/info.json")
        ep = segment["episode_index"]
        for camera, expected in segment.get("media_sha256", {}).items():
            media = inside(root, info["video_path"].format(
                episode_chunk=ep // info["chunks_size"], episode_index=ep, video_key=camera))
            if media not in checked_media:
                checked_media[media] = sha256(media) if media.is_file() else None
            if checked_media[media] != expected:
                raise ValueError("视频与标注版本不同")
    return segments


def sample_rows_valid(segment, observation_rows, action_rows):
    """Reject gaps/boundaries, including the target row of next-state actions.

    Unknown action semantics conservatively require the next row as well. An
    external Dataset may set action_relation='independent' only after validating
    its actual action contract.
    """
    actions = list(action_rows)
    rows = list(observation_rows) + actions
    if segment.get("action_relation", "unknown") != "independent":
        rows += [row + 1 for row in actions]
    if not rows:
        return False
    start, stop = segment["start_frame"], segment["stop_frame"]
    invalid = segment["excluded_intervals"]
    return all(start <= row < stop and not any(a <= row < b for a, b in invalid) for row in rows)
