"""Shared review and immutable-cleaning tools for WAM/VLA corpora.

Imports are lazy because review contracts obtain live adapter types through
the explicit :mod:`data_cleaner.wam` integration boundary. A lightweight
initializer lets the launcher select the host before those types are imported.
"""

__all__ = [
    "DEFAULT_REVIEWER_NAMES",
    "EpisodeReviewContext",
    "Finding",
    "REVIEWERS",
    "ReviewOptions",
    "ReviewResult",
]


def __getattr__(name):
    """Preserve the small convenience API without eager circular imports."""

    if name in {
        "EpisodeReviewContext",
        "Finding",
        "ReviewOptions",
        "ReviewResult",
    }:
        from . import contracts

        return getattr(contracts, name)
    if name in {"DEFAULT_REVIEWER_NAMES", "REVIEWERS"}:
        from . import registry

        return getattr(registry, name)
    raise AttributeError(name)
