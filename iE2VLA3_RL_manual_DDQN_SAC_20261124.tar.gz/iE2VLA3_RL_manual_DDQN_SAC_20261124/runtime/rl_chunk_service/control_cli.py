"""Choose base/speed/full locally without changing any robot-client RPC."""
import argparse
from pathlib import Path
import uuid
from .feedback import append_event


MODES = ("base", "speed", "full")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Running server's --control-file")
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument("--control-mode", choices=MODES)
    choice.add_argument("--interactive", action="store_true", help="1/2/3 + Enter; selection persists")
    parser.add_argument("--epoch", help="Optional current episode from get_status()['rl']['epoch']")
    parser.add_argument("--event-id", help="Reuse only when retrying the exact same command")
    args = parser.parse_args(argv)
    if args.interactive and args.event_id:
        parser.error("Interactive mode generates one event ID per selection")

    def submit(mode):
        event = dict(type="control", mode=mode, event_id=args.event_id or uuid.uuid4().hex)
        if args.epoch is not None:
            event["epoch"] = args.epoch
        append_event(args.output, event)
        print(f"Queued {mode}; check server get_status()['rl']['control'] for adoption.", flush=True)

    if args.control_mode:
        submit(args.control_mode)
        return
    print("1 = base (1x, release residual); 2 = speed (DQN, release residual); "
          "3 = full (DQN + SAC); q = exit this panel (mode stays active).", flush=True)
    while True:
        try:
            value = input("mode> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return
        if value == "q":
            return
        mode = {"1":"base", "2":"speed", "3":"full"}.get(value, value)
        if mode in MODES:
            submit(mode)
        else:
            print("Choose 1/2/3, base/speed/full, or q.", flush=True)


if __name__ == "__main__":
    main()
