"""Four-way Double DQN: online selection, target evaluation, no actor/entropy."""
import copy
from dataclasses import asdict, dataclass
import json
import math
import torch
from torch import nn
from torch.nn import functional as F
from models.speed_factor import FACTORS
from rl_factor_sac.networks import ObservationEncoder, validate_observation
from rl_factor_sac.replay import validate_batch


@dataclass(frozen=True)
class DoubleDQNConfig:
    learning_rate: float = 3e-4
    epsilon_start: float = .2
    epsilon_end: float = .05
    epsilon_decay_updates: int = 10000
    target_update_interval: int = 200

    def __post_init__(self):
        if (not math.isfinite(self.learning_rate) or self.learning_rate <= 0
                or not math.isfinite(self.epsilon_start) or not math.isfinite(self.epsilon_end)
                or not 0 <= self.epsilon_end <= self.epsilon_start <= 1):
            raise ValueError("Invalid Double DQN learning rate/epsilon")
        for name in ("epsilon_decay_updates", "target_update_interval"):
            if type(getattr(self, name)) is not int or getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")

    def asdict(self):
        return asdict(self)

    @classmethod
    def load(cls, path):
        with open(path) as stream:
            return cls(**json.load(stream))


class FactorQNetwork(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.encoder = ObservationEncoder(config)
        self.head = nn.Linear(config.hidden_dim, len(FACTORS))
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)
        with torch.no_grad():
            self.head.bias[FACTORS.index(1.)] = .001  # tiny initial 1x preference

    def forward(self, obs):
        return self.head(self.encoder(obs))


class FactorDecision:
    """Immutable Q snapshot plus an epsilon fixed at the snapshot's version."""
    def __init__(self, online, config, epsilon):
        self.online, self.config, self.epsilon = online, config, epsilon

    @torch.no_grad()
    def act(self, obs, deterministic=False):
        validate_observation(obs, self.config)
        values = self.online(obs)
        if not torch.isfinite(values).all():
            raise FloatingPointError("Nonfinite factor Q values")
        mask = obs["factor_mask"].bool()
        greedy = values.masked_fill(~mask, -torch.inf).argmax(-1, keepdim=True)
        if deterministic or self.epsilon == 0:
            return greedy
        random_action = torch.multinomial(mask.float(), 1)
        explore = torch.rand(greedy.shape, device=values.device) < self.epsilon
        return torch.where(explore, random_action, greedy)


class DoubleDQN:
    def __init__(self, config, device="cpu", factor_config=DoubleDQNConfig()):
        self.config, self.factor_config = config, factor_config
        self.online = FactorQNetwork(config).to(device)
        self.target = copy.deepcopy(self.online).eval().requires_grad_(False)
        self.optimizer = torch.optim.Adam(self.online.parameters(), lr=factor_config.learning_rate)
        self.updates = 0

    @property
    def epsilon(self):
        c = self.factor_config
        fraction = min(1., self.updates/c.epsilon_decay_updates)
        return c.epsilon_start+(c.epsilon_end-c.epsilon_start)*fraction

    def snapshot(self):
        return FactorDecision(copy.deepcopy(self.online).eval().requires_grad_(False), self.config, self.epsilon)

    @torch.no_grad()
    def target_value(self, batch):
        obs = batch["next_obs"]
        # Double DQN chooses with the ONLINE Q network and evaluates that same
        # action with the TARGET network. Never maximize the target network here.
        selection = self.online(obs).masked_fill(~obs["factor_mask"].bool(), -torch.inf)
        action = selection.argmax(-1, keepdim=True)
        value = self.target(obs).gather(1, action)
        bootstrap = torch.where(batch["terminated"].bool(), torch.zeros_like(value), value)
        return batch["reward"]+batch["discount"]*bootstrap

    def update(self, batch):
        validate_batch(batch, self.config, "factor")
        batch = {k:{n:x.detach() for n,x in v.items()} if isinstance(v,dict) else v.detach()
                 for k,v in batch.items()}
        target = self.target_value(batch)
        prediction = self.online(batch["obs"]).gather(1, batch["action"])
        loss = F.smooth_l1_loss(prediction, target)
        if not torch.isfinite(loss):
            raise FloatingPointError("Nonfinite Double DQN loss")
        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(self.online.parameters(), self.config.grad_clip, error_if_nonfinite=True)
        self.optimizer.step()
        self.updates += 1
        if self.updates % self.factor_config.target_update_interval == 0:
            self.target.load_state_dict(self.online.state_dict())
        return dict(q_loss=float(loss.detach()), q_mean=float(prediction.detach().mean()),
                    target_q=float(target.mean()), epsilon=self.epsilon, updates=self.updates)

    def state_dict(self):
        return dict(online=self.online.state_dict(), target=self.target.state_dict(),
                    optimizer=self.optimizer.state_dict(), updates=self.updates)

    def load_state_dict(self, saved):
        if (set(saved) != {"online", "target", "optimizer", "updates"}
                or type(saved["updates"]) is not int or saved["updates"] < 0):
            raise ValueError("Invalid Double DQN state; a discrete SAC checkpoint is not interchangeable")
        self.online.load_state_dict(saved["online"])
        self.target.load_state_dict(saved["target"])
        self.optimizer.load_state_dict(saved["optimizer"])
        self.updates = saved["updates"]
