"""Initialize/train factor Double DQN + residual SAC; never update the VLA."""
from dataclasses import replace
from pathlib import Path
from rl_chunk_service.execution import bind_execution
import json
import torch
from rl_factor_sac.config import SACConfig
from rl_factor_sac.reward import RewardConfig
from rl_factor_sac.train import artifact_bindings, parser
from .artifacts import ChunkDDQNSAC, load_replay
from .double_dqn import DoubleDQNConfig


def main(argv=None):
    p = parser()
    p.description = __doc__
    p.add_argument("--factor-config", type=Path, help="Double DQN configuration JSON; stored in the RL checkpoint")
    args = p.parse_args(argv)
    if min(args.steps, args.batch_size, args.save_every, args.threads) < 1 or args.max_policy_lag < 0:
        raise ValueError("Invalid training counts")
    if args.stage == "init" and (args.resume or args.replay):
        raise ValueError("init creates new chunk learners; use rl for resume/replay")
    if args.stage == "rl" and not args.replay:
        raise ValueError("RL needs actually executed chunk replay")
    if args.output.exists() and any(args.output.iterdir()) and not args.resume:
        raise FileExistsError("Use a new output directory or --resume")
    torch.set_num_threads(args.threads)
    torch.manual_seed(args.seed)
    reward = RewardConfig(**json.loads(args.reward_config.read_text())) if args.reward_config else RewardConfig()
    bindings, token_dim = artifact_bindings(args.base, args.token, reward)
    if args.resume:
        learner = ChunkDDQNSAC.load(args.resume, args.device, bindings, restore_rng=True)
        if args.config and SACConfig.load(args.config) != learner.config:
            raise ValueError("Resume config differs")
        if args.factor_config and DoubleDQNConfig.load(args.factor_config) != learner.factor_config:
            raise ValueError("Resume Double DQN config differs")
    else:
        config = SACConfig.load(args.config) if args.config else replace(SACConfig(), token_dim=token_dim)
        factor_config = DoubleDQNConfig.load(args.factor_config) if args.factor_config else DoubleDQNConfig()
        learner = ChunkDDQNSAC(config, args.device, factor_config)
    if learner.config.token_dim != token_dim:
        raise ValueError("RL/token dimensions differ")
    if args.stage == "init":
        learner.save(args.output/"sac_init.pt", bindings)
        print(json.dumps(dict(status="initialized_only", checkpoint=str(args.output/"sac_init.pt"))), flush=True)
        return
    buffers = load_replay(args.replay, learner.config, bindings)
    bind_execution(learner, buffers["factor"].execution)
    if any(not len(b) for b in buffers.values()):
        raise ValueError("Both branches need completed chunk transitions")
    for step in range(1, args.steps+1):
        batches = {k+"_batch": v.sample(args.batch_size, args.device, learner.versions, args.max_policy_lag)
                   for k, v in buffers.items()}
        metrics = learner.update(**batches)
        if step == 1 or step % 10 == 0:
            print(json.dumps(metrics), flush=True)
        if step % args.save_every == 0 or step == args.steps:
            learner.save(args.output/f"sac_f{learner.factor.updates:06d}_r{learner.residual.updates:06d}.pt", bindings)


if __name__ == "__main__":
    main()
