"""Manual terminal labels or normalized adapter events; never fake execution ACKs."""
import argparse
import json
from pathlib import Path
import time
import uuid
from .feedback import append_event


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--event", help="Normalized JSON from a measured execution adapter")
    p.add_argument("--outcome", choices=["success", "failure"])
    p.add_argument("--chunk-id", help="Optional; otherwise bind to the active episode")
    p.add_argument("--epoch", help="Optional episode ID from get_status, recommended for delayed labels")
    p.add_argument("--event-id", help="Optional idempotency key for retries")
    p.add_argument("--timestamp", type=float)
    p.add_argument("--abort", action="store_true")
    args = p.parse_args(argv)
    if sum((args.event is not None, args.outcome is not None, args.abort)) != 1:
        p.error("Select exactly one of --event, --outcome, --abort")
    event = json.loads(args.event) if args.event else dict(
        type="abort" if args.abort else "outcome", timestamp=time.time() if args.timestamp is None else args.timestamp,
        outcome=args.outcome, chunk_id=args.chunk_id, epoch=args.epoch, event_id=args.event_id or uuid.uuid4().hex)
    append_event(args.output, event)


if __name__ == "__main__":
    main()
