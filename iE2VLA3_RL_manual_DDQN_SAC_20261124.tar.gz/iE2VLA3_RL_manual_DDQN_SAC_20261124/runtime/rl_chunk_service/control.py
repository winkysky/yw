"""Local human selection inbox, separate from measured execution feedback."""
from .feedback import FeedbackReader


class ControlReceiver:
    def __init__(self, service):
        self.service = service

    def handle(self, event):
        return self.service._handle_control(event)

    def fault(self, message):
        # An invalid operator command must not stop inference or the learner.
        session = self.service.policy.session
        with session.lock:
            session.warn("control_rejected", message)


def start_control_reader(path, service):
    # EOF startup prevents old operator commands being replayed after restart.
    return FeedbackReader(path, ControlReceiver(service))
