"""Execution assumptions shared by both RL services; no wire/model changes."""
from dataclasses import asdict, dataclass
import math


@dataclass(frozen=True)
class ExecutionConfig:
    mode: str = "auto"
    clock_mode: str = "receipt"
    chunk_lifetime_s: float = 5.
    missing_wrench: str = "zero"
    fault_policy: str = "warn"
    execute_steps: int = 16
    blend_steps: int = 8

    def __post_init__(self):
        if (self.mode not in ("auto", "explicit") or self.clock_mode not in ("receipt", "shared")
                or self.missing_wrench not in ("zero", "error") or self.fault_policy not in ("warn", "stop")
                or not math.isfinite(self.chunk_lifetime_s) or self.chunk_lifetime_s <= 0
                or type(self.execute_steps) is not int or not 1 <= self.execute_steps <= 32
                or type(self.blend_steps) is not int or not 0 <= self.blend_steps <= self.execute_steps):
            raise ValueError("Invalid execution/clock/lifetime/fusion configuration")

    @classmethod
    def legacy(cls):
        return cls(mode="explicit", clock_mode="shared", chunk_lifetime_s=31/30,
                   missing_wrench="error", fault_policy="stop")

    def asdict(self):
        return asdict(self)


def add_execution_arguments(parser):
    parser.add_argument("--execution-mode", choices=["auto", "explicit"], default="auto")
    parser.add_argument("--clock-mode", choices=["receipt", "shared"], default="receipt")
    parser.add_argument("--chunk-lifetime-s", type=float, default=5.)
    parser.add_argument("--missing-wrench", choices=["zero", "error"], default="zero")
    parser.add_argument("--fault-policy", choices=["warn", "stop"], default="warn")
    parser.add_argument("--execute-steps", type=int, default=16)
    parser.add_argument("--blend-steps", type=int, default=8)


def execution_from_args(args):
    return ExecutionConfig(mode=args.execution_mode, clock_mode=args.clock_mode,
        chunk_lifetime_s=args.chunk_lifetime_s, missing_wrench=args.missing_wrench,
        fault_policy=args.fault_policy, execute_steps=args.execute_steps, blend_steps=args.blend_steps)


def bind_execution(learner, execution):
    """Untrained actors can adopt a contract; trained actors cannot silently mix it."""
    value = execution.asdict() if isinstance(execution, ExecutionConfig) else execution
    ExecutionConfig(**value)
    previous = getattr(learner, "execution", None)
    if previous is None and any(learner.versions.values()):
        previous = ExecutionConfig.legacy().asdict()
    if previous is not None and previous != value:
        raise ValueError("SAC execution semantics differ; initialize a separate learner for this configuration")
    learner.execution = value


def saved_semantics(base, execution):
    if execution is None:
        return dict(base)
    config = ExecutionConfig(**execution)
    return dict(base, feedback="configured_execution_v2", execution=config.asdict(),
                discount="gamma_per_second_to_rpc_delivery_interval" if config.mode == "auto"
                else "gamma_per_second_to_explicit_activation_interval")
