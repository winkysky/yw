"""Unchanged client wire view around factor Double DQN and residual SAC."""
import copy
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
from rl_chunk_service.execution import saved_semantics
from data_utils.tokenize import BatchDataTokenizedVLA
from dataset.lerobot_original import LeRobotOriginalCollator
from e2vla_compat.policy import Policy as WirePolicy
from e2vla_compat.observations import batch_to_samples
from rl_factor_sac.foundation import FrozenFoundation
from rl_factor_sac.reward import RewardConfig
from rl_factor_sac.train import artifact_bindings
from .artifacts import ChunkDDQNSAC, SEMANTICS, ALGORITHMS
from .session import ChunkSession


class Policy(WirePolicy):
    def __init__(self, settings, session, native_info, collator):
        engine = SimpleNamespace(data_config=session.foundation.data_config,
                                 get_policy_info=lambda: copy.deepcopy(native_info))
        super().__init__(settings, engine=engine)
        self.config.validate()
        if self.config.frame_stride != 1 or self.config.action_offset != 0 or self.config.geometry is None:
            raise ValueError("Requires calibrated 32-point factor VLA, action_offset=0, frame_stride=1")
        self.session, self.collator = session, collator
        self.cache = None
        self.last_chunk_id = None
        self.batch_chunk_ids = []

    @classmethod
    def load(cls, settings, token, sac, *, mode="inference", source="robot", journal=None,
             reward=RewardConfig(), execution=None, control_mode=None):
        device = settings.device
        if device == "auto":
            device = "cuda:0" if torch.cuda.is_available() else "cpu"
        bindings, _ = artifact_bindings(settings.checkpoint, token, reward)
        learner = ChunkDDQNSAC.load(sac, device, bindings)
        foundation = FrozenFoundation.load(settings.checkpoint, device, token)
        path = Path(settings.checkpoint)
        path = path/"model.pt" if path.is_dir() else path
        saved = torch.load(path, map_location="cpu", mmap=True, weights_only=False)
        info = {k: saved[k] for k in ("format", "step", "model_config", "data_config", "dataset_fingerprint")}
        info.update(checkpoint=str(path.resolve()), device=str(device), fps=30.)
        session = ChunkSession(foundation, learner, bindings, mode=mode, source=source, journal=journal,
                               execution=execution, control_mode=control_mode)
        return cls(settings, session, info, LeRobotOriginalCollator(foundation.base.vlm.processor))

    def get_info(self):
        result = super().get_info()
        result.update(backend="iE2VLA3_factor_chunk_DDQN_SAC", rl=dict(saved_semantics(SEMANTICS, self.session.execution.asdict()),
            mode=self.session.mode, bindings=self.session.bindings,
            algorithms=ALGORITHMS.copy(), factor_config=self.session.learner.factor_config.asdict(),
            manual_control=self.session.control_status(),
            legacy_speed_mps="unsupported; factor is decided internally",
            feedback="configured_execution_v2", execution=self.session.execution.asdict(),
            batch_timestamp="receipt time; legacy batch has no acquisition timestamp"))
        result["compatibility"]["bf16"] = "Backend VLA uses BF16 autocast on CUDA; RL uses float32"
        return result

    @staticmethod
    def _validate_request(seed, speed_mps, guidance_scale):
        if speed_mps is not None or guidance_scale != 1.:
            raise ValueError("Legacy physical speed/guidance remain unsupported; RL selects a dimensionless factor")
        if seed is not None and (type(seed) is not int or not 0 <= seed < 2**63):
            raise ValueError("seed must be a nonnegative integer below 2**63")

    def predict_at(self, sample, anchor, seed=None, speed_mps=None, guidance_scale=1., *, locator="planner_timestamp",
                   expected_epoch=None, received_at=None):
        self._validate_request(seed, speed_mps, guidance_scale)
        session = self.session
        with session.lock:
            epoch = session.epoch
            if expected_epoch is not None and expected_epoch != epoch:
                raise RuntimeError("Planner changed before encoding")
        key = (epoch, float(anchor), seed)
        # A repeated draw/get_action request for the same frame is the same
        # decision, even if the learner updated in between.
        if locator == "planner_timestamp" and self.cache is not None and self.cache[0] == key:
            if session.cached_valid(self.cache[2]):
                self.last_chunk_id = self.cache[2]
                return self.cache[1].clone()
            self.cache = None
        data = BatchDataTokenizedVLA(**self.collator([copy.deepcopy(sample)])).to(session.device)
        with torch.no_grad():
            prepared = session.foundation.encode(data)
            noise = None
            if seed is not None:
                generator = torch.Generator(device=session.device).manual_seed(seed)
                shape = (*data.action.shape[:-1], session.foundation.base.actor.pad_act_dim)
                noise = torch.randn(shape, device=session.device, generator=generator)
            actions, chunk_id = session.propose(prepared, anchor, expected_epoch=epoch,
                deterministic=session.mode == "inference", initial_noise=noise, locator=locator,
                received_at=received_at)
        self.last_chunk_id = chunk_id
        result = torch.from_numpy(np.ascontiguousarray(actions[None], dtype=np.float32))
        if locator == "planner_timestamp":
            self.cache = (key, result.clone(), chunk_id)
        return result

    def predict_samples(self, samples, seed=None, speed_mps=None, guidance_scale=1., *, expected_epoch=None):
        self._validate_request(seed, speed_mps, guidance_scale)
        # The legacy batch API has no timestamp. Each row is a separate proposal,
        # located by ID/digest in the server journal. The service may auto-adopt
        # a single row after return validation; multiple rows stay proposals.
        if not samples:
            raise ValueError("Empty observation batch")
        results, ids = [], []
        for sample in samples:
            receipt = self.session.clock()
            results.append(self.predict_at(sample, receipt, seed, speed_mps, guidance_scale,
                locator="batch_receipt", expected_epoch=expected_epoch, received_at=receipt))
            ids.append(self.last_chunk_id)
        self.batch_chunk_ids = ids
        return torch.cat(results)

    def run_batch(self, obs_data, seed, contract_sha256, speed_mps, guidance_scale, expected_epoch):
        if contract_sha256 is not None and contract_sha256 != self.signature:
            raise ValueError("Client task/data/calibration contract differs from this service")
        self._validate_request(seed, speed_mps, guidance_scale)
        samples = batch_to_samples(obs_data, self.config, self.wire_size)
        return self.predict_samples(samples, seed, speed_mps, guidance_scale, expected_epoch=expected_epoch)
