# iE2VLA3：chunk 同频 Double DQN 倍率 + 连续 SAC 残差

更新于 2026-11-24：倍率选择改为 **Double DQN**，四档仍为 **0.8 / 1 / 1.5 / 2**，残差继续复用原连续 SAC。默认自动执行账本、每 16 步接入新 chunk / 8 步融合约定和 Pyro4 接口保持不变。原 `e2vla_compat`、`e2vla_async`、基础 VLA、RL token、已有训练文件及 checkpoint 不作修改。**客户端代码不需要增加倍率、残差、力或 reward 字段。**

新增服务端人工选择：`base`（基础 VLA，1x）、`speed`（只调速）、`full`（调速＋残差）。**启动默认选择 `base`**；训练开关仍由独立的 `--mode train/collect/inference` 决定。人工选择通过服务器本地控制文件输入，不增加客户端 RPC。已有 Double DQN + SAC 权重可直接加载，网络形状、模型及 reward 配置不变。

验证包括 Double DQN 目标值与探索、连续 SAC 更新一致性、保存恢复、真实 localhost Pyro4 TCP/共享内存、小型真实 Qwen+动作网络加载推理。没有启动生产训练，没有连接机器人。部署服务器是 **ROS 2**；实际话题、字段、力传感器标定尚未提供，需按下文映射，不能把示例话题当成已接通的传感器。

## 行为与接口

一次新观测触发的推理：

1. 冻结 VLA 提取三路图像/语言特征，冻结已训练 RL token 编码器生成 token。
2. `base` 固定选 1x；`speed/full` 由 Double DQN 读 token、**双臂绝对 TCP state**、过去的力/力矩和执行上下文，输出四个 Q 值，选 `0.8 / 1 / 1.5 / 2`。
3. 倍率进入 VLA 原 FiLM 路径，生成 32 点基准轨迹。
4. `full` 由连续 SAC 再读取本次基准轨迹和选中倍率，输出**一组双臂 12 维残差**；`base/speed` 将上次已采用残差逐步退回零。每臂为局部 TCP 坐标系的平移 3 维、旋转向量 3 维，整段 32 点使用同一组修正；不改夹爪。
5. 返回原格式的轨迹。默认在新结果返回给客户端前，推定它开始参与执行/融合；下一段新结果返回时结算上一段，或由人工 success/failure 终结当前 episode。每段分别生成倍率和残差 transition。可以选择显式执行反馈模式。

**两路策略都按 VLA chunk 更新，没有 30 Hz 残差策略循环。** 轨迹仍为 32 点、30 Hz，首尾相隔 `31/30` 秒。倍率改变预测的运动进度，不改变时间戳间隔。`--max-inference-hz 0` 默认无额外推理限速；实际 chunk 频率由新观测、计算耗时和客户端取用决定。旧 `SACConfig.control_hz=30` 在本版用于轨迹/力历史采样，`replan_seconds` 不控制本服务的请求频率。

默认残差每轴不超过 ±5 mm / ±0.05 rad；相邻已采用 chunk 的残差变化，每轴不超过 1 mm / 0.01 rad。整段 TCP 线速度/角速度上限默认 0.5 m/s / 1 rad/s，超出则拒绝输出，不偷偷裁剪策略动作。连续性仍取决于 VLA 预测、客户端原有插值/融合与机器人控制器；本版不保证 chunk 切换位置天然连续。

原 RPC 方法及签名保留：

| 接口 | 行为 |
|---|---|
| `get_info/get_config/get_planner_config/get_status` | 原字段保留；info/status 增加 `rl` 信息 |
| `set_config/reset/set_prompt/set_speed` | 原调用形式；`reset` 丢弃未闭合区间，不伪造失败奖励 |
| `add_obs_frame/add_obs_frames` | 原始 LeRobot 位姿/夹爪、三路 RGB、任务文字；默认 **recorded/raw** |
| `get_action(...)` | 原 `(poses, grippers, times, image)`，形状 `(32,2,4,4)/(32,2)/(32,)` |
| `run_inference(...)` | 原 batch 输入，CPU float32 Tensor `(B,32,2,17)` |
| `run_inference_numpy(...)` | 同形状 NumPy 输出 |
| `set_ensemble_nums/ensemble_traj` | 原轨迹融合接口保留 |
| `start_async/pause_async/get_latest_action` | 原异步 envelope、sequence、generation 规则保留 |

单位、工具偏移、左右基座、三相机几何继续走原适配器，由 checkpoint 配置决定。输出 TCP 统一在左臂 recorded base 下。旧客户端识别用的顶层 `variant="no_speed"` 和 wire format 保留；`backend`、`checkpoint_format`、`checkpoint_metadata`、`rl` 如实标识倍率模型。`speed_mps` 仍不是倍率，非空值会被拒绝；不要给旧客户端传 `speed_mps=1.5`。

同一 planner 观测和 seed 的重复 `get_action`/画图复用同一决策，不重复激活或结算。后台生成但未被 `get_latest_action` 取走的结果不记执行。新观测可在旧 chunk 执行时上传/推理。自动模式假定每个返回的新结果被采用，无法判断 RPC 返回后的丢包、客户端丢弃或实际融合起点；这属于采集近似。

## 人工选择输出，后台继续学习

| `--control-mode` / 人工选择 | 返回轨迹的倍率 | 返回轨迹的残差 |
|---|---|---|
| `base`（启动默认） | 固定 1x | 从上次已采用值逐步退回零；到零后为纯 VLA |
| `speed` | Double DQN 的 0.8 / 1 / 1.5 / 2 | 同样逐步退回零 |
| `full` | Double DQN 选择 | 连续 SAC 选择 |

这里的基础 VLA 是**同一个四倍率 checkpoint 的 1x 推理**，不会切换加载另一个无速度模型。三种模式仍需要匹配的倍率 VLA、RL token 和 DDQN/SAC 权重。只持有无速度 checkpoint 时，继续使用原 `rl_residual_service`，不能通过本开关获得调速能力。

`--mode train --control-mode base` 表示机器人收到基础轨迹，但两路 learner 仍从真实闭合区间更新。人工选择只决定采集行为，不改变自主策略的动作空间或网络输入。DDQN/SAC 按 off-policy 方式训练：base 的 replay 动作为倍率索引 1（1x）、零残差或退回过程中的实际残差；speed 为所选倍率＋实际退回残差；full 为所选倍率＋SAC 残差。没有采用的 RL 候选不会得到这次执行的奖励。

后台更新仍受 warmup、batch、版本差和新 transition 数量限制；不会因切到 base/speed 停止，也不会在没有新执行区间时无限重复更新旧样本。SAC 的 actor/熵项和自主 Q 目标保持原算法，不把人工关闭当作永久禁止非零动作。只采集 1x/零残差时，其他动作的真实效果仍缺少覆盖，不能仅靠持续更新宣称全自主能力已经学好。

先启动服务，看到 `ready` 后，在**服务器另一终端**执行（无需模型环境，普通 Python + NumPy 即可）：

```bash
cd /home/hq/code/iE2VLA3

# 与服务端 --control-file 指向同一文件。
python3 -m rl_chunk_service.control_cli \
  --output /tmp/ie2vla_rl_control.jsonl --control-mode base

python3 -m rl_chunk_service.control_cli \
  --output /tmp/ie2vla_rl_control.jsonl --control-mode speed

python3 -m rl_chunk_service.control_cli \
  --output /tmp/ie2vla_rl_control.jsonl --control-mode full

# 交互面板：1/2/3 + 回车切换；q 只退出面板，当前模式保持。
python3 -m rl_chunk_service.control_cli \
  --output /tmp/ie2vla_rl_control.jsonl --interactive
```

也可以由已有服务器 ROS 2 通路向同一控制文件追加一行，例如 `{"type":"control","mode":"speed","event_id":"operator-001"}`。消息映射是部署端配置；本次没有预设未知 ROS 话题。`--epoch` 可限制命令只对当前 episode 生效，`--event-id` 用于同一请求重试去重。相同 ID 配不同模式会拒绝。控制文件与力／结果反馈文件分开，避免等待测力反馈阻塞切换。服务启动从文件末尾开始读，不重放重启前的命令；启动模式以 `--control-mode` 为准。未指定 `--control-file` 时使用 `OUTPUT/control.jsonl`。

CLI 的 `Queued` 只表示写入命令。确认状态使用原有 `get_status()['rl']['control']`：

- `requested_mode/revision`：服务器已接收的选择及版本。
- `active_mode/active_revision/active_factor/active_residual`：当前已返回／采用 chunk 的实际选择和归一化残差。
- `releasing`：该已采用 chunk 是否仍处于残差退回过程。base/speed 下为 false 且残差全零时，才已经退出修正。

人工切换不重置 episode、力缓冲或 active chunk；下一段采用时，上一段仍按原动作、原时间区间结算。`reset/pause/abort` 保持原含义，不能用它们代替模式切换。reset 后人工选择保持；服务重启则重新采用启动参数。

### 异步缓存与 16/8 融合

每次不同模式的选择增加控制版本和原协议的 `generation`，清除服务端待发结果及策略缓存。正在推理的旧版本结果会被丢弃；未采用过的最新观测可以重新推理，若最新观测已经用于当前 active chunk，则等待下一帧，不以旧时间戳重复发布一个新动作。同步调用被切换打断时返回 `None` 等待重试；batch 推理被切换打断时拒绝整次响应，不返回混合模式的 batch。旧客户端方法和返回形状不变。

切换只影响**尚未返回给客户端**的新 chunk，无法撤回客户端已经取走／缓存的轨迹。已经下发的旧 chunk 仍保留在父链上，下一段的 `previous_residual` 来自它实际被采用的残差。

退出残差遵守原每轴变化上限：默认每个新采用 chunk 最多退回 1 mm / 0.01 rad；从最大幅度退出最多需要 5 个新 chunk。重复取同一结果或后台预推理不会推进退回。客户端原有 8 步融合继续处理段间衔接，服务器不再叠加一层融合，也不把切换瞬间伪装成末端已经零残差。

**回放中的“采用动作”是服务器筛选并返回的 chunk 命令，不是未知的客户端融合后每一时刻的精确机器人动作。** 仍沿用 RPC 返回即采用、16 步执行 / 8 步融合的约定。客户端若又拒绝或改写命令而不给反馈，服务器无法知道。`quality` 明确保留 `execution_assumed`、融合约定、父 chunk、控制版本、实际选择的倍率／残差、轨迹哈希及缺力信息；不能把这些记录宣传为已有精确融合执行 ACK。

## 默认执行配置（两个 RL 服务共用）

```text
--execution-mode auto
--clock-mode receipt
--chunk-lifetime-s 5
--missing-wrench zero
--fault-policy warn
--execute-steps 16 --blend-steps 8
```

- `auto`：同步 `get_action`、异步 `get_latest_action` 实际返回新结果、单行 `run_inference` 返回前自动激活。下一次激活结算上一段。父链与策略输入中的上一段残差保持一致；异步生成期间父节点改变，则丢弃该候选并重新推理，不事后伪造 parent。多行 batch 不自动激活，因为接口没有表达实际采用哪一行。
- `receipt`：客户端 timestamp 是独立时钟域，原值仍用于客户端历史顺序、轨迹时间戳及相邻轨迹对齐；不与服务器时间做数值比较。服务器用 `time.monotonic()` 记录观测接收、推理和结果返回。ROS/人工反馈保留源时钟的域内顺序检查，但按服务器接收时刻进入执行/力缓冲区。不同传感器源可提供不同 `clock_domain` 字符串；双腕配对仍要求两路 ROS header 属于同一时钟域。该模式不消除传输延迟，不是精确时钟同步。
- `chunk-lifetime-s`：从观测在服务器的接收时刻起计算结果/执行窗口有效期，默认 5 秒。它不改变 32 点、30 Hz 的轨迹时间间隔。过期的非终止区间丢弃，不补造 transition；下一段可以继续运行。晚到的人工终止标签可绑定当前未终止 episode，累计时长最多计到该 chunk 的有效期末尾，并产生警告。
- `missing-wrench zero`：缺失历史采样点和执行区间的缺测部分补零，已有测量保留。日志警告，replay 的 `quality` 记录缺测点数和秒数。补零会减少力惩罚，学习结果带偏差；它不代表测得零力。选 `--missing-wrench error` 可以保留等待/拒绝缺测的行为。
- `fault-policy warn`：反馈故障记录 warning，不永久阻断推理。非法位姿、NaN、动作越界仍拒绝输出。学习线程本身出错会停止该线程，并在 `learning_error` 中显示；不会假称训练仍在更新。
- `execute-steps/blend-steps`：记录客户端采用/融合约定，不在服务器重复融合、不发执行定时器。按 30 Hz 理想节奏，每 16 步约 0.533 秒、8 步融合约 0.267 秒；实际 reward/discount 使用服务器记录的相邻结果返回间隔，不强制设为 16/30。

`get_status()['rl']` 提供当前 episode `epoch`、`active_chunk`、计数、配置和警告。客户端发生暂停、人工接管或开始新任务时，继续使用其现有 reset/pause 流程，或由服务器发送 abort。服务端无法仅从动作请求辨认这些外部状态。

恢复旧的严格模式需同时设置：

```text
--execution-mode explicit --clock-mode shared
--chunk-lifetime-s 1.0333333333333334
--missing-wrench error --fault-policy stop
```

`shared` 明确要求源时间与服务器 Unix 秒对齐。初始化 RL learner 可以绑定任一模式；已训练 learner 和 replay 的采集配置必须一致。旧 v1 replay 按旧严格模式解释，不能静默混入 auto 回放。基础 VLA/token checkpoint 无需改变。

## 所需权重与初始化

需要三个匹配文件：

- 已训练的四倍率 VLA：`lerobot_factor_full_v3`，含 `model.pt`、`complete.json`。
- 针对该 VLA 训练的 `ie2vla_rl_token_v1`。
- 本目录创建的混合 RL 权重：格式固定为 `ie2vla_chunk_ddqn_sac_v1`，标明 `factor=double_dqn`、`residual=continuous_sac`，包含两路网络、优化器、更新次数、随机数状态和采集配置。

**旧离散 SAC 的 `ie2vla_chunk_sac_v1/v2` 不能直接 `--resume` 为 Double DQN。** 倍率网络从分类 actor + 双 Q 改为在线 Q + 目标 Q，新加载器会明确拒绝旧格式，不会覆盖或转换旧文件。切换时用相同的倍率 VLA / token，在新目录执行下面的 `--stage init`，重新初始化两路 RL 网络；基础 VLA 和 RL token 无需因此重训。若仍需使用旧离散 SAC，应保留旧部署代码及其 RL 权重。

原无速度模型的独立残差服务 [rl_residual_service](../rl_residual_service/README.md) 保持连续 SAC，仍按原方式启动、加载原残差权重；本次没有给它增加倍率分支。

**现有无速度 100k checkpoint 不能直接当作倍率 VLA。** 本服务复用的是客户端协议，不会给无速度 checkpoint 凭空增加可训练的倍率能力。原 30 Hz 残差 SAC 权重/回放格式也不直接载入本版，以免语义混用。

从头训练倍率 VLA 的入口和参数仍见 [速度分支说明](../models/m0512_fm/README_lerobot_dual_velocity.md)，RL token 的架构和独立训练见 [RL token 说明](../rl_factor_sac/README.md)。示例训练顺序如下，下面是供部署时执行的命令，本次没有执行 GPU 训练：

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

# 四倍率基础 VLA；需要空闲 GPU，使用新的输出目录。
CUDA_VISIBLE_DEVICES=0,1,2,3 TOKENIZERS_PARALLELISM=false \
python -m models.m0512_fm.train_lerobot_dual_velocity \
  --output /nas_data_new/hq/98qwenvla/ie2vla3_factor_sft_new

# 以下路径替换成实际完成的倍率 VLA 和 token checkpoint。
BASE=/absolute/path/to/factor_sft/step_0100000
python -m rl_factor_sac.train_token \
  --base "$BASE" --output /absolute/path/to/token_run \
  --steps 20000 --device cuda:0

TOKEN=/absolute/path/to/token_run/token_020000.pt
python -m rl_chunk_service.train --stage init \
  --base "$BASE" --token "$TOKEN" \
  --factor-config /home/hq/code/iE2VLA3/rl_chunk_service/default_factor_config.json \
  --output /absolute/path/to/chunk_ddqn_sac_init --device cpu
```

token 步数是启动示例，需根据验证集重建/动作辅助损失选择 checkpoint。RL 初始化只建立网络，不表示已学会任务。默认倍率 Q 值有微小的 1x 初始偏好。对于人工选择开启的分支，`inference` 取最大 Q 对应倍率和连续策略均值，`collect/train` 使用 ε-greedy 倍率和连续 SAC 随机残差；关闭的分支按上文固定倍率／退回残差执行。在线学习始终冻结 VLA 和 token。

可给 init 传 `--config /absolute/sac_config.json` 调整共享观测编码器尺寸、残差边界及连续 SAC 参数；结构见原 [SAC 配置](../rl_factor_sac/default_config.json)。奖励可用 `--reward-config`，此配置必须在 init、服务端和离线学习时完全一致。权重绑定 base/token SHA256、奖励配置、chunk 语义；不支持静默换模型继续用旧 replay。

### Double DQN 参数和更新规则

[default_factor_config.json](default_factor_config.json) 是可选的 `--factor-config` 文件；不传时使用相同默认值：

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `learning_rate` | 0.0003 | 在线 Q 网络 Adam 学习率 |
| `epsilon_start` | 0.2 | 初始随机探索概率 |
| `epsilon_end` | 0.05 | 最终随机探索概率 |
| `epsilon_decay_updates` | 10000 | 按倍率优化器更新次数线性衰减；不是客户端请求次数 |
| `target_update_interval` | 200 | 每 200 次倍率更新，将在线 Q 硬复制到目标 Q |

探索时在合法倍率中均匀抽样，否则选最大在线 Q 值；掩码同时用于动作选择和训练 bootstrap。`inference` 始终关闭随机探索。`collect` 不更新网络，所以 ε 保持所加载 checkpoint 的值，不会随采集次数衰减。

训练采用真正的 Double DQN：

```text
a_next = argmax_a Q_online(next_obs, a)  # 只在合法倍率中选择
y = reward + discount * (1 - terminated) * Q_target(next_obs, a_next)
loss = Huber(Q_online(obs, executed_factor), y)
discount = gamma_per_second ** 实际账本区间秒数
```

倍率分支没有 actor、温度优化器或熵奖励；默认梯度裁剪为共享配置的 `grad_clip=1`。残差分支保持原 actor、双 Q、目标网络、自动温度和软更新。共享配置里的 `actor_lr`、`critic_lr`、`temperature_lr`、`tau` 继续控制残差 SAC；旧 `factor_entropy_fraction` 对新倍率分支不生效。倍率学习率和目标更新周期以 `--factor-config` 为准。

DDQN 参数随权重保存，服务端自动读取；离线 `--resume` 也恢复 ε 进度和目标网络。恢复时若显式传入 `--factor-config`，必须与 checkpoint 一致。`rl_factor_sac` 中的旧双 SAC 实现保留给旧流程，本服务只复用它的观测编码器、连续 SAC 和公共工具。

为保持原脚本路径约定，输出文件仍命名为 `sac_init.pt`、`sac_latest.pt`、`sac_fXXXXXX_rXXXXXX.pt`；**文件名含 sac 不表示倍率仍用 SAC**，应查看内部 `format` / `algorithms`，或服务端 `get_info()['rl']['algorithms']`。

## 启动服务

旧客户端的 URI、地址、端口不改时，新服务必须监听原来的注册名和端口。**原服务还占用该名字时，新服务会报错退出，不覆盖或停止原服务。** 当前正在运行的服务不在本次操作范围内；实际切换部署时由运维安排。下面 `e2vla:9101` 是原默认值，如果部署客户端使用别的值，就使用其原值。

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

BASE=/absolute/path/to/factor_sft/step_0100000
TOKEN=/absolute/path/to/token_run/token_020000.pt
RL=/absolute/path/to/chunk_ddqn_sac_init/sac_init.pt

python -m rl_chunk_service.remote_service \
  --checkpoint "$BASE" --token "$TOKEN" --rl-checkpoint "$RL" \
  --task close_box --device cuda:0 \
  --uri e2vla --host 127.0.0.1 --port 9101 \
  --ns-host 127.0.0.1 --ns-port 9090 --start-ns \
  --input-pose-format recorded --input-gripper-format raw \
  --feedback /tmp/ie2vla_rl_feedback.jsonl \
  --control-file /tmp/ie2vla_rl_control.jsonl --control-mode base \
  --output /absolute/path/to/rl_session_001 \
  --mode train
```

`--task` 保持与客户端原任务路由一致，可选 close_box/open_box/place_phone，实际任务文字仍由客户端 `set_prompt` 或 `--prompt` 设置。原客户端若上传的是已经转换的 world TCP/openness，应继续用它之前的 `--input-pose-format tcp_world --input-gripper-format openness`，避免重复转换。

未指定 URI/port 时，新服务默认 `e2vla_rl:9102`，方便旁路验证。`--output` 必须是**尚不存在的新目录**，避免覆盖已有训练产物。`--check-config` 可仅校验权重绑定而不加载 Qwen/GPU；其他必填参数仍需提供。

上述命令从 base 开始采集并后台训练；用控制面板切换 speed/full。只验证推理而不收集训练数据时，改为 `--mode inference`。需要与之前全程调速＋残差的行为一致时，显式加 `--control-mode full`。控制开关不自动改变 `--mode`，在 inference 模式下按 full 也不会开始训练。

客户端原来用同步方法就继续同步；原来用异步方法就继续异步。服务端可加 `--autostart --prompt '任务指令'` 启动后台推理。调试可用 `--max-inference-hz 2` 限制最多每秒两次新观测推理，不改轨迹点的 30 Hz 时基。

## ROS 2 力与执行反馈接入

在部署机器、已经 source ROS 2 环境的终端查询：

```bash
ros2 topic list -t
ros2 topic info /实际话题名 -v
ros2 topic echo /实际话题名 --once
ros2 interface show geometry_msgs/msg/WrenchStamped
```

复制 [ros2.example.json](ros2.example.json) 到部署配置，填写左右话题、消息类型、字段路径、frame_id、单位和传感器到 TCP 的标定。示例中的 `/REPLACE/...`、单位阵、零偏均为占位，**不是 E03 的力传感器标定**。

- 输出顺序固定 left/right，单臂 `[Fx,Fy,Fz,Tx,Ty,Tz]`，单位 N/Nm。
- `bias_si` 是传感器坐标系、换算为 SI 后减去的静态零偏。运动相关重力/工具载荷补偿应由已有传感器通路提供，桥接器不假装有这份模型。
- `sensor_to_tcp_rotation=R`；`tcp_to_sensor_translation_m=p` 为 TCP 原点指向传感器原点、用 TCP 轴表达。转换为 `F_tcp=R F_sensor`、`τ_tcp=R τ_sensor + p×F_tcp`。
- 默认 receipt 模式按上文分离时钟；只有显式选择 `--clock-mode shared` 才要求 ROS、客户端、服务器使用同一 Unix 秒时钟。
- 左右测力配对最大偏差默认 20 ms；策略读取过去 8 点、以 30 Hz 重采样的历史，最大缺测间隔默认 100 ms。默认缺测处补零并标记近似；`--missing-wrench error` 时等待足够历史再输出。

桥接程序只读 ROS，不发机器人控制命令。ROS Python 与模型 Conda 环境可以不同，桥接器只需 ROS 对应 Python + NumPy，不需要 PyTorch：

```bash
# ROS 2 终端（先 source 现场的 ROS/setup.bash）
cd /home/hq/code/iE2VLA3
python3 -m rl_chunk_service.ros_bridge \
  --config /absolute/path/to/ros2.actual.json \
  --output /tmp/ie2vla_rl_feedback.jsonl --check-config

python3 -m rl_chunk_service.ros_bridge \
  --config /absolute/path/to/ros2.actual.json \
  --output /tmp/ie2vla_rl_feedback.jsonl
```

先启动服务端，再运行桥接器/客户端；服务启动时从 inbox 文件末尾开始读，避免误收上一次运行的执行 ACK。一个 inbox 只对应一个服务实例。反馈文件是追加日志，应在服务停止后归档/轮换。

默认 auto 模式不需要 activate 事件，收到外部 activate 会警告并忽略，以免重复记账。以下 activate 接入仅用于 `--execution-mode explicit`，无需客户端新增 RPC。例如已有消息能给出实际接管时间、该轨迹首时间戳和采用状态时：

```json
{
  "topic": "/现场已有的轨迹采用反馈",
  "message_type": "your_msgs/msg/TrajectoryFeedback",
  "constants": {"type": "activate"},
  "fields": {
    "timestamp": "header.stamp",
    "anchor": "trajectory_start_time",
    "execution_matches_proposal": "accepted"
  }
}
```

字段名只是映射示例。`anchor` 必须是对应 `get_action` 返回的 **times[0]**，不是 ROS 收到消息的时刻。若实际驱动话题需要复杂关联、状态枚举判断或多个消息才能确认执行，在服务器侧另行适配成下列 JSON 事件即可；不能仅凭“推理已完成/轨迹已收到”就映射成执行确认。

### 规范化事件

ROS bridge 或服务器其他传感器程序可向 inbox 按行追加 JSON：

```json
{"type":"wrench","timestamp":1795400000.0,"values":[[1,2,3,0.1,0.2,0.3],[4,5,6,0.4,0.5,0.6]]}
{"type":"activate","timestamp":1795400000.2,"anchor":1795400000.0,"execution_matches_proposal":true}
{"type":"outcome","timestamp":1795400000.7,"chunk_id":"从 proposals.jsonl 中找到的当前已执行 chunk ID","outcome":"success"}
```

上面的时间与数值仅展示结构，不能作为真实反馈使用。

每个 proposal 的 ID、anchor、倍率、残差、策略版本、`trajectory_sha256` 写入 `--output/proposals.jsonl`，**该记录只表示提案，绝不是已执行**。在 explicit 模式，反馈需识别实际采用的提案；可使用 `chunk_id`、唯一的原 planner `anchor` 或唯一 `trajectory_sha256`。SHA256 对返回 `(32,2,17)` 动作的 C 连续 little-endian float32 bytes 计算，顺序为 16 项 TCP 矩阵+夹爪。相同值的重复 batch 可能有相同 digest，此时必须用 ID，不猜测是哪次请求。

在 explicit 模式，`execution_matches_proposal=true` 表示执行通路确认该提案开始被机器人采用，允许原有时间插值/IK。若被其他动作替换、人工接管，或无法确定融合/裁剪后的动作来源，应发 `abort`，不能把它算作这条策略的执行。在已有客户端存在 chunk 融合时，服务器侧反馈必须能追踪实际采用的 chunk；本服务不会假设客户端没有融合。

`run_inference` 的旧 batch 格式没有采集时间或 chunk ID 返回字段。单行 batch 默认在返回前自动激活；每次调用都视为新的决策，无法识别客户端重试。多行 batch 是多个候选，不自动产生执行记录，可使用 explicit 模式关联采用行。planner 接口则可以通过观测/seed 缓存去重。

人工任务结果无需 chunk ID：

```bash
python -m rl_chunk_service.feedback_cli \
  --output /tmp/ie2vla_rl_feedback.jsonl --outcome success

# 推荐：epoch 取自 get_status()['rl']['epoch']，避免迟到标签落入下一轮。
# 重试同一次标注时复用 event-id；更换任务时使用新的 event-id。
python -m rl_chunk_service.feedback_cli \
  --output /tmp/ie2vla_rl_feedback.jsonl --outcome failure \
  --epoch CURRENT_EPISODE_ID --event-id UNIQUE_LABEL_ID

python -m rl_chunk_service.feedback_cli \
  --output /tmp/ie2vla_rl_feedback.jsonl --abort
```

无 ID 的 outcome 原子地绑定当前 active chunk/episode。相同 event-id 或当前已结束 episode 的相同结果不会重复给奖；错误 epoch/明确但错误的 chunk ID 会拒绝该条反馈。不给 epoch 时，无法识别 reset 之后才送来的上一轮标签，部署端应及时标注。默认使用标注被服务器收到的时刻；人工反应延迟影响时间代价和奖励归因，超 lifetime 则截到有效期末尾。终止后通过现有 reset 开始下一轮。

反馈解析失败、源时钟倒退、错误 outcome 等默认在 `last_warning` 和日志中可见；后续合法反馈/推理可以继续。原 `error` 的锁存行为由 `--fault-policy stop` 启用。

## 在线与离线训练

上述服务命令使用 `--mode train`，一边按人工选择返回轨迹，一边训练倍率 Double DQN 和残差连续 SAC。`--mode collect` 只收集回放，开启的分支使用随机策略；`--mode inference` 使用确定性策略，不写训练 transitions。三种人工控制模式都可以与这三种学习模式组合。

在线训练默认累计至少 32 条**已闭合的执行账本区间**后开始，每次发现新的 transition 最多进行一轮 Double DQN + 连续 SAC 更新，batch=32，限制策略版本差不超过 1000。auto 模式按返回结果推定执行；没有闭合区间则不更新。可以加：

```text
--mode train --warmup 32 --batch-size 32 --save-every 100 --max-policy-lag 1000
```

两路 replay 使用同一账本时间区间的奖励，discount=`gamma_per_second ** 区间秒数`。auto 模式的区间边界是新结果返回时刻，属于执行近似。倍率 next_obs 是下一次倍率决策输入；残差 next_obs 是下一次残差决策输入，包含下一次倍率生成的基准轨迹。记录 decision→activation 的服务器时钟延迟。该方案仍受视觉延迟和异步执行影响；不能把未知执行延迟当成零，策略快照/版本用于限制陈旧回放。

默认奖励为 success `+10`、failure `-5`，加耗时、超阈值力/力矩、残差幅度与变化惩罚。力接触不自动等于成功。共享奖励让两路策略合作，但也带来联合训练的非平稳性；需要在机器人上检查成功率、接触力和倍率分布，不能仅凭 RL loss 下降判断动作变好。

每 100 条 transition（或正常 SIGINT/SIGTERM 退出）保存：

```text
rl_session_001/
  service.json          # 权重绑定和协议元信息
  proposals.jsonl       # 人工切换、实际选择的提案、确认、区间、错误审计
  loss.jsonl            # factor: q_loss/q_mean/target_q/epsilon/updates；residual: 原 SAC 指标
  status.json
  sac_latest.pt         # ie2vla_chunk_ddqn_sac_v1：DDQN + 连续 SAC 的完整训练状态
  replay_latest.pt      # 双路 chunk replay，含实际选择、控制版本、融合/缺力 quality
```

输出目录不包含 VLA 副本，不覆盖原 base/token checkpoint。回放默认每路保留 10000 条，实时写入不可变 CPU 副本；保存时有短时 I/O 和锁等待。模型与 RL 学习同 GPU 并发时会竞争计算资源，实际推理延迟需在部署 5090 上测量；可以先 collect，再离线学习。

人工选择不改变网络、奖励或动作定义，因此保留 DDQN/SAC checkpoint 格式和 replay v2 格式，可继续加载匹配的旧 DDQN/SAC 权重。新 replay 的 `quality` 追加选择来源与实际动作审计；旧 v2 质量记录仍可读取，但没有人工选择字段，不能推断为人工审核数据。保存的 learner 不替你恢复人工开关，重新启动默认仍为 base。

离线继续训练：

```bash
python -m rl_chunk_service.train --stage rl \
  --base "$BASE" --token "$TOKEN" \
  --resume /absolute/path/to/rl_session_001/sac_latest.pt \
  --replay /absolute/path/to/rl_session_001/replay_latest.pt \
  --output /absolute/path/to/rl_offline_001 \
  --steps 1000 --batch-size 32 --save-every 100 --device cuda:0
```

之后重启新服务，`--rl-checkpoint` 指向新混合 RL 文件、`--output` 使用新目录。在线重启不会恢复上一轮尚未执行/未闭合的 chunk；与该 learner 匹配的磁盘 replay 可供离线训练，新在线会重新采集。回放字段和 v1/v2 格式不变，绑定、执行配置和策略版本检查仍生效；旧离散 SAC 的高版本回放不能绕过检查直接配给更新次数为零的新 DDQN。旧策略回放超过 `max-policy-lag` 会拒绝更新，需新采集数据。

Double DQN 没有增加保守离线 RL 约束；离线训练仍依赖记录过的实际倍率、残差、执行观测与奖励。不能通过给 1x 轨迹改标签来制造其他倍率的力反馈或反事实奖励。

## 验证

```bash
cd /home/hq/code/iE2VLA3
PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 \
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \
python -m pytest -q tests/test_rl_manual_control.py tests/test_rl_double_dqn.py \
  tests/test_rl_chunk_service.py tests/test_rl_fusion_execution.py
```

测试覆盖 DDQN 在线选档/目标估值、终止与截断、倍率掩码、ε 探索、目标同步、快照隔离、恢复后下一步更新一致、残差与原连续 SAC 更新一致，以及 recorded/raw 坐标路径、原同步与异步签名/返回、TCP/共享内存、重复请求、reset 与并发推理、严格模式无确认不收集、auto 自动结算、跨时钟域、缺力补零及质量标记、实际时长折扣、ROS 单位/力矩力臂转换、小型真实 Qwen/token/VLA checkpoint 的加载推理和训练 CLI。socket/共享内存测试需要操作系统允许本机 IPC。

人工切换测试额外覆盖三种模式的返回轨迹与 replay 动作一致、零残差采集时两路仍更新、退出残差按已采用 chunk 渐退、缓存／在途计算作废、重复命令去重、旧 episode 命令拒绝、切换后终止奖励归于旧实际动作、batch 原子拒绝、控制文件重启不重放，以及真实 Pyro4 TCP/共享内存下使用原客户端调用形式完成切换。

2026-11-24 全量 CPU 回归：**182 passed, 4 skipped**。4 项跳过原因是本机未安装旧参考客户端／服务；本机真实 TCP 和共享内存测试已通过。源文件校验确认 117 个受保护文件未改变。报告位于 `audits/rl_manual_control_20261124/tests_report.xml`，修改前副本、差异和校验记录在同目录。

尚未验证：不可直接访问的现网客户端进程、未知 ROS 2 话题映射、完整生产权重的 GPU 时延、真实机器人闭环与成功率。完成话题映射和真实执行关联后，才能进入在线 RL 实验。
