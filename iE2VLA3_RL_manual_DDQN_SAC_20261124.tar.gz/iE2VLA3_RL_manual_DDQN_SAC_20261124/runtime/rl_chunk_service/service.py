"""Inherit all existing exposed signatures and serialization wrappers unchanged."""
import time
from collections import OrderedDict
import numpy as np
from shm_transport import expose
from e2vla_async.remote_service import Service as ExistingService
from e2vla_compat.planner import draw_prediction
from e2vla_compat.observations import HistoryNotReady
from .feedback import FeedbackNotReady
from .session import StaleDelivery, ExpiredProposal


class Service(ExistingService):
    def __init__(self, policy, config=None, *, max_inference_hz=0.):
        self.receipts = OrderedDict()
        super().__init__(policy=policy, config=config, max_inference_hz=max_inference_hz)

    def _invalidate(self):
        super()._invalidate()
        self.policy.session.reset("planner_generation_changed")
        self.policy.cache = None
        # Prompt/ensemble changes and pause retain observations in the legacy
        # planner. Keep their original receipt time instead of refreshing age.
        if self.sampler.latest is None:
            self.receipts.clear()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def add_obs_frames(self, obs_frames):
        with self.condition:
            received = self.policy.session.clock()
            result = super().add_obs_frames(obs_frames)
            if self.sampler.latest is not None:
                self.receipts[self.sampler.latest["timestamp"]] = received
                while len(self.receipts) > 256:
                    self.receipts.popitem(last=False)
            return result

    def _snapshot(self):
        snapshot = super()._snapshot()
        sampler = snapshot[0]
        sampler._rl_received_at = self.receipts[sampler.latest["timestamp"]]
        sampler._rl_control_revision = self.policy.session.control_revision
        return snapshot

    def _handle_control(self, event):
        """Local inbox only, not a new Pyro method. Serialize against delivery.

        Unlike reset/pause, this invalidates proposals without erasing the active
        chunk, rewards, observations or parent chain needed for client fusion.
        """
        with self.condition:
            if self.closed:
                raise RuntimeError("Planner is closed")
            if self.policy.session._select_control(event):
                self.generation += 1
                self.latest_result = None
                self.consumed = ((self.generation, self.observation_sequence)
                                 if self._waiting_for_control_observation() else None)
                self.policy.cache = None
                self.last_status = "operator_mode_changed"
                self.condition.notify_all()
            return self.policy.session.control_status()

    def _control_changed(self, snapshot):
        return snapshot[0]._rl_control_revision != self.policy.session.control_revision

    def _waiting_for_control_observation(self):
        session = self.policy.session
        active = session.active
        return bool(active is not None and active["control_revision"] != session.control_revision
            and active["locator"] == "planner_timestamp" and self.sampler.latest is not None
            and self.sampler.latest["timestamp"] <= active["anchor"])

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_status(self):
        result = super().get_status()
        result["rl"] = self.policy.session.status()
        return result

    def _predict(self, snapshot, seed=None, speed_mps=None, draw_traj=False, compress=False):
        sampler, settings, generation, sequence = snapshot
        with self.lock:
            if generation != self.generation or self.closed:
                if self._control_changed(snapshot) and not self.closed:
                    raise HistoryNotReady("Operator mode changed; infer again with the latest selection")
                raise RuntimeError("Planner changed before inference")
            epoch = self.policy.session.epoch
        sample = sampler.sample(settings.prompt)
        stamp = sampler.latest["timestamp"]
        started = time.monotonic()
        try:
            actions = self.policy.predict_at(sample, stamp, settings.seed if seed is None else seed,
                settings.speed_mps if speed_mps is None else speed_mps, settings.guidance_scale,
                expected_epoch=epoch, received_at=sampler._rl_received_at)[0].numpy()
        except FeedbackNotReady as exc:
            raise HistoryNotReady(f"Waiting for measured wrench: {exc}") from exc
        except ExpiredProposal as exc:
            if self.policy.session.execution.fault_policy == "stop":
                raise
            self.policy.session.warn("expired_proposal", str(exc))
            raise HistoryNotReady(str(exc)) from exc
        poses, grippers = actions[..., :16].reshape(-1, 2, 4, 4), actions[..., 16]
        times = stamp + np.arange(len(actions))/self.policy.fps
        return dict(stream_id=self.stream_id, generation=generation, observation_sequence=sequence,
            observation_timestamp=stamp, inference_seconds=time.monotonic()-started,
            _rl_chunk_id=self.policy.last_chunk_id,
            poses=poses.copy(), grippers=grippers.copy(), times=times,
            image=draw_prediction(sample, poses, compress) if draw_traj else None), sample

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_action(self, draw_traj=False, compress_traj_img=False, seed=None, speed_mps=None):
        # Retain the blocking endpoint's signature/return value. Activate only
        # after generation validation, immediately before handing the result out.
        with self.compute_lock:
            with self.lock:
                if not self.sampler.states:
                    return None
                if self._waiting_for_control_observation():
                    self.last_status = "operator_mode_changed; waiting for a fresh observation"
                    return None
                snapshot = self._snapshot()
            try:
                result, sample = self._predict(snapshot, seed, speed_mps, draw_traj, compress_traj_img)
            except HistoryNotReady as exc:
                with self.lock:
                    self.last_status = str(exc)
                return None
            with self.lock:
                if snapshot[2] != self.generation or self.closed:
                    if self._control_changed(snapshot) and not self.closed:
                        self.last_status = "operator_mode_changed; retry latest observation"
                        return None
                    raise RuntimeError("Planner changed during inference; result discarded")
                try:
                    self.policy.session.deliver(result["_rl_chunk_id"])
                except StaleDelivery as exc:
                    self.policy.session.warn("stale_delivery", str(exc))
                    self.last_status = str(exc)
                    return None
                self.last_obs_data, self.last_status = sample, "ready"
            return result["poses"], result["grippers"], result["times"], result["image"]

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_latest_action(self, after_sequence=0):
        with self.condition:
            response = super().get_latest_action(after_sequence)
            result = response["result"]
            if result is not None:
                chunk_id = result.pop("_rl_chunk_id")
                try:
                    self.policy.session.deliver(chunk_id)
                except StaleDelivery as exc:
                    self.policy.session.warn("stale_delivery", str(exc))
                    response["result"] = None
                    self.latest_result = None
                    self.consumed = None
                    self.condition.notify_all()
            return response

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        with self.compute_lock:
            with self.lock:
                settings, generation, epoch = self.settings, self.generation, self.policy.session.epoch
            result = self.policy.run_batch(obs_data, settings.seed if seed is None else seed, contract_sha256,
                settings.speed_mps if speed_mps is None else speed_mps,
                settings.guidance_scale if guidance_scale is None else guidance_scale, epoch)
            with self.lock:
                if generation != self.generation or self.closed:
                    raise RuntimeError("Planner changed during inference; result discarded")
                if len(self.policy.batch_chunk_ids) == 1:
                    self.policy.session.deliver(self.policy.batch_chunk_ids[0])
                elif self.policy.session.execution.mode == "auto":
                    self.policy.session.warn("batch_not_executed",
                        "Multi-row inference remains proposal-only: cannot infer which row the client executes")
            return result
