"""Double DQN + continuous SAC artifacts; chunk replay keeps its wire semantics."""
import copy
import threading
import torch
from rl_factor_sac.config import SACConfig
from rl_factor_sac.sac import SACBranch
from rl_factor_sac.io import atomic_save, validate_bindings
from rl_factor_sac.replay import ReplayBuffer
from rl_chunk_service.execution import ExecutionConfig, saved_semantics
from .double_dqn import DoubleDQN, DoubleDQNConfig

SEMANTICS = dict(decisions="one_factor_and_one_residual_per_vla_chunk",
                 residual="constant_local_tcp_offset_per_chunk",
                 feedback="measured_wrench_and_explicit_execution_v1",
                 discount="gamma_per_second_to_actual_activation_interval",
                 reference_hz=30, factors=[0.8, 1.0, 1.5, 2.0])
ALGORITHMS = dict(factor="double_dqn", residual="continuous_sac")
FORMAT = "ie2vla_chunk_ddqn_sac_v1"


class ChunkDDQNSAC:
    def __init__(self, config=SACConfig(), device="cpu", factor_config=DoubleDQNConfig()):
        self.config, self.factor_config = config, factor_config
        self.factor = DoubleDQN(config, device, factor_config)
        self.residual = SACBranch(config, "residual", device)
        self.lock = threading.RLock()

    @property
    def versions(self):
        return dict(factor=self.factor.updates, residual=self.residual.updates)

    def actor_snapshot(self):
        # Keep the execution engine's decision interface: only the factor's
        # implementation changes from a categorical actor to a Q decision.
        with self.lock:
            return dict(versions=self.versions, factor=self.factor.snapshot(),
                        residual=copy.deepcopy(self.residual.actor).eval().requires_grad_(False))

    def update(self, factor_batch=None, residual_batch=None):
        if factor_batch is None and residual_batch is None:
            raise ValueError("Supply a factor and/or residual batch")
        with self.lock:
            return {name:getattr(self, name).update(batch) for name, batch in
                    (("factor", factor_batch), ("residual", residual_batch)) if batch is not None}

    def save(self, path, bindings):
        validate_bindings(bindings)
        with self.lock:
            execution = getattr(self, "execution", None)
            atomic_save(dict(format=FORMAT, algorithms=ALGORITHMS,
                semantics=saved_semantics(SEMANTICS, execution), execution=execution,
                config=self.config.asdict(), factor_config=self.factor_config.asdict(), bindings=bindings,
                factor=self.factor.state_dict(), residual=self.residual.state_dict(),
                rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all()
                if torch.cuda.is_available() else None), path)

    @classmethod
    def load(cls, path, device="cpu", bindings=None, restore_rng=False):
        saved = torch.load(path, map_location=device, weights_only=False)
        if saved.get("format") in ("ie2vla_chunk_sac_v1", "ie2vla_chunk_sac_v2"):
            raise ValueError("Old discrete SAC checkpoint cannot resume Double DQN; run --stage init in a new "
                             "directory with the same base/token. Existing checkpoints are not modified.")
        execution = saved.get("execution")
        if (saved.get("format") != FORMAT or saved.get("algorithms") != ALGORITHMS
                or saved.get("semantics") != saved_semantics(SEMANTICS, execution)
                or (bindings is not None and saved["bindings"] != bindings)):
            raise ValueError("Chunk Double DQN/SAC format/algorithms/semantics/base/token/reward mismatch")
        validate_bindings(saved["bindings"])
        result = cls(SACConfig(**saved["config"]), device, DoubleDQNConfig(**saved["factor_config"]))
        for branch in ("factor", "residual"):
            getattr(result, branch).load_state_dict(saved[branch])
        result.execution = execution
        if restore_rng:
            torch.set_rng_state(saved["rng"].cpu())
            if torch.cuda.is_available() and saved["cuda_rng"] is not None:
                torch.cuda.set_rng_state_all([x.cpu() for x in saved["cuda_rng"]])
        return result


# Compatibility for existing Python integrations; persisted algorithms/formats
# above are explicit and never interpret discrete SAC weights as Double DQN.
ChunkSAC = ChunkDDQNSAC


def save_replay(path, buffers, bindings, *, execution=None, quality=None):
    validate_bindings(bindings)
    if set(buffers) != {"factor", "residual"} or buffers["factor"].config != buffers["residual"].config:
        raise ValueError("Expected matching dual replay buffers")
    atomic_save(dict(format="ie2vla_chunk_replay_v2" if execution else "ie2vla_chunk_replay_v1",
        semantics=saved_semantics(SEMANTICS, execution), execution=execution, quality=quality or [],
        config=buffers["factor"].config.asdict(), bindings=bindings,
        buffers={k: v.snapshot() for k, v in buffers.items()}), path)


def load_replay(path, config, bindings):
    saved = torch.load(path, map_location="cpu", weights_only=False)
    validate_bindings(bindings)
    execution = saved.get("execution")
    expected_format = "ie2vla_chunk_replay_v2" if execution else "ie2vla_chunk_replay_v1"
    if (saved.get("format") != expected_format or saved.get("semantics") != saved_semantics(SEMANTICS, execution)
            or saved["config"] != config.asdict() or saved["bindings"] != bindings
            or set(saved["buffers"]) != {"factor", "residual"}):
        raise ValueError("Chunk replay format/semantics/base/token/reward/config mismatch")
    result = {k: ReplayBuffer(config, k, max(1, len(rows))) for k, rows in saved["buffers"].items()}
    for branch, rows in saved["buffers"].items():
        result[branch].execution = execution or ExecutionConfig.legacy().asdict()
        result[branch].quality = saved.get("quality", [])
        if execution and len(result[branch].quality) != len(rows):
            raise ValueError("Replay quality metadata is incomplete")
        for row, meta in rows:
            result[branch].add(row, **meta)
    return result
