"""Human behavior selection, adopted-action replay and concurrent wire delivery."""
import copy
import inspect
import json
import threading
import numpy as np
import pytest
import torch

from rl_chunk_service.artifacts import ChunkDDQNSAC, load_replay
from rl_chunk_service.control import start_control_reader
from rl_chunk_service.control_cli import main as control_cli
from rl_chunk_service.execution import ExecutionConfig
from rl_chunk_service.feedback import append_event
from rl_chunk_service.online import OnlineLearner
from rl_chunk_service.service import Service
from rl_factor_sac.geometry import residual_target
from test_rl_chunk_service import setup
from test_rl_fusion_execution import get
from test_e2vla_compat import frame, legacy_batch
from test_e2vla_async import until


@pytest.fixture(autouse=True)
def threads():
    torch.set_num_threads(2)


def make(tmp_path, mode="base", *, execution=None, raw=False):
    service, session, now = setup(tmp_path, mode="train", raw=raw,
        execution=execution or ExecutionConfig(), control_mode=mode)
    # Distinct, feasible proposals make accidental use of the wrong branch
    # observable in returned SE(3) poses AND replay, without reward luck.
    snapshot = session.learner.actor_snapshot
    calls = dict(factor=0, residual=0)
    def actors():
        result = snapshot()
        def factor(obs, deterministic=False):
            calls["factor"] += 1
            return torch.full((len(obs["state"]), 1), 3, dtype=torch.long)
        def residual(obs, deterministic=False):
            calls["residual"] += 1
            return (obs["previous_residual"]+.18).clamp(-.8,.8)
        result["factor"].act = factor
        result["residual"].act = residual
        return result
    session.learner.actor_snapshot = actors
    return service, session, now, calls


def switch(service, mode, **kwargs):
    return service._handle_control(dict(type="control", mode=mode, **kwargs))


def assert_selected_poses(session, result):
    plan = session.active
    observed, valid = residual_target(torch.tensor(plan["reference"][...,:16].reshape(32,2,4,4)),
                                     torch.tensor(result[0]), session.config)
    assert valid.all()
    torch.testing.assert_close(observed,plan["residual_action"].expand(32,-1),atol=5e-5,rtol=1e-3)
    np.testing.assert_array_equal(result[1],plan["reference"][...,16])


def test_three_modes_only_selected_actions_enter_replay_and_keep_parent_chain(tmp_path):
    service, session, now, calls = make(tmp_path)
    try:
        first = get(service,now,100.,0.)
        epoch, old = session.epoch, session.active
        assert old["factor"] == 1. and old["residual_action"].count_nonzero() == 0
        assert calls == dict(factor=0,residual=0)
        switch(service,"speed")
        assert session.epoch == epoch and session.active is old and session.transitions == 0
        assert service.get_action(seed=42) is None  # do not recycle an already adopted observation
        second = get(service,now,100.+16/30,16/30)
        assert session.active["parent"] == old["id"] and session.active["factor"] == 2.
        assert session.active["residual_action"].count_nonzero() == 0
        assert calls == dict(factor=1,residual=0)
        switch(service,"full")
        third = get(service,now,100.+32/30,32/30)
        assert calls == dict(factor=2,residual=1)
        assert session.active["factor"] == 2.
        torch.testing.assert_close(session.active["residual_action"],torch.full((1,12),.18))
        assert_selected_poses(session,third)
        now[0] += .2
        session.handle(dict(type="outcome",outcome="success"))
        factor = session.buffers["factor"].snapshot()
        residual = session.buffers["residual"].snapshot()
        assert [r[0]["action"].item() for r in factor] == [1,3,3]
        assert [q["control_mode"] for q in session.transition_quality] == ["base","speed","full"]
        assert [q["factor_source"] for q in session.transition_quality] == ["fixed_1x","double_dqn","double_dqn"]
        for i, (f,r) in enumerate(zip(factor,residual)):
            torch.testing.assert_close(f[0]["reward"],r[0]["reward"])
            torch.testing.assert_close(f[0]["discount"],r[0]["discount"])
            torch.testing.assert_close(r[0]["action"],torch.full((1,12),.18 if i==2 else 0.))
        assert residual[-1][0]["terminated"].item() == 1
        assert session.transitions == 3
    finally:
        service.close()


def test_residual_release_uses_adopted_actions_not_cache_or_prefetch(tmp_path):
    service,session,now,_ = make(tmp_path,"full")
    try:
        for i in range(5):
            assert get(service,now,100.+i*16/30,i*16/30) is not None
        old = session.active
        torch.testing.assert_close(old["residual_action"],torch.full((1,12),.8))
        switch(service,"base")
        before = session.accepted
        for j, expected in enumerate((.6,.4,.2,0.),start=5):
            result = get(service,now,100.+j*16/30,j*16/30)
            assert result is not None
            torch.testing.assert_close(session.active["residual_action"],torch.full((1,12),expected),atol=1e-6,rtol=0)
            assert_selected_poses(session,result)
            assert session.active["factor"] == 1.
            selected = session.active
            np.testing.assert_array_equal(service.get_action(seed=42)[0],result[0])
            assert session.active is selected
        assert session.accepted == before+4
        assert not session.control_status()["releasing"]
        rows = session.buffers["residual"].snapshot()
        for row,_ in rows:
            assert (row["action"]-row["obs"]["previous_residual"]).abs().max() <= .200001
        assert any(q["residual_releasing"] for q in session.transition_quality)
        assert all(q["blend_steps"] == 8 and q["execute_steps"] == 16 for q in session.transition_quality)
    finally:
        service.close()


def test_prefetched_release_does_not_advance_until_delivered(tmp_path):
    service,session,now,_ = make(tmp_path,"full")
    try:
        for i in range(3): get(service,now,100.+i*.5,i*.5)
        old=session.active
        switch(service,"speed")
        service.start_async()
        # Selection waits for fresh observations rather than republishing old timestamps.
        assert service.get_latest_action()["result"] is None
        now[0] += .5; service.add_obs_frame(frame(service.policy,1.5)[0])
        until(lambda: service.latest_result)
        candidate=session.pending[service.latest_result["_rl_chunk_id"]]
        torch.testing.assert_close(candidate["residual_action"],old["residual_action"]-.2)
        now[0] += .1; service.add_obs_frame(frame(service.policy,1.6)[0])
        until(lambda: service.latest_result["observation_timestamp"] == 1.6)
        candidate=session.pending[service.latest_result["_rl_chunk_id"]]
        torch.testing.assert_close(candidate["residual_action"],old["residual_action"]-.2)
        assert session.active is old and session.transitions == 2
        result=service.get_latest_action()["result"]
        assert result is not None and session.active["id"] == candidate["id"]
        assert session.transitions == 3
    finally:
        service.close()


def test_switch_discards_ready_async_cache_and_recomputes_same_unadopted_observation(tmp_path):
    service,session,now,_=make(tmp_path,"full")
    try:
        service.add_obs_frame(frame(service.policy,0.)[0]); service.start_async()
        until(lambda: service.latest_result)
        stale=service.latest_result.copy(); oldid=stale["_rl_chunk_id"]
        assert session.accepted == 0
        switch(service,"base")
        result=until(lambda: service.get_latest_action(stale["sequence"])["result"])
        assert result["generation"] > stale["generation"]
        assert result["sequence"] > stale["sequence"]
        assert oldid not in session.pending and oldid not in session.delivered
        assert session.accepted == 1 and session.transitions == 0
        assert session.active["factor"] == 1. and session.active["residual_action"].count_nonzero() == 0
        assert session.active["control_revision"] == 1
    finally:
        service.close()


@pytest.mark.parametrize("asynchronous",[False,True])
def test_switch_during_inference_never_delivers_old_mode_or_resets_episode(tmp_path,asynchronous):
    service,session,now,_=make(tmp_path,"full")
    started,release=threading.Event(),threading.Event()
    predict=session.foundation.predict
    first=[True]
    def blocked(*args,**kwargs):
        if first[0]:
            first[0]=False; started.set(); assert release.wait(5.)
        return predict(*args,**kwargs)
    result=[]; errors=[]; worker=None
    try:
        session.foundation.predict=blocked
        epoch=session.epoch
        service.add_obs_frame(frame(service.policy,0.)[0])
        def call():
            try: result.append(service.get_action(seed=42))
            except Exception as exc: errors.append(exc)
        if asynchronous: service.start_async()
        else:
            worker=threading.Thread(target=call); worker.start()
        assert started.wait(3.)
        switch(service,"base")
        switch(service,"speed")
        switch(service,"base")
        assert session.epoch == epoch
        now[0] += .1; release.set()
        if asynchronous:
            output=until(lambda: service.get_latest_action()["result"])
            assert output is not None and service.enabled
        else:
            worker.join(5.); assert not worker.is_alive() and not errors and result == [None]
            assert service.get_action(seed=42) is not None
        assert session.active["control_mode"] == "base" and session.active["control_revision"] == 3
        assert session.accepted == 1 and session.transitions == 0
        assert all(p["control_revision"] == 3 for p in session.pending.values())
    finally:
        release.set()
        if worker: worker.join(5.)
        service.close()


def test_switch_after_compute_before_delivery_is_rejected(tmp_path):
    service,session,now,_=make(tmp_path,"full")
    predict=service._predict
    def computed(*args,**kwargs):
        result=predict(*args,**kwargs)
        switch(service,"base")
        return result
    service._predict=computed
    try:
        assert get(service,now,100.,0.) is None
        assert session.accepted == session.transitions == 0
        service._predict=predict
        assert service.get_action(seed=42) is not None
        assert session.active["control_mode"] == "base"
    finally:
        service.close()


def test_control_inbox_cli_dedup_rejection_and_restart_eof(tmp_path,monkeypatch):
    service,session,now,_=make(tmp_path)
    inbox=tmp_path/"control.jsonl"
    append_event(inbox,dict(type="control",mode="full"))
    reader=start_control_reader(inbox,service)
    try:
        assert session.control_revision == 0
        args=["--output",str(inbox),"--control-mode","speed","--event-id","request-1","--epoch",session.epoch]
        control_cli(args); until(lambda: session.control_mode == "speed")
        revision=session.control_revision
        control_cli(args)
        append_event(inbox,dict(type="control",mode="bad"))
        until(lambda: session.last_warning and "base/speed/full" in session.last_warning)
        assert session.control_revision == revision and session.error is None
        with pytest.raises(ValueError,match="different content"):
            switch(service,"full",event_id="request-1",epoch=session.epoch)
        with pytest.raises(ValueError,match="different episode"):
            switch(service,"full",epoch="old")
        inputs=iter(["3","bad","1","q"])
        monkeypatch.setattr("builtins.input",lambda _:next(inputs))
        control_cli(["--output",str(inbox),"--interactive"])
        until(lambda: session.control_revision == 3)
        assert session.control_mode == "base"
        rows=[json.loads(line) for line in inbox.read_text().splitlines()]
        assert rows[-1]["mode"] == "base" and rows[-2]["mode"] == "full"
        assert rows[-1]["event_id"] != rows[-2]["event_id"]
    finally:
        reader.close(); service.close()


def test_background_training_continues_in_every_mode_and_replay_resumes(tmp_path,monkeypatch):
    service,session,now,_=make(tmp_path)
    trainer=None
    try:
        get(service,now,100.,0.)
        trainer=OnlineLearner(session,tmp_path,warmup=1,batch_size=2,save_every=1)
        for i,mode in enumerate(("base","speed","full"),start=1):
            switch(service,mode)
            get(service,now,100.+i*.5,i*.5)
            until(lambda: session.learner.versions["factor"] >= i and session.learner.versions["residual"] >= i)
        trainer.close(); trainer=None
        assert session.learning_error is None
        assert all(p.grad is None for p in session.foundation.parameters())
        replay=load_replay(tmp_path/"replay_latest.pt",session.config,session.bindings)
        assert len(replay["factor"]) == len(replay["residual"]) == 3
        assert [q["control_mode"] for q in replay["factor"].quality] == ["base","base","speed"]
        for row,_ in replay["residual"].snapshot(): assert row["action"].count_nonzero() == 0
        saved=ChunkDDQNSAC.load(tmp_path/"sac_latest.pt",bindings=session.bindings)
        assert saved.versions == session.learner.versions
        import rl_chunk_service.train as cli
        monkeypatch.setattr(cli,"artifact_bindings",lambda *args:(session.bindings,session.config.token_dim))
        cli.main(["--stage","rl","--base","unused","--token","unused","--device","cpu",
                  "--resume",str(tmp_path/"sac_latest.pt"),"--replay",str(tmp_path/"replay_latest.pt"),
                  "--output",str(tmp_path/"offline"),"--steps","1","--batch-size","2"])
        restored=ChunkDDQNSAC.load(next((tmp_path/"offline").glob("*.pt")))
        assert restored.versions == {k:v+1 for k,v in saved.versions.items()}
    finally:
        if trainer: trainer.close()
        service.close()


def test_recorded_raw_batch_modes_and_unmodified_rpc_signatures(tmp_path):
    service,session,now,_=make(tmp_path,raw=True)
    from e2vla_async.remote_service import Service as Original
    try:
        obs,recorded=frame(service.policy)
        raw=copy.deepcopy(obs); raw.update(ee_pose=recorded,gripper=np.array([1886.,0.]))
        service.add_obs_frame(raw)
        result=service.get_action(seed=42)
        np.testing.assert_allclose(result[0][0],obs["ee_pose"],atol=2e-6)
        batch=legacy_batch(service.policy,obs)
        for i,mode in enumerate(("base","speed","full"),start=1):
            switch(service,mode); now[0] += .5
            output=service.run_inference(batch,seed=42)
            assert output.shape == (1,32,2,17) and output.dtype == torch.float32
            assert session.active["control_mode"] == mode
            assert session.active["factor"] == (1. if mode=="base" else 2.)
        info=service.get_info()
        assert info["variant"] == "no_speed" and info["protocol"] == "e2vla_lerobot_pyro_v1"
        for name in ("get_action","get_latest_action","run_inference","run_inference_numpy","start_async",
                     "pause_async","reset","set_prompt","add_obs_frame","get_status","ensemble_traj"):
            assert inspect.signature(getattr(Service,name)) == inspect.signature(getattr(Original,name))
        assert not getattr(Service._handle_control,"_pyroExposed",False)
    finally:
        service.close()


def test_manual_change_does_not_relabel_previous_terminal_or_accept_old_explicit_ack(tmp_path):
    execution=ExecutionConfig(mode="explicit")
    service,session,now,_=make(tmp_path,"full",execution=execution)
    try:
        get(service,now,100.,0.)
        stale=next(iter(session.pending))
        switch(service,"base")
        with pytest.raises(ValueError,match="no proposal"):
            session.handle(dict(type="activate",chunk_id=stale,execution_matches_proposal=True))
        assert session.transitions == session.accepted == 0
        get(service,now,100.2,.2)
        current=next(iter(session.pending))
        session.handle(dict(type="activate",chunk_id=current,execution_matches_proposal=True))
        active=session.active
        switch(service,"full")  # not yet delivered, therefore terminal belongs to base
        now[0] += .2
        session.handle(dict(type="outcome",outcome="failure"))
        assert session.transition_quality[-1]["control_mode"] == "base"
        assert session.transition_quality[-1]["chunk_id"] == active["id"]
        assert session.buffers["factor"].snapshot()[-1][0]["action"].item() == 1
        assert session.buffers["residual"].snapshot()[-1][0]["action"].count_nonzero() == 0
    finally:
        service.close()


def test_batch_switch_inflight_rejects_entire_response_and_multibatch_not_adopted(tmp_path):
    service,session,now,_=make(tmp_path,"full")
    predict=session.foundation.predict
    first=[True]
    def changed(*args,**kwargs):
        result=predict(*args,**kwargs)
        if first[0]: first[0]=False; switch(service,"base")
        return result
    try:
        batch=legacy_batch(service.policy,frame(service.policy)[0])
        session.foundation.predict=changed
        with pytest.raises(ValueError,match="mode changed"):
            service.run_inference(batch)
        assert session.accepted == session.transitions == 0
        session.foundation.predict=predict
        doubled={k:torch.cat((v,v)) if isinstance(v,torch.Tensor) else v*2 if k=="prompt_text" else v
                 for k,v in batch.items()}
        assert service.run_inference(doubled).shape == (2,32,2,17)
        assert session.accepted == session.transitions == 0
        now[0] += .5
        assert service.run_inference(batch).shape == (1,32,2,17)
        assert session.active["control_mode"] == "base"
    finally:
        service.close()


def test_remote_check_config_reports_default_base_and_rejects_inbox_collision(tmp_path,monkeypatch,capsys):
    service,session,now,_=make(tmp_path)
    try:
        import rl_factor_sac.train as bindings_module
        from rl_chunk_service.remote_service import main
        checkpoint=tmp_path/"rl.pt"; session.learner.save(checkpoint,session.bindings)
        monkeypatch.setattr(bindings_module,"artifact_bindings",lambda *args:(session.bindings,session.config.token_dim))
        common=["--checkpoint",str(tmp_path/"base"),"--token",str(tmp_path/"token.pt"),
                "--rl-checkpoint",str(checkpoint),"--task","close_box","--device","cpu",
                "--feedback",str(tmp_path/"feedback.jsonl"),"--output",str(tmp_path/"new"),"--check-config"]
        main(common)
        result=json.loads(capsys.readouterr().out)
        assert result["control_mode"] == "base" and result["control_file"] == str(tmp_path/"new/control.jsonl")
        assert result["algorithms"] == dict(factor="double_dqn",residual="continuous_sac")
        assert not (tmp_path/"new").exists()
        before=checkpoint.read_bytes()
        for path in (checkpoint,tmp_path/"feedback.jsonl",tmp_path/"new/sac_latest.pt"):
            with pytest.raises(SystemExit): main([*common,"--control-file",str(path)])
        assert checkpoint.read_bytes() == before
    finally:
        service.close()


def test_real_pyro_tcp_and_shared_memory_with_local_operator_switch(tmp_path):
    import Pyro4
    import Pyro4.naming
    from shm_transport import get_shm_proxy,run_simple_server
    from shm_transport.shm_mng import register_cleanup_this_process
    register_cleanup_this_process()
    service,session,now,_=make(tmp_path)
    inbox=tmp_path/"control.jsonl"; reader=start_control_reader(inbox,service)
    stopped=threading.Event(); errors=[]; proxies=[]
    _,ns_daemon,_=Pyro4.naming.startNS(host="127.0.0.1",port=0,enableBroadcast=False)
    ns_port=ns_daemon.sock.getsockname()[1]
    ns_thread=threading.Thread(target=ns_daemon.requestLoop,daemon=True); ns_thread.start()
    def serve():
        try:
            run_simple_server(service,"manual_test",ns_host="127.0.0.1",ns_port=ns_port,
                daemon_host="127.0.0.1",daemon_port=0,multiplex=False,
                loop_cond=lambda:not stopped.is_set(),replace_existing=False)
        except Exception as exc: errors.append(exc)
    worker=threading.Thread(target=serve,daemon=True); worker.start()
    try:
        def registered():
            if errors: raise errors[0]
            with Pyro4.locateNS(host="127.0.0.1",port=ns_port) as ns:
                return ns.list().get("manual_test")
        until(registered)
        step=0
        for tcp in (True,False):
            proxy=get_shm_proxy("manual_test",ns_host="127.0.0.1",ns_port=ns_port,
                                force_use_socket=tcp,en_arg_sh_cuda=False)
            proxies.append(proxy)
            for mode in ("base","speed","full"):
                control_cli(["--output",str(inbox),"--control-mode",mode])
                until(lambda: proxy.get_status()["rl"]["control"]["requested_mode"] == mode)
                step += 1; now[0]=100.+step*.5
                proxy.add_obs_frame(frame(service.policy,step*.5)[0])
                result=proxy.get_action(seed=42)
                assert result[0].shape == (32,2,4,4) and result[0].dtype == np.float32
                assert len(result) == 4 and result[1].shape == (32,2)
                assert proxy.get_status()["rl"]["control"]["active_mode"] == mode
            assert proxy.get_info()["variant"] == "no_speed"
        assert session.accepted == 6 and session.transitions == 5 and not errors
    finally:
        reader.close()
        for proxy in proxies: proxy._pyro_proxy._pyroRelease()
        stopped.set(); worker.join(5.)
        ns_daemon.shutdown(); ns_daemon.close(); ns_thread.join(5.)
        service.close()
    assert not worker.is_alive() and not errors
