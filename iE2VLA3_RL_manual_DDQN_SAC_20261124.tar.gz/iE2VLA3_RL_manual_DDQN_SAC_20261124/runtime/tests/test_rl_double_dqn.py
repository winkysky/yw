"""Algorithm checks beyond shape tests: DDQN targets, exploration and exact resume."""
import copy
from dataclasses import replace
import hashlib
import json
import numpy as np
import pytest
import torch
from torch import nn

from models.speed_factor import FACTORS
from rl_chunk_service.artifacts import ChunkDDQNSAC, FORMAT, ALGORITHMS
from rl_chunk_service.double_dqn import DoubleDQN, DoubleDQNConfig
from rl_chunk_service.execution import ExecutionConfig, bind_execution
from rl_factor_sac.sac import SACBranch
from test_rl_factor_sac import config, observation, transition, bindings


@pytest.fixture(autouse=True)
def threads():
    torch.set_num_threads(2)


class FixedQ(nn.Module):
    def __init__(self, values):
        super().__init__()
        self.register_buffer("values", torch.tensor(values, dtype=torch.float32)[None])

    def forward(self, obs):
        return self.values.expand(len(obs["token"]), -1)


def test_online_selects_target_evaluates_mask_terminal_and_elapsed_discount():
    learner = DoubleDQN(config())
    # Target maximum is index 2; online maximum is index 3, then index 1.
    # These disagree deliberately so a vanilla DQN backup cannot pass this test.
    learner.online = FixedQ([1., 8., 3., 99.])
    learner.target = FixedQ([4., 2., 100., 7.])
    batch = transition("factor", b=4)
    batch["next_obs"]["factor_mask"][:,3] = 0
    batch["next_obs"]["factor_mask"][3] = torch.tensor([1.,0,0,0])
    batch["reward"].fill_(1.)
    batch["discount"][:,0] = torch.tensor([.5, .25, .75, .1])
    batch["terminated"][0] = 1
    batch["truncated"][2] = 1  # time-limit transitions bootstrap
    actual = learner.target_value(batch)
    torch.testing.assert_close(actual, torch.tensor([[1.], [1.5], [2.5], [1.4]]))
    assert not actual.requires_grad


def test_epsilon_greedy_four_factors_mask_and_deterministic_inference():
    c = config()
    learner = DoubleDQN(c, factor_config=DoubleDQNConfig(epsilon_start=1., epsilon_end=1.))
    policy = learner.snapshot()
    obs = observation(c, b=2000)
    torch.manual_seed(172)
    sampled = policy.act(obs)
    assert sampled.dtype == torch.long and sampled.shape == (2000,1)
    assert set(sampled.flatten().tolist()) == {0,1,2,3}
    assert {FACTORS[i] for i in sampled.flatten().tolist()} == {.8,1.,1.5,2.}
    assert (policy.act(obs, deterministic=True) == 1).all()  # initial 1x preference
    obs["factor_mask"][:] = torch.tensor([1.,0,0,1])
    assert set(policy.act(obs).flatten().tolist()) == {0,3}
    obs["factor_mask"].zero_()
    with pytest.raises(ValueError, match="At least one"):
        policy.act(obs)


def test_target_hard_update_epsilon_schedule_and_snapshot_isolation():
    c = config()
    learner = DoubleDQN(c, factor_config=DoubleDQNConfig(
        target_update_interval=2, epsilon_start=.2, epsilon_end=.05, epsilon_decay_updates=2))
    batch = transition("factor")
    batch["reward"].fill_(3.)
    batch["terminated"].fill_(1.)
    target = copy.deepcopy(learner.target.state_dict())
    snapshot = learner.snapshot()
    snapshot_values = snapshot.online(batch["obs"]).clone()
    metrics = learner.update(batch)
    assert set(metrics) == {"q_loss", "q_mean", "target_q", "epsilon", "updates"}
    assert learner.epsilon == pytest.approx(.125)
    for k,v in learner.target.state_dict().items():
        torch.testing.assert_close(v, target[k], atol=0, rtol=0)
    assert any(not torch.equal(v,target[k]) for k,v in learner.online.state_dict().items())
    learner.update(batch)
    assert learner.epsilon == pytest.approx(.05)
    for k,v in learner.target.state_dict().items():
        torch.testing.assert_close(v, learner.online.state_dict()[k], atol=0, rtol=0)
    learner.update(batch)
    assert learner.epsilon == pytest.approx(.05)
    assert snapshot.epsilon == .2
    torch.testing.assert_close(snapshot.online(batch["obs"]), snapshot_values, atol=0, rtol=0)
    assert all(p.grad is None and not p.requires_grad for p in learner.target.parameters())
    for name in ("actor", "temperature", "log_temperature", "actor_optimizer", "temperature_optimizer"):
        assert not hasattr(learner, name)


def assert_tree_equal(left, right):
    if isinstance(left, torch.Tensor):
        torch.testing.assert_close(left, right, atol=0, rtol=0)
    elif isinstance(left, dict):
        assert left.keys() == right.keys()
        for key in left: assert_tree_equal(left[key], right[key])
    elif isinstance(left, (list,tuple)):
        assert len(left) == len(right)
        for a,b in zip(left,right): assert_tree_equal(a,b)
    else:
        assert left == right


def test_hybrid_resume_next_paired_update_exact_and_old_checkpoints_untouched(tmp_path):
    torch.manual_seed(122)
    learner = ChunkDDQNSAC(config(), factor_config=DoubleDQNConfig(target_update_interval=2))
    bind_execution(learner, ExecutionConfig())
    batch = {k+"_batch":transition(k) for k in ("factor", "residual")}
    learner.update(**batch)
    path = tmp_path/"new_rl.pt"
    learner.save(path, bindings())
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    expected = learner.update(**batch)  # second factor step copies target
    restored = ChunkDDQNSAC.load(path, bindings=bindings(), restore_rng=True)
    actual = restored.update(**batch)
    assert expected == actual and actual["factor"]["updates"] == 2
    assert_tree_equal(learner.factor.state_dict(), restored.factor.state_dict())
    assert_tree_equal(learner.residual.state_dict(), restored.residual.state_dict())
    assert restored.factor_config == learner.factor_config
    assert restored.execution == learner.execution
    assert hashlib.sha256(path.read_bytes()).hexdigest() == before
    artifact = torch.load(path, weights_only=False)
    assert artifact["format"] == FORMAT and artifact["algorithms"] == ALGORITHMS
    assert set(artifact["factor"]) == {"online", "target", "optimizer", "updates"}
    assert "actor" in artifact["residual"] and "log_temperature" in artifact["residual"]
    # No implicit conversion or writing back to prior discrete-SAC files.
    for old_format in ("ie2vla_chunk_sac_v1", "ie2vla_chunk_sac_v2"):
        old = tmp_path/(old_format+".pt")
        torch.save(dict(format=old_format), old)
        digest = hashlib.sha256(old.read_bytes()).hexdigest()
        with pytest.raises(ValueError, match="run --stage init"):
            ChunkDDQNSAC.load(old)
        assert hashlib.sha256(old.read_bytes()).hexdigest() == digest


def test_residual_still_uses_identical_continuous_sac_update():
    c = config()
    learner = ChunkDDQNSAC(c)
    assert type(learner.residual) is SACBranch
    standalone = SACBranch(c, "residual")
    standalone.load_state_dict(copy.deepcopy(learner.residual.state_dict()))
    data = transition("residual", c)
    factor_before = copy.deepcopy(learner.factor.state_dict())
    rng = torch.get_rng_state()
    expected = standalone.update(data)
    torch.set_rng_state(rng)
    actual = learner.update(residual_batch=data)
    assert actual == dict(residual=expected)
    assert_tree_equal(standalone.state_dict(), learner.residual.state_dict())
    assert_tree_equal(factor_before, learner.factor.state_dict())
    residual_before = copy.deepcopy(learner.residual.state_dict())
    learner.update(factor_batch=transition("factor", c))
    assert_tree_equal(residual_before, learner.residual.state_dict())


def test_factor_config_training_cli_and_resume_mismatch(tmp_path, monkeypatch):
    import rl_chunk_service.train as cli
    from rl_chunk_service.artifacts import save_replay
    from rl_factor_sac.replay import ReplayBuffer
    monkeypatch.setattr(cli, "artifact_bindings", lambda *args: (bindings(),16))
    common_config = tmp_path/"config.json"
    common_config.write_text(json.dumps(config().asdict()))
    cfg = replace(DoubleDQNConfig(), epsilon_start=.4, target_update_interval=2)
    factor_config = tmp_path/"factor.json"; factor_config.write_text(json.dumps(cfg.asdict()))
    common = ["--base","unused","--token","unused","--config",str(common_config),"--threads","2"]
    cli.main(["--stage","init","--output",str(tmp_path/"init"),"--factor-config",str(factor_config),*common])
    checkpoint = tmp_path/"init/sac_init.pt"
    learner = ChunkDDQNSAC.load(checkpoint, bindings=bindings())
    assert learner.factor_config == cfg
    buffers = {k:ReplayBuffer(learner.config,k) for k in ("factor","residual")}
    for name,buffer in buffers.items():
        buffer.add(transition(name,learner.config,b=1),versions=learner.versions,timestamp=0.,source="simulator")
    replay = tmp_path/"replay.pt"; save_replay(replay,buffers,bindings())
    cli.main(["--stage","rl","--resume",str(checkpoint),"--replay",str(replay),"--output",str(tmp_path/"trained"),
              "--steps","2","--batch-size","2","--save-every","2",*common])
    trained = ChunkDDQNSAC.load(tmp_path/"trained/sac_f000002_r000002.pt",bindings=bindings())
    assert trained.factor.updates == 2 and trained.factor_config == cfg
    factor_config.write_text(json.dumps(replace(cfg,epsilon_start=.6).asdict()))
    with pytest.raises(ValueError, match="Double DQN config differs"):
        cli.main(["--stage","rl","--resume",str(checkpoint),"--replay",str(replay),
                  "--factor-config",str(factor_config),"--output",str(tmp_path/"wrong"),*common])


@pytest.mark.parametrize("kwargs", [dict(epsilon_start=1.1),dict(epsilon_end=-.1),
    dict(epsilon_start=.1,epsilon_end=.2),dict(epsilon_decay_updates=0),
    dict(target_update_interval=1.5),dict(learning_rate=float("nan"))])
def test_bad_config_rejected(kwargs):
    with pytest.raises(ValueError):
        DoubleDQNConfig(**kwargs)
