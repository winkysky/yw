"""Legacy client calls with automatic 16/8 chunk accounting and separate clocks."""
import importlib
import json
import threading
import numpy as np
import pytest
import torch

from rl_chunk_service.execution import ExecutionConfig, bind_execution
from rl_chunk_service.feedback import FeedbackReader, WrenchBuffer, append_event
from rl_chunk_service.online import OnlineLearner
from rl_factor_sac.config import SACConfig
from test_e2vla_compat import frame, legacy_batch
from test_e2vla_async import until
from test_rl_chunk_service import setup as dual_setup
from test_rl_residual_service import setup as residual_setup


def make(tmp_path, branch="residual", **kwargs):
    factory = dual_setup if branch == "dual" else residual_setup
    return factory(tmp_path, mode="train", execution=kwargs.pop("execution", ExecutionConfig()), **kwargs)


def get(service, now, server_time, client_time, **kwargs):
    now[0] = server_time
    service.add_obs_frame(frame(service.policy, client_time)[0])
    return service.get_action(seed=42, **kwargs)


@pytest.mark.parametrize("branch", ["dual", "residual"])
@pytest.mark.parametrize("client_start", [0., 1_790_000_000.])
def test_auto_delivery_dedup_terminal_and_sac_updates(tmp_path, branch, client_start):
    service, session, now = make(tmp_path, branch)
    try:
        first = get(service, now, 100., client_start)
        assert first[0].shape == (32, 2, 4, 4)
        np.testing.assert_allclose(first[2], client_start+np.arange(32)/30)
        old = session.active
        assert old is not None and session.accepted == 1 and session.transitions == 0
        for _ in range(3):
            repeated = service.get_action(seed=42)
            np.testing.assert_array_equal(repeated[0], first[0])
        assert session.accepted == 1 and session.transitions == 0
        second = get(service, now, 100.+16/30, client_start+16/30)
        assert second is not None and session.transitions == 1 and session.accepted == 2
        assert session.active["parent"] == old["id"]
        row = session.buffers["residual"].snapshot()[0][0]
        torch.testing.assert_close(row["next_obs"]["previous_residual"], old["residual_action"])
        assert row["discount"].item() == pytest.approx(session.config.gamma_per_second**(16/30))
        quality = session.transition_quality[0]
        assert quality["execution_assumed"] and quality["reward_missing_wrench_s"] == pytest.approx(16/30)
        assert quality["history_missing_bins"] == session.config.force_history
        now[0] += .1
        event = dict(type="outcome", timestamp=20., outcome="success", event_id="manual-1", epoch=session.epoch)
        session.handle(event)
        session.handle(event)
        session.handle(dict(type="outcome", timestamp=21., outcome="success"))
        assert session.transitions == 2 and session.ended
        terminal = session.buffers["residual"].snapshot()[-1][0]
        assert terminal["terminated"].item() == 1 and terminal["reward"].item() > 9
        metrics = session.learner.update(**{k+"_batch":b.sample(2) for k,b in session.buffers.items()})
        assert np.isfinite([v for metric in metrics.values() for v in metric.values()]).all()
        assert session.learner.versions == dict(factor=int(branch=="dual"), residual=1)
        assert all(p.grad is None for p in session.foundation.parameters())
        service.reset()
        with pytest.raises(ValueError, match="different episode"):
            session.handle(event)
        assert session.transitions == 2 and session.active is None
    finally:
        service.close()


def test_force_clock_is_separate_and_bad_feedback_does_not_latch(tmp_path):
    service, session, now = make(tmp_path)
    reader = FeedbackReader(tmp_path/"feedback.jsonl", session)
    try:
        session.handle(dict(type="wrench", timestamp=1_000_000., values=np.ones((2,6)).tolist()))
        assert session.wrench.rows[-1][0] == 100.
        now[0] += .02
        session.handle(dict(type="wrench", timestamp=1_000_000.02, values=np.ones((2,6)).tolist()))
        with pytest.raises(ValueError, match="backwards"):
            session.handle(dict(type="wrench", timestamp=9., values=np.ones((2,6)).tolist()))
        get(service, now, 100.1, 10.)
        append_event(tmp_path/"feedback.jsonl", dict(type="outcome", timestamp=1., outcome="bogus"))
        until(lambda: session.warning_count > 1)
        assert session.error is None
        assert get(service, now, 100.6, 10.5) is not None
        assert session.transitions == 1
    finally:
        reader.close(); service.close()


def test_zero_fill_preserves_measured_force_and_reports_only_gaps():
    config = SACConfig()
    buffer = WrenchBuffer(config)
    values = np.full((2,6), 20., np.float32)
    buffer.add(10., values)
    segments, missing = buffer.interval_or_zero(10., 11.)
    assert missing == pytest.approx(1-config.max_history_gap_s)
    np.testing.assert_array_equal(segments[0][2], values)
    np.testing.assert_array_equal(segments[-1][2], np.zeros((2,6)))
    history, count = buffer.history_or_zero(10.)
    assert count > 0
    np.testing.assert_array_equal(history[-1], values)


def test_configurable_lifetime_and_late_episode_outcome(tmp_path):
    service, session, now = make(tmp_path, execution=ExecutionConfig(chunk_lifetime_s=3.))
    try:
        get(service, now, 100., 20.)
        assert get(service, now, 102., 22.) is not None  # over the old 31/30 s limit
        assert session.transitions == 1
        now[0] = 110.
        session.handle(dict(type="outcome", outcome="success"))
        assert session.transitions == 2 and session.ended
        row = session.buffers["residual"].snapshot()[-1][0]
        assert row["discount"].item() == pytest.approx(session.config.gamma_per_second**3)
        assert session.transition_quality[-1]["elapsed_s"] == 3.
        assert "Late manual outcome" in (tmp_path/"proposals.jsonl").read_text()
    finally:
        service.close()


def test_expired_gap_is_discarded_and_next_parent_is_consistent(tmp_path):
    service, session, now = make(tmp_path, execution=ExecutionConfig(chunk_lifetime_s=1.))
    try:
        get(service, now, 100., 0.)
        old = session.active["id"]
        assert get(service, now, 102., 2.) is not None
        assert session.transitions == 0 and session.discarded == 1
        assert session.active["parent"] == old
        assert get(service, now, 102.5, 2.5) is not None and session.transitions == 1
    finally:
        service.close()


def test_strict_force_option_keeps_inference_waiting_without_zero_fill(tmp_path):
    service, session, now = make(tmp_path, execution=ExecutionConfig(missing_wrench="error"))
    try:
        assert get(service, now, 100., 1.) is None
        assert session.transitions == session.accepted == 0
        assert session.error is None
    finally:
        service.close()


def test_async_prefetch_is_not_execution_and_polling_is_idempotent(tmp_path):
    service, session, now = make(tmp_path)
    try:
        service.add_obs_frame(frame(service.policy, 1.)[0]); service.start_async()
        until(lambda: service.latest_result)
        assert session.accepted == session.transitions == 0
        first = service.get_latest_action()
        assert first["result"] is not None and "_rl_chunk_id" not in first["result"]
        assert session.accepted == 1
        service.get_latest_action()
        assert service.get_latest_action(first["result"]["sequence"])["result"] is None
        assert session.accepted == 1 and session.transitions == 0
        now[0] += 16/30
        service.add_obs_frame(frame(service.policy, 1.+16/30)[0])
        second = until(lambda: service.get_latest_action(first["result"]["sequence"])["result"])
        assert second is not None and session.accepted == 2 and session.transitions == 1
        service.pause_async()
        assert session.active is None and session.transitions == 1
    finally:
        service.close()


def test_async_parent_changed_inflight_recomputes_instead_of_rewriting_history(tmp_path):
    service, session, now = make(tmp_path)
    started, release = threading.Event(), threading.Event()
    predict = session.foundation.predict
    def gated(*args, **kwargs):
        if len(session.foundation.calls) == 1:
            started.set()
            assert release.wait(5.)
        return predict(*args, **kwargs)
    try:
        service.add_obs_frame(frame(service.policy, 0.)[0]); service.start_async()
        until(lambda: service.latest_result)
        session.foundation.predict = gated
        now[0] = 100.2
        service.add_obs_frame(frame(service.policy, .2)[0])
        assert started.wait(3.)
        first = service.get_latest_action()["result"]  # activate while second is computing
        old = session.active["id"]
        now[0] = 100.4; release.set()
        until(lambda: service.latest_result["sequence"] > first["sequence"])
        assert service.get_latest_action(first["sequence"])["result"] is None
        assert session.transitions == 0 and session.active["id"] == old
        result = until(lambda: service.get_latest_action(first["sequence"])["result"])
        assert result is not None and session.active["parent"] == old
        assert session.transitions == 1
    finally:
        release.set(); service.close()


@pytest.mark.parametrize("branch", ["dual", "residual"])
def test_versioned_artifacts_and_real_background_training(tmp_path, branch, monkeypatch):
    service, session, now = make(tmp_path, branch)
    trainer = None
    try:
        get(service, now, 100., 0.)
        get(service, now, 100.5, .5)
        trainer = OnlineLearner(session, tmp_path, warmup=1, batch_size=2, save_every=1)
        until(lambda: session.learner.versions["residual"] == 1)
        trainer.close(); trainer = None
        artifact = torch.load(tmp_path/"sac_latest.pt", weights_only=False)
        replay = torch.load(tmp_path/"replay_latest.pt", weights_only=False)
        assert replay["format"].endswith("_v2")
        assert artifact["format"] == ("ie2vla_chunk_ddqn_sac_v1" if branch == "dual"
                                      else "ie2vla_no_speed_residual_sac_v2")
        assert artifact["execution"] == replay["execution"] == ExecutionConfig().asdict()
        assert service.get_info()["rl"]["discount"] == "gamma_per_second_to_rpc_delivery_interval"
        assert artifact["semantics"]["discount"] == replay["semantics"]["discount"]
        assert replay["quality"][0]["reward_missing_wrench_s"] == .5
        if branch == "dual":
            from rl_chunk_service.artifacts import ChunkSAC as Learner, load_replay
        else:
            from rl_residual_service.artifacts import ResidualSAC as Learner, load_replay
        loaded = Learner.load(tmp_path/"sac_latest.pt", bindings=session.bindings)
        buffers = load_replay(tmp_path/"replay_latest.pt", session.config, session.bindings)
        bind_execution(loaded, buffers["residual"].execution)
        assert loaded.versions == session.learner.versions
        with pytest.raises(ValueError, match="semantics differ"):
            bind_execution(loaded, ExecutionConfig.legacy())
        if branch == "residual":
            assert "factor" not in artifact
        module = importlib.import_module("rl_chunk_service.train" if branch == "dual" else "rl_residual_service.train")
        monkeypatch.setattr(module, "artifact_bindings", lambda *args: (session.bindings, session.config.token_dim))
        module.main(["--stage", "rl", "--base", "unused", "--token", "unused", "--device", "cpu",
            "--resume", str(tmp_path/"sac_latest.pt"), "--replay", str(tmp_path/"replay_latest.pt"),
            "--output", str(tmp_path/"offline"), "--steps", "2", "--batch-size", "2", "--save-every", "2"])
        restored = Learner.load(next((tmp_path/"offline").glob("*.pt")), bindings=session.bindings)
        assert restored.versions["residual"] == 3 and restored.execution == ExecutionConfig().asdict()
    finally:
        if trainer is not None: trainer.close()
        service.close()


def test_feedback_cli_without_chunk_id_and_repeat_event_id(tmp_path):
    from rl_chunk_service.feedback_cli import main
    path = tmp_path/"feedback.jsonl"
    main(["--output", str(path), "--outcome", "success", "--epoch", "test", "--event-id", "manual-1"])
    event = json.loads(path.read_text())
    assert event["chunk_id"] is None and event["epoch"] == "test" and event["event_id"] == "manual-1"


def test_single_batch_auto_adopts_multi_batch_remains_proposals(tmp_path):
    service, session, now = make(tmp_path)
    try:
        obs = frame(service.policy, 0.)[0]
        batch = legacy_batch(service.policy, obs)
        assert service.run_inference(batch).shape == (1,32,2,17)
        assert session.accepted == 1
        doubled = {k:torch.cat([v,v]) if isinstance(v,torch.Tensor)
                   else v*2 if k == "prompt_text" else v for k,v in batch.items()}
        now[0] += .5
        assert service.run_inference_numpy(doubled).shape == (2,32,2,17)
        assert session.accepted == 1 and session.transitions == 0
    finally:
        service.close()


def test_config_validation():
    for kwargs in (dict(chunk_lifetime_s=0), dict(chunk_lifetime_s=float("nan")),
                   dict(blend_steps=17), dict(execute_steps=0), dict(mode="fake")):
        with pytest.raises(ValueError):
            ExecutionConfig(**kwargs)


def test_prompt_change_and_pause_keep_original_observation_receipt(tmp_path):
    service, session, now = make(tmp_path)
    try:
        get(service, now, 100., 1.)
        old_epoch = session.epoch
        now[0] = 100.1
        service.set_prompt("a different task")
        assert session.epoch != old_epoch and session.active is None
        assert service.get_action(seed=42) is not None
        assert session.active["server_anchor"] == 100.
        service.pause_async()
        now[0] = 100.2
        assert service.get_action(seed=42) is not None
        assert session.active["server_anchor"] == 100.
        service.reset()
        assert service.get_action() is None and not service.receipts
    finally:
        service.close()


def test_slow_expired_inference_warns_and_async_recovers_on_new_observation(tmp_path):
    service, session, now = make(tmp_path, execution=ExecutionConfig(chunk_lifetime_s=.5))
    predict = session.foundation.predict
    def slow_once(*args, **kwargs):
        result = predict(*args, **kwargs)
        if len(session.foundation.calls) == 1:
            now[0] += 1.
        return result
    session.foundation.predict = slow_once
    try:
        service.add_obs_frame(frame(service.policy, 0.)[0]); service.start_async()
        until(lambda: "expired" in service.get_status()["status"])
        assert service.enabled and service.error is None and session.active is None
        service.add_obs_frame(frame(service.policy, 1.)[0])
        result = until(lambda: service.get_latest_action()["result"])
        assert result is not None and session.accepted == 1
    finally:
        service.close()


@pytest.mark.parametrize("branch", ["dual", "residual"])
def test_auto_real_pyro_socket_and_shared_memory(tmp_path, branch):
    import Pyro4
    import Pyro4.naming
    from shm_transport import get_shm_proxy, run_simple_server
    from shm_transport.shm_mng import register_cleanup_this_process
    register_cleanup_this_process()
    service, session, now = make(tmp_path, branch)
    _, daemon, _ = Pyro4.naming.startNS(host="127.0.0.1", port=0, enableBroadcast=False)
    port = daemon.sock.getsockname()[1]
    nt = threading.Thread(target=daemon.requestLoop, daemon=True); nt.start()
    stop, errors, proxies = threading.Event(), [], []
    def serve():
        try:
            run_simple_server(service, "fusion_test", ns_host="127.0.0.1", ns_port=port,
                daemon_host="127.0.0.1", daemon_port=0, multiplex=False,
                loop_cond=lambda: not stop.is_set(), replace_existing=False)
        except Exception as exc:
            errors.append(exc)
    worker = threading.Thread(target=serve, daemon=True); worker.start()
    try:
        def registered():
            if errors: raise errors[0]
            with Pyro4.locateNS(host="127.0.0.1", port=port) as ns:
                return ns.list().get("fusion_test")
        until(registered)
        for i, socket in enumerate((True, False)):
            proxy = get_shm_proxy("fusion_test", ns_host="127.0.0.1", ns_port=port,
                                  force_use_socket=socket, en_arg_sh_cuda=False)
            proxies.append(proxy)
            now[0] = 100.+i*16/30
            proxy.add_obs_frame(frame(service.policy, 1_790_000_000.+i*16/30)[0])
            result = proxy.get_action(seed=42)
            np.testing.assert_array_equal(proxy.get_action(seed=42)[0], result[0])
            assert result[0].shape == (32,2,4,4) and session.accepted == i+1
            assert proxy.get_status()["rl"]["execution"]["mode"] == "auto"
            assert proxy.get_info()["protocol"] == "e2vla_lerobot_pyro_v1"
        assert session.transitions == 1 and not errors
    finally:
        for proxy in proxies: proxy._pyro_proxy._pyroRelease()
        stop.set(); worker.join(5.)
        daemon.shutdown(); daemon.close(); nt.join(5.); service.close()
    assert not worker.is_alive() and not errors
