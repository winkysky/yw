"""No-speed base, isolated residual learner and token-free protocol probes."""
import copy
from dataclasses import asdict
from types import SimpleNamespace
import json
import numpy as np
import pytest
import torch
from e2vla_compat.config import PlannerConfig
from rl_factor_sac.config import SACConfig
from rl_factor_sac.reward import RewardConfig
from rl_chunk_service.service import Service
from rl_chunk_service.execution import ExecutionConfig
from rl_chunk_service.online import OnlineLearner
from rl_residual_service.artifacts import ResidualSAC, load_replay
from rl_residual_service.session import ResidualSession
from rl_residual_service.policy import Policy
from test_rl_chunk_service import Foundation, collator, force, activate
from test_e2vla_compat import FakePolicy, frame, legacy_batch
from test_e2vla_async import until


@pytest.fixture(autouse=True)
def threads():
    torch.set_num_threads(2)


def setup(tmp_path, mode="zero", **kwargs):
    old=FakePolicy(); now=[100.]
    execution=kwargs.pop("execution", ExecutionConfig.legacy())
    c=SACConfig(token_dim=16,hidden_dim=32)
    diagnostic=mode in ("zero","probe")
    learner=ResidualSAC(c,probe_only=diagnostic)
    session=ResidualSession(Foundation(old.config),learner,
        dict(base_sha256="a"*64,token_sha256="b"*64,reward_config=asdict(RewardConfig())),
        mode="inference" if diagnostic else mode,source="simulator",clock=lambda:now[0],
        probe_mode=mode if diagnostic else None,journal=tmp_path/"proposals.jsonl",
        dump_path=tmp_path/"last_prediction.npz",execution=execution,**kwargs)
    settings=PlannerConfig(task="close_box",prompt="close the box",input_pose_format="tcp_world",input_gripper_format="openness")
    policy=Policy(settings,session,old.native_info,collator)
    return Service(policy,settings),session,now


@pytest.mark.parametrize("mode,arm,axis,mm",[("zero","left","x",0.),("probe","left","x",.25),
                                          ("probe","right","z",-.4)])
def test_token_free_modes_exact_offset_and_no_training(tmp_path,mode,arm,axis,mm):
    s,session,now=setup(tmp_path,mode,probe_arm=arm,probe_axis=axis,probe_mm=mm or .25)
    try:
        s.add_obs_frame(frame(s.policy)[0]); result=s.get_action(seed=42)
        assert result[0].shape==(32,2,4,4)
        plan=next(iter(session.pending.values()))
        base=plan["reference"][...,:16].reshape(32,2,4,4)
        local=(base[...,:3,:3].swapaxes(-1,-2)@(result[0][...,:3,3]-base[...,:3,3])[...,None])[...,0]
        expected=np.zeros_like(local);expected[:,0 if arm=="left" else 1,"xyz".index(axis)]=mm/1000
        np.testing.assert_allclose(local,expected,atol=2e-7)
        np.testing.assert_array_equal(base[...,:3,:3],result[0][...,:3,:3])
        np.testing.assert_array_equal(result[1],plan["reference"][...,16])
        assert plan["factor"]==1. and session.learner.versions==dict(factor=0,residual=0)
        assert set(session.buffers)=={"residual"} and session.transitions==0
        assert s.get_info()["rl"]["diagnostic_only"]
        with pytest.raises(ValueError,match="Probe"):
            session.handle(dict(type="activate"))
        with pytest.raises(ValueError,match="probes"):
            session.learner.update(residual_batch={})
        with pytest.raises(ValueError,match="Diagnostic"):
            session.learner.save(tmp_path/"bad.pt",session.bindings)
        with pytest.raises(ValueError,match="Probe"):
            session.save_replay(tmp_path/"bad_replay.pt")
        assert s.run_inference_numpy(legacy_batch(s.policy,frame(s.policy)[0])).shape==(1,32,2,17)
        from rl_residual_service.inspect_dump import main
        main([str(tmp_path/"last_prediction.npz"),"--expect-mm",str(mm),"--arm",arm,"--axis",axis])
        s.start_async(); r=until(lambda:s.get_latest_action()["result"])
        assert r["times"][0]==100.
    finally:s.close()


def test_native_token_windows_use_original_rows_only():
    from rl_residual_service.dataset import NativeTokenDataset
    c=dict(timestamp=np.arange(90)/30.,task_index=np.r_[np.zeros(50),np.ones(40)],
           state_pose=np.arange(90*2*4*4).reshape(90,2,4,4),state_gripper=np.zeros((90,2)),
           action_pose=np.arange(90*2*4*4).reshape(90,2,4,4)+1000,action_gripper=np.ones((90,2)))
    d=NativeTokenDataset.__new__(NativeTokenDataset)
    d.readers=[];d.blocks=[];d.ends=[];d.counts={"1.0":0};d.config=SimpleNamespace(num_history_states=1)
    d.columns=lambda reader,ep:c
    reader=object();d._add(reader,0,np.arange(90),None,"episode")
    assert len(d.blocks)==1 and d.blocks[0]["factor"]==1.
    np.testing.assert_array_equal(d.blocks[0]["frames"],np.r_[np.arange(19),np.arange(50,59)])
    sample=d.numeric_sample(0)
    np.testing.assert_array_equal(sample["action_pose"],c["action_pose"][:32])
    np.testing.assert_array_equal(sample["history_pose"],c["state_pose"][:1])


from test_lerobot_original import local_qwen


def test_no_speed_real_model_parity_token_training_and_residual_init(local_qwen,monkeypatch,tmp_path):
    from models.m0512_fm import vla
    from models.m0512_fm.train_lerobot_dual import build_model
    from models.m0512_fm.lerobot_distributed import FORMAT
    from models.m0512_fm.lerobot_inference import infer_batch
    from test_lerobot_dual import synthetic_batch
    from data_utils.tokenize import ModalityType
    from rl_residual_service.foundation import NoSpeedFoundation
    from rl_factor_sac.foundation import decode_prediction
    from rl_factor_sac.io import atomic_save
    from rl_factor_sac.token import TokenConfig
    from rl_residual_service.train_token import main as train_token
    from rl_residual_service.train import main as train_sac
    import rl_residual_service.dataset as dataset_module
    import dataset.lerobot_original as dataset_original
    import rl_residual_service.policy as policy_module
    monkeypatch.setattr(vla,"vla_base",lambda inference_timesteps:vla.VLA(64,1,1,inference_timesteps))
    model=build_model("base",inference_timesteps=2,train_qwen=True).eval()
    data,_=synthetic_batch(horizon=32,idim=64)
    ids=torch.tensor([[62,60,60,63]*3+[1,2]]).repeat(2,1)
    data.tokenized_vl=dict(input_ids=ids,attention_mask=torch.ones_like(ids),
        pixel_values=torch.randn(48,3*2*16*16),image_grid_thw=torch.tensor([[1,2,4]]).repeat(6,1))
    data.modality=torch.where(ids==60,ModalityType.VISION,ModalityType.LANGUAGE)
    base=tmp_path/"base";base.mkdir()
    cfg=FakePolicy().config
    atomic_save(dict(format=FORMAT,step=1,world_size=1,model_config=dict(model="base",inference_timesteps=2,train_qwen=True),
        data_config=cfg.to_dict(),dataset_fingerprint="test",model=model.state_dict()),base/"model.pt")
    (base/"complete.json").write_text(json.dumps(dict(format=FORMAT,step=1,world_size=1)))
    foundation=NoSpeedFoundation.load(base)
    generator=torch.Generator().manual_seed(12)
    prepared=foundation.encode(data)
    actual=foundation.predict(prepared,initial_noise=torch.randn(2,2,32,80,generator=generator))
    expected=decode_prediction(infer_batch(foundation.base,data,torch.device("cpu"),seed=12))
    torch.testing.assert_close(actual,expected,atol=0,rtol=0)
    with pytest.raises(ValueError,match="tempo"):foundation.predict(prepared,1.5)

    class Episodes:
        def __init__(self,c):
            self.fingerprint="native-test-only";self.blocks=[dict(episode_key=f"episode{i}") for i in range(20)]
            self.ends=list(range(1,21))
        def __len__(self):return 20
        def __getitem__(self,i):return i
        def close(self):pass
    class Collator:
        def __init__(self,p):pass
        def __call__(self,items):return data.deepcopy().__dict__
    monkeypatch.setattr(dataset_module,"NativeTokenDataset",Episodes)
    monkeypatch.setattr(dataset_original,"LeRobotOriginalCollator",Collator)
    tc=TokenConfig(memory_dim=64,hidden_dim=32,token_dim=16,layers=1,reconstruction_per_modality=2)
    token_config=tmp_path/"token.json";token_config.write_text(json.dumps(asdict(tc)))
    common=["--base",str(base),"--token-config",str(token_config),"--device","cpu","--workers","0", "--threads","2",
            "--batch-size","2","--save-every","1","--validate-every","1","--validation-batches","1","--validation-fraction",".5"]
    train_token(["--output",str(tmp_path/"tokens"),"--steps","2",*common])
    train_token(["--output",str(tmp_path/"split"),"--steps","1",*common])
    train_token(["--output",str(tmp_path/"split"),"--steps","2","--resume",str(tmp_path/"split/token_000001.pt"),*common])
    token=tmp_path/"tokens/token_000002.pt"
    full=torch.load(token,weights_only=False);resume=torch.load(tmp_path/"split/token_000002.pt",weights_only=False)
    for k,v in full["token"].items():torch.testing.assert_close(v,resume["token"][k],atol=0,rtol=0)
    sac_config=SACConfig(token_dim=16,hidden_dim=32,max_command_speed_mps=1e6,max_command_angular_speed=1e6)
    sc=tmp_path/"sac.json";sc.write_text(json.dumps(asdict(sac_config)))
    train_sac(["--stage","init","--base",str(base),"--token",str(token),"--config",str(sc),"--output",str(tmp_path/"sac")])
    # Load one real no-speed model through the production policy factory, without
    # RL token/SAC artifacts for zero/probe, and with them for training.
    one=data.deepcopy();one.raw_vl=one.raw_vl[:1]
    for key in ("state","state_mask","action","action_mask","action_ref_pose","modality"):
        setattr(one,key,getattr(one,key)[:1])
    one.patch_pose=one.patch_pose[:6];one.patch_norm_xy=one.patch_norm_xy[:6]
    one.tokenized_vl={k:v[:24 if k=="pixel_values" else 3 if k=="image_grid_thw" else 1] for k,v in one.tokenized_vl.items()}
    monkeypatch.setattr(policy_module,"LeRobotOriginalCollator",lambda _:lambda samples:one.deepcopy().__dict__)
    settings=PlannerConfig(checkpoint=str(base),task="close_box",device="cpu",prompt="test",
        input_pose_format="tcp_world",input_gripper_format="openness")
    for mode in ("zero","probe","train"):
        diagnostic=mode!="train"
        probe_config=SACConfig(max_command_speed_mps=1e6,max_command_angular_speed=1e6)
        policy=Policy.load(settings,mode=mode,sac_config=probe_config if diagnostic else None,
                          token=None if diagnostic else token,sac=None if diagnostic else tmp_path/"sac/residual_init.pt",
                          source="simulator", execution=ExecutionConfig.legacy())
        session=policy.session;session.clock=lambda:100.
        assert not any(p.requires_grad for p in session.foundation.parameters())
        if not diagnostic:force(session,100.)
        s=Service(policy,settings)
        try:
            s.add_obs_frame(frame(policy)[0]);out=s.get_action(seed=12)
            assert out[0].shape==(32,2,4,4)
            if diagnostic:
                plan=next(iter(session.pending.values()))
                assert not plan["residual_obs"]["token"].any()
            else:
                chunk=next(iter(session.pending));activate(session,chunk,100.)
                session.clock=lambda:100.2;force(session,100.2)
                session.handle(dict(type="outcome",timestamp=100.2,chunk_id=chunk,outcome="success"))
                replay=tmp_path/"real_replay.pt";session.save_replay(replay)
                train_sac(["--stage","rl","--base",str(base),"--token",str(token),
                    "--resume",str(tmp_path/"sac/residual_init.pt"),"--replay",str(replay),
                    "--steps","1","--batch-size","2","--output",str(tmp_path/"trained")])
                trained=ResidualSAC.load(tmp_path/"trained/residual_000001.pt",bindings=session.bindings)
                assert trained.versions==dict(factor=0,residual=1)
        finally:s.close()


def test_residual_probe_real_pyro_transport(tmp_path):
    import threading
    import Pyro4
    import Pyro4.naming
    from shm_transport import get_shm_proxy,run_simple_server
    from shm_transport.shm_mng import register_cleanup_this_process
    register_cleanup_this_process()
    s,session,now=setup(tmp_path,"probe")
    _,daemon,_=Pyro4.naming.startNS(host="127.0.0.1",port=0,enableBroadcast=False)
    port=daemon.sock.getsockname()[1]
    nt=threading.Thread(target=daemon.requestLoop,daemon=True);nt.start()
    stop=threading.Event();errors=[]
    def run():
        try:run_simple_server(s,"residual_test",ns_host="127.0.0.1",ns_port=port,daemon_host="127.0.0.1",
                              daemon_port=0,multiplex=False,replace_existing=False,loop_cond=lambda:not stop.is_set())
        except Exception as exc:errors.append(exc)
    worker=threading.Thread(target=run,daemon=True);worker.start();proxies=[]
    try:
        def ready():
            if errors:raise errors[0]
            with Pyro4.locateNS(host="127.0.0.1",port=port) as ns:return ns.list().get("residual_test")
        until(ready)
        for tcp in (True,False):
            proxy=get_shm_proxy("residual_test",ns_host="127.0.0.1",ns_port=port,force_use_socket=tcp,en_arg_sh_cuda=False)
            proxies.append(proxy)
            if tcp:proxy.add_obs_frame(frame(s.policy)[0])
            result=proxy.get_action(seed=42)
            plan=next(iter(session.pending.values()))
            np.testing.assert_array_equal(result[0],plan["actions"][...,:16].reshape(32,2,4,4))
            assert proxy.get_info()["rl"]["diagnostic_only"]
            assert proxy.run_inference_numpy(legacy_batch(s.policy,frame(s.policy)[0])).shape==(1,32,2,17)
        assert session.transitions==0
    finally:
        for proxy in proxies:proxy._pyro_proxy._pyroRelease()
        stop.set();worker.join(5.);daemon.shutdown();daemon.close();nt.join(5.);s.close()
    assert not worker.is_alive() and not errors


def test_only_residual_learns_and_saves_with_measured_feedback(tmp_path):
    s,session,now=setup(tmp_path,"train")
    try:
        assert not hasattr(session.learner.factor,"critic")
        s.add_obs_frame(frame(s.policy)[0]);assert s.get_action() is None
        force(session,100.);s.get_action();p=next(reversed(session.pending));activate(session,p,100.)
        now[0]=100.5;force(session,100.5);s.add_obs_frame(frame(s.policy,100.5)[0]);s.get_action()
        q=next(reversed(session.pending));activate(session,q,100.5)
        assert session.transitions==1 and set(session.buffers)=={"residual"}
        before=copy.deepcopy(session.learner.residual.actor.state_dict())
        trainer=OnlineLearner(session,tmp_path,warmup=1,batch_size=2,save_every=1)
        try:until(lambda:session.learner.residual.updates==1)
        finally:trainer.close()
        assert session.learner.versions==dict(factor=0,residual=1)
        assert any(not torch.equal(v,session.learner.residual.actor.state_dict()[k]) for k,v in before.items())
        replay=load_replay(tmp_path/"replay_latest.pt",session.config,session.bindings)
        assert set(replay)=={"residual"} and len(replay["residual"])==1
        saved=torch.load(tmp_path/"sac_latest.pt",weights_only=False)
        assert "factor" not in saved
        restored=ResidualSAC.load(tmp_path/"sac_latest.pt",bindings=session.bindings,restore_rng=True)
        batch=replay["residual"].sample(2);rng=torch.get_rng_state()
        first=session.learner.update(residual_batch=batch)
        torch.set_rng_state(rng)
        assert restored.update(residual_batch=batch)==first
        assert all(p.grad is None for p in session.foundation.parameters())
    finally:s.close()
