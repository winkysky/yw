#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"
exec "${IE2VLA_PYTHON:-/home/hq/miniconda3/envs/ie2vla3/bin/python}" -u \
  -m models.m0512_fm.service_lerobot --start-ns "$@"
