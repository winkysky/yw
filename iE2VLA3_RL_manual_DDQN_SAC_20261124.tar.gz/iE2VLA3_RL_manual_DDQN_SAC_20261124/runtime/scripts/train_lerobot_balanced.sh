#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"
export TOKENIZERS_PARALLELISM=false
export HF_HUB_OFFLINE=1
export PYTHONUNBUFFERED=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
exec "${IE2VLA_PYTHON:-/home/hq/miniconda3/envs/ie2vla3/bin/python}" \
  -m models.m0512_fm.train_lerobot_dual \
  --data-config "$PWD/configs/lerobot_balanced_20261122/data_config.json" \
  --nproc-per-node 4 --batch-size 4 --gradient-accumulation-steps 2 \
  --max-steps 100000 --save-every 10000 \
  --output /nas_data_new/hq/98qwenvla/lerobot_original_full_balanced_h32_20261122 \
  "$@"
