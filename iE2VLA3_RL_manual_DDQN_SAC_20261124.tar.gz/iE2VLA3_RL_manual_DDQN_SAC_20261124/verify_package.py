"""Check the shipped payload using only Python's standard library."""
import hashlib
import json
from pathlib import Path, PurePosixPath


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "PACKAGE_MANIFEST.json").read_text())
    failures = []
    for name, meta in manifest["files"].items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Invalid manifest path")
        path = root / name
        if path.is_symlink() or not path.is_file():
            failures.append(name + ": missing/not a regular file")
        elif path.stat().st_size != meta["bytes"] or hashlib.sha256(path.read_bytes()).hexdigest() != meta["sha256"]:
            failures.append(name + ": size/hash mismatch")
    if failures:
        raise SystemExit("\n".join(failures))
    print(json.dumps(dict(status="verified", files=len(manifest["files"]), weights_included=False)))


if __name__ == "__main__":
    main()
