# iE2VLA3 RL 迁移包：Double DQN、连续 SAC 与人工切换

打包日期：2026-11-24。本包包含当前完整 RL 源码、RL token 编码/解码及训练、两版 Pyro4 服务、ROS 2 桥接、必要模型/数据/通信依赖、测试和启动说明。最新完整服务支持 `base / speed / full` 人工选择，后台继续训练，回放记录实际返回的倍率和残差。**不包含任何 checkpoint、Qwen 权重、数据集、运行回放、训练日志或机器专用软链接。**

推荐独立解压并从 `runtime/` 运行，直接引用目标服务器已有权重的绝对路径。无需覆盖旧代码、修改客户端或把运行中的模型移走。复制本包不等于启动或切换服务。

## 先确认已有权重属于哪条路径

| 已有文件 | 使用入口 | 支持内容 |
|---|---|---|
| 无速度基础 VLA，格式 `lerobot_original_full_v2` | `rl_residual_service.remote_service` | 无 token 时用 zero/probe 测接口；有匹配 token/残差 SAC 时，可只训练残差 |
| 四倍率 VLA，格式 `lerobot_factor_full_v3`，以及匹配 token | `rl_chunk_service.remote_service` | 最新 Double DQN 倍率＋连续 SAC 残差；三种人工选择 |
| 当前 `ie2vla_chunk_ddqn_sac_v1` RL 权重 | 上一行服务 | 可以继续加载，不因人工切换而改变网络形状或权重格式 |
| 旧 `ie2vla_chunk_sac_v1/v2` 离散 SAC 权重 | 不直接载入最新 DDQN 服务 | 使用原倍率 VLA/token，在新目录初始化 DDQN/SAC；保留旧权重 |

**三种人工模式里的 base 是“同一个倍率 VLA 的 1x 推理”，不会让旧无速度 checkpoint 获得调速能力。** 如果目前只有之前上传的无速度模型，先执行下面的 zero/probe 路径；该路径没有三种人工模式。

本次重新与之前的 `iE2VLA3_full_code_e2vla_recorded_raw_no_ckpt_20261118_010237.zip` 比较：13 个核心模型、推理及原协议文件 SHA256 相同，`build_model` 函数 AST 相同。与 2026-11-23 RL 包的逐文件差异也已记录，见 [兼容核对报告](OLD_PACKAGE_COMPATIBILITY.json)。这证明已核对的代码契约未改变；目标机器上的环境、权重是否齐全及客户端本地改动仍需按下面步骤验证。

## 解压、校验与环境

```bash
sha256sum -c iE2VLA3_RL_manual_DDQN_SAC_20261124.tar.gz.sha256
tar -xzf iE2VLA3_RL_manual_DDQN_SAC_20261124.tar.gz
cd iE2VLA3_RL_manual_DDQN_SAC_20261124
python3 verify_package.py
conda activate ie2vla3
```

沿用之前已经能运行模型的 Python/CUDA 环境。[ENVIRONMENT_VERSIONS.json](ENVIRONMENT_VERSIONS.json) 记录本次实际验证版本，[requirements_rl_reference.txt](requirements_rl_reference.txt) 是依赖参考，不是要求覆盖现有 PyTorch/CUDA。验证环境为 Python 3.10.19、PyTorch 2.9.1、Transformers 4.57.3、PEFT 0.17.1、Pyro4 4.82。PEFT 即使关闭 LoRA 也需要，因为原 VLM 模块会导入它。ROS 2 桥接可用已 source ROS 的系统 Python，与模型 Conda 环境分开。

原模型构造器仍会加载 `Qwen/Qwen3-VL-2B-Instruct`，再载入完整机器人 checkpoint。需要目标机器已有的**完整 Qwen 模型/processor/tokenizer 目录或 Hugging Face 缓存**，本包没有这些权重。使用本地目录时，在尚未存在该链接的新解压目录中执行：

```bash
mkdir -p runtime/Qwen
ln -s /目标机器上完整Qwen目录的绝对路径 runtime/Qwen/Qwen3-VL-2B-Instruct
```

若原 Hugging Face 缓存已完整，沿用原环境变量即可，不必建立链接。目标服务器断网时可设置 `HF_HUB_OFFLINE=1`，前提是缓存完整。不要把只有 config 的目录当成完整 Qwen 目录。

后续命令均从本包 `runtime/` 执行：

```bash
cd runtime
python -m rl_chunk_service.remote_service --help
python -m rl_residual_service.remote_service --help
python3 -m rl_chunk_service.control_cli --help
```

子目录 README 中示例的 `/home/hq/code/iE2VLA3` 均替换为本机解压后的 `runtime/`；训练数据和输出绝对路径也需要按目标机器设置。不要从旧代码根目录运行本包模块，以免 Python 导入旧文件。

## 只有之前的无速度模型：先验证客户端接口

仅需完整 checkpoint 的 `model.pt` 和 `complete.json`，不需要 `rank_0000` 优化器分片、不需要 token/SAC 权重、力数据或奖励。下面 `BASE` 指向目标机已有 checkpoint 目录，不复制或修改权重。

```bash
BASE=/已有无速度模型的绝对路径/step_0100000

python -m rl_residual_service.remote_service \
  --checkpoint "$BASE" --task close_box --device cuda:0 \
  --mode zero --seed 42 \
  --uri e2vla --host 127.0.0.1 --port 9101 \
  --ns-host 127.0.0.1 --ns-port 9090 --start-ns \
  --input-pose-format recorded --input-gripper-format raw \
  --dump-predictions --output runs/residual_zero_001
```

URI、地址、端口、task 填现有客户端实际配置；示例沿用旧默认值。原客户端同步、batch、异步调用以及 prompt 设置方式保持不变。若它上传的是已转换的 world TCP/openness，保持 `--input-pose-format tcp_world --input-gripper-format openness`，不能重复转换。

`--output` 使用不存在的新目录。服务名被占用时会拒绝启动，不会替你停止旧服务；先旁路验证或按现场安排切换。旁路默认地址为 `e2vla_residual:9103`，倍率服务默认 `e2vla_rl:9102`；要复用旧客户端，最终仍需使用客户端原 URI/地址/端口。

确认 zero 返回正确后，退出本测试服务，把 `--mode zero` 改为 `--mode probe`，输出目录改为 `runs/residual_probe_001`。probe 是固定左臂 TCP 局部 x 的 +0.25 mm 测试偏移，不是训练后的策略。数值检查：

```bash
python -m rl_residual_service.inspect_dump \
  runs/residual_zero_001/last_prediction.npz --expect-mm 0

python -m rl_residual_service.inspect_dump \
  runs/residual_probe_001/last_prediction.npz --expect-mm 0.25 --arm left --axis x
```

zero/probe 不训练、不生成 RL replay。正式只训练残差时，需要为该无速度模型单独训练 token，再初始化残差 SAC；完整命令见 [无速度残差服务 README](runtime/rl_residual_service/README.md)。该服务仍为连续 SAC，客户端接口不变。

## 已有倍率 VLA：启动最新人工切换与后台训练

先设置三个匹配的权重路径。若已有当前 DDQN/SAC 权重，直接设置 `RL`；若只有倍率 VLA/token，则先初始化轻量 RL 网络：

```bash
BASE=/已有四倍率VLA的绝对路径/step_0100000
TOKEN=/与该VLA匹配的绝对路径/token_020000.pt

# 仅首次没有 DDQN/SAC 权重时运行；输出使用新目录。
python -m rl_chunk_service.train --stage init \
  --base "$BASE" --token "$TOKEN" --device cpu \
  --factor-config rl_chunk_service/default_factor_config.json \
  --output /新的绝对路径/ddqn_sac_init

RL=/新的绝对路径/ddqn_sac_init/sac_init.pt
# 已有当前 RL 权重时，改为：RL=/已有绝对路径/sac_latest.pt
```

若还没有 token，先用 `python -m rl_factor_sac.train_token --base "$BASE" --output /新目录/token_run --steps 20000 --device cuda:0`。它冻结 VLA，单独训练外部 token；20000 仅为命令示例。token 与 VLA 文件 SHA256 绑定，不能拿另一个 checkpoint 的 token 混用。新服务器上的训练数据目录要存在或通过 `--data-root` 调整。

完整服务命令：

```bash
python -m rl_chunk_service.remote_service \
  --checkpoint "$BASE" --token "$TOKEN" --rl-checkpoint "$RL" \
  --task close_box --device cuda:0 \
  --uri e2vla --host 127.0.0.1 --port 9101 \
  --ns-host 127.0.0.1 --ns-port 9090 --start-ns \
  --input-pose-format recorded --input-gripper-format raw \
  --feedback /tmp/ie2vla_rl_feedback.jsonl \
  --control-file /tmp/ie2vla_rl_control.jsonl --control-mode base \
  --output /新的绝对路径/rl_manual_session_001 \
  --mode train --warmup 32 --batch-size 32 --save-every 100
```

首次可在同一命令末尾加 `--check-config`，只检查配置和权重绑定，不加载 Qwen/GPU、不创建输出目录、不注册服务。正式运行时移除它。若 RL 权重绑定了自定义 reward，须同时提供匹配的 `--reward-config`。

`--mode train` 控制是否训练，`--control-mode` 控制实际返回哪种动作；两者独立。只做确定性推理验证改为 `--mode inference`，只采集改为 `--mode collect`。异步客户端沿用原接口；可加 `--autostart --prompt '任务指令'` 启动后台推理。

服务打印 `ready` 后，在服务器另一个终端、同一 `runtime/` 下打开人工面板：

```bash
python3 -m rl_chunk_service.control_cli \
  --output /tmp/ie2vla_rl_control.jsonl --interactive
```

输入 `1 / 2 / 3` 后回车：

| 按键 | 模式 | 实际返回动作 |
|---|---|---|
| 1 | base | 固定 1x，残差逐步退回零；到零后为基础轨迹 |
| 2 | speed | Double DQN 选择 0.8 / 1 / 1.5 / 2，残差逐步退回零 |
| 3 | full | Double DQN 调速＋连续 SAC 残差 |

`q` 只关闭面板，不改变当前模式。也可单次执行 `python3 -m rl_chunk_service.control_cli --output /tmp/ie2vla_rl_control.jsonl --control-mode full`。普通 Python + NumPy 即可运行面板，不需要加载模型。

`Queued` 表示命令已写入，实际状态在原 `get_status()['rl']['control']` 中：`requested_mode` 是已接收的选择，`active_mode` 是当前已采用 chunk，`releasing` 表示残差仍在退回。命令从下一个新 chunk 生效；不会撤回客户端已经取走的轨迹。

切换会使旧服务端缓存和在途候选失效，保留 active chunk、episode、父链和奖励区间。退出残差遵守默认每个新采用 chunk 每轴 1 mm / 0.01 rad 的变化限制，最大幅度退出最多需要 5 个新 chunk。重复取结果和后台预推理不会推进退回；客户端继续原有 16 步执行、8 步融合，服务端不重复融合。

训练只记录服务器实际筛选并返回的倍率/残差，包含 base 的 1x/零残差及过渡修正；未采用的 RL 提案不会冒充执行动作。后台在三种人工模式下都继续按新闭合 transition 更新两路网络。客户端融合后的精确运动仍不可直接观测，沿用“返回即采用”的账本近似，回放保留该标记；它不等于机器人逐点执行确认。

## 力、人工结果与保存

控制文件与反馈文件分开。ROS 2 力话题、单位、坐标标定需要按目标机器填写 [ros2.example.json](runtime/rl_chunk_service/ros2.example.json)，不能直接使用里面的 REPLACE/单位阵占位。

```bash
# 另一个已 source ROS 2 环境的终端，在 runtime 下运行。
python3 -m rl_chunk_service.ros_bridge \
  --config /实际路径/ros2.actual.json \
  --output /tmp/ie2vla_rl_feedback.jsonl

# 人工任务结果；失败也要显式标注，不以 reset 代替。
python3 -m rl_chunk_service.feedback_cli \
  --output /tmp/ie2vla_rl_feedback.jsonl --outcome success

python3 -m rl_chunk_service.feedback_cli \
  --output /tmp/ie2vla_rl_feedback.jsonl --outcome failure
```

可加 `--epoch CURRENT_EPISODE_ID --event-id UNIQUE_LABEL_ID` 避免迟到/重复标注。默认自动账本不要求额外 activate；缺力补零并警告、记录质量信息，不能解释为真实零接触力。力可用时应接入真实测量。默认 `chunk-lifetime-s=5`，力/结果时钟按服务器接收时间归一化。完整细节见 [最新服务 README](runtime/rl_chunk_service/README.md)。

正常退出会保存新输出目录下的 `sac_latest.pt`、`replay_latest.pt`、`loss.jsonl` 等；不会写入原基础权重。再次启动时指定保存的 `--rl-checkpoint` 和一个新输出目录，人工模式重新从启动参数开始。训练保存格式、Double DQN 参数、离线回放入口均在上述 README 中；这次打包不改变 reward 默认值。

## 验证、完整性与迁移边界

本包源码从压缩包重新解压后，在独立目录运行全部测试；最终归档再逐文件核对，确保源码与已测试副本一致。结果见 [VALIDATION.json](VALIDATION.json)、`tests_report.xml` 和 `IMPORT_VALIDATION.json`。复现命令（在 runtime 下）：

```bash
PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 \
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \
python -m pytest -q -p no:cacheprovider tests
```

包括真实本机 Pyro4 TCP/共享内存、三种人工切换、异步缓存作废、平滑退出、采用动作回放、后台更新、恢复训练、小型真实 Qwen/VLA，以及旧无速度模型推理一致性。测试需要本机 socket/共享内存权限；生产 Qwen 权重和机器人不参与这些 CPU 测试。

本机未安装的旧参考客户端/服务测试会明确跳过；不可直接观测的部署客户端进程、目标 GPU 时延、ROS 话题及真实机器人闭环仍需现场验证。代码包不能代替这些验证。

`SOURCE_HASHES.json` 记录原样复制的源码校验值；`PACKAGE_MANIFEST.json` 记录包内文件大小和 SHA256；`verify_package.py` 不加载模型即可核对。压缩包外另附 `.sha256`。请整体迁移本包，单独复制 `rl_chunk_service` 会缺少 token、模型、数据和通信依赖。
