# iE2VLA3 完整 RL 算法与兼容服务包

打包日期：2026-11-23。包含完整 RL 算法、独立残差服务、倍率+残差服务、RL token 训练、ROS 2 反馈桥接、必要模型/数据/通信代码、测试及启动说明。**不含任何 checkpoint、Qwen 权重、数据集、运行日志或机器专用软链接。**

本包采用独立 `runtime/` 目录运行，直接引用旧模型路径。不要把它覆盖解压到旧代码目录，也不需要修改客户端或替换正在训练的代码。

## 与之前上传的代码、模型如何对接

已与 `iE2VLA3_full_code_e2vla_recorded_raw_no_ckpt_20261118_010237.zip` 核对：13 个核心模型/推理/协议文件 SHA256 完全相同，`build_model` 函数 AST 完全相同，详见 `OLD_PACKAGE_COMPATIBILITY.json`。较新的训练与数据读取依赖已包含在本包，采用独立目录避免与旧版本混用。

| 你已有的模型 | 使用入口 | 能做什么 |
|---|---|---|
| 之前训练的无速度全量模型（`lerobot_original_full_v2`） | `rl_residual_service.remote_service` | 直接 zero/probe 联调；训练基础模型对应 token 后，可单独训练连续残差 SAC |
| 新的四倍率模型（`lerobot_factor_full_v3`） | `rl_chunk_service.remote_service` | 离散倍率 SAC + 连续残差 SAC，两者均按 VLA chunk 决策 |

旧无速度模型不需要重新训练或转换即可做残差联调；它不能作为四倍率模型使用。两种模型的 token/SAC/replay 格式严格区分，禁止混用。

## 1. 解压与环境

```bash
tar -xzf iE2VLA3_RL_complete_20261123_134648.tar.gz
cd iE2VLA3_RL_complete_20261123_134648
python verify_package.py
conda activate ie2vla3
```

沿用之前能运行基础模型的 Python/CUDA 环境。`ENVIRONMENT_VERSIONS.json` 记录本次验证环境，`requirements_rl_reference.txt` 是主要依赖版本参考，**不必为了使用本包重装或升级现有 PyTorch/CUDA 环境**。本包不打包 Python 环境。

原模型构造器仍会先加载 `Qwen/Qwen3-VL-2B-Instruct`，再严格加载机器人完整 checkpoint，所以需要沿用原有完整 Qwen 基础模型缓存/目录。若旧部署使用本地 `旧代码/Qwen/Qwen3-VL-2B-Instruct`，在本包创建一个指向它的链接：

```bash
mkdir -p runtime/Qwen
ln -s /旧代码的绝对路径/Qwen/Qwen3-VL-2B-Instruct \
  runtime/Qwen/Qwen3-VL-2B-Instruct
```

目标必须是完整 Qwen 模型目录，包含权重分片、tokenizer 和 processor，不是只有 config 的目录。若原环境已配置 Hugging Face 完整缓存，也可直接沿用该缓存，无需此链接。本包不读取打包机器的 NAS 软链接。

以下示例从 `runtime/` 执行；基础 checkpoint 路径使用测试机器的绝对路径：

```bash
cd runtime
BASE=/已有模型的绝对路径/step_0100000
python -m rl_residual_service.remote_service --help
```

## 2. 没有 RL token：立即验证原客户端接口

仅需基础 checkpoint 的 `model.pt` 和 `complete.json`，不需要 rank 优化器分片、RL token、SAC 权重或 ROS 力反馈。

```bash
python -m rl_residual_service.remote_service \
  --checkpoint "$BASE" --task close_box --device cuda:0 \
  --mode zero --seed 42 \
  --uri e2vla --host 127.0.0.1 --port 9101 \
  --ns-host 127.0.0.1 --ns-port 9090 --start-ns \
  --input-pose-format recorded --input-gripper-format raw \
  --dump-predictions --output runs/residual_zero_001
```

客户端沿用原调用方式和返回结构，包括同步 `get_action/run_inference` 以及异步接口。URI、地址、端口、task 应填写旧客户端的实际值；示例值不是对现网配置的假定。服务名被占用时会拒绝启动，不会停止/替换旧服务。`--output` 每次使用新的目录。

默认 recorded/raw；如果现有客户端发的是转换后的 world TCP/openness，继续使用 `--input-pose-format tcp_world --input-gripper-format openness`。已有的 prompt 设置方法不变。

`zero` 输出零残差。退出本测试服务后，把命令改为 `--mode probe`，并换成 `--output runs/residual_probe_001`，即可测试默认**左臂 TCP 局部 x 固定 +0.25 mm**。这只是未训练 actor 的可复现联调信号，**不是正式 SAC 的残差上限或学习结果**。probe/zero 均不训练、不生成训练 replay。

数值验收：

```bash
python -m rl_residual_service.inspect_dump \
  runs/residual_zero_001/last_prediction.npz --expect-mm 0

python -m rl_residual_service.inspect_dump \
  runs/residual_probe_001/last_prediction.npz --expect-mm 0.25 --arm left --axis x
```

完整说明：[独立残差服务 README](runtime/rl_residual_service/README.md)。其中子文档的 `/home/hq/code/iE2VLA3` 示例工作目录，在本包均替换为当前 `runtime/`。

## 3. 现有基础模型：只训练残差 SAC

基础模型不动，先训练它对应的外部 RL token，再初始化残差 SAC：

```bash
python -m rl_residual_service.train_token \
  --base "$BASE" --output /新的绝对路径/no_speed_token \
  --steps 10000 --device cuda:0

TOKEN=/新的绝对路径/no_speed_token/token_010000.pt
python -m rl_residual_service.train --stage init \
  --base "$BASE" --token "$TOKEN" \
  --output /新的绝对路径/residual_init --device cpu

python -m rl_residual_service.remote_service \
  --checkpoint "$BASE" --token "$TOKEN" \
  --rl-checkpoint /新的绝对路径/residual_init/residual_init.pt \
  --mode train --task close_box --device cuda:0 \
  --uri e2vla --port 9101 --ns-host 127.0.0.1 --ns-port 9090 --start-ns \
  --feedback /tmp/ie2vla_residual_feedback.jsonl \
  --output /新的绝对路径/residual_online_001
```

正式训练需要真实力、执行确认和任务结果。ROS 2 话题和标定在 [映射模板](runtime/rl_chunk_service/ros2.example.json) 中填写；桥接程序只读机器人通路：

```bash
# 另一个已 source ROS 2 的终端，在本包 runtime 下执行。
python3 -m rl_chunk_service.ros_bridge \
  --config /实际路径/ros2.actual.json \
  --output /tmp/ie2vla_residual_feedback.jsonl
```

当前尚未提供实际话题名，模板中的 REPLACE/单位阵/零偏不能当作真实标定。`--mode collect` 只收集执行回放，`--mode inference` 使用已训练策略确定性推理。离线续训、奖励、断点、执行配对要求见 [残差训练文档](runtime/rl_residual_service/README.md)。

## 4. 倍率 + 残差完整算法

- 四倍率 VLA 及从头训练：[倍率模型说明](runtime/models/m0512_fm/README_lerobot_dual_velocity.md)。
- 外部 RL token 编码/解码与 SAC 网络：[算法说明](runtime/rl_factor_sac/README.md)。
- 倍率离散 SAC、残差连续 SAC，均按 chunk 更新：[Pyro4 服务、训练和 ROS 2 反馈说明](runtime/rl_chunk_service/README.md)。

该服务需要四倍率基础模型、对应 token 和 `rl_chunk_service.train --stage init` 创建的双 SAC 权重。之前的无速度模型走第 2/3 节即可，不能强行载入倍率服务。

`rl_factor_sac/runtime.py` 保留早期独立双频执行组件作为算法代码；当前服务端使用的是 **chunk 同频**实现。部署入口选择本说明中的两版服务，不要把早期双频组件当成 Pyro4 服务。

## 验证和包内容

```bash
# 在 runtime 下执行，只用 CPU 和临时测试权重；包括本机 IPC。
PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 \
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \
python -m pytest -q tests
```

本包解压后的测试结果见 `VALIDATION.json`、`tests_report.xml`。测试包含实际 localhost Pyro4 TCP/共享内存、小型真实 Qwen/动作网络、与原无速度推理逐元素一致、两版 token/SAC 更新与恢复。没有连接生产机器人、启动生产训练或验证不可直接观测的部署客户端进程。

`PACKAGE_MANIFEST.json` 为本包文件清单，`SOURCE_HASHES.json` 记录原样复制的 200 个源码/配置文件。`verify_package.py` 验证完整性。源码中训练示例的 `/home/...`、`/nas_data_new/...` 数据路径仍需根据部署机器填写；数据和 review handoff 不在代码包中。
