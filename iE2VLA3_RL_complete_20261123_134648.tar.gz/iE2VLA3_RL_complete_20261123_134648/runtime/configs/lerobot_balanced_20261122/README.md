# 两组数据各占 50% 的无速度版训练

本配置把 239 条人工复核轨迹和 68 条 DAgger 复核轨迹合并为 A 组，694 条原始轨迹作为 B 组。四卡训练的每个全局 microbatch 都严格一半来自 A、一半来自 B。

## 数据范围

| 组 | 数据目录 | 轨迹数 | 当前配置的采样起点数 |
| --- | --- | ---: | ---: |
| A | `/home/hq/code/huawei_261112/reviewed_training_20261115/filtered_data` | 239 | 64,241 |
| A | `/home/hq/code/hw_1122_review/dagger_reviewed_20261122_phone_prompt/filtered_data` | 68 | 14,317 |
| B | `/home/hq/code/hw_1122/data_1118_694/close_box_1118` | 694 | 647,830 |
| 合计 | A：307 条；B：694 条 | **1,001** | **726,388** |

按用户确认，`/home/hq/code/hw_1122/data_1118_694/rollout` 中额外的 57 条不加入训练。源数据文件不复制、不修改。`dataset_groups.json` 明确列出三个来源，并校验预期轨迹数量，避免误读整个父目录。

A 组通过各自交付包的 `read_training.py` 核验并加载，只读取保留的任务片段。继续使用复核后的 Parquet、分段 prompt、裁剪范围和排除区间；历史与动作窗口必须在同一有效片段内。68 条的 `action_relation=unknown` 继续保留交付包要求的额外下一行边界检查。两个交付包的 Python runtime 分别加载，避免同名模块串用。

B 组使用现有 LeRobot 原始数据读取规则：优先使用有效的逐帧 `prompt`，否则使用 `task_index` 对应的任务指令；轨迹末尾不足 32 步的动作继续使用原有 padding 和 mask。表中的 B 组数量是采样起点数，包含这些带尾部 mask 的窗口。

## 采样方式

`LeRobotGroupedDataset` 负责映射来源，`TrainingStream` 自动选择 `BalancedGroupBatchSampler` 执行比例约束，不能用普通 shuffle 替代该采样器。

- A、B 两组各占每个全局 microbatch 的 50%。下方启动脚本每卡 4 个样本，每张卡分别取 A 组 2 个和 B 组 2 个。
- 四卡合计每个 microbatch 为 A 组 8 个、B 组 8 个；梯度累积 2 次后，每次参数更新为 **A 组 16 个 + B 组 16 个 = 32 个样本**。
- 组内按采样起点均匀打乱，无放回遍历；一组耗尽时重新打乱并循环。A 内两个来源合并后共同采样，比例由有效窗口数量决定，不按来源各分一半，也不按轨迹数均分。
- 一个 epoch 按较大组完整遍历一次并向上补齐全局 batch。本配置每个 epoch 有 80,979 个 microbatch，每组各抽取 647,832 个样本。B 组末尾补 2 个；A 组循环约 8.25 遍。训练进度和保存间隔仍按优化器 iteration 计算。
- 四个 rank 使用一致的全局索引计划并领取各自部分。`seed + epoch` 决定计划；断点续训按已消费的 `batch_in_epoch` 恢复，DataLoader 预取不会导致跳样本。
- 全局 microbatch 大小必须是偶数。单卡 batch 为奇数时仍支持全局 50/50，额外样本所属组随 microbatch 轮换。

## 启动

从任意目录执行：

```bash
bash /home/hq/code/iE2VLA3/scripts/train_lerobot_balanced.sh
```

脚本使用 `/home/hq/miniconda3/envs/ie2vla3/bin/python`，自动启动四卡 DDP。沿用当前模型与训练参数：Qwen3-VL-2B-Instruct 全量训练、LoRA 关闭、无速度条件、1 帧历史观测、32 步动作、三路 RGB、原有单位/工具/左右基座转换，100,000 次参数更新，每 10,000 次保存。

默认 checkpoint 输出目录：

```text
/nas_data_new/hq/98qwenvla/lerobot_original_full_balanced_h32_20261122
```

可在末尾覆盖输出路径等参数，例如：

```bash
bash /home/hq/code/iE2VLA3/scripts/train_lerobot_balanced.sh \
  --output /nas_data_new/hq/98qwenvla/my_balanced_run
```

需要保存控制台日志时，可自行将输出重定向到一个新的日志文件。仅检查数据、不启动训练：

```bash
bash /home/hq/code/iE2VLA3/scripts/train_lerobot_balanced.sh \
  --check-data --check-all-episodes
```

启动时会打印 `sampling_config`，包含每组比例、来源、轨迹数、窗口数及 epoch 长度；输出目录的 `config.json` 也保存采样信息。原先不指定新配置的训练入口仍使用此前的默认数据；此脚本显式选择本次两组配置。

## Checkpoint、恢复与推理

继续调用原有保存逻辑，格式仍为 `lerobot_original_full_v2`：`model.pt`、`complete.json` 和四个 `rank_0000*.pt` 优化器/RNG 分片。模型结构、特征接入和配置 schema 保持当前版本；`train_config` 额外记录采样方式，数据指纹绑定分组清单和来源元数据/复核快照。

现有 `e2vla_compat`、`e2vla_async` 推理服务端可按原流程加载该训练产生的模型。推理不需要访问这个混合数据目录。

恢复本次混合训练的示例：

```bash
bash /home/hq/code/iE2VLA3/scripts/train_lerobot_balanced.sh \
  --resume /nas_data_new/hq/98qwenvla/lerobot_original_full_balanced_h32_20261122/step_0010000
```

恢复必须使用对应混合训练的完整 checkpoint 和相同参数。历史 239 条或全原始数据训练的 checkpoint 不能直接用 `--resume` 切换到这套数据，现有的数据指纹校验会拒绝这种变更。本启动命令没有指定恢复路径，会按现有初始化逻辑开始一次新训练。

## 验证记录

`/home/hq/code/iE2VLA3/audits/lerobot_balanced_20261122/check_data.log` 记录真实数据校验：全部 1,001 条轨迹的数值字段通过检查，并抽查三路视频解码、双臂状态/动作及 mask；没有加载大模型或开始 GPU 训练。

采样与读取回归测试位于 `/home/hq/code/iE2VLA3/tests/test_lerobot_grouped.py`，覆盖四 rank 的比例与索引划分、组内覆盖与重复采样、跨 epoch、预取后恢复、两个复核来源的隔离、prompt/几何/mask 保留，以及数据指纹变化。

2026-11-22 验证结果：相关读取、模型和训练回归共 **36 项通过**，报告为 `/home/hq/code/iE2VLA3/audits/lerobot_balanced_20261122/pytest_results.xml`。多进程张量传输测试在沙箱中阻塞，改在沙箱外运行后全部通过。

`/home/hq/code/iE2VLA3/audits/lerobot_balanced_20261122/sampling_validation.json` 记录按真实窗口规模生成的四 rank 索引检查：模拟 1,000 次参数更新（只生成索引，没有模型训练），A、B 各 16,000 个样本，每张卡每个 microbatch 各 2 个；从第 1,537 个 microbatch 恢复后顺序完全一致。完整 epoch 覆盖所有窗口，A 组各窗口出现 8～9 次，B 组各起点出现 1～2 次。
