import time
import scipy
import threading
import numpy as np
import scipy.interpolate
from dataclasses import dataclass
from typing import Optional, Union, Callable, Dict, List, Tuple

from . import align, mpc


def unwrap_so3(
    so3_seq: np.ndarray, 
    so3_init: Optional[np.ndarray] = None, 
    eps=1e-12
):
    """
    Args:
        so3_seq (np.ndarray): (T, 3)
        so3_init (np.ndarray): (3,) 
        eps (float): eps
    
    Returns:
        unwrapped (np.ndarray): (T, 3)
    """
    if so3_init is None:
        so3_init = so3_seq[0]
    
    unwrapped = so3_seq.copy()
    for i in range(len(so3_seq)):
        rotv = so3_seq[i]
        rotv_prev = unwrapped[i-1] if i > 0 else so3_init

        theta = np.linalg.norm(rotv)
        axis = rotv / (theta[..., None] + eps)

        proj = np.dot(rotv_prev - rotv, axis)
        m = int(np.round(proj / (2.0 * np.pi)))
        unwrapped[i] = rotv + (2.0 * np.pi * m) * axis
        
    return unwrapped


def dynamics(xv: np.ndarray, a: np.ndarray):
    x, v = np.array_split(xv, 2, axis=-1)
    return np.concatenate([v, a], axis=-1)


def discrete_linear_model(xv: np.ndarray, a: np.ndarray, dt: float):
    # x_{k+1} = x_k + v_k * dt
    # v_{k+1} = v_k + a_k * dt

    D = a.shape[-1]
    I = np.eye(D)
    O = np.zeros((D, D))

    A = np.block([[I, I*dt],
                  [O, I]])
    B = np.block([[O],
                  [I*dt]])
    return A, B


def mpc_optimize(
    now_xva: np.ndarray, 
    new_seq_t: np.ndarray,
    new_seq_xva: np.ndarray, 
    query_seq_t: np.ndarray, 
    unwrap_fn: Optional[Callable[[np.ndarray, np.ndarray], np.ndarray]] = None, 
    max_acc: Union[float, np.ndarray] = 1.0,
    cache: Optional[dict] = None
):
    """
    Args:
        now_t (np.ndarray): current timestamp
        now_xva (np.ndarray): (3*D,)
        new_seq_t (np.ndarray): (T,)
        new_seq_xva (np.ndarray): (T, 3*D)
        query_seq_t (np.ndarray): (Tq,)
        max_acc: maximum acceleration
    """
    D = now_xva.shape[-1] // 3
    assert len(query_seq_t) >= 2
    dt = (query_seq_t[-1] - query_seq_t[0]) / (len(query_seq_t) - 1)

    # interpolate to get gt traj
    target_xva = align.align_data(
        query_time=query_seq_t,
        train_time=new_seq_t,
        train_data={"linear": new_seq_xva},
        interp_funcs={"linear": align.interp_linear}
    )["linear"]  # (Tq, 3*D)

    # 对于外插的点, 手动将速度和加速度置为0
    exceeds_mask = query_seq_t >= new_seq_t[-1]
    if np.any(exceeds_mask):
        target_xva[exceeds_mask, D:] = 0.0

    if unwrap_fn is not None:
        target_xva[:, :D] = unwrap_fn(target_xva[:, :D], now_xva[:D])
    
    U, X_opt = mpc.solve_ilmpc_time_invariant(
        x0=now_xva[:2*D],           # (2*D,)
        ref=target_xva[:, :2*D],    # (n_switching, 2*D)
        U_init=target_xva[:, -D:],  # (n_switching, D)
        dt=dt,
        dynamic_fn=dynamics,
        discrete_linear_model=discrete_linear_model,
        Q=np.diag([1.0] * D + [0.01] * D),  # (2*D, 2*D)
        R=np.diag([0.01] * D),              # (D, D)
        u_min=-np.abs(max_acc),
        u_max=np.abs(max_acc),
        max_iters=10,
        cache=cache, 
        verbose=False
    )

    opt_seq_xva = np.concatenate([X_opt[1:], U], axis=-1)  # (T, D)
    return opt_seq_xva


SCIPY_VERSION = scipy.__version__

if SCIPY_VERSION >= "1.16":
    def evaluate_va(t: np.ndarray, x: np.ndarray):
        """
        Args:
            t (np.ndarray): (T,)
            x (np.ndarray): (T, D)
        
        Returns:
            xva (np.ndarray): (T, 3*D)
        """
        # scipy >= 1.16.* supports batch make_smoothing_spline
        # see: https://github.com/scipy/scipy/pull/22484
        spl = scipy.interpolate.make_smoothing_spline(t, x)
        x = spl(t)
        v = spl.derivative(1)(t)
        a = spl.derivative(2)(t)
        xva = np.concatenate([x, v, a], axis=-1)
        return xva
else:
    def evaluate_va(t: np.ndarray, x: np.ndarray):
        """
        Args:
            t (np.ndarray): (T,)
            x (np.ndarray): (T, D)
        
        Returns:
            xva (np.ndarray): (T, 3*D)
        """
        T, D = x.shape
        xva = []
        for d in range(D):
            spl = scipy.interpolate.make_smoothing_spline(t, x[:, d])
            x_d = spl(t)  # (T,)
            v_d = spl.derivative(1)(t)  # (T,)
            a_d = spl.derivative(2)(t)  # (T,)
            xva_d = np.stack([x_d, v_d, a_d], axis=-1)  # (T, 3)
            xva.append(xva_d)
        xva = np.stack(xva, axis=-1)  # (T, 3, D)
        xva = xva.reshape(T, 3*D)
        return xva


def default_time_fn():
    return time.perf_counter()


@dataclass
class MPCConfig(object):
    dt: float = 0.05
    horizon_time: float = 1.0
    est_opt_time: float = 0.1


class ActionChunkingMPC(object):
    def __init__(
        self, 
        x0: Dict[str, np.ndarray], 
        max_acc: Dict[str, Union[float, np.ndarray]], 
        unwrap_fn: Dict[str, Callable[[np.ndarray, np.ndarray], np.ndarray]], 
        time_fn: Callable[[], float] = default_time_fn,
        mpc_config: MPCConfig = MPCConfig(), 
        save_history: bool = False,
    ):
        self.max_acc = max_acc
        self.time_fn = time_fn
        self.unwrap_fn = unwrap_fn
        self.mpc_config = mpc_config
        self.save_history = save_history
        self.x0 = {k: v.copy() for k, v in x0.items()}

        # 存储网络规划的结果
        self._new_t = None
        self._new_xva = {k: None for k in self.x0}
        self._new_history: List[Tuple[np.ndarray, Dict[str, np.ndarray]]] = []  # only for debug
        self._new_data_lock = threading.Lock()

        # 存储mpc优化后的结果
        self._optimized_t = None
        self._optimized_xva = {k: None for k in self.x0}
        self._optimized_data_lock = threading.Lock()
        self._solver_cache = {k: {} for k in self.x0}

        # start optimization
        self._requires_stop = False
        self._optimization_thread = threading.Thread(
            target=self._optimization_thread_func,
            daemon=True
        )
    
    def launch_thread(self):
        self._optimization_thread.start()
    
    def stop_thread(self):
        self._requires_stop = True
        self._optimization_thread.join()
    
    def clear_history(self):
        """此函数仅清除一些用于绘图的信息, 不会对优化结果造成影响, 前提是time_fn是正确的"""
        self._new_history.clear()
        self._trunc_optimized_past(self.time_fn())

    def query_optimized(self, t: float) -> Dict[str, np.ndarray]:
        with self._optimized_data_lock:
            x0 = self.x0
            optimized_t = self._optimized_t
            optimized_xva = self._optimized_xva.copy()  # shallow copy is enough
        
        if optimized_t is None:
            queries = {}
            for name, x in x0.items():
                v = a = np.zeros_like(x)
                queries[name] = np.concatenate([x, v, a], axis=-1)
                
        else:
            queries = align.align_data(
                query_time=t,
                train_time=optimized_t,
                train_data=optimized_xva,
                interp_funcs={k: align.interp_linear for k in self.x0}
            )
        
        return queries

    def set_desired_trajectory(self, new_t: np.ndarray, new_x: Dict[str, np.ndarray]):
        """
        Args:
            new_t (np.ndarray): (T,)
            new_x (Dict[str, np.ndarray]): each of (T, D)
        """
        if self.save_history:
            self._new_history.append((new_t, new_x))

        new_xva: Dict[str, np.ndarray] = {}
        for key in self.x0:
            xk = new_x[key]  # (T, D)
            # unwrap for so3_seq
            unwrap_fn = self.unwrap_fn.get(key, None)
            if unwrap_fn:
                xk = unwrap_fn(xk, xk[0])
            # smooth + derivatives
            new_xva[key] = evaluate_va(new_t, xk)
        
        with self._new_data_lock:
            self._new_xva = new_xva
            self._new_t = new_t

    def _optimize(self, t_now: float, t_start: float):
        t0 = time.perf_counter()

        assert t_start >= t_now
        # 从t_start时刻开始进行优化跟踪，优化的视野长度由horizon_time决定
        n_queries = max(1, int(round(self.mpc_config.horizon_time / self.mpc_config.dt)))
        query_t = t_start + (1 + np.arange(n_queries)) * self.mpc_config.dt
        xva = self.query_optimized(t_start)

        if self._new_t is None:
            print("[INFO] desired trajectory is not set, skip")
            return
        
        with self._new_data_lock:
            new_t = self._new_t
            new_xva = self._new_xva.copy()

        planned_seq_xva: Dict[str, np.ndarray] = {}
        for key in self.x0:
            planned_seq_xva[key] = mpc_optimize(
                now_xva=xva[key],
                new_seq_t=new_t,
                new_seq_xva=new_xva[key],
                query_seq_t=query_t,
                max_acc=self.max_acc[key],
                cache=self._solver_cache[key]
            )
        if not self.save_history:
            self._trunc_optimized_past(t_now)
        self._overwrite_optimized_future(query_t, planned_seq_xva)

        t1 = time.perf_counter()
        print("[INFO] Optimization time: {:.4f}".format(t1 - t0))

    def _trunc_optimized_past(self, t_util: float):
        if self._optimized_t is None:
            return
        
        index = np.digitize(t_util, self._optimized_t, right=True)

        with self._optimized_data_lock:
            if index == len(self._optimized_t):
                # 当前的时间t_util已经超过先前规划的结果的最后一刻了，因此重新初始化
                print("[INFO] re-initialize called")
                self._optimized_t = None
                for key in self.x0:
                    D = self.x0[key].shape[-1]
                    self.x0[key] = self._optimized_xva[key][-1, :D].copy()
                    self._optimized_xva[key] = None
            
            else:
                index = np.clip(index - 1, 0, None)
                self._optimized_t = self._optimized_t[index:]
                for key in self.x0:
                    self._optimized_xva[key] = self._optimized_xva[key][index:]

    def _overwrite_optimized_future(self, t: np.ndarray, xva: Dict[str, np.ndarray]):
        if self._optimized_t is None:
            with self._optimized_data_lock:
                self._optimized_t = t
                self._optimized_xva = xva
            return

        # 找到处于t[0]之前的self._optimized_t的片段
        optimized_xva: Dict[str, np.ndarray] = {}
        index = np.digitize(t[0], self._optimized_t, right=False)

        # 保留t[0]之前的, 拼接上新的
        optimized_t = np.concatenate([self._optimized_t[:index], t], axis=0)
        for key in self.x0:
            preserved = self._optimized_xva[key][:index]  # (N_preserved, 3*D)
            optimized_xva[key] = np.concatenate([preserved, xva[key]], axis=0)
            # unwrap for so3_seq
            unwrap_fn = self.unwrap_fn.get(key, None)
            if unwrap_fn:
                D = self.x0[key].shape[-1]
                optimized_xva[key][:, :D] = unwrap_fn(optimized_xva[key][:, :D], 
                                                      preserved[-1, :D])  # initial as the last preseved

        with self._optimized_data_lock:
            self._optimized_t = optimized_t
            self._optimized_xva = optimized_xva

    def _optimization_thread_func(self):
        while True:
            if self._requires_stop:
                break

            if self._new_t is None:
                time.sleep(0.1)
                continue

            t = self.time_fn()
            self._optimize(t, t + self.mpc_config.est_opt_time)


class PoseChunkingMPC(object):
    def __init__(
        self, 
        pose0: np.ndarray, 
        max_acc: np.ndarray, 
        max_beta: np.ndarray,
        mpc_config: MPCConfig = MPCConfig(), 
        time_fn: Callable[[], float] = default_time_fn,
        save_history: bool = False
    ):
        """
        Args:
            pose0 (np.ndarray): (Nee, 4, 4)
            max_acc (np.ndarray): (Nee,) or (Nee, 3)
            max_beta (np.ndarray): (Nee,) or (Nee, 3)
            time_fn (Callable): returns the current time
            save_history (bool): save history planning result
        """
        assert pose0.ndim == 3
        pos = pose0[:, :3, 3]
        rot = align.Log(pose0[:, :3, :3])
        self.nee = pose0.shape[0]

        x0 = {f"pos{i}": pos[i] for i in range(self.nee)}
        x0.update({f"rot{i}": rot[i] for i in range(self.nee)})

        acc = {f"pos{i}": max_acc[i] for i in range(self.nee)}
        acc.update({f"rot{i}": max_beta[i] for i in range(self.nee)})

        unwrap_fn = {f"rot{i}": unwrap_so3 for i in range(self.nee)}

        self.ac = ActionChunkingMPC(
            x0=x0,
            max_acc=acc,
            unwrap_fn=unwrap_fn,
            time_fn=time_fn,
            mpc_config=mpc_config, 
            save_history=save_history
        )
    
    def launch_thread(self):
        self.ac.launch_thread()
    
    def stop_thread(self):
        self.ac.stop_thread()
    
    def clear_history(self):
        self.ac.clear_history()
    
    def query_optimized(self, t: float):
        """
        Args:
            t (float): query timestep
        
        Returns:
            pose (np.ndarray): (Nee, 4, 4)
        """
        pose = np.eye(3)[None].repeat(self.nee, axis=0)
        queries = self.ac.query_optimized(t)

        for i in range(self.nee):
            pos = queries[f"pos{i}"]
            rot = align.Exp(queries[f"rot{i}"])
            pose[i, :3, 3] = pos
            pose[i, :3, :3] = rot

        return pose
    
    @property
    def optimized_history(self):
        """
        Returns:
            optimized_t (np.ndarray): (T,)
            optimized_pose (np.ndarray): (Nee, T, 4, 4)
        """
        if self.ac._optimized_t is None:
            return None, None
        
        with self.ac._optimized_data_lock:
            optimized_t = self.ac._optimized_t
            optimized_xva = self.ac._optimized_xva.copy()
        
        optimized_pose = np.zeros((self.nee, len(optimized_t), 4, 4))
        optimized_pose[..., -1, -1] = 1.0
        for i in range(self.nee):
            pos = optimized_xva[f"pos{i}"][:, :3]
            rot = optimized_xva[f"rot{i}"][:, :3]
            optimized_pose[i, :, :3, :3] = align.Exp(rot)
            optimized_pose[i, :, :3, 3] = pos
        return optimized_t, optimized_pose
    
    def set_desired_trajectory(self, traj_t: np.ndarray, traj_pose: np.ndarray):
        """
        Args:
            traj_t (np.ndarray): (T,)
            traj_pose (np.ndarray): (Nee, T, 4, 4)
        """
        assert traj_pose.ndim == 4
        traj_pos = traj_pose[:, :, :3, 3]
        traj_rot = align.Log(traj_pose[:, :, :3, :3])

        new_x = {f"pos{i}": traj_pos[i] for i in range(self.nee)}
        new_x.update({f"rot{i}": traj_rot[i] for i in range(self.nee)})
        self.ac.set_desired_trajectory(
            new_t=traj_t,
            new_x=new_x
        )


def test():
    import matplotlib.pyplot as plt
    from .mpc import integration, default_add
    
    def reference_traj(N, D, dt, u_min, u_max, seed=1):
        np.random.seed(seed)

        alpha = 0.1
        u_range = (u_max - u_min)
        U = np.random.rand(N, D) * u_range * (1 - alpha * 2) + u_min + alpha * u_range

        assert np.all(U < u_max)
        assert np.all(U > u_min)
        x0 = np.random.randn(2*D) * 0.1

        ref = integration(
            x0=x0, U=U, dt=dt, 
            dyn_fn=dynamics,
            add_fn=default_add,
        )[1:]  # (N, 2*D)

        return ref, U

    N = 32
    D = 3
    dt = 0.2
    u_min = -0.5
    u_max = 0.5

    ac = ActionChunkingMPC(
        x0={"trans": np.zeros(D)},
        max_acc={"trans": 0.5},
        unwrap_fn={"trans": None},
        save_history=True
    )

    ref0, U0 = reference_traj(N, D, dt, u_min, u_max, seed=0)
    ref1, U1 = reference_traj(N, D, dt, u_min, u_max, seed=1)
    t0 = 0.0
    t1 = N//2 * dt
    ref1[:, :D] += ref0[N//2, :D] + [0.1, 0.2, 0.3]
    tt0 = t0 + np.arange(N) * dt
    tt1 = t1 + np.arange(N) * dt

    ac.set_desired_trajectory(tt0, {"trans": ref0})

    replan_dt = 0.15
    steps = int(tt1[-1] // replan_dt * 1.2)
    for i in range(steps):
        t_prev = (i - 1) * replan_dt
        t_now = i * replan_dt

        if t_prev < t1 and t_now >= t1:
            ac.set_desired_trajectory(tt1, {"trans": ref1})
        
        ac._optimize(t_now, t_now + ac.est_opt_time)

    fig, axes = plt.subplots(D, 1)

    for d in range(D):
        axes[d].plot(tt0, ref0[:, d], ".-")
        axes[d].plot(tt1, ref1[:, d], ".-")
        axes[d].plot(ac._optimized_t, ac._optimized_xva["trans"][:, d])

    plt.show()



def test2():
    import matplotlib.pyplot as plt
    from .mpc import integration, default_add
    
    def reference_traj(N, D, dt, u_min, u_max, seed=1):
        np.random.seed(seed)

        alpha = 0.1
        u_range = (u_max - u_min)
        U = np.random.rand(N, D) * u_range * (1 - alpha * 2) + u_min + alpha * u_range

        assert np.all(U < u_max)
        assert np.all(U > u_min)
        x0 = np.random.randn(2*D) * 0.1

        ref = integration(
            x0=x0, U=U, dt=dt, 
            dyn_fn=dynamics,
            add_fn=default_add,
        )[1:]  # (N, 2*D)

        return ref, U

    N = 32
    D = 3
    dt = 0.2
    acc_min = -0.5
    acc_max = 0.5
    beta_min = -2
    beta_max = 2

    pc = PoseChunkingMPC(
        pose0=np.eye(4)[None],
        max_acc=np.array([acc_max]),
        max_beta=np.array([beta_max]),
        time_fn=default_time_fn,
        save_history=True,
        mpc_config=MPCConfig(
            # est_opt_time=0.01
        )
    )

    ref_pos0_xv, _ = reference_traj(N, D, dt, acc_min, acc_max, seed=0)
    ref_pos1_xv, _ = reference_traj(N, D, dt, acc_min, acc_max, seed=1)
    ref_rot0_xv, _ = reference_traj(N, D, dt, beta_min, beta_max, seed=2)
    ref_rot1_xv, _ = reference_traj(N, D, dt, beta_min, beta_max, seed=3)
    t0 = 0.0
    t1 = N//2 * dt
    ref_pos1_xv[:, :D] += ref_pos0_xv[N//2, :D] + [0.1, 0.2, 0.3]
    ref_rot1_xv[:, :D] += ref_rot0_xv[N//2, :D] + [0.4, 0.8, 1.2]
    tt0 = t0 + np.arange(N) * dt
    tt1 = t1 + np.arange(N) * dt

    ref_pose0 = np.eye(4)[None].repeat(N, 0)
    ref_pose0[:, :3, :3] = align.Exp(ref_rot0_xv[:, :3])
    ref_pose0[:, :3, 3] = ref_pos0_xv[:, :3]

    ref_pose1 = np.eye(4)[None].repeat(N, 0)
    ref_pose1[:, :3, :3] = align.Exp(ref_rot1_xv[:, :3])
    ref_pose1[:, :3, 3] = ref_pos1_xv[:, :3]

    pc.set_desired_trajectory(tt0, ref_pose0[None])

    replan_dt = 0.15
    steps = int(tt1[-1] // replan_dt * 1.2)
    for i in range(steps):
        t_prev = (i - 1) * replan_dt
        t_now = i * replan_dt

        if t_prev < t1 and t_now >= t1:
            pc.set_desired_trajectory(tt1, ref_pose1[None])
        
        pc.ac._optimize(t_now, t_now + pc.ac.mpc_config.est_opt_time)
    
    optimized_t, optimized_pose = pc.optimized_history
    optimized_pos = optimized_pose[0, :, :3, 3]
    optimized_rot = align.Log(optimized_pose[0, :, :3, :3])

    fig, axes = plt.subplots(9, 1)

    for d in range(3):
        axes[d].plot(tt0, ref_pos0_xv[:, d], ".-")
        axes[d].plot(tt1, ref_pos1_xv[:, d], ".-")
        axes[d].plot(optimized_t, optimized_pos[:, d])
    
    ref_rot6d0 = ref_pose0[:, :2, :3].reshape(-1, 6)
    ref_rot6d1 = ref_pose1[:, :2, :3].reshape(-1, 6)
    optimized_rot6d = optimized_pose[0, :, :2, :3].reshape(-1, 6)
    
    # for d in range(D):
    #     axes[d + 3].plot(tt0, ref_rot0_xv[:, d], ".-")
    #     axes[d + 3].plot(tt1, ref_rot1_xv[:, d], ".-")
    #     axes[d + 3].plot(optimized_t, optimized_rot[:, d])

    for d in range(6):
        axes[d + 3].plot(tt0, ref_rot6d0[:, d], ".-")
        axes[d + 3].plot(tt1, ref_rot6d1[:, d], ".-")
        axes[d + 3].plot(optimized_t, optimized_rot6d[:, d])

    plt.show()



if __name__ == "__main__":
    # test()
    test2()

