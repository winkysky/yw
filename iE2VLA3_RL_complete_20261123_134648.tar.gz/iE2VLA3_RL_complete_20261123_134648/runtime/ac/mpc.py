import time
import osqp
import numpy as np
from scipy import sparse
from numpy import ndarray as NDA
from typing import Callable, Tuple, Union, Optional, Dict


def default_add(x, dx):
    return x + dx


def default_sub(x, b):
    return x - b


def integration(
    x0: NDA,  # (xdim,)
    U: NDA,   # (N, udim)
    dt: float,
    dyn_fn: Callable[[NDA, NDA], NDA],
    add_fn: Callable[[NDA, NDA], NDA] = default_add
):
    xdim, = x0.shape
    N, udim = U.shape
    
    X = np.zeros((N+1, xdim))
    x = x0.copy()
    X[0] = x0
    for k, u in enumerate(U):
        dxdt = dyn_fn(x, u)
        x_next = add_fn(x, dxdt * dt)
        X[k+1] = x_next
        x = x_next
    return X


def linearize_discrete_sequence(
    X: NDA,  # (N+1, xdim), the first element is x0
    U: NDA,  # (N, udim)
    dt: float, 
    discrete_linear_model: Callable[[NDA, NDA, float], Tuple[NDA, NDA]],
):
    N, xdim = X.shape
    N, udim = U.shape
    
    A_stack = np.zeros((N, xdim, xdim))
    B_stack = np.zeros((N, xdim, udim))
    
    for k in range(N):
        Abar, Bbar = discrete_linear_model(X[k], U[k], dt)
        A_stack[k] = Abar
        B_stack[k] = Bbar
    
    return A_stack, B_stack


def build_U_contributions(
    A_stack: NDA,  # (N, xdim, xdim)
    B_stack: NDA,  # (N, xdim, udim)
):
    N, xdim, udim = B_stack.shape
    Su = np.zeros((N * xdim, N * udim))

    for k in range(N):
        # compute contribution of past u's and c's
        Ak_Aj = np.eye(xdim)
        for j in range(k, -1, -1):
            # contribution of u_j to x_{k+1} is A_{k}...A_{j+1} B_j
            Su[k*xdim: (k+1)*xdim, j*udim: (j+1)*udim] = Ak_Aj @ B_stack[j]
            Ak_Aj = Ak_Aj @ A_stack[j]
    
    return Su


def build_constraints(
    Su: NDA,  # (N*xdim, N*udim)
    X_hat: NDA,  # (N, xdim)
    U: NDA,  # (N, udim)
    x_min: Optional[Union[float, NDA]],
    x_max: Optional[Union[float, NDA]],
    u_min: Optional[Union[float, NDA]],
    u_max: Optional[Union[float, NDA]]
):
    N, xdim = X_hat.shape
    udim = Su.shape[1] // N
    
    def exapnd_size(limit, dim, inf_val):
        if limit is None:
            limit = inf_val * np.ones(dim)
        elif np.size(limit) == 1:
            limit = np.array(limit).ravel() * np.ones(dim)
        else:
            assert np.size(limit) == dim
            limit = np.array(limit).ravel()
        return limit
    
    Aineq = []
    lbs = []
    ubs = []
    
    if (x_min is not None) or (x_max is not None):
        x_min = exapnd_size(x_min, xdim, -np.inf)
        x_max = exapnd_size(x_max, xdim, np.inf)
        
        offset = X_hat.ravel()
        x_lb = np.tile(x_min, N) - offset
        x_ub = np.tile(x_max, N) - offset

        Aineq.append(Su)
        lbs.append(x_lb)
        ubs.append(x_ub)
    
    if (u_min is not None) or (u_max is not None):
        u_min = exapnd_size(u_min, udim, -np.inf)
        u_max = exapnd_size(u_max, udim, np.inf)
        
        offset = U.ravel()
        u_lb = np.tile(u_min, N) - offset
        u_ub = np.tile(u_max, N) - offset
        
        Aineq.append(np.eye(N*udim))
        lbs.append(u_lb)
        ubs.append(u_ub)
    
    if len(Aineq):
        Aineq = np.concatenate(Aineq, axis=0)
        lbs = np.concatenate(lbs, axis=0)
        ubs = np.concatenate(ubs, axis=0)
    else:
        Aineq = None
        lbs = None
        ubs = None
    
    return Aineq, lbs, ubs


def solve_qp(P, q, A, l, u):
    problem = osqp.OSQP()
    problem.setup(P, q, A, l, u, verbose=False)
    res = problem.solve()
    return res.x


def compute_cost(
    X: NDA, U: NDA, ref: NDA, Q: NDA, R: NDA, 
    sub_fn: Callable = default_sub
):
    e_x: NDA = sub_fn(X, ref)  # (N, xdim)
    cost_x = ((e_x @ Q) * e_x).sum()
    cost_u = ((U @ R) * U).sum()
    cost = cost_x + cost_u
    return e_x, cost


def solve_ilmpc_time_varying(
    x0: NDA, 
    ref: NDA, 
    U_init: NDA, 
    dt: float, 
    dynamic_fn: Callable, 
    discrete_linear_model: Callable,
    Q: NDA, 
    R: NDA, 
    x_min=None,
    x_max=None, 
    u_min=None, 
    u_max=None, 
    max_iters=10, 
    tol=1e-5, 
    state_add_fn: Callable = default_add,
    state_sub_fn: Callable = default_sub,
    max_line_search_trials = 0,
):
    U = np.array(U_init)
    N, udim = U.shape
    
    Qbig = np.kron(np.eye(N), Q)  # (N*xdim, N*xdim)
    Rbig = np.kron(np.eye(N), R)  # (N*udim, N*udim)
    
    X = integration(x0=x0, U=U, dt=dt, dyn_fn=dynamic_fn, add_fn=state_add_fn)  # (N+1, xdim)
    E, cost = compute_cost(X=X[1:], U=U, ref=ref, Q=Q, R=R, sub_fn=state_sub_fn)

    for iter in range(max_iters):
        A_stack, B_stack = linearize_discrete_sequence(
            X=X, U=U, dt=dt, discrete_linear_model=discrete_linear_model
        )
        
        Su = build_U_contributions(A_stack, B_stack)
        # build q P matrix
        P = Su.T @ Qbig @ Su + Rbig
        q = Su.T @ (Qbig @ E.ravel()) + Rbig @ U.ravel()
        
        Aineq, lb, ub = build_constraints(Su=Su, X_hat=X[1:], U=U,
                                          x_min=x_min, x_max=x_max, 
                                          u_min=u_min, u_max=u_max)
        # solve qp
        P = sparse.csc_matrix(P)
        if Aineq is not None:
            Aineq = sparse.csc_matrix(Aineq)

        dU: NDA = solve_qp(P=P, q=q, A=Aineq, l=lb, u=ub)
        dU = dU.reshape(N, udim)
        
        # line search
        line_search_success = True
        for trial in range(max_line_search_trials):
            alpha = 0.5**trial
            U_next = U + alpha * dU
            X_next = integration(
                x0=x0, U=U_next, dt=dt, dyn_fn=dynamic_fn, add_fn=state_add_fn
            )  # (N+1, xdim)
            E_next, cost_next = compute_cost(
                X=X_next[1:], U=U_next, ref=ref, Q=Q, R=R, sub_fn=state_sub_fn)
            U_diff = alpha * np.linalg.norm(dU) / (np.linalg.norm(U) + 1e-9)
            
            if trial == 0:
                print("[INFO] iter = {}, search = {}/{}, cost_prev = {:.3e}, cost = {:.3e}, U_diff = {:.3e}"
                      .format(iter+1, trial+1, max_line_search_trials, cost, cost_next, U_diff))
            else:
                blank = " "*len(str(iter))
                print("              {}  search = {}/{}, cost_prev = {:.3e}, cost = {:.3e}, U_diff = {:.3e}"
                      .format(blank, trial+1, max_line_search_trials, cost, cost_next, U_diff))
            
            if cost_next <= cost:
                U = U_next
                X = X_next
                E = E_next
                cost = cost_next
                break
        else:
            if max_line_search_trials > 0:
                line_search_success = False
                print("[INFO] iter = {}, line search faild".format(iter+1))
                break
            
            U_diff = np.linalg.norm(dU) / (np.linalg.norm(U) + 1e-9)
            U = U + dU
            cost_prev = cost
            X = integration(x0=x0, U=U, dt=dt, dyn_fn=dynamic_fn, add_fn=state_add_fn)  # (N+1, xdim)
            E, cost = compute_cost(X=X[1:], U=U, ref=ref, Q=Q, R=R, sub_fn=state_sub_fn)
            print("[INFO] iter = {}, cost_prev = {:.3e}, cost = {:.3e}, U_diff = {:.3e}"
                .format(iter+1, cost_prev, cost, U_diff))

        if not line_search_success:
            print("[INFO] Stop due to line search failed")
            break
        if U_diff < tol:
            print("[INFO] Stop due to U_diff tol satisfied")
            break
    print("[INFO] Final cost = {:.3e}".format(cost))
    return U, X


def solve_ilmpc_time_invariant(
    x0: NDA, 
    ref: NDA, 
    U_init: NDA, 
    dt: float, 
    dynamic_fn: Callable, 
    discrete_linear_model: Callable,
    Q: NDA, 
    R: NDA, 
    x_min=None,
    x_max=None, 
    u_min=None, 
    u_max=None, 
    max_iters=10, 
    tol=1e-5, 
    state_add_fn: Callable = default_add,
    state_sub_fn: Callable = default_sub,
    cache: Optional[Dict[str, Union[NDA, osqp.OSQP]]] = None,
    verbose: bool = True
):
    U = np.array(U_init)
    N, udim = U.shape
    xdim, = x0.shape
    
    Qbig = np.kron(np.eye(N), Q)  # (N*xdim, N*xdim)
    Rbig = np.kron(np.eye(N), R)  # (N*udim, N*udim)

    if cache is None:
        cache: Dict[str, Union[NDA, osqp.OSQP]] = {}
    
    for iter in range(max_iters):
        X = integration(
            x0=x0, U=U, dt=dt, dyn_fn=dynamic_fn, add_fn=state_add_fn
        )  # (N+1, xdim)
        
        E, cost = compute_cost(X=X[1:], U=U, ref=ref, Q=Q, R=R, sub_fn=state_sub_fn)
        
        if ("problem" not in cache) or ("Su" not in cache):
            A_stack, B_stack = linearize_discrete_sequence(
                X=X, U=U, dt=dt, discrete_linear_model=discrete_linear_model
            )
            
            Su = build_U_contributions(A_stack, B_stack)  # (N*xdim, N*udim)
            # build Q p matrix
            P = Su.T @ Qbig @ Su + Rbig
            q = Su.T @ (Qbig @ E.ravel()) + Rbig @ U.ravel()

            Aineq, lb, ub = build_constraints(Su=Su, X_hat=X[1:], U=U,
                                              x_min=x_min, x_max=x_max, 
                                              u_min=u_min, u_max=u_max)
            # solve qp
            # P = P + np.eye(P.shape[0]) * 0.01
            P = sparse.csc_matrix(P)
            if Aineq is not None:
                Aineq = sparse.csc_matrix(Aineq)
            
            problem = osqp.OSQP()
            problem.setup(P=P, q=q, A=Aineq, l=lb, u=ub, verbose=False)
            cache.update(dict(Su=Su, problem=problem))
        
        else:
            Su = cache["Su"]
            q = Su.T @ (Qbig @ E.ravel()) + Rbig @ U.ravel()
            _, lb, ub = build_constraints(Su=Su, X_hat=X[1:], U=U,
                                          x_min=x_min, x_max=x_max, 
                                          u_min=u_min, u_max=u_max)
            problem = cache["problem"]
            problem.update(q=q, l=lb, u=ub)
        
        # print("E =")
        # print(E)
        # print("q =")
        # print(q)
        res = problem.solve()
        # if not res.info.status_val in (1, 4):  # solved/optimal
        #     print(res)
        #     print("[INFO] iter = {}, cost = {:.3e}".format(iter+1, cost))
        #     raise ValueError("problem cannot be solved")
        dU: NDA = res.x.reshape(N, udim)
        
        U_diff = np.linalg.norm(dU) / (np.linalg.norm(U) + 1e-9)
        
        if verbose:
            print("[INFO] iter = {}, cost = {:.3e}, U_diff = {:.3e}"
                  .format(iter+1, cost, U_diff))
        
        U = U + dU
        if U_diff < tol:
            break
    
    X_opt = integration(
        x0=x0, U=U, dt=dt, dyn_fn=dynamic_fn, add_fn=state_add_fn
    )  # (N+1, xdim)
    
    return U, X_opt
