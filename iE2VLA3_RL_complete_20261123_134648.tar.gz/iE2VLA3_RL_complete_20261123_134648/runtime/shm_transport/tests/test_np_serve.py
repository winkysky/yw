import argparse
import numpy as np
from ..shm_service import expose, run_simple_server, get_shm_proxy


class NumpyServer(object):
    def __init__(self):
        pass
    
    @expose()
    def get_random_matrix(self):
        return np.random.randn(3, 3)


def run_server():
    server = NumpyServer()
    run_simple_server(
        server,
        uri_name="numpy",
        multiplex=False,
        ns_port=9091
    )


def run_client():
    proxy = get_shm_proxy(
        uri_name="numpy",
        ns_port=9091,
        force_use_socket=True,
    )

    mat = proxy.get_random_matrix()
    print(mat)



if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("type", type=str)
    opt = parser.parse_args()

    if opt.type.startswith("s"):
        run_server()
    if opt.type.startswith("c"):
        run_client()


