import pickle
import torch
import copy
import multiprocessing as mp
from .. import get_shm_proxy, setup_log_level


# setup_log_level("DEBUG")

proxy = get_shm_proxy("test_server", shm_nbytes_thresh=0)
print(proxy.get(torch.tensor([0])))
bb = pickle.dumps(proxy)
proxy2 = pickle.loads(bb)
# proxy2 = copy.copy(proxy)
proxy2._pyro_proxy._pyroConnection
print(proxy2._pyro_proxy)
print(proxy2.get(torch.tensor([1])))
print(proxy._pyro_proxy._pyroConnection.sock)
print(proxy2._pyro_proxy._pyroConnection.sock)


# print(proxy2.get(torch.tensor([1])))

# print(proxy.get(torch.tensor([2])))

_ = input("::::::::::::::::::")
