import os
import time
import torch
import multiprocessing as mp
from torch.utils.data import Dataset, IterableDataset, DataLoader
from torch.utils.data import get_worker_info
from .. import get_shm_proxy, setup_log_level
from ..shm_mng import _cleanup_shm, get_client_shm_managers



class IndexDataset(Dataset):
    def __init__(self):
        super().__init__()
        self.client = None
    
    def __len__(self):
        return 10
    
    def __getitem__(self, i):
        if self.client is None:
            # lazy init
            self.client = get_shm_proxy(
                uri_name="test_server",
                copy_ret_shm=True,
                shm_nbytes_thresh=0
            )
            print(self.client.__dict__)

        # print(get_worker_info().id, id(self), id(self.client), get_client_shm_managers().managers)
        # print(get_worker_info().id, id(self), id(self.client))
        ret = self.client.get(torch.tensor([i]))
        time.sleep(0.1)
        return ret


def get_indexed_dataloader(batch_size, num_workers):
    dset = IndexDataset()
    loader = DataLoader(
        dset,
        batch_size=batch_size,
        num_workers=num_workers,
        shuffle=False,
        # persistent_workers=True
        persistent_workers=False
    )
    return loader


def test_indexed_dataloader():
    # setup_log_level("DEBUG")
    # torch.multiprocessing.set_start_method("spawn")

    # dataloader = get_indexed_dataloader(20, 4)
    dataloader = get_indexed_dataloader(20, 0)
    # dataloader = get_indexed_dataloader(4, 2)
    all_data = []
    for data in dataloader:
        all_data.append(data)
    
    all_data = torch.cat(all_data, dim=0)
    # print(all_data)
    assert (all_data[1:] >= all_data[:-1]).all()

    
    print(get_client_shm_managers().managers)
    print(os.getpid())  # 结束时为什么没有safe exit?



if __name__ == "__main__":
    test_indexed_dataloader()
    # test_iter_dataloader()
    _ = input(":::::::::::::::::::::::::::")



