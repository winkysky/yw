"""Transport-independent two-rate execution; caller owns robot I/O and clock.

begin_plan -> generate (may run on a worker) -> accept_plan. Residual control may
continue on the old reference meanwhile. No method sends a robot command.
"""
from dataclasses import dataclass
import math
import numpy as np
import torch
from .geometry import pose_features, compose_residual, so3_log
from .networks import validate_observation
from models.speed_factor import FACTORS
from .geometry import check_se3


def force_history(times, values, now, config):
    times, values = np.asarray(times, np.float64), np.asarray(values, np.float32)
    if (times.ndim != 1 or values.shape != (len(times), 2, 6) or not len(times)
            or not np.isfinite(times).all() or not np.isfinite(values).all()
            or np.any(np.diff(times) <= 0) or not math.isfinite(now)):
        raise ValueError("Expected ordered timestamps and calibrated (N,2,6) wrench history")
    # Never let a future sample influence the observed history.
    keep = times <= now + 2e-6
    times, values = times[keep], values[keep]
    query = now + np.arange(1 - config.force_history, 1) / config.control_hz
    if not len(times) or query[0] < times[0] - 2e-6 or now - times[-1] > config.max_history_gap_s:
        raise ValueError("Insufficient or stale force history")
    first = max(0, np.searchsorted(times, query[0], side='right') - 1)
    if np.any(np.diff(times[first:]) > config.max_history_gap_s):
        raise ValueError("Gap in force history")
    flat = values.reshape(len(values), 12)
    # Linear resampling of measured past values; bounded hold after latest sample.
    result = np.stack([np.interp(query - now, times - now, flat[:, j]) for j in range(12)], -1)
    return result.reshape(config.force_history, 2, 6).astype(np.float32)


@dataclass
class Plan:
    request_id: int
    epoch: int
    anchor: float
    decision_time: float
    speed_factor: float
    action: torch.Tensor
    observation: dict
    prepared: object
    versions: dict


class CommandLimitError(RuntimeError):
    pass


class DualRateController:
    def __init__(self, foundation, learner):
        self.foundation = foundation.freeze_online()
        self.learner, self.config = learner, learner.config
        self.device = next(learner.factor.actor.parameters()).device
        if next(foundation.base.parameters()).device != self.device:
            raise ValueError("Foundation and RL policies must use the same device")
        if foundation.token.config.token_dim != self.config.token_dim:
            raise ValueError("RL token dimension mismatch")
        self.policies = learner.actor_snapshot()
        self.epoch, self.serial = -1, 0
        self.reset()

    def sync_policies(self):
        """Call on the control thread; learner updates never mutate active actors."""
        self.policies = self.learner.actor_snapshot()

    def reset(self):
        self.epoch += 1
        self.pending = self.active = None
        self.token = None
        self.token_time = None
        self.previous_residual = torch.zeros(1, 12, device=self.device)
        self.previous_command = None
        self.previous_command_time = None
        self.last_request_time = -math.inf

    def observation(self, state_pose, gripper, wrench, now):
        if self.token is None or not math.isfinite(now) or now < self.token_time - 2e-6:
            raise ValueError("A causal RL token is required")
        state_pose = check_se3(np.asarray(state_pose), 'current world TCP')
        if state_pose.shape != (2, 4, 4) or np.asarray(gripper).shape != (2,) or np.any((np.asarray(gripper) < 0) | (np.asarray(gripper) > 1)):
            raise ValueError("Invalid dual-arm state")
        tensor = lambda x: torch.as_tensor(x, dtype=torch.float32, device=self.device)
        state = pose_features(tensor(state_pose), tensor(gripper)).flatten().unsqueeze(0)
        reference = torch.zeros(1, 32, 20, device=self.device)
        mask = torch.zeros(1, 32, device=self.device)
        speed, phase, age = 0., 0., 0.
        if self.active is not None:
            from data_utils.trajectory_retime32 import sample_poses, sample_grippers
            plan, prediction = self.active
            times = np.arange(32) / self.config.control_hz
            query = now - plan.anchor + times
            valid = (query >= -2e-6) & (query <= times[-1] + 2e-6)
            if valid.any():
                poses = sample_poses(times, prediction[..., :16].reshape(32, 2, 4, 4), query[valid])
                grips = sample_grippers(times, np.clip(prediction[..., 16], 0, 1), query[valid])
                reference[0, valid] = pose_features(tensor(poses), tensor(grips)).flatten(-2)
                mask[0, valid] = 1
            speed, age = plan.speed_factor, now - plan.anchor
            phase = np.clip(age / times[-1], 0, 1)
        execution = tensor([[speed, self.pending.speed_factor if self.pending else 0., phase,
                             age, now - self.token_time, float(mask[0, 0]), float(self.pending is not None)]])
        obs = dict(token=self.token, state=state, wrench=tensor(wrench)[None], reference=reference,
                   reference_mask=mask, execution=execution, previous_residual=self.previous_residual.clone(),
                   factor_mask=torch.ones(1,4,device=self.device))
        validate_observation(obs, self.config)
        return obs

    @torch.no_grad()
    def begin_plan(self, prepared, anchor, state_pose, gripper, wrench, now,
                   deterministic=False, factor_index=None):
        if self.pending is not None:
            raise RuntimeError('One VLA request is already pending')
        if (not math.isfinite(now) or not math.isfinite(anchor) or now < anchor
                or now-self.last_request_time < self.config.replan_seconds-1e-6):
            raise ValueError('Invalid anchor or replan interval')
        if prepared.token.shape != (1,self.config.token_dim):
            raise ValueError('Runtime controls one robot at a time')
        if self.token_time is not None and anchor < self.token_time:
            raise ValueError('Out-of-order observation')
        self.token,self.token_time=prepared.token.detach(),float(anchor)
        obs=self.observation(state_pose,gripper,wrench,now)
        if factor_index is None:
            action=self.policies['factor'].act(obs,deterministic)
        else:
            if type(factor_index) is not int or not 0<=factor_index<4:
                raise ValueError('Factor index must be 0..3')
            action=torch.tensor([[factor_index]],dtype=torch.long,device=self.device)
        self.serial+=1
        plan=Plan(self.serial,self.epoch,float(anchor),float(now),FACTORS[int(action[0,0])],
                  action,obs,prepared,dict(self.policies['versions']))
        self.pending,self.last_request_time=plan,float(now)
        return plan

    @torch.no_grad()
    def generate(self, plan, initial_noise=None):
        # Run on a single VLA worker. Original scheduler is not reentrant.
        return self.foundation.predict(plan.prepared, plan.speed_factor, initial_noise,
                                       fp16=self.device.type == 'cuda').detach().cpu().numpy()[0]

    def accept_plan(self, plan, prediction, now):
        if not math.isfinite(now):
            raise ValueError('Acceptance time must be finite')
        if self.pending is not plan or plan.epoch != self.epoch:
            raise ValueError("Stale/cancelled VLA response")
        prediction = np.asarray(prediction, np.float32)
        if prediction.shape != (32, 2, 17) or not np.isfinite(prediction).all():
            raise ValueError("Invalid VLA prediction")
        check_se3(prediction[..., :16].reshape(32, 2, 4, 4), 'predicted TCP')
        if now < plan.decision_time or now > plan.anchor + 31 / self.config.control_hz:
            self.pending = None
            raise ValueError("VLA response is out of order or its entire trajectory expired")
        self.active, self.pending = (plan, prediction.copy()), None
        # Timestamps remain anchor+k/30; no shifting a stale trajectory into the future.
        return dict(request_id=plan.request_id, effective_time=float(now),
                    activation_delay_s=float(now - plan.decision_time))

    def cancel_plan(self, plan):
        if self.pending is plan:
            self.pending = None

    @torch.no_grad()
    def propose_control(self, state_pose, gripper, wrench, now, deterministic=False):
        obs = self.observation(state_pose, gripper, wrench, now)
        if not obs['reference_mask'][0, 0]:
            raise RuntimeError("No current reference; caller must hold/stop and record actual behavior")
        from data_utils.trajectory_retime32 import sample_poses, sample_grippers
        plan, prediction = self.active
        times = np.arange(32) / self.config.control_hz
        query = np.array([now - plan.anchor])
        ref = sample_poses(times, prediction[..., :16].reshape(32, 2, 4, 4), query)
        grip = sample_grippers(times, np.clip(prediction[..., 16], 0, 1), query)[0]
        action = self.policies["residual"].act(obs, deterministic)
        reference = torch.as_tensor(ref, device=self.device)
        command = compose_residual(reference, action, self.config)[0]
        previous = (torch.as_tensor(state_pose, dtype=command.dtype, device=self.device)
                    if self.previous_command is None else self.previous_command)
        dt = 1 / self.config.control_hz if self.previous_command_time is None else now - self.previous_command_time
        if dt < 1 / self.config.control_hz - 2e-6:
            raise ValueError("Residual decisions cannot exceed 30 Hz")
        linear = torch.linalg.vector_norm(command[:, :3, 3] - previous[:, :3, 3], dim=-1) / dt
        angular = torch.linalg.vector_norm(so3_log(previous[:, :3, :3].transpose(-1, -2) @ command[:, :3, :3]), dim=-1) / dt
        if (linear > self.config.max_command_speed_mps).any() or (angular > self.config.max_command_angular_speed).any():
            raise CommandLimitError("Composed command exceeds limits; rejected without changing execution history")
        return dict(world_tcp=command, gripper=grip.copy(), action=action, observation=obs,
                    timestamp=float(now), epoch=self.epoch, request_id=plan.request_id,
                    versions=dict(factor=plan.versions['factor'],residual=self.policies['versions']['residual']))

    def acknowledge(self, proposal):
        # Call only AFTER this exact command was accepted by robot transport.
        if (proposal['epoch'] != self.epoch or self.active is None
                or proposal['request_id'] != self.active[0].request_id
                or (self.previous_command_time is not None and proposal['timestamp'] <= self.previous_command_time)):
            raise ValueError("Stale command acknowledgement")
        self.previous_command = proposal['world_tcp'].detach().clone()
        self.previous_residual = proposal['action'].detach().clone()
        self.previous_command_time = proposal['timestamp']
