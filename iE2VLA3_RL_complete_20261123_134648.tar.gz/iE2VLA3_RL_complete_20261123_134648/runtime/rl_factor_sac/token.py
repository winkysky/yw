"""External read-only cross-attention bottleneck and non-teacher-forced decoder."""
from dataclasses import asdict, dataclass
import torch
from torch import nn
from torch.nn import functional as F


@dataclass(frozen=True)
class TokenConfig:
    memory_dim: int = 768
    token_dim: int = 768
    hidden_dim: int = 256
    queries: int = 4
    layers: int = 2
    heads: int = 4
    geometry_dim: int = 19
    auxiliary_horizon: int = 8
    reconstruction_per_modality: int = 16
    action_loss_weight: float = .1

    def __post_init__(self):
        if any(type(v) is not int or v<1 for k,v in asdict(self).items() if k!='action_loss_weight'):
            raise ValueError('Token dimensions/counts must be positive integers')
        if self.hidden_dim%self.heads or self.geometry_dim!=19 or not 0<self.auxiliary_horizon<=32:
            raise ValueError('Invalid readout dimensions')
        if not 0<=self.action_loss_weight< float('inf'):
            raise ValueError('Invalid action auxiliary weight')


class ReadoutBlock(nn.Module):
    def __init__(self,c):
        super().__init__()
        self.norm=nn.LayerNorm(c.hidden_dim)
        self.attn=nn.MultiheadAttention(c.hidden_dim,c.heads,batch_first=True,dropout=0.)
        self.ffn=nn.Sequential(nn.LayerNorm(c.hidden_dim),nn.Linear(c.hidden_dim,c.hidden_dim*2),
                               nn.SiLU(),nn.Linear(c.hidden_dim*2,c.hidden_dim))

    def forward(self,q,memory,valid):
        q=q+self.attn(self.norm(q),memory,memory,key_padding_mask=~valid,need_weights=False)[0]
        return q+self.ffn(q)


class RLToken(nn.Module):
    def __init__(self,config=TokenConfig()):
        super().__init__()
        self.config=config
        c=config
        self.query=nn.Parameter(torch.randn(1,c.queries,c.hidden_dim)*.02)
        self.memory_proj=nn.Sequential(nn.LayerNorm(c.memory_dim),nn.Linear(c.memory_dim,c.hidden_dim))
        self.geometry_proj=nn.Linear(c.geometry_dim,c.hidden_dim)
        self.encoder=nn.ModuleList([ReadoutBlock(c) for _ in range(c.layers)])
        self.readout=nn.Sequential(nn.LayerNorm(c.queries*c.hidden_dim),
                                   nn.Linear(c.queries*c.hidden_dim,c.token_dim))
        self.decoder_query=nn.Linear(c.geometry_dim,c.hidden_dim)
        self.decoder_memory=nn.Linear(c.token_dim,c.hidden_dim)
        layer=nn.TransformerDecoderLayer(c.hidden_dim,c.heads,2*c.hidden_dim,dropout=0.,batch_first=True)
        self.decoder=nn.TransformerDecoder(layer,c.layers)
        self.reconstruction_head=nn.Linear(c.hidden_dim,c.memory_dim)
        self.action_head=nn.Sequential(nn.Linear(c.token_dim+21,c.hidden_dim),nn.SiLU(),
                                       nn.Linear(c.hidden_dim,c.auxiliary_horizon*20))

    def encode(self,memory,geometry,valid):
        if (memory.ndim!=3 or memory.shape[-1]!=self.config.memory_dim
                or geometry.shape!=(*memory.shape[:2],19) or valid.shape!=memory.shape[:2]
                or valid.dtype!=torch.bool or not valid.any(-1).all()):
            raise ValueError('Invalid frozen feature/mask/geometry tensors')
        # Detach at the boundary, not around the trainable readout computation.
        features=self.memory_proj(memory.detach().float())+self.geometry_proj(geometry.detach().float())
        q=self.query.expand(len(memory),-1,-1)
        for block in self.encoder:
            q=block(q,features,valid)
        return self.readout(q.flatten(1))

    def reconstruct(self,token,geometry):
        # Decoder receives only bottleneck + known positions, never target features.
        q=self.decoder_query(geometry.detach().float())
        memory=self.decoder_memory(token).unsqueeze(1)
        return self.reconstruction_head(self.decoder(q,memory))

    def reconstruction_loss(self,token,memory,geometry,valid):
        # Equal weight for head/left/right/language, not the first 64 image tokens.
        losses=[]
        for b in range(len(memory)):
            for modality in range(4):
                indices=torch.where(valid[b] & (geometry[b,:,1+modality]>.5))[0]
                if not len(indices):
                    continue
                positions=torch.linspace(0,len(indices)-1,min(len(indices),self.config.reconstruction_per_modality),
                                         device=indices.device).round().long()
                indices=indices[positions]
                target=F.layer_norm(memory[b:b+1,indices].detach().float(),(self.config.memory_dim,))
                pred=self.reconstruct(token[b:b+1],geometry[b:b+1,indices])
                losses.append(F.mse_loss(pred,target))
        if not losses:
            raise ValueError('No valid reconstruction targets')
        return torch.stack(losses).mean()

    def loss(self,memory,geometry,valid,state,factor,action_target):
        z=self.encode(memory,geometry,valid)
        reconstruction=self.reconstruction_loss(z,memory,geometry,valid)
        inputs=torch.cat((z,state.detach().float(),factor.detach().float().log().unsqueeze(-1)),-1)
        prediction=self.action_head(inputs).reshape(len(z),self.config.auxiliary_horizon,20)
        if action_target.shape!=prediction.shape:
            raise ValueError('Wrong auxiliary action target shape')
        auxiliary=F.smooth_l1_loss(prediction,action_target.detach().float())
        loss=reconstruction+self.config.action_loss_weight*auxiliary
        return loss,dict(reconstruction=float(reconstruction.detach()),action_auxiliary=float(auxiliary.detach()))

    @torch.no_grad()
    def diagnostics(self,memory,geometry,valid):
        z=self.encode(memory,geometry,valid)
        result={'normal':float(self.reconstruction_loss(z,memory,geometry,valid)),
                'zero':float(self.reconstruction_loss(torch.zeros_like(z),memory,geometry,valid))}
        if len(z)>1:
            result['shuffled']=float(self.reconstruction_loss(z.roll(1,0),memory,geometry,valid))
        return result
