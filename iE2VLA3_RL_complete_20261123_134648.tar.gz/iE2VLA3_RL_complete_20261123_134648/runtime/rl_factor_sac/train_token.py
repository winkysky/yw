"""Train only the external RL readout/decoder against a frozen factor VLA."""
import argparse
import bisect
from dataclasses import asdict, replace
import hashlib
import json
from pathlib import Path
import random
import numpy as np
import torch
from torch.utils.data import Dataset
from .foundation import FrozenFoundation,state_features,action_targets
from .io import atomic_save
from .token import RLToken,TokenConfig


class EpisodeSplit(Dataset):
    """Split physical episodes before windows/factors; retain equal group sampling."""
    def __init__(self,base,validation,fraction=.1,seed=42):
        if not 0<fraction<1:
            raise ValueError('Validation fraction must be between zero and one')
        self.base,self.spans,self.ends,self.episode_keys=base,[],[],set()
        self.group_ranges=[]
        source_groups=getattr(base,'group_ranges',[(0,len(base))])
        for group_start,group_end in source_groups:
            begin=len(self)
            for block,start,end in zip(base.blocks,[0]+base.ends[:-1],base.ends):
                if not group_start<=start<group_end:
                    continue
                key=block['episode_key']
                score=int(hashlib.sha256(f'{seed}:{key}'.encode()).hexdigest()[:16],16)/2**64
                if (score<fraction)==validation:
                    self.spans.append((start,end))
                    self.ends.append(len(self)+end-start)
                    self.episode_keys.add(key)
            self.group_ranges.append((begin,len(self)))
        if not hasattr(base,'group_ranges'):
            del self.group_ranges
        if not len(self) or any(a==b for a,b in getattr(self,'group_ranges',[])):
            raise ValueError('Episode split has an empty partition/group; adjust seed/fraction or supply more episodes')

    def __len__(self):
        return self.ends[-1] if self.ends else 0

    def __getitem__(self,index):
        if not 0<=index<len(self):
            raise IndexError(index)
        i=bisect.bisect_right(self.ends,index)
        return self.base[self.spans[i][0]+index-(self.ends[i-1] if i else 0)]

    def close(self):
        self.base.close()


def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--resume',type=Path)
    p.add_argument('--data-root')
    p.add_argument('--token-config',type=Path)
    p.add_argument('--device',default='cuda:0')
    p.add_argument('--steps',type=int,default=10000)
    p.add_argument('--batch-size',type=int,default=4)
    p.add_argument('--workers',type=int,default=2)
    p.add_argument('--threads',type=int,default=4)
    p.add_argument('--lr',type=float,default=1e-4)
    p.add_argument('--save-every',type=int,default=1000)
    p.add_argument('--validate-every',type=int,default=200)
    p.add_argument('--validation-batches',type=int,default=4)
    p.add_argument('--validation-fraction',type=float,default=.1)
    p.add_argument('--seed',type=int,default=42)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    if (min(args.steps,args.batch_size,args.threads,args.save_every,args.validate_every,args.validation_batches)<1
            or args.workers<0 or args.lr<=0):
        raise ValueError('Invalid token training parameters')
    if args.output.exists() and any(args.output.iterdir()) and not args.resume:
        raise FileExistsError('Use a new output directory or --resume')
    torch.set_num_threads(args.threads)
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityDataset,LeRobotRetimedVelocityCollator
    from models.m0512_fm.train_lerobot_dual_velocity import TrainingStream,rng_state,restore_rng
    from data_utils.tokenize import BatchDataTokenizedVLA
    from transformers import Qwen3VLProcessor
    foundation=FrozenFoundation.load(args.base,args.device)
    if args.token_config:
        c=TokenConfig(**json.loads(args.token_config.read_text()))
        if c.memory_dim!=foundation.base.actor.context_encoder.hdim:
            raise ValueError('Token memory dimension differs from frozen action context')
        foundation.token=RLToken(c).to(args.device)
    cfg=replace(foundation.data_config,root=args.data_root) if args.data_root else foundation.data_config
    base=LeRobotRetimedVelocityDataset(cfg)
    stream=None
    try:
        train=EpisodeSplit(base,False,args.validation_fraction,args.seed)
        val=EpisodeSplit(base,True,args.validation_fraction,args.seed)
        assert not train.episode_keys & val.episode_keys
        train_config={k:getattr(args,k) for k in ('batch_size','lr','seed','validation_fraction')}
        train_config['data_config']=asdict(cfg)
        optimizer=torch.optim.AdamW(foundation.token.parameters(),lr=args.lr,weight_decay=1e-4)
        saved=None
        if args.resume:
            saved=torch.load(args.resume,map_location='cpu',weights_only=False)
            if (saved.get('format')!='ie2vla_rl_token_v1' or saved['base_sha256']!=foundation.base_sha256
                    or saved['token_config']!=asdict(foundation.token.config)
                    or saved['dataset_fingerprint']!=base.fingerprint or saved['train_config']!=train_config):
                raise ValueError('Token resume base/config/data mismatch')
            foundation.token.load_state_dict(saved['token'],strict=True)
            optimizer.load_state_dict(saved['optimizer'])
        processor=Qwen3VLProcessor.from_pretrained('Qwen/Qwen3-VL-2B-Instruct')
        collator=LeRobotRetimedVelocityCollator(processor)
        stream=TrainingStream(train,collator,args.batch_size,args.workers,args.seed,
                              **(saved['stream'] if saved else {}))
        if saved:
            restore_rng(saved['rng'])
        print(json.dumps(dict(stage='token',train_episodes=len(train.episode_keys),validation_episodes=len(val.episode_keys),
                              base_sha256=foundation.base_sha256,trainable_parameters=sum(p.numel() for p in foundation.token.parameters()))),flush=True)
        def validation():
            foundation.eval()
            metrics=[]
            # Deterministic coverage; do not mutate the training stream/RNG.
            for batch_index in range(args.validation_batches):
                indices=[(batch_index*args.batch_size+j)*len(val)//(args.validation_batches*args.batch_size)
                         for j in range(args.batch_size)]
                data=BatchDataTokenizedVLA(**collator([val[i] for i in indices])).to(args.device)
                context=foundation.encode(data,False)
                metrics.append(foundation.token.diagnostics(context.memory,context.geometry,context.valid))
            foundation.train()
            return {k:sum(m[k] for m in metrics)/len(metrics) for k in metrics[0]}
        foundation.train()
        for step in range((saved['step'] if saved else 0)+1,args.steps+1):
            data=BatchDataTokenizedVLA(**stream.next()).to(args.device)
            context=foundation.encode(data,False)
            optimizer.zero_grad(set_to_none=True)
            loss,metrics=foundation.token.loss(context.memory,context.geometry,context.valid,
                state_features(context.batch),data._aux_data['speed_factor'],
                action_targets(context.batch,foundation.token.config.auxiliary_horizon))
            if not torch.isfinite(loss):
                raise FloatingPointError('Nonfinite token loss')
            loss.backward()
            torch.nn.utils.clip_grad_norm_(foundation.token.parameters(),1.,error_if_nonfinite=True)
            optimizer.step()
            if step%10==0 or step==1:
                print(json.dumps(dict(step=step,loss=float(loss.detach()),**metrics)),flush=True)
            if step%args.validate_every==0 or step==args.steps:
                print(json.dumps(dict(step=step,validation=validation())),flush=True)
            if step%args.save_every==0 or step==args.steps:
                atomic_save(dict(format='ie2vla_rl_token_v1',step=step,base_sha256=foundation.base_sha256,
                    token_config=asdict(foundation.token.config),token=foundation.token.state_dict(),optimizer=optimizer.state_dict(),
                    dataset_fingerprint=base.fingerprint,train_config=train_config,rng=rng_state(),
                    stream=dict(epoch=stream.epoch,batch_in_epoch=stream.batch_in_epoch)),args.output/f'token_{step:06d}.pt')
    finally:
        stream.close() if stream else base.close()


if __name__=='__main__':
    main()
