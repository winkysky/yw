"""World TCP poses; residual translation and rotation are in reference TCP frame."""
import torch
from torch import Tensor


def pose_features(pose: Tensor, gripper: Tensor) -> Tensor:
    # Same rotation ROW convention as the existing state interface.
    return torch.cat((pose[..., :3, 3], pose[..., :2, :3].flatten(-2),
                      gripper.unsqueeze(-1)), -1)


def so3_exp(vector: Tensor) -> Tensor:
    # matrix_exp is stable and differentiable at exactly zero (zero-initialized actor).
    x, y, z = vector.unbind(-1)
    zero = torch.zeros_like(x)
    skew = torch.stack((zero, -z, y, z, zero, -x, -y, x, zero), -1).reshape(*vector.shape[:-1], 3, 3)
    return torch.matrix_exp(skew)


def so3_log(matrix: Tensor) -> Tensor:
    # BC/diagnostic targets only; scipy handles the pi singularity robustly.
    from scipy.spatial.transform import Rotation
    shape = matrix.shape[:-2]
    result = Rotation.from_matrix(matrix.detach().double().cpu().numpy().reshape(-1, 3, 3)).as_rotvec()
    return torch.as_tensor(result.copy(), device=matrix.device, dtype=matrix.dtype).reshape(*shape, 3)


def residual_scale(config, like):
    return like.new_tensor([config.translation_bound_m] * 3 + [config.rotation_bound_rad] * 3).repeat(2)


def compose_residual(reference: Tensor, normalized: Tensor, config) -> Tensor:
    if reference.shape[-3:] != (2, 4, 4) or normalized.shape != (*reference.shape[:-3], 12):
        raise ValueError("Expected (...,2,4,4) reference and (...,12) residual")
    delta = (normalized * residual_scale(config, normalized)).reshape(*normalized.shape[:-1], 2, 6)
    result = reference.clone()
    result[..., :3, 3] = reference[..., :3, 3] + (reference[..., :3, :3] @ delta[..., :3, None]).squeeze(-1)
    result[..., :3, :3] = reference[..., :3, :3] @ so3_exp(delta[..., 3:])
    return result


def residual_target(reference: Tensor, target: Tensor, config):
    rotation = reference[..., :3, :3].transpose(-1, -2)
    translation = (rotation @ (target[..., :3, 3] - reference[..., :3, 3]).unsqueeze(-1)).squeeze(-1)
    angle = so3_log(rotation @ target[..., :3, :3])
    value = torch.cat((translation, angle), -1).flatten(-2)
    value = value / residual_scale(config, value)
    # Do not silently teach clipped, unachievable demonstration targets.
    valid = (value.abs() <= 1).all(-1)
    return value, valid


def check_se3(value,name='poses'):
    import numpy as np
    value=np.asarray(value,dtype=np.float32)
    if value.shape[-2:]!=(4,4) or not np.isfinite(value).all():
        raise ValueError(f'{name}: expected finite 4x4 poses')
    r=value[...,:3,:3]
    if (not np.allclose(value[...,3,:],[0,0,0,1],atol=1e-5)
            or not np.allclose(r.swapaxes(-1,-2)@r,np.eye(3),atol=2e-3)
            or not np.allclose(np.linalg.det(r),1,atol=2e-3)):
        raise ValueError(f'{name}: invalid rigid transform')
    return value
