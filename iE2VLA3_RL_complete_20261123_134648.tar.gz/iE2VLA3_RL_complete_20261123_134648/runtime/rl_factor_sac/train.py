"""Initialize dual SAC or update both branches from recorded execution replay."""
import argparse
from dataclasses import asdict,replace
import json
from pathlib import Path
import torch
from .config import SACConfig
from .io import file_sha256,validate_bindings
from .reward import RewardConfig
from .sac import DualSAC
from .replay import load_replay
from .token import TokenConfig,RLToken


def artifact_bindings(base,token,reward_config):
    from models.m0512_fm.factor_checkpoint import FORMAT
    base=Path(base)
    base=base/'model.pt' if base.is_dir() else base
    marker=json.loads((base.parent/'complete.json').read_text())
    saved=torch.load(base,map_location='cpu',weights_only=False,mmap=True)
    if (saved.get('format')!=FORMAT or marker.get('format')!=FORMAT
            or marker['step']!=saved['step'] or marker['world_size']!=saved['world_size']):
        raise ValueError('Requires a completed factor VLA checkpoint')
    base_hash=file_sha256(base)
    saved=torch.load(token,map_location='cpu',weights_only=False)
    if saved.get('format')!='ie2vla_rl_token_v1' or saved['base_sha256']!=base_hash:
        raise ValueError('RL token must be trained against this exact factor VLA')
    c=TokenConfig(**saved['token_config'])
    # Check actual encoder/decoder shapes without loading Qwen or using a GPU.
    rng=torch.get_rng_state()
    try:
        RLToken(c).load_state_dict(saved['token'],strict=True)
    finally:
        torch.set_rng_state(rng)
    bindings=dict(base_sha256=base_hash,token_sha256=file_sha256(token),reward_config=asdict(reward_config))
    validate_bindings(bindings)
    return bindings,c.token_dim


def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage',choices=['init','rl'],required=True)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--token',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--config',type=Path)
    p.add_argument('--reward-config',type=Path)
    p.add_argument('--resume',type=Path)
    p.add_argument('--replay',type=Path)
    p.add_argument('--steps',type=int,default=10000,help='Additional learner updates on this replay')
    p.add_argument('--batch-size',type=int,default=32)
    p.add_argument('--save-every',type=int,default=1000)
    p.add_argument('--max-policy-lag',type=int,default=1000)
    p.add_argument('--device',default='cpu')
    p.add_argument('--threads',type=int,default=4)
    p.add_argument('--seed',type=int,default=42)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    if min(args.steps,args.batch_size,args.save_every,args.threads)<1 or args.max_policy_lag<0:
        raise ValueError('Invalid training counts/freshness bound')
    if args.stage=='init' and (args.resume or args.replay):
        raise ValueError('init creates new actors; use rl for resume/replay')
    if args.stage=='rl' and not args.replay:
        raise ValueError('RL needs real robot/simulator execution replay; demonstrations are not rewards')
    if args.output.exists() and any(args.output.iterdir()) and not args.resume:
        raise FileExistsError('Use an empty output directory or --resume')
    torch.set_num_threads(args.threads)
    torch.manual_seed(args.seed)
    reward=RewardConfig(**json.loads(args.reward_config.read_text())) if args.reward_config else RewardConfig()
    bindings,token_dim=artifact_bindings(args.base,args.token,reward)
    if args.resume:
        learner=DualSAC.load(args.resume,args.device,bindings,restore_rng=True)
        if args.config and SACConfig.load(args.config)!=learner.config:
            raise ValueError('Resume SAC config differs')
    else:
        c=SACConfig.load(args.config) if args.config else replace(SACConfig(),token_dim=token_dim)
        learner=DualSAC(c,args.device)
    if learner.config.token_dim!=token_dim:
        raise ValueError('SAC/token dimensions differ')
    if args.stage=='init':
        learner.save(args.output/'sac_init.pt',bindings)
        print(json.dumps(dict(status='initialized_only',checkpoint=str(args.output/'sac_init.pt'))),flush=True)
        return
    buffers=load_replay(args.replay,learner.config,bindings)
    if any(not len(b) for b in buffers.values()):
        raise ValueError('Both branches need completed execution transitions')
    for step in range(1,args.steps+1):
        batches={k+'_batch':v.sample(args.batch_size,args.device,learner.versions,args.max_policy_lag)
                 for k,v in buffers.items()}
        metrics=learner.update(**batches)
        if step==1 or step%10==0:
            print(json.dumps(dict(replay_source=str(args.replay),**metrics)),flush=True)
        if step%args.save_every==0 or step==args.steps:
            learner.save(args.output/f'sac_f{learner.factor.updates:06d}_r{learner.residual.updates:06d}.pt',bindings)


if __name__=='__main__':
    main()
