"""Versioned, atomic artifacts, bound to a base, token and reward definition."""
import hashlib
import os
from pathlib import Path
import uuid
import torch


def file_sha256(path):
    path = Path(path)
    if path.is_dir():
        path = path/'model.pt'
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(1024*1024), b''):
            digest.update(data)
    return digest.hexdigest()


def atomic_save(value,path):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temp = path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temp.open('wb') as stream:
            torch.save(value,stream)
            stream.flush()
            os.fsync(stream.fileno())
        temp.replace(path)
    finally:
        if temp.exists():
            temp.unlink()


def validate_bindings(bindings):
    if set(bindings) != {'base_sha256','token_sha256','reward_config'}:
        raise ValueError('Artifacts must bind base, token and reward definition')
    for name in ('base_sha256','token_sha256'):
        if (not isinstance(bindings[name],str) or len(bindings[name]) != 64
                or any(c not in '0123456789abcdef' for c in bindings[name])):
            raise ValueError(f'Invalid {name}')
    from .reward import RewardConfig
    RewardConfig(**bindings['reward_config'])
