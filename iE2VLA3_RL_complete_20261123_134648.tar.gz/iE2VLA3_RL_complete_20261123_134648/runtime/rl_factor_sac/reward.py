from dataclasses import asdict, dataclass
import math
import numpy as np


@dataclass(frozen=True)
class RewardConfig:
    success: float = 10.
    failure: float = 5.
    time_cost: float = .1
    force_soft_limit_n: float = 15.
    torque_soft_limit_nm: float = 2.
    force_cost: float = .01
    torque_cost: float = .01
    residual_cost: float = .01
    residual_change_cost: float = .01

    def __post_init__(self):
        if any(not math.isfinite(v) or v < 0 for v in asdict(self).values()):
            raise ValueError("Reward coefficients/thresholds must be finite and nonnegative")


class EpisodeReward:
    def __init__(self, config=RewardConfig()):
        self.config = config
        self.ended = False

    def step(self, dt, wrench, residual, previous_residual, outcome=None):
        if self.ended or not math.isfinite(dt) or dt <= 0:
            raise ValueError("Invalid duration or episode already ended")
        if outcome not in (None, 'success', 'failure'):
            raise ValueError("Outcome must be a terminal event, not a per-frame success annotation")
        wrench, residual, previous_residual = map(np.asarray, (wrench, residual, previous_residual))
        if (wrench.shape != (2, 6) or residual.shape != (12,) or previous_residual.shape != (12,)
                or not all(np.isfinite(x).all() for x in (wrench, residual, previous_residual))):
            raise ValueError("Invalid reward measurements")
        c = self.config
        force = np.maximum(0, np.linalg.norm(wrench[:, :3], axis=-1) - c.force_soft_limit_n)
        torque = np.maximum(0, np.linalg.norm(wrench[:, 3:], axis=-1) - c.torque_soft_limit_nm)
        parts = dict(time=-c.time_cost * dt, force=-c.force_cost * float((force ** 2).sum()) * dt,
                     torque=-c.torque_cost * float((torque ** 2).sum()) * dt,
                     residual=-c.residual_cost * float((residual ** 2).mean()) * dt,
                     smooth=-c.residual_change_cost * float(((residual - previous_residual) ** 2).mean()) * dt,
                     terminal=c.success if outcome == 'success' else -c.failure if outcome == 'failure' else 0.)
        self.ended = outcome is not None
        return sum(parts.values()), parts
