from collections import deque
import math
import threading
import torch
from .networks import validate_observation
from .io import atomic_save,validate_bindings


def validate_batch(batch,c,branch):
    if branch not in ('factor','residual'):
        raise ValueError('Unknown branch')
    if set(batch) != {'obs','next_obs','action','reward','discount','terminated','truncated'}:
        raise ValueError('Invalid transition fields')
    validate_observation(batch['obs'],c)
    validate_observation(batch['next_obs'],c)
    b = len(batch['obs']['token'])
    if b < 1 or len(batch['next_obs']['token']) != b:
        raise ValueError('Empty or inconsistent batch')
    for k in ('action','reward','discount','terminated','truncated'):
        shape = (b,12 if k=='action' and branch=='residual' else 1)
        if batch[k].shape != shape or not torch.isfinite(batch[k]).all():
            raise ValueError(f'Invalid {k}')
    if branch=='factor':
        a = batch['action']
        if a.dtype != torch.long or (a<0).any() or (a>=4).any():
            raise ValueError('Factor actions are int64 indices 0..3, not physical values')
        if not batch['obs']['factor_mask'].gather(1,a).bool().all():
            raise ValueError('Recorded factor was not feasible')
    else:
        a,prev = batch['action'],batch['obs']['previous_residual']
        if (a.abs()>1.00001).any() or ((a-prev).abs()>c.residual_change_fraction+1e-5).any():
            raise ValueError('Recorded residual exceeds amplitude/slew bounds')
        if not batch['obs']['reference_mask'][:,0].bool().all():
            raise ValueError('Residual decisions require an active reference')
    if not ((batch['discount']>0)&(batch['discount']<=1)).all():
        raise ValueError('Invalid elapsed-time discount')
    for k in ('terminated','truncated'):
        if not ((batch[k]==0)|(batch[k]==1)).all():
            raise ValueError('Termination flags must be binary')
    if ((batch['terminated']+batch['truncated'])>1).any():
        raise ValueError('A transition cannot be both terminal and time-limit truncated')
    if branch=='residual' and ((batch['terminated'][:,0]==0)&(batch['next_obs']['reference_mask'][:,0]==0)).any():
        raise ValueError('Residual bootstrap needs a valid final reference; end expired-reference episodes explicitly')


def copy_obs(obs,device=None):
    return {k:v.detach().to(device or v.device).clone() for k,v in obs.items()}


class ReplayBuffer:
    def __init__(self,config,branch,capacity=100000):
        if branch not in ('factor','residual') or capacity<1:
            raise ValueError('Invalid replay configuration')
        self.config,self.branch,self.rows = config,branch,deque(maxlen=capacity)
        self.lock=threading.RLock()

    def __len__(self):
        with self.lock:
            return len(self.rows)

    def snapshot(self):
        # Added rows are immutable CPU copies. Learner sampling can run alongside
        # control-thread append without iterating a mutating deque.
        with self.lock:
            return list(self.rows)

    def add(self,row,*,versions,timestamp,source,activation_delay_s=None):
        validate_batch(row,self.config,self.branch)
        if len(row['action'])!=1 or source not in ('robot','simulator'):
            raise ValueError('Append one actually executed robot/simulator transition')
        if (set(versions)!= {'factor','residual'} or any(type(x) is not int or x<0 for x in versions.values())
                or not math.isfinite(timestamp)):
            raise ValueError('Invalid replay policy versions/time')
        if activation_delay_s is not None and (not math.isfinite(activation_delay_s) or activation_delay_s<0):
            raise ValueError('Invalid activation delay')
        row = {k:copy_obs(v,'cpu') if isinstance(v,dict) else v.detach().cpu().clone() for k,v in row.items()}
        with self.lock:
            self.rows.append((row,dict(versions=dict(versions),timestamp=float(timestamp),source=source,
                                       activation_delay_s=activation_delay_s)))

    def sample(self,batch_size,device='cpu',versions=None,max_policy_lag=None):
        rows = self.snapshot()
        if max_policy_lag is not None:
            if versions is None or max_policy_lag<0:
                raise ValueError('Freshness filtering requires both policy versions')
            rows = [x for x in rows if all(0<=versions[k]-x[1]['versions'][k]<=max_policy_lag for k in versions)]
        if batch_size<1 or not rows:
            raise ValueError('No eligible replay transitions')
        chosen = [rows[i][0] for i in torch.randint(len(rows),(batch_size,)).tolist()]
        return {k:({n:torch.cat([x[k][n] for x in chosen]).to(device) for n in chosen[0][k]}
                   if isinstance(chosen[0][k],dict) else torch.cat([x[k] for x in chosen]).to(device))
                for k in chosen[0]}


class IntervalRecorder:
    def __init__(self,c,obs,action,timestamp,versions):
        self.config,self.obs,self.action = c,copy_obs(obs),action.detach().clone()
        self.start=self.last=float(timestamp)
        self.reward,self.elapsed = 0.,0.
        self.versions=dict(versions)
        self.activation_delay=None
        self.closed=False

    def activate(self,now):
        if not math.isfinite(now) or now<self.start or self.activation_delay is not None:
            raise ValueError('Invalid activation time')
        self.activation_delay=now-self.start

    def tick(self,reward,now):
        if self.closed or not math.isfinite(reward) or not math.isfinite(now) or now<=self.last:
            raise ValueError('Feedback must advance actual time')
        self.reward += self.config.gamma_per_second**self.elapsed*float(reward)
        self.elapsed,self.last=now-self.start,float(now)

    def finish(self,next_obs,terminated=False,truncated=False):
        if self.closed or self.elapsed<=0:
            raise ValueError('Empty or already closed interval')
        scalar=lambda x: self.obs['state'].new_tensor([[float(x)]])
        result=dict(obs=self.obs,next_obs=copy_obs(next_obs),action=self.action,
                    reward=scalar(self.reward),discount=scalar(self.config.discount(self.elapsed)),
                    terminated=scalar(terminated),truncated=scalar(truncated))
        self.closed=True
        return result


def save_replay(path,buffers,bindings):
    validate_bindings(bindings)
    if set(buffers)!= {'factor','residual'} or buffers['factor'].config!=buffers['residual'].config:
        raise ValueError('Expected matching dual replay buffers')
    atomic_save(dict(format='ie2vla_factor_sac_replay_v1',config=buffers['factor'].config.asdict(),
                     bindings=bindings,buffers={k:v.snapshot() for k,v in buffers.items()}),path)


def load_replay(path,c,bindings):
    validate_bindings(bindings)
    saved=torch.load(path,map_location='cpu',weights_only=False)
    if (saved.get('format')!='ie2vla_factor_sac_replay_v1' or saved['config']!=c.asdict()
            or saved['bindings']!=bindings):
        raise ValueError('Replay base/token/reward/config mismatch')
    result={k:ReplayBuffer(c,k,max(1,len(v))) for k,v in saved['buffers'].items()}
    if set(result)!= {'factor','residual'}:
        raise ValueError('Missing replay branch')
    for k,rows in saved['buffers'].items():
        for row,meta in rows:
            result[k].add(row,**meta)
    return result
