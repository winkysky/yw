"""New offline/RL bridge. It does not import or modify any inference service."""
from dataclasses import dataclass
import json
from pathlib import Path
import torch
from torch import nn
from action.parser import ProprioParser
from data_utils.tokenize import ModalityType
from models.m0512_fm.action_expert import pad_or_trunc_inputs
from .token import RLToken,TokenConfig
from .io import file_sha256


def feature_geometry(batch,merge_size=2):
    vision=batch.modality==ModalityType.VISION
    valid=batch.modality!=ModalityType.PAD
    b,length=vision.shape
    geometry=torch.zeros(b,length,19,device=vision.device)
    geometry[:,:,0]=valid.cumsum(-1)/valid.sum(-1,keepdim=True).clamp_min(1)
    geometry[:,:,4]=(~vision & valid).float()
    geometry[...,5:7][vision]=batch.patch_norm_xy.float()
    geometry[...,7:19][vision]=batch.patch_pose[:,:3].float().flatten(1)
    grids=batch.tokenized_vl.get('image_grid_thw')
    if grids is None or grids.shape!=(b*3,3):
        raise ValueError('RL token bridge expects three current RGB images per observation')
    counts=(grids.prod(-1)//(merge_size*merge_size)).reshape(b,3)
    for i in range(b):
        positions=torch.where(vision[i])[0]
        if int(counts[i].sum())!=len(positions):
            raise ValueError('Image patch count differs from vision mask')
        begin=0
        for cam,count in enumerate(counts[i].tolist()):
            geometry[i,positions[begin:begin+count],1+cam]=1
            begin+=count
    return geometry*valid[:,:,None],valid


def state_features(batch):
    # Actual world TCP state, BEFORE the actor's wrist-camera transformation.
    return batch.state[:,:,-1,:10].flatten(1).float()


def action_targets(batch,horizon):
    state=ProprioParser(batch.state[:,:,-1]).posemat
    action=ProprioParser(batch.action[:,:,:horizon]).posemat
    relative=torch.linalg.inv(state)[:,:,None]@action
    # Scale translation to decimetres only for the auxiliary training loss.
    target=torch.cat((relative[...,:3,3]/.1,relative[...,:2,:3].flatten(-2),
                      batch.action[:,:,:horizon,9:10]),-1)
    return target.transpose(1,2).flatten(-2).float()


def decode_prediction(prediction):
    poses=ProprioParser(prediction).posemat.permute(0,2,1,3,4)
    grips=prediction[...,9].permute(0,2,1)
    return torch.cat((poses.flatten(-2),grips[...,None]),-1).float()


@dataclass
class PreparedContext:
    batch: object
    vl_outputs: dict
    memory: torch.Tensor
    geometry: torch.Tensor
    valid: torch.Tensor
    token: torch.Tensor | None = None


class FrozenFoundation(nn.Module):
    def __init__(self,base,token_config=None):
        super().__init__()
        self.base=base.eval().requires_grad_(False)
        c=token_config or TokenConfig(memory_dim=base.actor.context_encoder.hdim)
        self.token=RLToken(c).to(next(base.parameters()).device)
        self.base_sha256=None
        self.data_config=None

    @classmethod
    def load(cls,checkpoint,device='cpu',token_checkpoint=None):
        from models.m0512_fm.factor_checkpoint import FORMAT
        from models.m0512_fm.vla_lerobot_dual_velocity import LeRobotDualVelocityVLA
        from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityConfig
        path=Path(checkpoint)
        path=path/'model.pt' if path.is_dir() else path
        marker=json.loads((path.parent/'complete.json').read_text())
        saved=torch.load(path,map_location='cpu',weights_only=False,mmap=True)
        if (marker.get('format')!=FORMAT or saved.get('format')!=FORMAT
                or saved['step']!=marker['step'] or saved['world_size']!=marker['world_size']):
            raise ValueError('Requires a completed four-factor full checkpoint')
        # Keep saved feature semantics while freezing AFTER construction/loading.
        model=LeRobotDualVelocityVLA(**saved['model_config'])
        model.load_state_dict(saved['model'],strict=True)
        model.to(device)
        token_saved=None
        base_hash=file_sha256(path)
        if token_checkpoint:
            token_saved=torch.load(token_checkpoint,map_location='cpu',weights_only=False)
            if token_saved.get('format')!='ie2vla_rl_token_v1' or token_saved['base_sha256']!=base_hash:
                raise ValueError('Token and base checkpoint do not match')
        result=cls(model,TokenConfig(**token_saved['token_config']) if token_saved else None)
        result.base_sha256=base_hash
        result.data_config=LeRobotRetimedVelocityConfig(**saved['data_config'])
        if token_saved:
            result.token.load_state_dict(token_saved['token'],strict=True)
        from models.m0512_fm.lerobot_runtime import configure_conv3d_layout
        configure_conv3d_layout(result.base)
        return result

    def train(self,mode=True):
        super().train(mode)
        self.base.eval()
        return self

    def encode(self,batch,with_token=True):
        with torch.no_grad():
            data=pad_or_trunc_inputs(batch.deepcopy())
            features=self.base.vlm.hidden_layer_features(data.tokenized_vl,self.base.vlm_layer_indices)
            context=self.base.actor.context_encoder(data,features)
            # The final highway is UNUSED by the action expert. The last used
            # one is -2 and contains normalized final Qwen output in full mode.
            memory=context['vl_highways'][-2] if len(context['vl_highways'])>1 else context['vl0']
            merge=self.base.vlm.qwen.config.vision_config.spatial_merge_size
            geometry,valid=feature_geometry(data,merge)
        token=self.token.encode(memory,geometry,valid) if with_token else None
        # Actor.forward owns 73 -> 80 channel padding. Keep the raw-width batch
        # here so cached prediction does not pad the already padded tensor twice.
        return PreparedContext(batch.deepcopy(),features,memory.detach(),geometry,valid,token)

    @torch.no_grad()
    def predict(self,prepared,speed_factor,initial_noise=None,fp16=False):
        prediction=self.base.actor(prepared.batch,prepared.vl_outputs,True,fp16,
                                   speed_factor=speed_factor,initial_noise=initial_noise)
        return decode_prediction(prediction)

    def freeze_online(self):
        return self.eval().requires_grad_(False)
