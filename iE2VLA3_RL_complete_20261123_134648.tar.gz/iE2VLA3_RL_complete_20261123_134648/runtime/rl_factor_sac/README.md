# 四倍率 VLA、RL token 与双 SAC

本目录提供训练与不绑定通信协议的执行模块，不导入或修改 e2vla 的代码。
现有 `e2vla_compat`、`e2vla_async`、`lerobot_raw_inference` 和原客户端保持原状。
这里没有启动机器人，没有创建新 RPC 接口，也没有把 30 Hz 残差自动接入现有服务。

## 模型与训练阶段

1. **倍率 VLA 监督训练**：四档 0.8/1/1.5/2，32 点，30 Hz。标量倍率通过 MLP 加入原 FiLM 条件路径。
   Qwen 全量微调、LoRA 关闭；任务动作网络从头训练。命令见 [速度版说明](../models/m0512_fm/README_lerobot_dual_velocity.md)。
2. **RL token 编解码训练**：冻结已训好的倍率 VLA。4 个可学习 query 经两层 cross-attention 读取动作专家实际使用的最后一路视觉语言特征，输出 768 维 token。
   读取点是 `context['vl_highways'][-2]`，不是从未被动作专家使用的最后一项。
   对于当前 full-Qwen 模式，它对应经过最终归一化的 Qwen 输出再投影到动作网络维度。
3. **在线 RL**：冻结 VLA 和 RL token；离散 SAC 每次新 chunk 请求选择一档倍率，连续 SAC 每个 30 Hz 控制步输出双臂 12 维位姿残差。
   两个独立 replay、actor、双 Q、target Q 和温度优化器在同一训练循环内更新；按各自实际决策间隔构造 transition。

当前/历史输入契约：

| 输入 | 形状与含义 |
|---|---|
| RL token | `(B,768)`，冻结 VLA 的当前三路图像与任务指令特征 |
| 当前 state | `(B,20)`，每臂 xyz 米 + 旋转矩阵前两行 6D + 夹爪 openness；**左臂 recorded base 下的绝对 TCP state** |
| 历史力 | `(B,8,2,6)`，截至当前时间的真实测量，前三维 N、后三维 Nm；固定在每臂工具/传感器约定下，调用方先完成标定和去偏置 |
| 参考动作 | `(B,32,20)` 和有效 mask，当前已接受 chunk 在当前时刻之后的剩余动作 |
| 执行信息 | 活跃倍率、待生效倍率、chunk 相位、参考年龄、token 年龄、有无参考/待返回请求 |
| 上一步残差 | `(B,12)`，实际被传输层接受的归一化残差 |

绝对 state 和历史力直接进入 SAC 的观测编码器；力使用 GRU 编码。它们不会修改基础 VLA 的原有 state 变换。
RL token 的训练是独立旁路，不能改变基础 VLA 输出。它没有向 VLA 主干追加 token，也没有恢复旧 QFormer。

## RL token 编码器、解码器和损失

- 编码器：冻结特征及位置/相机几何 → 投影 → 4 query cross-attention → 拼接投影为 768D。
- 解码器：已知位置/模态/相机几何作为 query，**只以 RL token 为 memory** 重建冻结特征。不会把目标特征作为 decoder 输入。
- 主损失：重建归一化特征 MSE。头部、左腕、右腕、语言四类等权，各均匀选最多 16 个目标。
- 辅助损失：`token + 当前绝对 state + log(倍率)` 预测前 8 步相对当前 TCP 的双臂动作，Smooth L1，权重 0.1。
  平移在该辅助损失中除以 0.1 米，旋转仍为 6D、夹爪 openness。未来动作只作监督目标。
- 验证按物理 episode/split_group 切分后再展开倍率，避免同一轨迹的不同帧或倍率泄漏。
- 验证输出 normal、zero、shuffled 的重建误差；若正常 token 相比零/打乱 token 没有收益，不能据此宣布 token 已学好。

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3
python -m rl_factor_sac.train_token \
  --base /nas_data_new/hq/98qwenvla/ie2vla3_factor_sft_20261123/step_0100000 \
  --output /nas_data_new/hq/98qwenvla/ie2vla3_factor_token_20261123 \
  --device cuda:0 --steps 10000 --batch-size 4
```

默认只训 token 模块；保留 10% episode 验证，训练组间采样仍为 50/50。可用 `--token-config` 覆盖 `TokenConfig` 字段，
`--resume token_001000.pt` 恢复权重、优化器、数据游标和 RNG。基础 VLA 的 SHA256、数据指纹和配置必须匹配。
每个 token checkpoint 同时包含 encoder、decoder 和辅助动作头。在线只运行 encoder。

## 离散与连续 SAC

离散分支对四个动作精确求期望，不对倍率取整或使用连续 actor 冒充离散 actor。
初始 logits 略偏向 1x，但采样仍有探索。连续分支使用重参数化 Gaussian → tanh → 状态相关仿射映射。
概率密度同时包含 tanh 和仿射变换的 Jacobian，自动温度的目标熵也采用同一坐标系。
实现依据 [SAC 原论文](https://arxiv.org/abs/1812.05905) 和 [离散 SAC](https://arxiv.org/abs/1910.07207)。

默认残差每臂为 `[dx,dy,dz,rx,ry,rz]`，相对于参考 TCP 的局部坐标：

```text
p_cmd = p_ref + R_ref @ delta_p
R_cmd = R_ref @ Exp(delta_rotvec)
```

每轴平移上限 5 mm、每轴旋转上限 0.05 rad；归一化动作在 [-1,1]，每步最多变化 0.2。
连续 actor 直接在可行区间采样；不会先让 actor 产生无限制动作，再把被裁剪后的不同动作当原动作训练。
夹爪沿用 VLA 输出，不由残差策略修改。合成命令另有速度/角速度上限检查，超限拒绝，不写入成功执行记录。
这些物理量仅用于动作边界与反馈，不是 VLA 的速度标签。

默认每 0.5 秒允许一次新 chunk 请求（32 点参考可覆盖 31/30 秒）；倍率在新请求时确定，并在结果接受后生效。
`replan_seconds` 可配置。连续分支按 30 Hz 调用；这里提供时序校验，未声称 Python/PyTorch 达到了实机硬实时要求。

折扣以真实秒数计算：`discount = gamma_per_second ** elapsed_seconds`，默认 `gamma_per_second=0.99`。
倍率回放累计一个决策间隔内的折扣奖励；残差回放每个实际控制步一条。真终止不 bootstrap，时间截断保留 bootstrap。
残差 bootstrap 要有有效的下一参考；参考耗尽导致控制失败时，应记录实际失败终止，不能伪造一条可执行的下一状态。

默认奖励包含真实成功/失败终止事件、耗时、超阈值力/力矩、残差幅度和平滑项；参数在 `RewardConfig`。
没有自动视觉成功检测，调用方必须提供可靠的真实任务结果。LeRobot 示范不能凭空生成 RL reward/done。
时间重采样的动作也不能用于伪造“倍速下测得的历史力”。

初始化 RL（仅保存初始网络，不代表完成训练）：

```bash
python -m rl_factor_sac.train --stage init \
  --base /nas_data_new/hq/98qwenvla/ie2vla3_factor_sft_20261123/step_0100000 \
  --token /nas_data_new/hq/98qwenvla/ie2vla3_factor_token_20261123/token_010000.pt \
  --config rl_factor_sac/default_config.json \
  --output /nas_data_new/hq/98qwenvla/ie2vla3_dual_sac_init
```

从实际收集的执行回放更新两个分支：

```bash
python -m rl_factor_sac.train --stage rl \
  --base /nas_data_new/hq/98qwenvla/ie2vla3_factor_sft_20261123/step_0100000 \
  --token /nas_data_new/hq/98qwenvla/ie2vla3_factor_token_20261123/token_010000.pt \
  --resume /nas_data_new/hq/98qwenvla/ie2vla3_dual_sac_init/sac_init.pt \
  --replay /absolute/path/executed_replay.pt \
  --output /nas_data_new/hq/98qwenvla/ie2vla3_dual_sac_run \
  --steps 500 --batch-size 32 --device cpu
```

此命令消费固定回放；持续在线训练使用下述 `OnlineSession.update()`。
默认仅使用两个 policy 版本各自落后不超过 1000 次更新的样本；没有足够新数据时需要继续收集真实回放。
`--steps` 是本次额外更新次数；SAC checkpoint 保留两套网络、target、优化器、温度和 RNG。
SAC、token 和回放均绑定基础模型/token 哈希与完整奖励定义。修改奖励或基础模型不能混用旧 replay。

## 执行与记录 API

```python
from rl_factor_sac.policy import load_runtime
from rl_factor_sac.runtime import force_history

controller, collector, bindings = load_runtime(
    base_checkpoint, token_checkpoint, sac_checkpoint,
    source='simulator',  # 实际机器人执行时显式填写 'robot'
    device='cuda:0',
)
```

调用方负责 RGB/任务/state 的原 tokenizer 输入、同一单调时钟、真实力测量、任务结果和动作传输。
记录 pose 使用与模型相同的左臂基座 TCP（米、4x4），gripper 为 openness；原 recorded/raw 在边界用相同标定转换一次。
本目录没有改变现有 recorded/raw RPC 约定，也没有假设普通 RPC 自动提供了 30 Hz 力反馈。

执行流程：

1. 在**同一个 VLA 工作线程**调用 `controller.foundation.encode(batch)` 得到 prepared context。
   其 anchor 是图像/state 捕获时间。可在上一 chunk 执行期间准备最新观测；Qwen 特征提取与生成不可重入。
2. 控制线程在新 chunk 决策点调用 `begin_plan(prepared, anchor, state_pose, gripper, wrench_history, now)`。
   倍率 actor 看到最新实测 state/力和带年龄的 token/旧参考；最多保留一个 pending 请求。
3. 工作线程执行 `generate(plan)`；期间控制线程继续使用旧参考。返回后控制线程 `accept_plan(plan, prediction, now)`。
   保留原始 `anchor + k/30` 时间轴，丢弃已过期部分，不把旧观测产生的动作整体平移到未来。
4. 每个控制时刻调用 `propose_control(..., now)`；只有传输层接受了这个确切命令，才调用 `controller.acknowledge(proposal)`
   与 `collector.on_command_accepted(proposal)`。实际裁剪/限速导致的不同命令不能当作该 proposal 直接训练。
5. 在下一反馈时刻用新观测调用 `collector.observe_tick(next_obs, now, measured_wrench, actual_residual, previous_residual, outcome=...)`。
   `next_obs` 必须是**下一次残差决策实际使用的观测**：包括已经发生的参考切换、最新 token 和新 pending 倍率。
   同一时刻需要新倍率决策时，先让 controller 完成参考接受/`begin_plan`，取得下一残差观测；再记录本次反馈，
   然后 `collector.on_factor_decision(plan)`（它使用 plan 自带的倍率决策前观测），最后提交下一条残差命令。
   `on_factor_effective(plan, now)` 记录接受时刻；新决策与接受同一时刻时，先登记该决策再登记生效。
6. 真成功/失败分别传 `outcome='success'/'failure'`；纯时间截断用 `truncated=True`。最后反馈完成后分别 reset controller/collector。
   命令被拒绝时不记残差成功执行；factor 的等待时段仍累计实际耗时/力反馈。
7. learner 工作线程调用 `collector.update(batch_size=32)`；有两组完整数据时同时更新两个分支。
   控制线程通过 `controller.sync_policies()` 在时刻边界发布网络快照，优化器更新不会原地改变执行中的 actor。
   `collector.save_replay(path, bindings)` 保存执行数据；`controller.learner.save(path, bindings)` 保存 RL 权重。

执行事件和 replay 采样由内部缓冲区锁协调；controller 的 reset/accept/propose/ack/sync 应由一个控制线程串行调用。
`tests/test_rl_factor_sac.py` 给出了静态参考模拟器中的完整决策→执行确认→反馈→双 SAC 更新例子。
现有客户端若不提供执行侧的 state/力/动作确认，就不能仅靠服务端返回一个 chunk 实现每步闭环残差；这次按要求保留所有既有服务端代码，未添加这种传输接线。

## 测试与边界

CPU 测试覆盖四档数据增强、分组采样、双臂 FiLM/Qwen 梯度、缓存一致性、token 学习与消融、SAC 目标/概率密度、
独立温度/actor/critic 更新、恢复后下一步一致性、异步参考过期、执行确认和模拟回放 CLI。
完整基础 VLA、RL token 的真实数据训练及机器人在线 RL 尚未运行；新权重的任务表现和 30 Hz 延迟尚未实测。
修改范围和原文件哈希记录在 `audits/factor_sac_20261123`。
