"""Categorical tempo and bounded Gaussian residual policies with twin critics."""
import math
import torch
from torch import nn
from torch.nn import functional as F
from models.speed_factor import FACTORS

EXECUTION_FIELDS = ('active_factor', 'pending_factor', 'phase', 'reference_age_s',
                    'token_age_s', 'has_reference', 'has_pending')


def observation_shapes(c):
    return dict(token=(c.token_dim,), state=(20,), wrench=(c.force_history, 2, 6),
                reference=(32,20), reference_mask=(32,), execution=(7,),
                previous_residual=(12,), factor_mask=(len(FACTORS),))


def validate_observation(obs, c):
    if set(obs) != set(observation_shapes(c)):
        raise ValueError('Unexpected RL observation fields')
    b = len(obs['token'])
    for key, shape in observation_shapes(c).items():
        if obs[key].shape != (b,*shape) or not torch.isfinite(obs[key]).all():
            raise ValueError(f'Invalid {key}, expected {(b,*shape)}')
    for key in ('reference_mask', 'factor_mask'):
        if not ((obs[key] == 0) | (obs[key] == 1)).all():
            raise ValueError(f'{key} must be binary')
    if not obs['factor_mask'].bool().any(-1).all():
        raise ValueError('At least one factor must be available')
    if (obs['previous_residual'].abs() > 1).any():
        raise ValueError('Previous residual must be normalized to [-1,1]')


def mlp(i, h, o):
    return nn.Sequential(nn.Linear(i,h), nn.LayerNorm(h), nn.SiLU(),
                         nn.Linear(h,h), nn.SiLU(), nn.Linear(h,o))


class ObservationEncoder(nn.Module):
    def __init__(self, c):
        super().__init__()
        h = c.hidden_dim
        self.token = nn.Sequential(nn.LayerNorm(c.token_dim), nn.Linear(c.token_dim,h), nn.SiLU())
        self.force = nn.GRU(12,h//2,batch_first=True)
        self.reference = mlp(32*21,h,h//2)
        self.fusion = mlp(2*h+20+7+12+4,h,h)
        self.register_buffer('wrench_scale', torch.tensor([c.force_scale_n]*3+[c.torque_scale_nm]*3))

    def forward(self, obs):
        token = self.token(obs['token'].detach())
        force, _ = self.force((obs['wrench']/self.wrench_scale).flatten(-2))
        mask = obs['reference_mask'].unsqueeze(-1)
        reference = self.reference(torch.cat((obs['reference']*mask,mask),-1).flatten(1))
        return self.fusion(torch.cat((token,force[:,-1],reference,obs['state'],obs['execution'],
                                      obs['previous_residual'],obs['factor_mask'].float()),-1))


class FactorActor(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.encoder = ObservationEncoder(c)
        self.head = nn.Linear(c.hidden_dim,4)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)
        with torch.no_grad():
            self.head.bias[1] = 2.  # initial preference for recorded 1x pace

    def distribution(self, obs):
        logits = self.head(self.encoder(obs)).masked_fill(~obs['factor_mask'].bool(), -torch.inf)
        logp = F.log_softmax(logits,-1)
        # Avoid 0 * -inf in exact categorical expectations.
        return logp.exp(), torch.where(obs['factor_mask'].bool(),logp,torch.zeros_like(logp))

    def act(self, obs, deterministic=False):
        p, _ = self.distribution(obs)
        return (p.argmax(-1,keepdim=True) if deterministic else torch.multinomial(p,1))


class ResidualActor(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.config = c
        self.encoder = ObservationEncoder(c)
        self.head = nn.Linear(c.hidden_dim,24)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)
        with torch.no_grad():
            self.head.bias[12:] = -2.

    def bounds(self, obs):
        p, d = obs['previous_residual'], self.config.residual_change_fraction
        lo, hi = (p-d).clamp(-1,1), (p+d).clamp(-1,1)
        return (lo+hi)/2, (hi-lo)/2

    def sample(self, obs, deterministic=False):
        mean, logstd = self.head(self.encoder(obs)).chunk(2,-1)
        logstd = logstd.clamp(-5,1)
        normal = torch.distributions.Normal(mean,logstd.exp())
        raw = mean if deterministic else normal.rsample()
        unit = raw.tanh()
        center, half = self.bounds(obs)
        # Stable tanh Jacobian AND state-dependent affine/slew Jacobian.
        log_jac = 2*(math.log(2)-raw-F.softplus(-2*raw))
        log_half = half.log().sum(-1,keepdim=True)
        logp = (normal.log_prob(raw)-log_jac).sum(-1,keepdim=True)-log_half
        return center+half*unit, logp, center+half*mean.tanh(), log_half

    def act(self, obs, deterministic=False):
        return self.sample(obs,deterministic)[0]


class QNetwork(nn.Module):
    def __init__(self, c, branch):
        super().__init__()
        self.encoder = ObservationEncoder(c)
        self.branch = branch
        self.head = mlp(c.hidden_dim+(12 if branch=='residual' else 0),c.hidden_dim,
                        1 if branch=='residual' else 4)

    def forward(self, obs, action=None):
        h = self.encoder(obs)
        return self.head(torch.cat((h,action),-1) if self.branch=='residual' else h)


class TwinCritic(nn.Module):
    def __init__(self,c,branch):
        super().__init__()
        self.q1,self.q2 = QNetwork(c,branch),QNetwork(c,branch)

    def forward(self,obs,action=None):
        return self.q1(obs,action), self.q2(obs,action)
