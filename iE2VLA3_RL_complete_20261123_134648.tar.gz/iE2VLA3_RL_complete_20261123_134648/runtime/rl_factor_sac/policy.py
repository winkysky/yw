"""Artifact-checked construction for a future transport adapter or simulator."""
from dataclasses import asdict
from .foundation import FrozenFoundation
from .io import file_sha256
from .sac import DualSAC
from .reward import RewardConfig
from .runtime import DualRateController
from .online import OnlineSession


def load_runtime(base_checkpoint,token_checkpoint,sac_checkpoint,*,source,device='cpu',
                 reward_config=RewardConfig(),replay_capacity=100000):
    """Does not connect, subscribe, start threads, or send any robot commands."""
    foundation=FrozenFoundation.load(base_checkpoint,device,token_checkpoint)
    bindings=dict(base_sha256=foundation.base_sha256,token_sha256=file_sha256(token_checkpoint),
                  reward_config=asdict(reward_config))
    learner=DualSAC.load(sac_checkpoint,device,bindings)
    controller=DualRateController(foundation,learner)
    collector=OnlineSession(learner,source=source,capacity=replay_capacity,reward_config=reward_config)
    return controller,collector,bindings
