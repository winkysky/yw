from dataclasses import asdict, dataclass
import json
import math
from models.speed_factor import FACTORS


@dataclass(frozen=True)
class SACConfig:
    token_dim: int = 768
    hidden_dim: int = 256
    force_history: int = 8
    horizon: int = 32
    control_hz: float = 30.
    replan_seconds: float = .5
    translation_bound_m: float = .005
    rotation_bound_rad: float = .05
    residual_change_fraction: float = .2
    max_command_speed_mps: float = .5
    max_command_angular_speed: float = 1.
    force_scale_n: float = 20.
    torque_scale_nm: float = 2.
    max_history_gap_s: float = .1
    gamma_per_second: float = .99
    tau: float = .005
    actor_lr: float = 1e-4
    critic_lr: float = 3e-4
    temperature_lr: float = 1e-4
    initial_temperature: float = .05
    factor_entropy_fraction: float = .6
    residual_regularizer: float = .01
    smooth_regularizer: float = .01
    grad_clip: float = 1.

    def __post_init__(self):
        for key, value in asdict(self).items():
            if not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f'Invalid {key}')
        for key in ('token_dim', 'hidden_dim', 'force_history', 'horizon'):
            if type(getattr(self, key)) is not int:
                raise ValueError(f'{key} must be an integer')
        if self.horizon != 32 or self.control_hz != 30 or self.hidden_dim % 2:
            raise ValueError('Expected 32 targets, 30 Hz, even hidden dimension')
        if max(self.gamma_per_second, self.tau, self.factor_entropy_fraction) > 1:
            raise ValueError('Discount/tau/entropy fraction cannot exceed one')
        if self.residual_change_fraction > 2:
            raise ValueError('Residual slew is in normalized [-1,1] units')

    def asdict(self):
        return asdict(self)

    @classmethod
    def load(cls, path):
        with open(path) as stream:
            return cls(**json.load(stream))

    def discount(self, elapsed_seconds):
        if not math.isfinite(elapsed_seconds) or elapsed_seconds <= 0:
            raise ValueError('Discount requires positive measured elapsed time')
        return self.gamma_per_second ** elapsed_seconds
