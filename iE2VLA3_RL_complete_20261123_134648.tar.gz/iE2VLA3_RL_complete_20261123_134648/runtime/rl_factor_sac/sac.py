"""Separate categorical and continuous SAC updates over measured decision intervals."""
import copy
import threading
import torch
from torch import nn
from torch.nn import functional as F
from .config import SACConfig
from .networks import FactorActor,ResidualActor,TwinCritic,validate_observation
from .replay import validate_batch
from .io import atomic_save,validate_bindings


class SACBranch:
    def __init__(self,c,branch,device='cpu'):
        self.config,self.branch=c,branch
        self.actor=(FactorActor(c) if branch=='factor' else ResidualActor(c)).to(device)
        self.critic=TwinCritic(c,branch).to(device)
        self.target=copy.deepcopy(self.critic).eval().requires_grad_(False)
        self.log_temperature=nn.Parameter(torch.tensor(c.initial_temperature,device=device).log())
        self.actor_optimizer=torch.optim.Adam(self.actor.parameters(),lr=c.actor_lr)
        self.critic_optimizer=torch.optim.Adam(self.critic.parameters(),lr=c.critic_lr)
        self.temperature_optimizer=torch.optim.Adam([self.log_temperature],lr=c.temperature_lr)
        self.updates=0

    @property
    def temperature(self):
        return self.log_temperature.exp()

    @torch.no_grad()
    def target_value(self,batch):
        obs=batch['next_obs']
        if self.branch=='factor':
            p,logp=self.actor.distribution(obs)
            q1,q2=self.target(obs)
            value=(p*(torch.minimum(q1,q2)-self.temperature*logp)).sum(-1,keepdim=True)
        else:
            a,logp,_,_=self.actor.sample(obs)
            q1,q2=self.target(obs,a)
            value=torch.minimum(q1,q2)-self.temperature*logp
        return batch['reward']+batch['discount']*(1-batch['terminated'])*value

    def _step(self,loss,optimizer,parameters):
        if not torch.isfinite(loss):
            raise FloatingPointError('Nonfinite SAC loss')
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(parameters,self.config.grad_clip,error_if_nonfinite=True)
        optimizer.step()

    def update(self,batch):
        validate_batch(batch,self.config,self.branch)
        batch={k:{n:x.detach() for n,x in v.items()} if isinstance(v,dict) else v.detach() for k,v in batch.items()}
        target=self.target_value(batch)
        q1,q2=self.critic(batch['obs'],batch['action'] if self.branch=='residual' else None)
        if self.branch=='factor':
            q1,q2=q1.gather(1,batch['action']),q2.gather(1,batch['action'])
        critic_loss=F.mse_loss(q1,target)+F.mse_loss(q2,target)
        self._step(critic_loss,self.critic_optimizer,self.critic.parameters())
        self.critic_optimizer.zero_grad(set_to_none=True)
        self.critic.requires_grad_(False)
        try:
            obs=batch['obs']
            if self.branch=='factor':
                p,logp=self.actor.distribution(obs)
                q1,q2=self.critic(obs)
                actor_loss=(p*(self.temperature.detach()*logp-torch.minimum(q1,q2))).sum(-1).mean()
                entropy=-(p*logp).sum(-1,keepdim=True)
                target_entropy=self.config.factor_entropy_fraction*obs['factor_mask'].sum(-1,keepdim=True).float().log()
            else:
                a,logp,_,log_half=self.actor.sample(obs)
                q1,q2=self.critic(obs,a)
                actor_loss=(self.temperature.detach()*logp-torch.minimum(q1,q2)).mean()
                actor_loss += self.config.residual_regularizer*a.square().mean()
                actor_loss += self.config.smooth_regularizer*(a-obs['previous_residual']).square().mean()
                entropy=-logp
                # Match target entropy to the same affine coordinate system as logp.
                target_entropy=-12.+log_half
            self._step(actor_loss,self.actor_optimizer,self.actor.parameters())
        finally:
            self.critic.requires_grad_(True)
        temperature_loss=(self.log_temperature*(entropy-target_entropy).detach()).mean()
        self._step(temperature_loss,self.temperature_optimizer,[self.log_temperature])
        with torch.no_grad():
            self.log_temperature.clamp_(-12,4)
            for source,target_param in zip(self.critic.parameters(),self.target.parameters()):
                target_param.lerp_(source,self.config.tau)
            for source,target_buffer in zip(self.critic.buffers(),self.target.buffers()):
                target_buffer.copy_(source)
        self.updates+=1
        return dict(critic_loss=float(critic_loss.detach()),actor_loss=float(actor_loss.detach()),
                    temperature=float(self.temperature.detach()),entropy=float(entropy.detach().mean()),
                    target_q=float(target.mean()),updates=self.updates)

    def state_dict(self):
        result={k:getattr(self,k).state_dict() for k in ('actor','critic','target','actor_optimizer',
                                                        'critic_optimizer','temperature_optimizer')}
        return dict(result,log_temperature=self.log_temperature.detach().clone(),updates=self.updates)

    def load_state_dict(self,saved):
        for k in ('actor','critic','target','actor_optimizer','critic_optimizer','temperature_optimizer'):
            getattr(self,k).load_state_dict(saved[k])
        with torch.no_grad():
            self.log_temperature.copy_(saved['log_temperature'])
        self.updates=saved['updates']


class DualSAC:
    def __init__(self,config=SACConfig(),device='cpu'):
        self.config=config
        self.factor,self.residual=SACBranch(config,'factor',device),SACBranch(config,'residual',device)
        self.lock=threading.RLock()

    @property
    def versions(self):
        return dict(factor=self.factor.updates,residual=self.residual.updates)

    def update(self,factor_batch=None,residual_batch=None):
        if factor_batch is None and residual_batch is None:
            raise ValueError('Supply a completed factor and/or residual batch')
        with self.lock:
            return {name:getattr(self,name).update(batch) for name,batch in
                    (('factor',factor_batch),('residual',residual_batch)) if batch is not None}

    def actor_snapshot(self):
        with self.lock:
            return dict(versions=self.versions,**{k:copy.deepcopy(getattr(self,k).actor).eval().requires_grad_(False)
                                                for k in ('factor','residual')})

    def save(self,path,bindings):
        validate_bindings(bindings)
        with self.lock:
            atomic_save(dict(format='ie2vla_dual_sac_v1',config=self.config.asdict(),bindings=bindings,
                             factor=self.factor.state_dict(),residual=self.residual.state_dict(),
                             rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all()
                             if torch.cuda.is_available() else None),path)

    @classmethod
    def load(cls,path,device='cpu',bindings=None,restore_rng=False):
        saved=torch.load(path,map_location=device,weights_only=False)
        if saved.get('format')!='ie2vla_dual_sac_v1' or (bindings is not None and saved['bindings']!=bindings):
            raise ValueError('SAC format/base/token/reward mismatch')
        validate_bindings(saved['bindings'])
        result=cls(SACConfig(**saved['config']),device)
        for k in ('factor','residual'):
            getattr(result,k).load_state_dict(saved[k])
        if restore_rng:
            torch.set_rng_state(saved['rng'].cpu())
            if torch.cuda.is_available() and saved['cuda_rng'] is not None:
                torch.cuda.set_rng_state_all([x.cpu() for x in saved['cuda_rng']])
        return result
