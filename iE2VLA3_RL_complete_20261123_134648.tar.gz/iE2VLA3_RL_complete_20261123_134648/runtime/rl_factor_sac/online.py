"""Executed-command bookkeeping only; no RPC, ROS, or robot transport changes.

The caller serializes collector events on its control thread. Updates may run
on a learner worker; publish fresh actors with controller.sync_policies().
"""
import math
import numpy as np
from .replay import ReplayBuffer,IntervalRecorder,save_replay
from .reward import EpisodeReward,RewardConfig
from .networks import validate_observation


class OnlineSession:
    def __init__(self,learner,*,source,capacity=100000,reward_config=RewardConfig()):
        if source not in ('robot','simulator'):
            raise ValueError('Specify the actual execution source')
        self.learner,self.config,self.source=learner,learner.config,source
        self.buffers={k:ReplayBuffer(self.config,k,capacity) for k in ('factor','residual')}
        self.reward_config=reward_config
        self.reset_episode()

    def reset_episode(self):
        if any(getattr(self,k+'_interval',None) is not None for k in ('factor','residual')):
            raise RuntimeError('Record final feedback before resetting an episode')
        self.reward=EpisodeReward(self.reward_config)
        self.factor_interval=self.residual_interval=None
        self.last_time=self.factor_id=None
        self.ended=False

    def _finish(self,branch,next_obs,terminated=False,truncated=False):
        interval=getattr(self,branch+'_interval')
        if interval is not None:
            transition=interval.finish(next_obs,terminated,truncated)
            try:
                self.buffers[branch].add(transition,versions=interval.versions,timestamp=interval.start,
                    source=self.source,activation_delay_s=interval.activation_delay)
            except BaseException:
                interval.closed=False
                raise
            setattr(self,branch+'_interval',None)

    def on_factor_decision(self,plan):
        if self.ended or (self.last_time is not None and abs(plan.decision_time-self.last_time)>2e-6):
            raise ValueError('Decision must follow feedback at the same control timestamp')
        self._finish('factor',plan.observation)
        self.last_time=plan.decision_time
        self.factor_interval=IntervalRecorder(self.config,plan.observation,plan.action,self.last_time,plan.versions)
        self.factor_id=plan.request_id

    def on_factor_effective(self,plan,now):
        if self.factor_interval is None or plan.request_id!=self.factor_id:
            raise ValueError('Unexpected factor activation')
        self.factor_interval.activate(now)

    def on_command_accepted(self,proposal):
        if (self.ended or self.residual_interval is not None or self.last_time is None
                or abs(proposal['timestamp']-self.last_time)>2e-6):
            raise ValueError('Command must follow feedback; acknowledge only after transport accepts it')
        self.residual_interval=IntervalRecorder(self.config,proposal['observation'],proposal['action'],
                                                 self.last_time,proposal['versions'])
        self.residual_interval.activate(self.last_time)

    def observe_tick(self,next_obs,timestamp,measured_wrench,actual_residual,previous_residual,
                     *,outcome=None,truncated=False):
        if (self.ended or self.last_time is None or not math.isfinite(timestamp) or timestamp<=self.last_time
                or (outcome is not None and truncated)):
            raise ValueError('Invalid feedback time/termination')
        validate_observation(next_obs,self.config)
        # Validate before mutating rewards/intervals so rejected feedback can be
        # retried with a correct terminal event at the same timestamp.
        if (self.residual_interval is not None and outcome is None
                and not next_obs['reference_mask'][:,0].bool().all()):
            raise ValueError('Residual bootstrap needs a valid final reference; report expired-reference failure explicitly')
        if outcome not in (None,'success','failure'):
            raise ValueError('Unknown episode outcome')
        if self.residual_interval is not None:
            expected=self.residual_interval.action.detach().cpu().numpy()[0]
            if not np.allclose(actual_residual,expected,atol=1e-6,rtol=0):
                raise ValueError('Actual residual differs from the accepted action; do not fabricate replay')
        reward,terms=self.reward.step(timestamp-self.last_time,measured_wrench,
                                      actual_residual,previous_residual,outcome)
        for interval in (self.factor_interval,self.residual_interval):
            if interval is not None:
                interval.tick(reward,timestamp)
        terminated=outcome is not None
        self._finish('residual',next_obs,terminated,truncated)
        self.last_time=timestamp
        if terminated or truncated:
            self._finish('factor',next_obs,terminated,truncated)
            self.ended=True
        return reward,terms

    def update(self,batch_size=32,max_policy_lag=1000):
        device=next(self.learner.factor.actor.parameters()).device
        batches={}
        for name,buffer in self.buffers.items():
            if len(buffer)>=batch_size:
                try:
                    batches[name+'_batch']=buffer.sample(batch_size,device,self.learner.versions,max_policy_lag)
                except ValueError as exc:
                    if 'No eligible' not in str(exc):
                        raise
        return self.learner.update(**batches) if batches else {'ready':False}

    def save_replay(self,path,bindings):
        from dataclasses import asdict
        if bindings['reward_config']!=asdict(self.reward_config):
            raise ValueError('Reward definition differs from the collected replay')
        save_replay(path,self.buffers,bindings)
