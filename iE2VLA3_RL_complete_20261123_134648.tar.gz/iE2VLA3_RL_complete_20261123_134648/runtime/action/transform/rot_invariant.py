import torch
from torch import Tensor


def weT_to_ccT(cur_wcT: Tensor, cur_weT: Tensor, fut_weT: Tensor):
    """
    Args:
        cur_wcT (Tensor): (..., 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (..., 4, 4), ^{world} T _{ee}
        fut_weT (Tensor): (..., T, 4, 4), future ee pose in world frame
    
    Returns:
        fut_ccT (Tensor): ^{cam} _{ee_*} T @ ^{ee} _{cam} T, shape (..., T, 4, 4)
    """
    e1e2T = torch.inverse(cur_weT.unsqueeze(-3)) @ fut_weT  # (..., T, 4, 4)
    e1e2R = e1e2T[..., :3, :3]  # (..., T, 3, 3)
    e1e2t = e1e2T[..., :3, 3]   # (..., T, 3)

    ceT = torch.inverse(cur_wcT) @ cur_weT  # (..., 4, 4)
    ceR = ceT[..., :3, :3]  # (..., 3, 3)
    ceR = ceR.unsqueeze(-3)  # (..., 1, 3, 3)
    
    fut_ccT = torch.zeros_like(fut_weT)
    fut_ccT[..., :3, :3] = ceR @ e1e2R @ ceR.transpose(-1, -2)
    fut_ccT[..., :3, 3] = (ceR @ e1e2t.unsqueeze(-1)).squeeze(-1)
    fut_ccT[..., 3, 3] = 1.0
    return fut_ccT


def ccT_to_weT(cur_wcT: Tensor, cur_weT: Tensor, fut_ccT: Tensor):
    """
    Args:
        cur_wcT (Tensor): (..., 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (..., 4, 4), ^{world} T _{ee}
        fut_ccT (Tensor): (..., T, 4, 4)
    
    Returns:
        fut_weT (Tensor), future ee pose in world frame, shape (..., T, 4, 4)
    """
    ecT = torch.inverse(cur_weT) @ cur_wcT  # (..., 4, 4)
    ecR = ecT[..., :3, :3]  # (..., 3, 3)
    ecR = ecR.unsqueeze(-3)  # (..., 1, 3, 3)
    
    e1e2R = ecR @ fut_ccT[..., :3, :3] @ ecR.transpose(-1, -2)  # (..., T, 3, 3)
    e1e2t = (ecR @ fut_ccT[..., :3, 3].unsqueeze(-1)).squeeze(-1)  # (..., T, 3)
    
    e1e2T = e1e2t.new_zeros(*e1e2t.shape[:-1], 4, 4)
    e1e2T[..., :3, :3] = e1e2R
    e1e2T[..., :3, 3] = e1e2t
    e1e2T[..., 3, 3] = 1

    fut_weT = cur_weT.unsqueeze(-3) @ e1e2T
    return fut_weT


def ccT_to_ceT(cur_wcT: Tensor, cur_weT: Tensor, fut_ccT: Tensor):
    """
    Args:
        cur_wcT (Tensor): (..., 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (..., 4, 4), ^{world} T _{ee}
        t3r3 (Tensor): (..., T, 6)
    
    Returns:
        fut_ceT (Tensor), future ee pose in camera frame, shape (..., T, 4, 4)
    """
    ecT = torch.inverse(cur_weT) @ cur_wcT  # (..., 4, 4)
    ecR = ecT[..., :3, :3]  # (..., 3, 3)
    ecR = ecR.unsqueeze(-3)  # (..., 1, 3, 3)
    
    e1e2R = ecR @ fut_ccT[..., :3, :3] @ ecR.transpose(-1, -2)  # (..., T, 3, 3)
    e1e2t = (ecR @ fut_ccT[..., :3, 3].unsqueeze(-1)).squeeze(-1)  # (..., T, 3)
    
    e1e2T = e1e2t.new_zeros(*e1e2t.shape[:-1], 4, 4)  # (..., T, 4, 4)
    e1e2T[..., :3, :3] = e1e2R
    e1e2T[..., :3, 3] = e1e2t
    e1e2T[..., 3, 3] = 1

    ceT = torch.inverse(cur_wcT) @ cur_weT  # (..., 4, 4)
    fut_ceT = ceT.unsqueeze(-3) @ e1e2T
    return fut_ceT


if __name__ == "__main__":
    import pypose as pp

    cur_wcT = pp.randn_SE3().matrix()
    cur_weT = pp.randn_SE3().matrix()
    fut_weT = pp.randn_SE3(10).matrix()

    fut_ccT = weT_to_ccT(cur_wcT, cur_weT, fut_weT)
    fut_weT_recover = ccT_to_weT(cur_wcT, cur_weT, fut_ccT)

    error = torch.abs(fut_weT - fut_weT_recover).max()
    print(error)
