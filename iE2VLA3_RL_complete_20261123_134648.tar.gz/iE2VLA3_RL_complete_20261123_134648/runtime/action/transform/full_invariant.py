import torch
from torch import Tensor


def weT_to_ccT(cur_wcT: Tensor, cur_weT: Tensor, fut_weT: Tensor):
    """
    Args:
        cur_wcT (Tensor): (..., 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (..., 4, 4), ^{world} T _{ee}
        fut_weT (Tensor): (..., T, 4, 4), future ee pose in world frame
    
    Returns:
        fut_ccT (Tensor): ^{cam} _{ee_*} T @ ^{ee} _{cam} T, shape (..., T, 4, 4)
    """
    cur_ecT = (torch.inverse(cur_weT) @ cur_wcT).unsqueeze(-3)  # (..., 1, 4, 4)
    fut_ceT = torch.inverse(cur_wcT).unsqueeze(-3) @ fut_weT    # (..., T, 4, 4)
    fut_ccT = fut_ceT @ cur_ecT
    return fut_ccT


def ccT_to_weT(cur_wcT: Tensor, cur_weT: Tensor, fut_ccT: Tensor):
    """
    Args:
        cur_wcT (Tensor): (..., 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (..., 4, 4), ^{world} T _{ee}
        fut_ccT (Tensor): (..., T, 4, 4)
    
    Returns:
        fut_weT (Tensor), future ee pose in world frame, shape (..., T, 4, 4)
    """
    cur_ceT = (torch.inverse(cur_wcT) @ cur_weT).unsqueeze(-3)  # (..., 1, 4, 4)
    fut_ceT = fut_ccT @ cur_ceT                                 # (..., T, 4, 4)
    fut_weT = cur_wcT.unsqueeze(-3) @ fut_ceT                   # (..., T, 4, 4)
    return fut_weT


def ccT_to_ceT(cur_wcT: Tensor, cur_weT: Tensor, fut_ccT: Tensor):
    """
    Args:
        cur_wcT (Tensor): (..., 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (..., 4, 4), ^{world} T _{ee}
        t3r3 (Tensor): (..., T, 6)
    
    Returns:
        fut_ceT (Tensor), future ee pose in camera frame, shape (..., T, 4, 4)
    """
    cur_ceT = (torch.inverse(cur_wcT) @ cur_weT).unsqueeze(-3)  # (..., 1, 4, 4)
    fut_ceT = fut_ccT @ cur_ceT                                 # (..., T, 4, 4)
    return fut_ceT


if __name__ == "__main__":
    import pypose as pp

    cur_wcT = pp.randn_SE3().matrix()
    cur_weT = pp.randn_SE3().matrix()
    fut_weT = pp.randn_SE3(10).matrix()

    fut_ccT = weT_to_ccT(cur_wcT, cur_weT, fut_weT)
    fut_weT_recover = ccT_to_weT(cur_wcT, cur_weT, fut_ccT)

    error = torch.abs(fut_weT - fut_weT_recover).max()
    print(error)

    ee_disturb = pp.randn_SE3().matrix()
    fut_ccT2 = weT_to_ccT(
        cur_wcT, 
        cur_weT @ ee_disturb,
        fut_weT @ ee_disturb
    )
    error = torch.abs(fut_ccT - fut_ccT2).max()
    print(error)

