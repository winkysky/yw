import torch
import numpy as np
from torch import Tensor
from typing import Optional, Dict, TypeVar
from dataclasses import dataclass, asdict

from . import rotations_numpy, rotations_torch
from .define import START_END_INDICES, ACTION_SPACE_SIZE


Array = TypeVar("Array", np.ndarray, Tensor)


@dataclass
class ProprioData(object):
    rotmat: Optional[Array] = None       # (..., 3, 3)
    posemat: Optional[Array] = None      # (..., 4, 4)
    trans: Optional[Array] = None
    rot6d: Optional[Array] = None
    gripper: Optional[Array] = None
    dexhand: Optional[Array] = None

    def as_nonone_dict(self) -> Dict[str, Array]:
        data_dict: Dict[str, Array] = asdict(self)
        return {k: v for k, v in data_dict.items() if v is not None}

    def to_raw(self):
        data_dict: Dict[str, Array] = self.as_nonone_dict()
        assert len(data_dict), "At least one field must be not None to infer batch shape."
        
        for k, v in data_dict.items():
            if k in ["rotmat", "posemat"]:
                batch_shape = v.shape[:-2]
            else:
                batch_shape = v.shape[:-1]
            break
        
        if isinstance(v, Tensor):
            raw = torch.zeros(batch_shape + (ACTION_SPACE_SIZE,), dtype=torch.float32)
            mask = torch.zeros_like(raw, dtype=torch.bool)
        else:
            raw = np.zeros(batch_shape + (ACTION_SPACE_SIZE,), dtype=np.float32)
            mask = np.zeros_like(raw, dtype=bool)
        
        parser = ProprioParser(raw, mask)
        for k, v in data_dict.items():
            setattr(parser, k, v)
        
        return parser.raw, parser.mask


class ProprioParser(object):
    def __init__(self, raw: Array, mask: Optional[Array] = None):
        self.raw = raw
        self.mask = mask
        self._rot_impl = rotations_numpy if isinstance(raw, np.ndarray) else rotations_torch

    def _get_slice(self, name: str):
        START, END = START_END_INDICES[name]
        return self.raw[..., START:END]

    def _get_mask(self, name: str):
        if self.mask is None:
            if isinstance(self.raw, np.ndarray):
                return np.ones_like(self._get_slice(name), dtype=bool)
            else:
                return torch.ones_like(self._get_slice(name), dtype=torch.bool)
        
        START, END = START_END_INDICES[name]
        return self.mask[..., START:END]

    def _set_slice(self, name: str, value: Array):
        START, END = START_END_INDICES[name]
        self.raw[..., START:END] = value
        if self.mask is not None:
            self.mask[..., START:END] = True

    @property
    def rotmat(self):
        return self._rot_impl.rotation_6d_to_matrix(self.raw[..., 3:9])

    @rotmat.setter
    def rotmat(self, rotmat: Array):
        self.raw[..., 3:9] = self._rot_impl.matrix_to_rotation_6d(rotmat)
        if self.mask is not None:
            self.mask[..., 3:9] = True

    @property
    def posemat(self):
        return self._rot_impl.t3r6_to_mat4x4(self.raw[..., :9])

    @posemat.setter
    def posemat(self, posemat: Array):
        self.raw[..., :9] = self._rot_impl.mat4x4_to_t3r6(posemat)
        if self.mask is not None:
            self.mask[..., :9] = True

    @property
    def trans(self):
        return self._get_slice("trans")

    @property
    def trans_mask(self):
        return self._get_mask("trans")

    @trans.setter
    def trans(self, trans: Array):
        self._set_slice("trans", trans)

    @property
    def rot6d(self):
        return self._get_slice("rot6d")

    @property
    def rot6d_mask(self):
        return self._get_mask("rot6d")

    @rot6d.setter
    def rot6d(self, rot6d: Array):
        self._set_slice("rot6d", rot6d)

    @property
    def gripper(self):
        return self._get_slice("gripper")

    @property
    def gripper_mask(self):
        return self._get_mask("gripper")

    @gripper.setter
    def gripper(self, gripper: Array):
        self._set_slice("gripper", gripper)

    @property
    def dexhand(self):
        return self._get_slice("dexhand")

    @property
    def dexhand_mask(self):
        return self._get_mask("dexhand")

    @dexhand.setter
    def dexhand(self, dexhand: Array):
        self._set_slice("dexhand", dexhand)

