import numpy as np
from typing import Dict, Tuple
from . import align


ORDERED_ACTION_SPACE = {
    "trans": (3, align.interp_linear),
    "rot6d": (6, align.interp_rot6d),
    "gripper": (1, align.interp_linear),
    "dexhand": (21*3, align.interp_linear),
}

DERIVED_ACTION_SPACE = {
    "posemat": ((4, 4), align.interp_SE3_sep),
    "rotmat": ((3, 3), align.interp_SO3),
}

ACTION_SPACE_SIZE = sum(v[0] for v in ORDERED_ACTION_SPACE.values())


def make_start_end_indices():
    chunk_sizes = list(v[0] for v in ORDERED_ACTION_SPACE.values())
    chunk_sizes = [0] + chunk_sizes
    cumsum = np.cumsum(chunk_sizes).tolist()

    START_END_INDICES: Dict[str, Tuple[int, int]] = {}
    for i, k in enumerate(ORDERED_ACTION_SPACE.keys()):
        START_END_INDICES[k] = (cumsum[i], cumsum[i+1])
    return START_END_INDICES


START_END_INDICES = make_start_end_indices()


parser_body = (
"""import torch
import numpy as np
from torch import Tensor
from typing import Optional, Union, Dict
from dataclasses import dataclass, asdict

from .. import rotations_torch
from .define import START_END_INDICES, ACTION_SPACE_SIZE
from .transform.conversion import t3r6_to_mat4x4, mat4x4_to_t3r6


@dataclass
class ProprioData(object):
    rotmat: Optional[Union[np.ndarray, Tensor]] = None       # (..., 3, 3)
    posemat: Optional[Union[np.ndarray, Tensor]] = None      # (..., 4, 4){0}
    
    def as_nonone_dict(self) -> Dict[str, Union[np.ndarray, Tensor]]:
        data_dict: Dict[str, Union[np.ndarray, Tensor]] = asdict(self)
        return {{k: v for k, v in data_dict.items() if v is not None}}

    def to_raw(self):
        data_dict = self.as_nonone_dict()
        assert len(data_dict), "At least one field must be not None to infer batch shape."
        
        for k, v in data_dict.items():
            if k in ["rotmat", "posemat"]:
                batch_shape = v.shape[:-2]
            else:
                batch_shape = v.shape[:-1]
            break
        
        raw = torch.zeros(batch_shape + (ACTION_SPACE_SIZE,), dtype=torch.float32)
        mask = torch.zeros_like(raw, dtype=torch.bool)
        parser = ProprioParser(raw, mask)
        
        for k, v in data_dict.items():
            setattr(parser, k, torch.from_numpy(v).float() if isinstance(v, np.ndarray) else v)
        
        return parser.raw, parser.mask


class ProprioParser(object):
    def __init__(self, raw: Tensor, mask: Optional[Tensor] = None):
        self.raw = raw
        self.mask = mask

    def _get_slice(self, name: str):
        START, END = START_END_INDICES[name]
        return self.raw[..., START:END]

    def _get_mask(self, name: str):
        if self.mask is None:
            return torch.ones_like(self._get_slice(name), dtype=torch.bool)
        START, END = START_END_INDICES[name]
        return self.mask[..., START:END]

    def _set_slice(self, name: str, value: Tensor):
        START, END = START_END_INDICES[name]
        self.raw[..., START:END] = value
        if self.mask is not None:
            self.mask[..., START:END] = True

    @property
    def rotmat(self):
        return rotations_torch.rotation_6d_to_matrix(self.raw[..., 3:9])

    @rotmat.setter
    def rotmat(self, rotmat: Tensor):
        self.raw[..., 3:9] = rotations_torch.matrix_to_rotation_6d(rotmat)
        if self.mask is not None:
            self.mask[..., 3:9] = True

    @property
    def posemat(self):
        return t3r6_to_mat4x4(self.raw[..., :9])

    @posemat.setter
    def posemat(self, posemat: Tensor):
        self.raw[..., :9] = mat4x4_to_t3r6(posemat)
        if self.mask is not None:
            self.mask[..., :9] = True
{1}
""")


data_extra_template = (
"""
    {0}: Optional[Union[np.ndarray, Tensor]] = None""")


parser_extra_template = (
"""
    @property
    def {0}(self):
        return self._get_slice("{0}")

    @property
    def {0}_mask(self):
        return self._get_mask("{0}")

    @{0}.setter
    def {0}(self, {0}: Tensor):
        self._set_slice("{0}", {0})
""")


def generate_parser(output_path):
    # strings = [parser_body]
    
    data_extra_strings = []
    parser_extra_strings = []

    for name in ORDERED_ACTION_SPACE:
        data_extra_strings.append(data_extra_template.format(name))
        parser_extra_strings.append(parser_extra_template.format(name))
    
    content = parser_body.format(
        "".join(data_extra_strings),
        "".join(parser_extra_strings),
    )
    
    with open(output_path, "w") as fp:
        fp.write("".join(content))


if __name__ == "__main__":
    import os
    here = os.path.dirname(__file__)
    output_path = os.path.join(here, "parser.py")
    generate_parser(output_path)

