# import numpy as np
# from typing import Optional


# def quaternion_to_matrix(quaternions: np.ndarray) -> np.ndarray:
#     r, i, j, k = np.moveaxis(quaternions, -1, 0)
#     two_s = 2.0 / np.sum(quaternions * quaternions, axis=-1)

#     o = np.stack(
#         [
#             1 - two_s * (j * j + k * k),
#             two_s * (i * j - k * r),
#             two_s * (i * k + j * r),
#             two_s * (i * j + k * r),
#             1 - two_s * (i * i + k * k),
#             two_s * (j * k - i * r),
#             two_s * (i * k - j * r),
#             two_s * (j * k + i * r),
#             1 - two_s * (i * i + j * j),
#         ],
#         axis=-1,
#     )
#     return o.reshape(quaternions.shape[:-1] + (3, 3))


# def _copysign(a: np.ndarray, b: np.ndarray) -> np.ndarray:
#     return np.where((a < 0) != (b < 0), -a, a)


# def _sqrt_positive_part(x: np.ndarray) -> np.ndarray:
#     out = np.zeros_like(x)
#     mask = x > 0
#     out[mask] = np.sqrt(x[mask])
#     return out


# def matrix_to_quaternion(matrix: np.ndarray) -> np.ndarray:
#     if matrix.shape[-2:] != (3, 3):
#         raise ValueError(f"Invalid rotation matrix shape {matrix.shape}")

#     batch = matrix.shape[:-2]
#     m = matrix.reshape(batch + (9,))
#     m00, m01, m02, m10, m11, m12, m20, m21, m22 = np.moveaxis(m, -1, 0)

#     q_abs = _sqrt_positive_part(
#         np.stack(
#             [
#                 1 + m00 + m11 + m22,
#                 1 + m00 - m11 - m22,
#                 1 - m00 + m11 - m22,
#                 1 - m00 - m11 + m22,
#             ],
#             axis=-1,
#         )
#     )

#     quat_by_rijk = np.stack(
#         [
#             np.stack([q_abs[..., 0] ** 2, m21 - m12, m02 - m20, m10 - m01], axis=-1),
#             np.stack([m21 - m12, q_abs[..., 1] ** 2, m10 + m01, m02 + m20], axis=-1),
#             np.stack([m02 - m20, m10 + m01, q_abs[..., 2] ** 2, m12 + m21], axis=-1),
#             np.stack([m10 - m01, m20 + m02, m21 + m12, q_abs[..., 3] ** 2], axis=-1),
#         ],
#         axis=-2,
#     )

#     denom = 2.0 * np.maximum(q_abs[..., None], 0.1)
#     quat_candidates = quat_by_rijk / denom

#     idx = np.argmax(q_abs, axis=-1)
#     out = quat_candidates[
#         np.arange(np.prod(batch)).reshape(batch), idx
#     ]
#     return standardize_quaternion(out)


# def _axis_angle_rotation(axis: str, angle: np.ndarray) -> np.ndarray:
#     c, s = np.cos(angle), np.sin(angle)
#     one = np.ones_like(angle)
#     zero = np.zeros_like(angle)

#     if axis == "X":
#         R = (one, zero, zero, zero, c, -s, zero, s, c)
#     elif axis == "Y":
#         R = (c, zero, s, zero, one, zero, -s, zero, c)
#     elif axis == "Z":
#         R = (c, -s, zero, s, c, zero, zero, zero, one)
#     else:
#         raise ValueError

#     return np.stack(R, axis=-1).reshape(angle.shape + (3, 3))


# def euler_angles_to_matrix(euler_angles: np.ndarray, convention: str) -> np.ndarray:
#     mats = [
#         _axis_angle_rotation(c, a)
#         for c, a in zip(convention, np.moveaxis(euler_angles, -1, 0))
#     ]
#     return mats[0] @ mats[1] @ mats[2]


# def standardize_quaternion(q: np.ndarray) -> np.ndarray:
#     return np.where(q[..., :1] < 0, -q, q)


# def quaternion_raw_multiply(a: np.ndarray, b: np.ndarray) -> np.ndarray:
#     aw, ax, ay, az = np.moveaxis(a, -1, 0)
#     bw, bx, by, bz = np.moveaxis(b, -1, 0)

#     return np.stack(
#         [
#             aw * bw - ax * bx - ay * by - az * bz,
#             aw * bx + ax * bw + ay * bz - az * by,
#             aw * by - ax * bz + ay * bw + az * bx,
#             aw * bz + ax * by - ay * bx + az * bw,
#         ],
#         axis=-1,
#     )


# def quaternion_multiply(a: np.ndarray, b: np.ndarray) -> np.ndarray:
#     return standardize_quaternion(quaternion_raw_multiply(a, b))


# def quaternion_invert(q: np.ndarray) -> np.ndarray:
#     return q * np.array([1, -1, -1, -1])


# def axis_angle_to_quaternion(axis_angle: np.ndarray) -> np.ndarray:
#     angles = np.linalg.norm(axis_angle, axis=-1, keepdims=True)
#     half = 0.5 * angles
#     eps = 1e-6

#     scale = np.empty_like(angles)
#     mask = angles > eps
#     scale[mask] = np.sin(half[mask]) / angles[mask]
#     scale[~mask] = 0.5 - (angles[~mask] ** 2) / 48

#     return np.concatenate([np.cos(half), axis_angle * scale], axis=-1)


# def quaternion_to_axis_angle(q: np.ndarray) -> np.ndarray:
#     v = q[..., 1:]
#     norm = np.linalg.norm(v, axis=-1, keepdims=True)
#     half = np.arctan2(norm, q[..., :1])
#     angle = 2 * half

#     eps = 1e-6
#     scale = np.empty_like(angle)
#     mask = angle > eps
#     scale[mask] = np.sin(half[mask]) / angle[mask]
#     scale[~mask] = 0.5 - (angle[~mask] ** 2) / 48

#     return v / scale


# def rotation_6d_to_matrix(d6: np.ndarray) -> np.ndarray:
#     a1, a2 = d6[..., :3], d6[..., 3:]
#     b1 = a1 / np.linalg.norm(a1, axis=-1, keepdims=True)
#     proj = np.sum(b1 * a2, axis=-1, keepdims=True) * b1
#     b2 = a2 - proj
#     b2 = b2 / np.linalg.norm(b2, axis=-1, keepdims=True)
#     b3 = np.cross(b1, b2)
#     return np.stack([b1, b2, b3], axis=-2)


# def matrix_to_rotation_6d(matrix: np.ndarray) -> np.ndarray:
#     return matrix[..., :2, :].reshape(matrix.shape[:-2] + (6,))


# def random_quaternions(n: int) -> np.ndarray:
#     q = np.random.randn(n, 4)
#     s = np.sum(q * q, axis=1, keepdims=True)
#     q = q / _copysign(np.sqrt(s), q[:, :1])
#     return q


# def random_rotations(n: int) -> np.ndarray:
#     return quaternion_to_matrix(random_quaternions(n))





# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

from typing import Optional

import numpy as np

# 帮助函数：实现 PyTorch 的 F.normalize
def _normalize(x: np.ndarray, axis: int = -1, eps: float = 1e-12) -> np.ndarray:
    norm = np.linalg.norm(x, axis=axis, keepdims=True)
    return x / np.maximum(norm, eps)

"""
The transformation matrices returned from the functions in this file assume
the points on which the transformation will be applied are column vectors.
i.e. the R matrix is structured as

    R = [
            [Rxx, Rxy, Rxz],
            [Ryx, Ryy, Ryz],
            [Rzx, Rzy, Rzz],
        ]  # (3, 3)

This matrix can be applied to column vectors by post multiplication
by the points e.g.

    points = [[0], [1], [2]]  # (3 x 1) xyz coordinates of a point
    transformed_points = R * points

To apply the same matrix to points which are row vectors, the R matrix
can be transposed and pre multiplied by the points:

e.g.
    points = [[0, 1, 2]]  # (1 x 3) xyz coordinates of a point
    transformed_points = points * R.transpose(1, 0)
"""


def quaternion_to_matrix(quaternions: np.ndarray) -> np.ndarray:
    """
    Convert rotations given as quaternions to rotation matrices.

    Args:
        quaternions: quaternions with real part first,
            as array of shape (..., 4).

    Returns:
        Rotation matrices as array of shape (..., 3, 3).
    """
    # Unbind equivalent in numpy
    r, i, j, k = np.moveaxis(quaternions, -1, 0)
    
    # epsilon added to avoid division by zero for zero quaternions
    two_s = 2.0 / (np.sum(quaternions * quaternions, axis=-1) + 1e-12)

    o = np.stack(
        (
            1 - two_s * (j * j + k * k),
            two_s * (i * j - k * r),
            two_s * (i * k + j * r),
            two_s * (i * j + k * r),
            1 - two_s * (i * i + k * k),
            two_s * (j * k - i * r),
            two_s * (i * k - j * r),
            two_s * (j * k + i * r),
            1 - two_s * (i * i + j * j),
        ),
        axis=-1,
    )
    return o.reshape(quaternions.shape[:-1] + (3, 3))


def _copysign(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """
    Return an array where each element has the absolute value taken from the,
    corresponding element of a, with sign taken from the corresponding
    element of b.
    """
    return np.copysign(a, b)


def _sqrt_positive_part(x: np.ndarray) -> np.ndarray:
    """
    Returns np.sqrt(np.maximum(0, x))
    """
    ret = np.zeros_like(x)
    positive_mask = x > 0
    ret[positive_mask] = np.sqrt(x[positive_mask])
    return ret


def matrix_to_quaternion(matrix: np.ndarray) -> np.ndarray:
    """
    Convert rotations given as rotation matrices to quaternions.

    Args:
        matrix: Rotation matrices as array of shape (..., 3, 3).

    Returns:
        quaternions with real part first, as array of shape (..., 4).
    """
    if matrix.shape[-1] != 3 or matrix.shape[-2] != 3:
        raise ValueError(f"Invalid rotation matrix shape {matrix.shape}.")

    batch_dim = matrix.shape[:-2]
    
    # Unpack matrix elements
    m_flat = matrix.reshape(batch_dim + (9,))
    m00, m01, m02, m10, m11, m12, m20, m21, m22 = np.moveaxis(m_flat, -1, 0)

    q_abs = _sqrt_positive_part(
        np.stack(
            [
                1.0 + m00 + m11 + m22,
                1.0 + m00 - m11 - m22,
                1.0 - m00 + m11 - m22,
                1.0 - m00 - m11 + m22,
            ],
            axis=-1,
        )
    )

    # we produce the desired quaternion multiplied by each of r, i, j, k
    quat_by_rijk = np.stack(
        [
            np.stack([q_abs[..., 0] ** 2, m21 - m12, m02 - m20, m10 - m01], axis=-1),
            np.stack([m21 - m12, q_abs[..., 1] ** 2, m10 + m01, m02 + m20], axis=-1),
            np.stack([m02 - m20, m10 + m01, q_abs[..., 2] ** 2, m12 + m21], axis=-1),
            np.stack([m10 - m01, m20 + m02, m21 + m12, q_abs[..., 3] ** 2], axis=-1),
        ],
        axis=-2,
    )

    # We floor here at 0.1 but the exact level is not important; if q_abs is small,
    # the candidate won't be picked.
    # In numpy we can just use a float directly usually, but following logic strictly:
    flr = 0.1
    quat_candidates = quat_by_rijk / (2.0 * np.maximum(q_abs[..., None], flr))

    # if not for numerical problems, quat_candidates[i] should be same (up to a sign),
    # forall i; we pick the best-conditioned one (with the largest denominator)
    
    # Logic: one_hot(argmax) > 0.5 is essentially creating a mask for the max index
    argmax_idx = np.argmax(q_abs, axis=-1)
    # Create one-hot mask manually
    one_hot = np.eye(4)[argmax_idx]
    mask = one_hot > 0.5
    
    # Select elements using boolean indexing, then reshape back
    out = quat_candidates[mask].reshape(batch_dim + (4,))
    return standardize_quaternion(out)


def _axis_angle_rotation(axis: str, angle: np.ndarray) -> np.ndarray:
    """
    Return the rotation matrices for one of the rotations about an axis
    of which Euler angles describe, for each value of the angle given.

    Args:
        axis: Axis label "X" or "Y or "Z".
        angle: any shape array of Euler angles in radians

    Returns:
        Rotation matrices as array of shape (..., 3, 3).
    """

    cos = np.cos(angle)
    sin = np.sin(angle)
    one = np.ones_like(angle)
    zero = np.zeros_like(angle)

    if axis == "X":
        R_flat = (one, zero, zero, zero, cos, -sin, zero, sin, cos)
    elif axis == "Y":
        R_flat = (cos, zero, sin, zero, one, zero, -sin, zero, cos)
    elif axis == "Z":
        R_flat = (cos, -sin, zero, sin, cos, zero, zero, zero, one)
    else:
        raise ValueError("letter must be either X, Y or Z.")

    return np.stack(R_flat, axis=-1).reshape(angle.shape + (3, 3))


def euler_angles_to_matrix(euler_angles: np.ndarray, convention: str) -> np.ndarray:
    """
    Convert rotations given as Euler angles in radians to rotation matrices.

    Args:
        euler_angles: Euler angles in radians as array of shape (..., 3).
        convention: Convention string of three uppercase letters from
            {"X", "Y", and "Z"}.

    Returns:
        Rotation matrices as array of shape (..., 3, 3).
    """
    if euler_angles.ndim == 0 or euler_angles.shape[-1] != 3:
        raise ValueError("Invalid input euler angles.")
    if len(convention) != 3:
        raise ValueError("Convention must have 3 letters.")
    if convention[1] in (convention[0], convention[2]):
        raise ValueError(f"Invalid convention {convention}.")
    for letter in convention:
        if letter not in ("X", "Y", "Z"):
            raise ValueError(f"Invalid letter {letter} in convention string.")
    
    matrices = [
        _axis_angle_rotation(c, e)
        for c, e in zip(convention, np.moveaxis(euler_angles, -1, 0))
    ]
    
    # Matrix multiplication: M1 @ M2 @ M3
    return np.matmul(np.matmul(matrices[0], matrices[1]), matrices[2])


def _angle_from_tan(
    axis: str, other_axis: str, data, horizontal: bool, tait_bryan: bool
) -> np.ndarray:
    """
    Extract the first or third Euler angle from the two members of
    the matrix which are positive constant times its sine and cosine.
    """

    i1, i2 = {"X": (2, 1), "Y": (0, 2), "Z": (1, 0)}[axis]
    if horizontal:
        i2, i1 = i1, i2
    even = (axis + other_axis) in ["XY", "YZ", "ZX"]
    if horizontal == even:
        return np.arctan2(data[..., i1], data[..., i2])
    if tait_bryan:
        return np.arctan2(-data[..., i2], data[..., i1])
    return np.arctan2(data[..., i2], -data[..., i1])


def _index_from_letter(letter: str) -> int:
    if letter == "X":
        return 0
    if letter == "Y":
        return 1
    if letter == "Z":
        return 2
    raise ValueError("letter must be either X, Y or Z.")


def matrix_to_euler_angles(matrix: np.ndarray, convention: str) -> np.ndarray:
    """
    Convert rotations given as rotation matrices to Euler angles in radians.

    Args:
        matrix: Rotation matrices as array of shape (..., 3, 3).
        convention: Convention string of three uppercase letters.

    Returns:
        Euler angles in radians as array of shape (..., 3).
    """
    if len(convention) != 3:
        raise ValueError("Convention must have 3 letters.")
    if convention[1] in (convention[0], convention[2]):
        raise ValueError(f"Invalid convention {convention}.")
    for letter in convention:
        if letter not in ("X", "Y", "Z"):
            raise ValueError(f"Invalid letter {letter} in convention string.")
    if matrix.shape[-1] != 3 or matrix.shape[-2] != 3:
        raise ValueError(f"Invalid rotation matrix shape {matrix.shape}.")
    
    i0 = _index_from_letter(convention[0])
    i2 = _index_from_letter(convention[2])
    tait_bryan = i0 != i2
    if tait_bryan:
        central_angle = np.arcsin(
            matrix[..., i0, i2] * (-1.0 if i0 - i2 in [-1, 2] else 1.0)
        )
    else:
        central_angle = np.arccos(matrix[..., i0, i0])

    o = (
        _angle_from_tan(
            convention[0], convention[1], matrix[..., i2], False, tait_bryan
        ),
        central_angle,
        _angle_from_tan(
            convention[2], convention[1], matrix[..., i0, :], True, tait_bryan
        ),
    )
    return np.stack(o, axis=-1)


def random_quaternions(
    n: int, dtype: Optional[np.dtype] = None
) -> np.ndarray:
    """
    Generate random quaternions representing rotations,
    i.e. versors with nonnegative real part.

    Args:
        n: Number of quaternions in a batch to return.
        dtype: Type to return.

    Returns:
        Quaternions as array of shape (N, 4).
    """
    o = np.random.randn(n, 4).astype(dtype if dtype else np.float64)
    s = (o * o).sum(1)
    o = o / _copysign(np.sqrt(s), o[:, 0])[:, None]
    return o


def random_rotations(
    n: int, dtype: Optional[np.dtype] = None
) -> np.ndarray:
    """
    Generate random rotations as 3x3 rotation matrices.

    Args:
        n: Number of rotation matrices in a batch to return.
        dtype: Type to return.

    Returns:
        Rotation matrices as array of shape (n, 3, 3).
    """
    quaternions = random_quaternions(n, dtype=dtype)
    return quaternion_to_matrix(quaternions)


def random_rotation(
    dtype: Optional[np.dtype] = None
) -> np.ndarray:
    """
    Generate a single random 3x3 rotation matrix.

    Args:
        dtype: Type to return

    Returns:
        Rotation matrix as array of shape (3, 3).
    """
    return random_rotations(1, dtype)[0]


def standardize_quaternion(quaternions: np.ndarray) -> np.ndarray:
    """
    Convert a unit quaternion to a standard form: one in which the real
    part is non negative.

    Args:
        quaternions: Quaternions with real part first,
            as array of shape (..., 4).

    Returns:
        Standardized quaternions as array of shape (..., 4).
    """
    return np.where(quaternions[..., 0:1] < 0, -quaternions, quaternions)


def quaternion_raw_multiply(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """
    Multiply two quaternions.
    Usual numpy rules for broadcasting apply.

    Args:
        a: Quaternions as array of shape (..., 4), real part first.
        b: Quaternions as array of shape (..., 4), real part first.

    Returns:
        The product of a and b, an array of quaternions shape (..., 4).
    """
    aw, ax, ay, az = np.moveaxis(a, -1, 0)
    bw, bx, by, bz = np.moveaxis(b, -1, 0)
    ow = aw * bw - ax * bx - ay * by - az * bz
    ox = aw * bx + ax * bw + ay * bz - az * by
    oy = aw * by - ax * bz + ay * bw + az * bx
    oz = aw * bz + ax * by - ay * bx + az * bw
    return np.stack((ow, ox, oy, oz), axis=-1)


def quaternion_multiply(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """
    Multiply two quaternions representing rotations, returning the quaternion
    representing their composition, i.e. the versor with nonnegative real part.
    Usual numpy rules for broadcasting apply.

    Args:
        a: Quaternions as array of shape (..., 4), real part first.
        b: Quaternions as array of shape (..., 4), real part first.

    Returns:
        The product of a and b, an array of quaternions of shape (..., 4).
    """
    ab = quaternion_raw_multiply(a, b)
    return standardize_quaternion(ab)


def quaternion_invert(quaternion: np.ndarray) -> np.ndarray:
    """
    Given a quaternion representing rotation, get the quaternion representing
    its inverse.

    Args:
        quaternion: Quaternions as array of shape (..., 4), with real part
            first, which must be versors (unit quaternions).

    Returns:
        The inverse, an array of quaternions of shape (..., 4).
    """

    scaling = np.array([1, -1, -1, -1], dtype=quaternion.dtype)
    return quaternion * scaling


def quaternion_apply(quaternion: np.ndarray, point: np.ndarray) -> np.ndarray:
    """
    Apply the rotation given by a quaternion to a 3D point.
    Usual numpy rules for broadcasting apply.

    Args:
        quaternion: Array of quaternions, real part first, of shape (..., 4).
        point: Array of 3D points of shape (..., 3).

    Returns:
        Array of rotated points of shape (..., 3).
    """
    if point.shape[-1] != 3:
        raise ValueError(f"Points are not in 3D, {point.shape}.")
    
    # Broadcast padding zeros for the real part
    real_parts = np.zeros(point.shape[:-1] + (1,), dtype=point.dtype)
    point_as_quaternion = np.concatenate((real_parts, point), axis=-1)
    
    out = quaternion_raw_multiply(
        quaternion_raw_multiply(quaternion, point_as_quaternion),
        quaternion_invert(quaternion),
    )
    return out[..., 1:]


def axis_angle_to_matrix(axis_angle: np.ndarray) -> np.ndarray:
    """
    Convert rotations given as axis/angle to rotation matrices.

    Args:
        axis_angle: Rotations given as a vector in axis angle form,
            as an array of shape (..., 3), where the magnitude is
            the angle turned anticlockwise in radians around the
            vector's direction.

    Returns:
        Rotation matrices as array of shape (..., 3, 3).
    """
    return quaternion_to_matrix(axis_angle_to_quaternion(axis_angle))


def matrix_to_axis_angle(matrix: np.ndarray) -> np.ndarray:
    """
    Convert rotations given as rotation matrices to axis/angle.

    Args:
        matrix: Rotation matrices as array of shape (..., 3, 3).

    Returns:
        Rotations given as a vector in axis angle form, as an array
            of shape (..., 3), where the magnitude is the angle
            turned anticlockwise in radians around the vector's
            direction.
    """
    return quaternion_to_axis_angle(matrix_to_quaternion(matrix))


def axis_angle_to_quaternion(axis_angle: np.ndarray) -> np.ndarray:
    """
    Convert rotations given as axis/angle to quaternions.

    Args:
        axis_angle: Rotations given as a vector in axis angle form,
            as an array of shape (..., 3), where the magnitude is
            the angle turned anticlockwise in radians around the
            vector's direction.

    Returns:
        quaternions with real part first, as array of shape (..., 4).
    """
    angles = np.linalg.norm(axis_angle, axis=-1, keepdims=True)
    half_angles = angles * 0.5
    eps = 1e-6
    small_angles = np.abs(angles) < eps
    
    sin_half_angles_over_angles = np.empty_like(angles)
    
    # Standard formula for non-small angles
    # Using ~small_angles to index
    not_small = ~small_angles
    sin_half_angles_over_angles[not_small] = (
        np.sin(half_angles[not_small]) / angles[not_small]
    )
    
    # for x small, sin(x/2) is about x/2 - (x/2)^3/6
    # so sin(x/2)/x is about 1/2 - (x*x)/48
    sin_half_angles_over_angles[small_angles] = (
        0.5 - (angles[small_angles] * angles[small_angles]) / 48
    )
    
    quaternions = np.concatenate(
        [np.cos(half_angles), axis_angle * sin_half_angles_over_angles], axis=-1
    )
    return quaternions


def quaternion_to_axis_angle(quaternions: np.ndarray) -> np.ndarray:
    """
    Convert rotations given as quaternions to axis/angle.

    Args:
        quaternions: quaternions with real part first,
            as array of shape (..., 4).

    Returns:
        Rotations given as a vector in axis angle form, as an array
            of shape (..., 3), where the magnitude is the angle
            turned anticlockwise in radians around the vector's
            direction.
    """
    norms = np.linalg.norm(quaternions[..., 1:], axis=-1, keepdims=True)
    half_angles = np.arctan2(norms, quaternions[..., :1])
    angles = 2 * half_angles
    eps = 1e-6
    small_angles = np.abs(angles) < eps
    
    sin_half_angles_over_angles = np.empty_like(angles)
    
    not_small = ~small_angles
    sin_half_angles_over_angles[not_small] = (
        np.sin(half_angles[not_small]) / angles[not_small]
    )
    
    # for x small, sin(x/2) is about x/2 - (x/2)^3/6
    # so sin(x/2)/x is about 1/2 - (x*x)/48
    sin_half_angles_over_angles[small_angles] = (
        0.5 - (angles[small_angles] * angles[small_angles]) / 48
    )
    
    return quaternions[..., 1:] / sin_half_angles_over_angles


def rotation_6d_to_matrix(d6: np.ndarray) -> np.ndarray:
    """
    Converts 6D rotation representation by Zhou et al. [1] to rotation matrix
    using Gram--Schmidt orthogonalization per Section B of [1].
    Args:
        d6: 6D rotation representation, of size (*, 6)

    Returns:
        batch of rotation matrices of size (*, 3, 3)

    [1] Zhou, Y., Barnes, C., Lu, J., Yang, J., & Li, H.
    On the Continuity of Rotation Representations in Neural Networks.
    IEEE Conference on Computer Vision and Pattern Recognition, 2019.
    Retrieved from http://arxiv.org/abs/1812.07035
    """

    a1, a2 = d6[..., :3], d6[..., 3:]
    b1 = _normalize(a1, axis=-1)
    
    # b2 = a2 - (b1 * a2).sum(-1, keepdim=True) * b1
    dot_prod = np.sum(b1 * a2, axis=-1, keepdims=True)
    b2 = a2 - dot_prod * b1
    b2 = _normalize(b2, axis=-1)
    
    b3 = np.cross(b1, b2, axis=-1)
    return np.stack((b1, b2, b3), axis=-2)


def matrix_to_rotation_6d(matrix: np.ndarray) -> np.ndarray:
    """
    Converts rotation matrices to 6D rotation representation by Zhou et al. [1]
    by dropping the last row. Note that 6D representation is not unique.
    Args:
        matrix: batch of rotation matrices of size (*, 3, 3)

    Returns:
        6D rotation representation, of size (*, 6)

    [1] Zhou, Y., Barnes, C., Lu, J., Yang, J., & Li, H.
    On the Continuity of Rotation Representations in Neural Networks.
    IEEE Conference on Computer Vision and Pattern Recognition, 2019.
    Retrieved from http://arxiv.org/abs/1812.07035
    """
    batch_dim = matrix.shape[:-2]
    # Slicing the first two rows and reshaping
    return matrix[..., :2, :].copy().reshape(batch_dim + (6,))


def t3r6_to_mat4x4(t3r6: np.ndarray):
    matrix: np.ndarray = np.zeros(t3r6.shape[:-1] + (4, 4), dtype=t3r6.dtype)
    matrix[..., :3, :3] = rotation_6d_to_matrix(t3r6[..., 3:9])
    matrix[..., :3, 3] = t3r6[..., 0:3]
    matrix[..., 3, 3] = 1.0
    return matrix


def mat4x4_to_t3r6(matrix: np.ndarray):
    t3 = matrix[..., :3, 3]
    r6 = matrix_to_rotation_6d(matrix[..., :3, :3])  # (..., T, 3)
    return np.concatenate([t3, r6], axis=-1)

