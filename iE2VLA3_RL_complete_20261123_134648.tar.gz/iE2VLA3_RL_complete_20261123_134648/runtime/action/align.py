import numpy as np
from typing import Dict, Callable, Union
from scipy.spatial.transform import Rotation
from .rotations_numpy import rotation_6d_to_matrix, matrix_to_rotation_6d


def find_closest_ind(train: np.ndarray, query: np.ndarray):
    zero_qdim = False
    if np.ndim(query) == 0:
        query = np.array([query])
        zero_qdim = True
    
    bin_indices = np.digitize(query, train)
    sample_indices = []
    
    # query < train
    mask = (bin_indices == 0)
    if np.any(mask):
        sample_indices.append(np.array([0]*mask.sum(), dtype=bin_indices.dtype))
    
    # query in train
    mask = (bin_indices > 0) & (bin_indices < len(train))
    if np.any(mask):
        r_ind = bin_indices[mask]
        l_ind = r_ind - 1
        
        dist0 = np.abs(train[l_ind] - query[mask])
        dist1 = np.abs(train[r_ind] - query[mask])
        sample_indices.append(np.where(dist0 < dist1, l_ind, r_ind))

    # query > train
    mask = (bin_indices == len(train))
    if np.any(mask):
        sample_indices.append(np.array([len(train)-1]*mask.sum(), dtype=bin_indices.dtype))
    
    sample_indices = np.concatenate(sample_indices)

    if zero_qdim:
        sample_indices = sample_indices[0]

    return sample_indices


def interp_linear(q0: np.ndarray, q1: np.ndarray, t0, t1, t) -> np.ndarray:
    """
    Args:
        q0 (np.ndarray): (T, ...)
        q1 (np.ndarray): (T, ...)
        t0 (np.ndarray or float): (T,) or scalar
        t0 (np.ndarray or float): (T,) or scalar
        t (np.ndarray): (T,)
    
    Returns:
        q (np.ndarray): (T, ...)
    """
    delta = q1 - q0
    alpha = (t - t0) / (t1 - t0)
    if isinstance(alpha, np.ndarray) and isinstance(delta, np.ndarray):
        if alpha.ndim < delta.ndim:
            alpha = alpha.reshape(alpha.shape + (1,) * (delta.ndim - alpha.ndim))
    update = alpha * delta
    q = q0 + update.astype(q0.dtype)
    return q


def Log(x: np.ndarray):
    assert x.shape[-2:] == (3, 3)

    if x.ndim <= 3:
        return Rotation.from_matrix(x).as_rotvec()
    else:
        original_shape = x.shape
        aux_shape = np.prod(original_shape[:-2])
        rotv: np.ndarray = Rotation.from_matrix(x.reshape(aux_shape, 3, 3)).as_rotvec()
        return rotv.reshape(original_shape[:-1])  # (..., 3)


def Exp(x: np.ndarray):
    assert x.shape[-1] == 3

    if x.ndim <= 2:
        return Rotation.from_rotvec(x).as_matrix()
    else:
        original_shape = x.shape
        aux_shape = np.prod(original_shape[:-1])
        rotm: np.ndarray = Rotation.from_rotvec(x.reshape(aux_shape, 3)).as_matrix()
        return rotm.reshape(original_shape + (3,))


def Mul(x: np.ndarray, y: np.ndarray):
    return x @ y


def Inv(x: np.ndarray):
    return np.linalg.inv(x)


def interp_SO3(R0: np.ndarray, R1: np.ndarray, t0, t1, t) -> np.ndarray:
    """
    Args:
        R0 (np.ndarray): (T, ..., 3, 3)
        R1 (np.ndarray): (T, ..., 3, 3)
        t0 (np.ndarray or float): (T,) or scalar
        t0 (np.ndarray or float): (T,) or scalar
        t (np.ndarray): (T,)
    
    Returns:
        R (np.ndarray): (T, ..., 3, 3)
    """
    delta = Log(Mul(Inv(R0), R1))
    alpha = (t - t0) / (t1 - t0)
    
    if isinstance(alpha, np.ndarray):
        if alpha.ndim < delta.ndim:
            alpha = alpha.reshape(alpha.shape + (1,) * (delta.ndim - alpha.ndim))
    
    update = alpha * delta
    R = Mul(R0, Exp(update))
    return R


def interp_rot6d(rot6d0: np.ndarray, rot6d1: np.ndarray, t0, t1, t) -> np.ndarray:
    """
    Args:
        rot6d0 (np.ndarray): (T, ..., 6)
        rot6d1 (np.ndarray): (T, ..., 6)
        t0 (np.ndarray or float): (T,) or scalar
        t0 (np.ndarray or float): (T,) or scalar
        t (np.ndarray): (T,)
    
    Returns:
        rot6d (np.ndarray): (T, ..., 6)
    """
    R0 = rotation_6d_to_matrix(rot6d0)
    R1 = rotation_6d_to_matrix(rot6d1)
    R = interp_SO3(R0, R1, t0, t1, t)
    rot6d = matrix_to_rotation_6d(R)
    return rot6d


def interp_SE3_sep(T0: np.ndarray, T1: np.ndarray, t0, t1, t) -> np.ndarray:
    """
    Args:
        T0 (np.ndarray): (T, ..., 4, 4)
        T1 (np.ndarray): (T, ..., 4, 4)
        t0 (np.ndarray or float): (T,) or scalar
        t0 (np.ndarray or float): (T,) or scalar
        t (np.ndarray): (T,)
    
    Returns:
        T (np.ndarray): (T, ..., 4, 4)
    """
    R = interp_SO3(T0[..., :3, :3], T1[..., :3, :3], t0, t1, t)
    trans = interp_linear(T0[..., :3, 3], T1[..., :3, 3], t0, t1, t)
    shape = R.shape[:-2] + (4, 4)
    T = np.zeros(shape, R.dtype)
    T[..., :3, :3] = R
    T[..., :3, 3] = trans
    T[..., 3, 3] = 1
    return T


def align_data(
    query_time: Union[float, np.ndarray], 
    train_time: np.ndarray,
    train_data: Dict[str, np.ndarray],
    interp_funcs: Dict[str, Callable]
) -> Dict[str, np.ndarray]:
    """
    Args:
        query_time (float | np.ndarray): scalar or shape (Tq,)
        train_time (np.ndarray): shape (T,)
        train_data (Dict[str, np.ndarray]): each of shape (T, ..., D)
        interp_funcs (Dict[str, Callable]): 
    
    Returns:
        query_data (Dict[str, np.ndarray]): each of shape (..., D) if query_time is scalar otherwise (Tq, ..., D)
    """
    zero_qdim = False
    if np.ndim(query_time) == 0:
        query_time = np.array([query_time])
        zero_qdim = True

    query_data = {k: [] for k in train_data}
    bin_indices = np.digitize(query_time, train_time)

    # query_time < min(train_time)
    mask = (bin_indices == 0)
    if np.any(mask):
        for k in query_data:
            query_data[k].append(np.repeat(train_data[k][0:1], repeats=mask.sum(), axis=0))
    
    # query_time in train_time
    mask = (bin_indices > 0) & (bin_indices < len(train_time))
    if np.any(mask):
        l_ind = bin_indices[mask] - 1
        t0 = train_time[l_ind]
        t1 = train_time[l_ind + 1]
        for k, f in interp_funcs.items():
            q0 = train_data[k][l_ind]
            q1 = train_data[k][l_ind + 1]
            query_data[k].append(f(q0, q1, t0, t1, query_time[mask]))
        
    # query_time > max(train_time)
    mask = (bin_indices == len(train_time))
    if np.any(mask):
        for k in query_data:
            query_data[k].append(np.repeat(train_data[k][-1:], repeats=mask.sum(), axis=0))
    
    for k in query_data:
        query_data[k] = np.concatenate(query_data[k], axis=0)
        if zero_qdim:
            query_data[k] = query_data[k][0]

    return query_data

