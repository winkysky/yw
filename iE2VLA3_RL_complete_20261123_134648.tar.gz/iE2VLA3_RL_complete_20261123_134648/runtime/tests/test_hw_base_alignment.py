"""HW frame regression against a pinned upstream calibration, without network.

Fixture copied verbatim from winkysky/yw at
aa219ea6779a2b30101f2de80b2dfc499185ee3f/lerobot_hdf5_tools/camera_params.json.
Expected poses are built from that reference, never from the config under test.
"""

from dataclasses import replace
import json
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest

from action.parser import ProprioParser
from data_utils.trajectory_retime32 import retime_sample
from dataset.lerobot_dual import decode_tcp
from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityConfig
from dataset.lerobot_original import LeRobotOriginalConfig, LeRobotOriginalDataset
from e2vla_compat.config import PlannerConfig
from e2vla_compat.observations import ObservationBuffer
from test_lerobot_dual import dataset


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = json.loads((Path(__file__).parent / "fixtures/yw_camera_params_aa219ea.json").read_text())
COMMIT = "aa219ea6779a2b30101f2de80b2dfc499185ee3f"


def config(variant):
    cls = LeRobotOriginalConfig if variant == "original" else LeRobotRetimedVelocityConfig
    return cls.load(ROOT / f"models/m0512_fm/lerobot_huawei_close_box_{variant}.json")


def reference_poses(raw, *, common_base=True):
    """Independent Rz Ry Rx construction with upstream mm/m conventions."""
    raw = np.asarray(raw).reshape(-1, 2, 6)
    flange = np.broadcast_to(np.eye(4), (*raw.shape[:2], 4, 4)).copy()
    for frame in range(len(raw)):
        for arm, name in enumerate(("LEFT", "RIGHT")):
            x, y, z = np.deg2rad(raw[frame, arm, 3:])
            cx, cy, cz = np.cos([x, y, z])
            sx, sy, sz = np.sin([x, y, z])
            rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
            ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
            rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
            flange[frame, arm, :3, :3] = rz @ ry @ rx
            flange[frame, arm, :3, 3] = raw[frame, arm, :3] / 1000
            if common_base:
                flange[frame, arm] = REFERENCE[f"{name}_BASE_IN_ROBOTBASE"] @ flange[frame, arm]
    tools = np.array([REFERENCE[f"{name}_T_FLANGE_TCP"] for name in ("LEFT", "RIGHT")])
    tools[..., :3, 3] /= 1000
    return flange, flange @ tools


def raw_poses(n):
    raw = np.empty((n, 2, 6), dtype=np.float64)
    raw[:, 0] = [220, -340, -180, 17, -23, 41]
    raw[:, 1] = [-150, 290, 210, -31, 19, -53]
    t = np.arange(n) / 30
    raw[:, 0, 0] += 40 * t
    raw[:, 1, 1] += 70 * t
    raw[:, 0, 4] += 9 * t
    raw[:, 1, 5] -= 13 * t
    return raw


@pytest.mark.parametrize("variant", ["original", "speed32"])
def test_shipped_calibration_matches_pinned_yw(variant):
    cfg = config(variant)
    assert cfg.geometry["source_commit"] == COMMIT
    assert cfg.geometry["world_frame"] == "left_recorded_arm_base"
    for arm, name in enumerate(("LEFT", "RIGHT")):
        np.testing.assert_array_equal(cfg.base_to_world[arm], REFERENCE[f"{name}_BASE_IN_ROBOTBASE"])
        tool = np.array(REFERENCE[f"{name}_T_FLANGE_TCP"], dtype=float)
        tool[:3, 3] /= 1000
        np.testing.assert_allclose(cfg.pose_to_tcp[arm], tool, atol=1e-15)
    for key, name, parent in zip(cfg.camera_keys, ("HEAD", "LEFT", "RIGHT"),
                                 ("world", "left_flange", "right_flange")):
        camera = cfg.geometry["cameras"][key]
        np.testing.assert_array_equal(camera["K"], REFERENCE[f"{name}_CAMERA_K"])
        extrinsic = "HEAD_CAMINBASEPOSE" if name == "HEAD" else f"{name}_CAMINTOOLPOSE"
        np.testing.assert_array_equal(camera["pose"], REFERENCE[extrinsic])
        assert camera["parent"] == parent and camera["image_size"] == [480, 640]
    raw = raw_poses(3)
    _, expected = reference_poses(raw)
    np.testing.assert_allclose(decode_tcp(raw, cfg), expected, atol=1e-7)
    _, own_base = reference_poses(raw, common_base=False)
    np.testing.assert_allclose(expected[:, 0], own_base[:, 0], atol=1e-12)
    # Both rotation and translation must change. Inverse/order/xyz-only bugs fail.
    assert not np.allclose(expected[:, 1, :3, :3], own_base[:, 1, :3, :3])
    assert not np.allclose(expected[:, 1, :3, 3], own_base[:, 1, :3, 3])


def test_parquet_history_actions_and_all_camera_projections(dataset):
    cfg = replace(config("original"), root=str(dataset.root), image_size=[32, 64],
                  num_history_states=2, num_future_actions=3)
    raw = raw_poses(4)
    commands = raw.copy()
    commands[..., :3] += [13, -27, 8]
    commands[..., 3:] += [4, 3, -2]
    path = dataset._path("data_path", 0)
    values = pq.read_table(path).to_pydict()
    values[cfg.state_pose_key] = raw.reshape(4, 12).tolist()
    values[cfg.action_pose_key] = commands.reshape(4, 12).tolist()
    pq.write_table(pa.table(values), path)
    reader = LeRobotOriginalDataset(cfg)
    try:
        sample = reader[1]
        flange, tcp = reference_poses(raw)
        _, targets = reference_poses(commands)
        np.testing.assert_allclose(ProprioParser(sample.state).posemat, tcp[:2].swapaxes(0, 1), atol=2e-6)
        actual_targets = ProprioParser(sample.action).posemat.numpy()
        np.testing.assert_allclose(actual_targets, targets[1:].swapaxes(0, 1), atol=2e-6)
        assert sample.state_mask[..., :10].all() and sample.action_mask[..., :10].all()
        expected_cameras = [np.array(REFERENCE["HEAD_CAMINBASEPOSE"]),
                            flange[1, 0] @ REFERENCE["LEFT_CAMINTOOLPOSE"],
                            flange[1, 1] @ REFERENCE["RIGHT_CAMINTOOLPOSE"]]
        # Current and future positions of BOTH arms project through all 3 cameras.
        points = np.concatenate([targets[1:, :, :3, 3].reshape(-1, 3), np.ones((6, 1))], axis=1)
        actual_points = np.concatenate([actual_targets.swapaxes(0, 1)[..., :3, 3].reshape(-1, 3),
                                        np.ones((6, 1))], axis=1)
        h, w = cfg.image_size
        resize = np.array([[w / 640, 0, (w / 640 - 1) / 2],
                           [0, h / 480, (h / 480 - 1) / 2], [0, 0, 1]])
        for i, name in enumerate(("HEAD", "LEFT", "RIGHT")):
            camera = sample.raw_vl.pose[i][0].numpy()
            np.testing.assert_allclose(camera, expected_cameras[i], atol=2e-6)
            k = resize @ REFERENCE[f"{name}_CAMERA_K"]
            np.testing.assert_allclose(sample.raw_vl.K[i], k, atol=2e-6)
            expected_camera_points = (np.linalg.inv(expected_cameras[i]) @ points.T).T[:, :3]
            actual_camera_points = (np.linalg.inv(camera) @ actual_points.T).T[:, :3]
            np.testing.assert_allclose(actual_camera_points, expected_camera_points, atol=2e-6)
            expected_pixels = expected_camera_points @ k.T
            actual_pixels = actual_camera_points @ sample.raw_vl.K[i].numpy().T
            np.testing.assert_allclose(actual_pixels[:, :2] / actual_pixels[:, 2:],
                                       expected_pixels[:, :2] / expected_pixels[:, 2:], atol=2e-3, rtol=1e-5)
        np.testing.assert_allclose(sample.action_ref_pose, expected_cameras[1:], atol=2e-6)
    finally:
        reader.close()


@pytest.mark.parametrize("factor", [1., 1.5, 2.])
def test_retiming_preserves_common_frame_and_physical_speed(factor):
    cfg = config("speed32")
    raw = raw_poses(130)
    _, own_base = reference_poses(raw, common_base=False)
    common = decode_tcp(raw, cfg)
    def sample(poses):
        return retime_sample(dict(timestamp=np.arange(130) / 30, state_pose=poses, action_pose=poses,
                                  state_gripper=np.zeros((130, 2)), action_gripper=np.zeros((130, 2))),
                             10, factor, 5, history_mode="retimed")
    before, after = sample(own_base), sample(common)
    bases = np.array([REFERENCE[f"{name}_BASE_IN_ROBOTBASE"] for name in ("LEFT", "RIGHT")])
    for key in ("history_pose", "action_pose"):
        np.testing.assert_allclose(after[key], bases @ before[key], atol=2e-6)
    np.testing.assert_allclose(after["speed_per_arm"], before["speed_per_arm"], atol=1e-6)


def test_hw_inference_converts_recorded_once_and_preserves_world_tcp():
    cfg = config("original")
    raw = raw_poses(4)
    times = np.arange(4) / 30
    flange, expected = reference_poses(raw)
    recorded = ObservationBuffer(cfg, PlannerConfig(input_pose_format="recorded", input_gripper_format="raw"))
    world = ObservationBuffer(cfg, PlannerConfig(input_pose_format="tcp_world", input_gripper_format="openness"))
    for i, timestamp in enumerate(times):
        cameras = {
            key: dict(camera=dict(K=cfg.geometry["cameras"][key]["K"]),
                      data=dict(color=np.zeros((480, 640, 3), np.uint8), encoding="rgb", timestep=timestamp))
            for key in cfg.camera_keys
        }
        recorded.add_obs_frame(dict(timestamp=timestamp, ee_pose=raw[i], gripper=np.array([0., 1886.]), **cameras))
        world.add_obs_frame(dict(timestamp=timestamp, ee_pose=expected[i], gripper=np.array([1., 0.]), **cameras))
    batch = recorded.sample("Close the box")
    already_common = world.sample("Close the box")
    np.testing.assert_allclose(ProprioParser(batch.state[:, -1]).posemat, expected[-1], atol=2e-6)
    np.testing.assert_array_equal(batch.state[:, -1, 9], [1., 0.])
    np.testing.assert_allclose(already_common.state, batch.state, atol=1e-7)
    expected_cameras = [REFERENCE["HEAD_CAMINBASEPOSE"],
                        flange[-1, 0] @ REFERENCE["LEFT_CAMINTOOLPOSE"],
                        flange[-1, 1] @ REFERENCE["RIGHT_CAMINTOOLPOSE"]]
    for i, camera in enumerate(expected_cameras):
        np.testing.assert_allclose(batch.raw_vl.pose[i][0], camera, atol=2e-6)
        np.testing.assert_allclose(already_common.raw_vl.pose[i], batch.raw_vl.pose[i], atol=2e-6)
    np.testing.assert_allclose(batch.action_ref_pose, expected_cameras[1:], atol=2e-6)
