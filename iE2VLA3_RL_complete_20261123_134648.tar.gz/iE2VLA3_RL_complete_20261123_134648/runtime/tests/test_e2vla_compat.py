"""Regression checks for the additive Planner/coordinate/protocol boundary."""
import copy
from dataclasses import replace
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import cv2
import numpy as np
import pytest
import torch

from action.parser import ProprioParser
from dataset.lerobot_dual import LeRobotDualConfig, decode_tcp
from e2vla_compat.config import PlannerConfig
from e2vla_compat.observations import camera_pose, camera_rays, batch_to_samples
from e2vla_compat.policy import Policy, decode_prediction, signature, TASKS
from e2vla_compat.remote_service import Service
from models.m0512_fm.lerobot_inference import observation_to_sample
from test_lerobot_original import calibrated_config, transform
from test_lerobot_pyro import assert_same_observation


class FakePolicy(Policy):
    def __init__(self, task="close_box"):
        cfg = calibrated_config(LeRobotDualConfig(root="unused", image_size=[32,64], num_future_actions=32))
        cfg.base_to_world = [transform(x=1.), transform(y=2.)]
        cfg.base_to_world[1][1][1] = cfg.base_to_world[1][2][2] = -1.
        cfg.pose_to_tcp = [transform(z=.1), transform(z=.15)]
        info = dict(fps=30., format="lerobot_original_full_v2", checkpoint="unchanged/model.pt", step=100000,
                    device="cpu", model_config=dict(model="base",train_qwen=True,inference_timesteps=4),
                    data_config=cfg.to_dict(), dataset_fingerprint="f"*64)
        super().__init__(PlannerConfig(task=task), engine=SimpleNamespace(data_config=cfg, get_policy_info=lambda: copy.deepcopy(info)))
        self.calls = []

    def predict_samples(self, samples, seed=None, speed_mps=None, guidance_scale=1.):
        if speed_mps is not None or guidance_scale != 1.:
            raise ValueError("no speed condition")
        self.calls.extend(samples)
        raw = torch.stack([s.state[:, -1:].repeat(1,32,1) for s in samples])
        raw[...,0] += torch.arange(32)*.001
        return decode_prediction(raw)


def world_service(policy):
    # The existing ROS TF client uploads already-converted world TCPs. Its
    # tests must opt in explicitly now that production defaults are recorded/raw.
    return Service(policy=policy, config=PlannerConfig(task=policy.task,
        input_pose_format="tcp_world", input_gripper_format="openness"))


def frame(policy, stamp=100.):
    cfg = policy.config
    recorded = np.array([[120,20,300,10,20,30], [120,20,300,10,20,30]], np.float32)
    tcp = decode_tcp(recorded.reshape(1,-1), cfg)[0]
    result = dict(timestamp=stamp, ee_pose=tcp, gripper=np.array([0.,1.],np.float32))
    for key in cfg.camera_keys:
        cam = cfg.geometry["cameras"][key]
        h,w = cam["image_size"]
        image = np.zeros((h,w,3),np.uint8)
        image[...,0] = np.arange(w)[None] % 256
        image[...,1] = np.arange(h)[:,None] % 256
        result[key] = dict(camera=dict(K=cam["K"]), data=dict(color=image,encoding="rgb",timestep=stamp,
                           wcT=camera_pose(tcp,cfg,cam)))
    return result, recorded


def legacy_batch(policy, observation):
    cfg, size = policy.config, policy.wire_size
    tcp, grip = observation["ee_pose"], observation["gripper"]
    images = [cv2.resize(observation[key]["data"]["color"], tuple(size[::-1]), interpolation=cv2.INTER_AREA)
              for key in cfg.camera_keys]
    h,w = size
    return dict(obs_rgbs=torch.from_numpy(np.stack(images).transpose(0,3,1,2))[None,None].float()/255,
        obs_masks=torch.ones(1,1,3,h,w,dtype=torch.bool), obs_norm_xys=camera_rays(cfg,size),
        obs_extrinsics=torch.from_numpy(np.stack([camera_pose(tcp,cfg,cfg.geometry["cameras"][k]) for k in cfg.camera_keys]))[None,None],
        current_ee_pose=torch.from_numpy(tcp)[None],
        history_ee_states=torch.from_numpy(np.concatenate([tcp.reshape(2,16),grip[:,None]],-1))[None,None],
        valid_ee_mask=torch.ones(1,2,dtype=torch.bool), prompt_text=["close the box"])


def test_world_recorded_match_existing_training_path_without_double_transform():
    policy = FakePolicy()
    world = world_service(policy)
    raw = Service(policy=policy)
    config_path = Path(__file__).resolve().parents[1]/"e2vla_compat/planner.json"
    shipped = PlannerConfig.load(config_path)
    assert (shipped.input_pose_format, shipped.input_gripper_format) == ("recorded", "raw")
    assert raw.get_planner_config()["input_pose_format"] == "recorded"
    assert raw.get_planner_config()["input_gripper_format"] == "raw"
    observed, recorded = frame(policy)
    before = copy.deepcopy(observed)
    local = copy.deepcopy(observed)
    local.update(ee_pose=recorded, gripper=np.array([1886.,0.]))
    packed = np.zeros((1,14)); packed[0,policy.config.gripper_indices] = local["gripper"]
    expected = observation_to_sample({policy.config.state_pose_key:recorded.reshape(1,-1),
        policy.config.state_gripper_key:packed, "instruction":"task",
        "images":{k:observed[k]["data"]["color"] for k in policy.config.camera_keys}},policy.config)
    for service, value in [(world,observed),(raw,local)]:
        service.set_prompt("task")
        service.add_obs_frame(value)
        assert_same_observation(service.sampler.sample("task"),expected)
        poses,grippers,times,image = service.get_action(seed=2)
        assert poses.shape == (32,2,4,4) and grippers.shape == (32,2) and image is None
        np.testing.assert_array_equal(times,100.+np.arange(32)/30.)
        np.testing.assert_allclose(poses[0],ProprioParser(expected.state[:,-1]).posemat.numpy())
    np.testing.assert_array_equal(observed["ee_pose"],before["ee_pose"])
    for key in policy.config.camera_keys:
        np.testing.assert_array_equal(observed[key]["data"]["color"],before[key]["data"]["color"])


@pytest.mark.parametrize("fault",["duplicate","intrinsics","extrinsics","image_time","rotation","gripper","resolution","encoding"])
def test_bad_frame_upload_is_atomic(fault):
    p=FakePolicy(); s=world_service(p)
    first,_=frame(p); second,_=frame(p,101.)
    key=p.config.camera_keys[0]
    if fault=="duplicate": second["timestamp"]=100.
    elif fault=="intrinsics": second[key]["camera"]["K"]=np.eye(3)
    elif fault=="extrinsics": second[key]["data"]["wcT"]=np.eye(4)
    elif fault=="image_time": second[key]["data"]["timestep"]-=1
    elif fault=="rotation": second["ee_pose"][0,:3,:3]*=-1
    elif fault=="gripper": second["gripper"][0]=1886.
    elif fault=="resolution": second[key]["data"]["color"]=np.zeros((8,8,3),np.uint8)
    elif fault=="encoding": second[key]["data"]["encoding"]="yuv"
    with pytest.raises(ValueError): s.add_obs_frames([first,second])
    assert s.get_status()["observation_count"]==0
    assert s.sampler.latest is None and not p.calls


def test_reset_config_and_no_speed_leave_model_contract_immutable():
    p=FakePolicy(); s=world_service(p)
    info=copy.deepcopy(s.get_info())
    assert s.get_action() is None
    obs,_=frame(p); s.add_obs_frame(obs)
    with pytest.raises(ValueError): s.get_action()
    s.set_prompt("task")
    result=s.get_action()
    s.set_ensemble_nums(3); s.ensemble_traj(*result[:3])
    for values in [{"image_size":[256,256]},{"num_history_states":5},{"history_tolerance_s":1.},
                   {"speed_mps":.1},{"guidance_scale":2.},{"seed":-1}]:
        with pytest.raises(ValueError): s.set_config(values)
    with pytest.raises(ValueError): s.set_speed(.1)
    with pytest.raises(ValueError): s.get_action(speed_mps=.1)
    assert s.get_info()["checkpoint_metadata"]==info["checkpoint_metadata"]
    s.reset()
    assert s.get_action() is None and s.get_status()["observation_count"]==0
    assert not s.pos_ensembler.history_time and s.settings.prompt=="task"
    s.add_obs_frame(obs)
    s.set_config({"input_gripper_format":"raw"})
    assert s.get_status()["observation_count"]==0


def test_rgb_bgr_and_jpeg_decoding():
    p=FakePolicy(); rgb,_=frame(p); bgr=copy.deepcopy(rgb)
    for k in p.config.camera_keys:
        bgr[k]["data"].update(color=rgb[k]["data"]["color"][...,::-1],encoding="bgr")
    a,b=world_service(p),world_service(p)
    a.add_obs_frame(rgb); b.add_obs_frame(bgr)
    assert_same_observation(a.sampler.sample("task"),b.sampler.sample("task"))
    jpeg=copy.deepcopy(rgb)
    for k in p.config.camera_keys:
        _,encoded=cv2.imencode('.jpg',bgr[k]["data"]["color"])
        jpeg[k]["data"]=dict(color_jpeg=encoded.tobytes())
    c=world_service(p); c.add_obs_frame(jpeg)
    assert c.sampler.sample("task").raw_vl.rgb[0].dtype==torch.uint8


def test_batch_validation_and_numpy_endpoint():
    p=FakePolicy(); s=world_service(p); obs,_=frame(p); batch=legacy_batch(p,obs)
    batch["gt_future_ee_states"]=torch.full((1,32,2,17),float('nan'))
    result=s.run_inference_numpy(batch,contract_sha256=p.signature)
    assert result.shape==(1,32,2,17) and np.isfinite(result).all()
    assert s.get_status()["observation_count"]==0
    assert p.calls[-1].raw_vl.rgb[0].shape[-2:]==(32,64)
    with pytest.raises(ValueError): s.run_inference(batch,contract_sha256="wrong")
    for key in ["obs_masks","valid_ee_mask","obs_norm_xys","obs_extrinsics","current_ee_pose","history_ee_states","obs_rgbs"]:
        bad=copy.deepcopy(batch)
        if key in ("obs_masks","valid_ee_mask"): bad[key].fill_(False)
        elif key=="history_ee_states": bad[key][...,16]=2
        elif key=="obs_rgbs": bad[key].fill_(2)
        else: bad[key].zero_()
        with pytest.raises(ValueError): batch_to_samples(bad,p.config,p.wire_size)


def test_trajectory_render_and_ensemble_match_legacy_semantics():
    p=FakePolicy(); s=world_service(p); obs,_=frame(p)
    s.set_prompt('task'); s.add_obs_frame(obs)
    poses,grippers,times,image=s.get_action(draw_traj=True)
    assert image.shape==(32,3*64,3) and image.dtype==np.uint8
    jpeg=s.get_action(draw_traj=True,compress_traj_img=True)[3]
    assert cv2.imdecode(jpeg,cv2.IMREAD_COLOR).shape==image.shape
    s.set_ensemble_nums(2)
    a,b=s.ensemble_traj(poses,grippers,times)
    np.testing.assert_array_equal(a,poses)
    newer=poses.copy(); newer[...,:3,3]+=.1
    a,b=s.ensemble_traj(newer,grippers,times)
    np.testing.assert_allclose(a[:-1,...,:3,3],(poses[:-1,...,:3,3]*.1+newer[:-1,...,:3,3])/1.1,atol=1e-6)
    np.testing.assert_array_equal(a[...,:3,:3],newer[...,:3,:3])
    with pytest.raises(ValueError): s.ensemble_traj(poses,grippers,times-1)


@pytest.mark.parametrize("task",list(TASKS))
def test_unmodified_existing_e03_client_accepts_task_route(task):
    directory=Path('/home/hq/code/e2vla/e03_lerobot_client/clients')
    if not directory.is_dir(): pytest.skip("Reference client not installed; use the socket probe on its host")
    spec=importlib.util.spec_from_file_location('_reference_e03',directory/'__init__.py',submodule_search_locations=[str(directory)])
    import sys
    package=importlib.util.module_from_spec(spec); sys.modules[spec.name]=package; spec.loader.exec_module(package)
    from _reference_e03.lerobot_policy import RemotePolicy
    p=FakePolicy(task); s=world_service(p)
    client=RemotePolicy(s,p.config.camera_keys,2,task)
    client.start('task')
    obs,_=frame(p); prediction=client.infer([obs])
    assert prediction.poses.shape==(32,2,4,4) and client.history_seconds==0
    info=s.get_info()
    assert info['data_config']['reviewed_datasets']==TASKS[task]
    assert info['compatibility']['checkpoint_is_not_task_filtered']
    assert info['checkpoint_metadata']['data_config']['image_size']==[32,64]
    assert info['checkpoint_metadata']['model_config']['train_qwen'] is True
    assert signature(info['data_config'])==info['contract_sha256']


def test_all_legacy_service_methods_preserve_signatures():
    import ast
    source=Path('/home/hq/code/e2vla/infer_utils/remote_service.py')
    if not source.is_file(): pytest.skip('Reference service not installed')
    def signatures(path):
        cls=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='Service')
        return {n.name:ast.dump(n.args) for n in cls.body if isinstance(n,ast.FunctionDef)}
    import e2vla_compat.remote_service as remote
    assert signatures(source)==signatures(Path(remote.__file__))
