"""Smoke-test the actual training entry with reviewed data and a tiny random Qwen.

Launch with torchrun and pass normal train_lerobot_dual CLI arguments. Uses the
local production tokenizer; replaces only model dimensions/pretrained weights.
"""
import json
from pathlib import Path
import sys

import torch
from transformers import Qwen3VLConfig, Qwen3VLForConditionalGeneration

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def tiny_qwen(*args, **kwargs):
    reference = json.loads((ROOT / "Qwen/Qwen3-VL-2B-Instruct/config.json").read_text())
    config = Qwen3VLConfig(
        text_config=dict(vocab_size=reference["text_config"]["vocab_size"], hidden_size=64,
                         intermediate_size=128, num_hidden_layers=4, num_attention_heads=1,
                         num_key_value_heads=1, head_dim=64,
                         rope_scaling={"rope_type": "default", "mrope_section": [12, 10, 10]}),
        vision_config=dict(depth=2, hidden_size=64, intermediate_size=128, num_heads=1,
                           out_hidden_size=64, deepstack_visual_indexes=[0, 1]),
        **{k: reference[k] for k in ("image_token_id", "video_token_id", "vision_start_token_id", "vision_end_token_id")})
    config._attn_implementation = "sdpa"
    return Qwen3VLForConditionalGeneration(config).to(torch.bfloat16)


if __name__ == "__main__":
    from models.m0512_fm import vla
    from models.m0512_fm.train_lerobot_dual import main
    Qwen3VLForConditionalGeneration.from_pretrained = tiny_qwen
    vla.vla_base = lambda inference_timesteps=4: vla.VLA(64, 1, 1, inference_timesteps)
    main()
