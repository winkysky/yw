"""Real checkpoint/socket integration probe against a running LeRobot service.

Run from the repo root: python -m tests.pyro_lerobot_probe is not required;
use PYTHONPATH=. python tests/pyro_lerobot_probe.py --help.
"""
import argparse
import copy
import json
from pathlib import Path
import time

import cv2
import numpy as np
import pyarrow.parquet as pq
import torch

from client import Client
from data_utils.tokenize import BatchDataTokenizedVLA
from dataset.lerobot_original import LeRobotOriginalConfig, LeRobotOriginalCollator
from dataset.lerobot_reviewed import build_dataset
from models.m0512_fm.lerobot_inference import load_checkpoint, load_inference_model, predict_sample


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--uri", default="ie2vla3_lerobot_h32")
    parser.add_argument("--ns-host", default="127.0.0.1")
    parser.add_argument("--ns-port", type=int, default=19090)
    parser.add_argument("--index", type=int, default=214)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(4)
    cv2.setNumThreads(1)
    clients, dataset = [], None
    try:
        for tcp in [True, False]:
            clients.append(Client(args.uri, args.ns_host, args.ns_port, force_tcp=tcp))
        tcp, shm = clients
        info = tcp.policy_info
        assert info["input_contract"] == "lerobot_dual_v1"
        assert tcp.data_config == info["data_config"]
        cfg = LeRobotOriginalConfig(**info["data_config"])
        dataset = build_dataset(cfg)
        dataset.require_geometry()
        assert dataset.fingerprint == info["dataset_fingerprint"]
        sample = dataset[args.index]
        original = copy.deepcopy(sample)
        saved, _ = load_checkpoint(info["checkpoint"])
        model = load_inference_model(saved, torch.device("cpu"))
        del saved
        assert model.vlm.full_qwen_features and not model.vlm.enable_lora
        collator = LeRobotOriginalCollator(model.vlm.processor)
        seed = 42 + args.index
        local = predict_sample(model, collator, sample, torch.device("cpu"), seed).numpy()
        metadata = sample._review_metadata
        reader = dataset.readers[metadata["dataset_id"]]
        table = pq.read_table(reader._path("data_path", metadata["episode_index"]),
                              columns=[cfg.state_pose_key, cfg.state_gripper_key]).to_pydict()
        frames = metadata["frame"] + np.arange(1 - cfg.num_history_states, 1) * cfg.frame_stride
        observation = {key: np.asarray(table[key])[frames] for key in table}
        observation.update(instruction=sample.raw_vl.prompt,
                           images={key: image[0].permute(1, 2, 0).numpy()
                                   for key, image in zip(cfg.camera_keys, sample.raw_vl.rgb)})
        changed_targets = copy.deepcopy(sample)
        changed_targets.action.fill_(123456.)
        batch = BatchDataTokenizedVLA(**collator([copy.deepcopy(sample)]))
        checks = [
            ("tcp_raw", lambda: tcp.inference_raw(sample, seed)),
            ("tcp_repeat", lambda: tcp.inference_raw(sample, seed)),
            ("tcp_changed_future_targets", lambda: tcp.inference_raw(changed_targets, seed)),
            ("tcp_observation", lambda: tcp.inference_observation(observation, seed)),
            ("tcp_batch", lambda: tcp.inference_batch(batch, seed)[0].numpy()),
            ("shm_raw", lambda: shm.inference_raw(sample, seed)),
            ("shm_observation", lambda: shm.inference_observation(observation, seed)),
            ("shm_batch", lambda: shm.inference_batch(batch, seed)[0].numpy()),
        ]
        results = []
        for name, call in checks:
            start = time.monotonic()
            prediction = call()
            np.testing.assert_allclose(prediction, local, rtol=1e-5, atol=1e-6)
            assert np.isfinite(prediction).all() and list(prediction.shape) == info["output_shape"]
            result = dict(check=name, seconds=time.monotonic() - start,
                          max_abs_diff=float(np.max(np.abs(prediction - local))))
            results.append(result)
            print(json.dumps(result), flush=True)
        torch.testing.assert_close(sample.state, original.state, rtol=0, atol=0)
        torch.testing.assert_close(sample.action, original.action, rtol=0, atol=0)
        bad = copy.deepcopy(sample)
        bad.action = bad.action[:, :-1]
        try:
            tcp.inference_raw(bad)
        except ValueError as error:
            assert "Expected state" in str(error)
        else:
            raise AssertionError("Remote service accepted wrong horizon")
        # An invalid request must not kill the service or alter its model.
        assert tcp.policy_info["step"] == info["step"]
        result = dict(checkpoint=info["checkpoint"], step=info["step"], sample_index=args.index,
                      seed=seed, output_shape=info["output_shape"], checks=results,
                      invalid_request_rejected=True, input_unchanged=True,
                      full_qwen_features=True, lora=False)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    finally:
        if dataset is not None:
            dataset.close()
        for client in clients:
            client.close()


if __name__ == "__main__":
    main()
