"""Full-Qwen defaults, useful gradients, reviewed sampling and DDP partitioning."""
from dataclasses import replace
from types import SimpleNamespace

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch

from data_utils.tokenize import ModalityType
from dataset.lerobot_original import LeRobotOriginalConfig
from dataset.lerobot_reviewed import LeRobotReviewedDataset, load_reviewed_view
from models.m0512_fm import vla
from models.m0512_fm.train_lerobot_dual import parser, build_model, EpochBatchSampler, save_checkpoint
from models.m0512_fm.train_lerobot_dual_velocity import parser as speed_parser
from test_lerobot_dual import dataset, synthetic_batch
from test_lerobot_original import local_qwen, calibrated_config


def tiny_batch():
    data, _ = synthetic_batch(idim=64)
    ids = torch.tensor([[62, 60, 60, 63] * 3 + [1, 2]]).repeat(2, 1)
    data.tokenized_vl = dict(input_ids=ids, attention_mask=torch.ones_like(ids),
                           pixel_values=torch.randn(48, 3 * 2 * 16 * 16),
                           image_grid_thw=torch.tensor([[1, 2, 4]]).repeat(6, 1))
    data.modality = torch.where(ids == 60, ModalityType.VISION, ModalityType.LANGUAGE)
    data._aux_data = {}
    return data


def test_full_training_defaults_and_speed_entry_independence():
    args = parser().parse_args([])
    assert args.train_qwen and args.nproc_per_node == 4
    assert args.batch_size * args.nproc_per_node * args.gradient_accumulation_steps == 32
    assert args.optimizer_sharding == "zero1"
    assert (args.max_steps, args.save_every) == (100000, 10000)
    config = LeRobotOriginalConfig.load(args.data_config)
    assert config.root == "/home/hq/code/huawei_261112/reviewed_training_20261115/filtered_data"
    assert config.num_future_actions == 32
    # The separate factor branch now also trains full Qwen; its defaults must
    # not change the no-speed assertions above.
    speed = speed_parser().parse_args([])
    assert speed.batch_size * speed.gradient_accumulation_steps * speed.nproc_per_node == 32
    assert speed.save_every == 10000
    assert speed.train_qwen


def test_unfreeze_keeps_pretrained_values_and_disables_lora(local_qwen):
    torch.manual_seed(123)
    frozen = build_model(train_qwen=False)
    torch.manual_seed(123)
    full = build_model()
    assert not full.vlm.enable_lora and full.vlm.full_qwen_features
    assert all(p.requires_grad for p in full.vlm.parameters())
    for key, value in frozen.vlm.state_dict().items():
        torch.testing.assert_close(full.vlm.state_dict()[key], value, rtol=0, atol=0)
    with pytest.raises(ValueError, match="actor-only"):
        save_checkpoint(None, full, None, None, 0, None, None, None, None)


def test_action_loss_reaches_visual_last_language_block_and_final_norm(local_qwen):
    torch.set_num_threads(2)
    model = vla.VLA(64, 1, 1)
    model.vlm.requires_grad_(True)
    model.vlm.full_qwen_features = True
    torch.nn.init.normal_(model.actor.dp_head.act_head.weight, std=.01)
    loss, _ = model(tiny_batch(), inference=False, fp16=True)
    loss.backward()
    probes = [model.vlm.qwen.visual.patch_embed.proj.weight,
              model.vlm.qwen.language_model.layers[0].self_attn.q_proj.weight,
              model.vlm.qwen.language_model.layers[-1].self_attn.q_proj.weight,
              model.vlm.qwen.language_model.norm.weight]
    for parameter in probes:
        assert parameter.grad is not None and torch.isfinite(parameter.grad).all()
        assert parameter.grad.abs().sum() > 0


def test_distributed_sampler_has_disjoint_equal_batches_and_exact_resume():
    world, batch, size = 4, 3, 53
    parts = [list(EpochBatchSampler(size, batch, 42, 2, rank=r, world_size=world)) for r in range(world)]
    assert {len(p) for p in parts} == {4}
    flat = [idx for part in parts for chunk in part for idx in chunk]
    assert len(flat) == len(set(flat)) == 48
    expected = list(EpochBatchSampler(size, batch * world, 42, 2))
    assert [[idx for rank in range(world) for idx in parts[rank][step]] for step in range(4)] == expected
    for rank in range(world):
        assert list(EpochBatchSampler(size, batch, 42, 2, start_batch=2, rank=rank, world_size=world)) == parts[rank][2:]


def test_reviewed_source_uses_corrected_rows_original_video_frames_and_subtask_prompt(dataset, monkeypatch):
    import dataset.lerobot_reviewed as reviewed
    cfg = replace(calibrated_config(dataset.config), num_history_states=1, num_future_actions=2)
    path = dataset.root / "corrected.parquet"
    values = pq.read_table(dataset._path("data_path", 0)).to_pydict()
    commands = np.array(values[cfg.action_pose_key])
    commands[:, 0] += 50
    values[cfg.action_pose_key] = commands.tolist()
    pq.write_table(pa.table(values), path)
    segments = [dict(dataset_id="source", source_root=str(dataset.root), episode_index=0,
                     parquet_path=str(path), segment_id="subtask_A", frames=np.array([0]),
                     instruction="Only the reviewed subtask", split_group="source_hash")]
    monkeypatch.setattr(reviewed, "load_reviewed_view", lambda root, config: (segments, "snapshot"))
    reader = LeRobotReviewedDataset(cfg)
    try:
        assert len(reader) == 1 and len(reader.episodes) == 1
        sample = reader[0]
        assert sample.raw_vl.prompt == "Only the reviewed subtask"
        torch.testing.assert_close(sample.action[0, :, 0], torch.tensor([.055, .065]))
        torch.testing.assert_close(sample.raw_vl.rgb[0], dataset[0].raw_vl.rgb[0])
        assert sample.action_mask[..., :10].all()
        with pytest.raises(IndexError):
            reader[1]
    finally:
        reader.close()


def test_reviewed_windows_respect_offsets_stride_history_bad_rows_and_bounds(tmp_path, monkeypatch):
    import dataset.lerobot_reviewed as reviewed
    cfg = LeRobotOriginalConfig("unused", num_history_states=2, num_future_actions=2,
                                frame_stride=2, action_offset=1)
    segment = dict(segment_id="s", dataset_id="d", episode_index=0, source_root=str(tmp_path),
                   parquet_path=str(tmp_path / "source.parquet"), start_frame=10, stop_frame=24,
                   instruction="subtask", excluded_intervals=[[15, 17]], action_relation="independent", split_group="g")
    seen = []
    def valid(s, history, actions):
        seen.append((list(history), list(actions)))
        return all(10 <= row < 24 and row not in (15, 16) for row in [*history, *actions])
    handoff = SimpleNamespace(load_reviewed_segments=lambda root: [segment], sample_rows_valid=valid)
    monkeypatch.setattr(reviewed.importlib.util, "module_from_spec", lambda spec: handoff)
    monkeypatch.setattr(reviewed.importlib.util, "spec_from_file_location",
                        lambda *a: SimpleNamespace(loader=SimpleNamespace(exec_module=lambda module: None)))
    (tmp_path / "run_manifest.json").write_text("{}")
    result, _ = load_reviewed_view(tmp_path / "filtered_data", cfg)
    np.testing.assert_array_equal(result[0]["frames"], [19, 20])
    assert seen[0] == ([8, 10], [11, 13])
