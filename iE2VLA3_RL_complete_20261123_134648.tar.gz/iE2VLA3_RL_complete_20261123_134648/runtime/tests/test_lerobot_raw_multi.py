"""Whole-source sampling, exact prompts and legacy checkpoint-config compatibility."""
from dataclasses import replace
import hashlib
import json
import pickle
from pathlib import Path
import shutil

import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch

from dataset.lerobot_original import LeRobotOriginalConfig, LeRobotOriginalDataset
from dataset.lerobot_reviewed import build_dataset
from models.m0512_fm.train_lerobot_dual import TrainingStream
from test_lerobot_dual import dataset, collate_states
from test_lerobot_original import calibrated_config


@pytest.fixture
def raw_manifest(dataset, tmp_path_factory):
    second = tmp_path_factory.mktemp("raw_second")
    for name in ("meta", "data", "videos"):
        shutil.copytree(dataset.root / name, second / name)
    # Embedded per-frame prompt must not override the user's source instruction.
    path = dataset._path("data_path", 0)
    table = pq.read_table(path).append_column("prompt", pa.array(["stale task"] * 4))
    pq.write_table(table, path)
    manifest = tmp_path_factory.mktemp("raw_manifest")
    sources = [dict(name="first", root=str(dataset.root), instruction="First full task."),
               dict(name="second", root=str(second), instruction="Second full task.")]
    (manifest / "raw_sources.json").write_text(json.dumps(dict(format="lerobot_raw_sources_v1", sources=sources)))
    return replace(calibrated_config(dataset.config), root=str(manifest)), sources


def test_all_frames_prompts_boundaries_geometry_and_unmodified_sources(raw_manifest):
    config, sources = raw_manifest
    reader = build_dataset(config)
    reference = LeRobotOriginalDataset(replace(config, root=sources[0]["root"]))
    path = reference._path("data_path", 0)
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    try:
        assert len(reader) == 16 and len(reader.episodes) == 4
        assert reader.fps == 30
        assert LeRobotOriginalConfig(**config.to_dict()).to_dict() == config.to_dict()
        for index in (0, 3, 4, 7, 8, 11, 12, 15):
            sample = reader[index]
            assert sample.raw_vl.prompt == sources[index // 8]["instruction"]
            assert sample._raw_metadata["episode_index"] == (index % 8) // 4
            assert sample._raw_metadata["frame"] == index % 4
        sample, expected = reader[0], reference[0]
        assert expected.raw_vl.prompt == "stale task"
        for field in ("state", "action", "state_mask", "action_mask", "action_ref_pose"):
            torch.testing.assert_close(getattr(sample, field), getattr(expected, field), rtol=0, atol=0)
        for a, b in zip(sample.raw_vl.rgb, expected.raw_vl.rgb):
            torch.testing.assert_close(a, b, rtol=0, atol=0)
        torch.testing.assert_close(sample.raw_vl.K, expected.raw_vl.K, rtol=0, atol=0)
        assert reader[7].action_mask[0].any(-1).tolist() == [True, False, False]
        assert reader[8].action_mask[0].any(-1).tolist() == [True, True, True]
        restored = pickle.loads(pickle.dumps(reader))
        try:
            assert restored[8].raw_vl.prompt == sources[1]["instruction"]
        finally:
            restored.close()
        for bad in (-1, len(reader)):
            with pytest.raises(IndexError):
                reader[bad]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == before
    finally:
        reader.close()
        reference.close()


def test_prompt_changes_fingerprint_and_duplicate_roots_fail(raw_manifest):
    config, sources = raw_manifest
    path = Path(config.root) / "raw_sources.json"
    reader = build_dataset(config)
    old_fingerprint = reader.fingerprint
    reader.close()
    sources[0]["instruction"] = "Changed full task."
    payload = dict(format="lerobot_raw_sources_v1", sources=sources)
    path.write_text(json.dumps(payload))
    changed = build_dataset(config)
    assert changed.fingerprint != old_fingerprint
    changed.close()
    sources[1]["root"] = sources[0]["root"]
    path.write_text(json.dumps(payload))
    with pytest.raises(ValueError, match="Duplicate raw source"):
        build_dataset(config)


def test_raw_sources_spawn_workers_and_close_cleanly(raw_manifest):
    config, _ = raw_manifest
    reader = build_dataset(config)
    stream = TrainingStream(reader, collate_states, batch_size=2, workers=2, seed=42)
    try:
        assert stream.next()["state"].shape == (2, 2, 2, 73)
        workers = list(stream.iterator._workers)
    finally:
        stream.close()
    assert all(not worker.is_alive() for worker in workers)
