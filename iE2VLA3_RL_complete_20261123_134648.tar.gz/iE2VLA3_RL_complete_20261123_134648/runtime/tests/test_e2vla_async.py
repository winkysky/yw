"""Scheduling, clock alignment, invalidation and concurrent-control tests."""
import copy
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pytest
from scipy.spatial.transform import Rotation

from e2vla_compat.config import PlannerConfig
from e2vla_async.remote_service import Service
from e2vla_async.client import TrajectoryBuffer, PipelinedClient
from test_e2vla_compat import FakePolicy, frame


def until(predicate, timeout=4.):
    deadline = time.monotonic()+timeout
    while time.monotonic() < deadline:
        value = predicate()
        if value:
            return value
        time.sleep(.002)
    raise AssertionError('Timed out')


class GatedPolicy(FakePolicy):
    def __init__(self, count=2):
        super().__init__()
        self.started = [threading.Event() for _ in range(count)]
        self.release = [threading.Event() for _ in range(count)]
        self.number = 0
        self.prompts = []

    def predict_samples(self, samples, *args):
        n = self.number
        self.number += 1
        self.prompts.append(samples[0].raw_vl.prompt)
        if n < len(self.started):
            self.started[n].set()
            assert self.release[n].wait(5.), 'test gate timed out'
        return super().predict_samples(samples,*args)

    def unblock(self):
        for event in self.release:
            event.set()


def service(policy, **kwargs):
    return Service(policy=policy, config=PlannerConfig(task='close_box',prompt='old task',
        input_pose_format='tcp_world',input_gripper_format='openness'), **kwargs)


def test_observation_upload_during_inference_and_latest_frame_coalescing():
    p=GatedPolicy();s=service(p)
    try:
        s.add_obs_frame(frame(p,100.)[0]);s.start_async()
        assert p.started[0].wait(2.)
        with ThreadPoolExecutor(1) as pool:
            pool.submit(s.add_obs_frames,[frame(p,101.)[0],frame(p,102.)[0]]).result(timeout=1.)
        assert s.get_status()['last_timestamp']==102.
        p.release[0].set()
        assert p.started[1].wait(2.)
        first=s.get_latest_action()['result']
        assert first['observation_timestamp']==100.
        np.testing.assert_array_equal(first['times'],100.+np.arange(32)/30)
        p.release[1].set()
        second=until(lambda:s.get_latest_action(first['sequence'])['result'])
        assert second['observation_timestamp']==102.
        assert second['observation_sequence']==3
        assert s.get_latest_action(second['sequence'])['result'] is None
        time.sleep(.04)
        assert p.number==2  # no backlog and no repeated inference of an unchanged frame
    finally:
        p.unblock();s.close()


@pytest.mark.parametrize('change',['reset','prompt','pause'])
def test_inflight_result_invalidated_on_session_change(change):
    p=GatedPolicy();s=service(p)
    try:
        s.add_obs_frame(frame(p,100.)[0]);s.start_async();assert p.started[0].wait(2.)
        generation=s.get_status()['generation']
        if change=='reset':
            s.reset();s.set_prompt('new task');s.add_obs_frame(frame(p,50.)[0]);s.start_async()
        elif change=='prompt':
            s.set_prompt('new task')
        else:
            s.pause_async()
        assert s.get_status()['generation']>generation
        p.release[0].set()
        until(lambda:s.get_status()['counts']['discarded']==1)
        assert s.get_latest_action()['result'] is None
        if change!='pause':
            assert p.started[1].wait(2.);p.release[1].set()
            latest=until(lambda:s.get_latest_action()['result'])
            assert latest['generation']==s.get_status()['generation']
            assert p.prompts==['old task','new task']
        else:
            assert not s.get_status()['enabled'] and p.number==1
    finally:
        p.unblock();s.close()


def test_sync_endpoint_keeps_snapshot_timestamp_while_uploads_continue():
    p=GatedPolicy(1);s=service(p)
    try:
        s.add_obs_frame(frame(p,100.)[0])
        with ThreadPoolExecutor(1) as pool:
            future=pool.submit(s.get_action)
            assert p.started[0].wait(2.)
            s.add_obs_frame(frame(p,200.)[0]);p.release[0].set()
            result=future.result(timeout=2.)
        np.testing.assert_array_equal(result[2],100.+np.arange(32)/30.)
        assert s.get_status()['last_timestamp']==200.
    finally:
        p.unblock();s.close()


def test_invalid_batch_atomic_and_inference_error_visible():
    class Broken(FakePolicy):
        def predict_samples(self,*args):raise RuntimeError('test failure')
    p=Broken();s=service(p)
    try:
        a=frame(p,100.)[0];b=frame(p,101.)[0];b['gripper']=np.array([5.,0.])
        with pytest.raises(ValueError):s.add_obs_frames([a,b])
        assert s.get_status()['observation_sequence']==0
        assert s.get_status()['observation_count']==0
        s.add_obs_frame(a);s.start_async()
        envelope=until(lambda:s.get_latest_action() if s.get_status()['error'] else None)
        assert 'test failure' in envelope['error'] and not envelope['enabled']
        with pytest.raises(RuntimeError,match='test failure'):TrajectoryBuffer().accept(envelope)
    finally:s.close()


def envelope(start=100.,seq=1,generation=0):
    poses=np.tile(np.eye(4),(3,2,1,1))
    poses[:,:,0,3]=np.array([0.,1.,2.])[:,None]
    poses[:,:,:3,:3]=Rotation.from_euler('z',[0,90,180],degrees=True).as_matrix()[:,None]
    return dict(stream_id='server',generation=generation,enabled=True,error=None,
        result=dict(stream_id='server',generation=generation,sequence=seq,
                    poses=poses,grippers=np.array([[0.,0.],[.5,.5],[1.,1.]]),
                    times=start+np.arange(3),observation_timestamp=start))


def test_buffer_interpolation_expiry_and_future_chunk_handover():
    b=TrajectoryBuffer();assert b.accept(envelope())
    target=b.target(100.5)
    np.testing.assert_allclose(target['poses'][:,0,3],.5)
    np.testing.assert_allclose(target['grippers'],.25)
    np.testing.assert_allclose(target['poses'][0,:3,:3],Rotation.from_euler('z',45,degrees=True).as_matrix())
    b.accept(envelope(101.,2))
    assert b.target(100.75)['sequence']==1
    assert b.target(101.)['sequence']==2
    assert b.target(102.9)['sequence']==2
    assert b.target(103.01) is None
    assert b.target(103.01,lead_time_s=.1) is None
    assert b.target(1.) is None  # never shift a trajectory to a different clock epoch


def test_buffer_generation_error_and_ordering():
    b=TrajectoryBuffer();b.accept(envelope())
    assert not b.accept(envelope())
    with pytest.raises(ValueError,match='advance'):b.accept(envelope(99.,2))
    changed=dict(stream_id='server',generation=1,enabled=True,error=None,result=None)
    b.accept(changed);assert b.target(100.5) is None
    b.accept(envelope(100.,2,1));assert b.target(100.5)
    b.accept(dict(changed,enabled=False));assert b.target(100.5) is None
    malformed=envelope(100.,3,1);malformed['result']['poses'][0,0,0,0]=4.
    with pytest.raises(ValueError,match='rotations'):b.accept(malformed)


def test_client_executes_old_chunk_while_server_computes_new_one():
    class Slow(FakePolicy):
        def predict_samples(self,*args):
            time.sleep(.06)
            return super().predict_samples(*args)
    p=Slow();s=service(p)
    client=PipelinedClient(proxy_factory=lambda:s,poll_interval_s=.003)
    sent=[];waiting=[];overlap=[]
    try:
        client.start('task')
        def capture():return frame(p,time.time())[0]
        def execute(target):
            sent.append(target)
            overlap.append(s.get_status()['in_flight'])
        client.run(capture,execute,lambda:waiting.append(True),control_hz=100,capture_hz=50,duration_s=.65)
        assert len(sent)>10 and any(overlap)
        assert len({x['sequence'] for x in sent})>=2
        assert all(x['timestamp']>=x['observation_timestamp'] for x in sent)
        assert all(a['timestamp']<b['timestamp'] for a,b in zip(sent,sent[1:]))
        assert client.stats['uploaded']>s.get_status()['counts']['completed']
        assert waiting
    finally:client.close();s.close()


def test_capture_error_stops_control_and_calls_wait():
    p=FakePolicy();s=service(p);c=PipelinedClient(proxy_factory=lambda:s)
    waited=[]
    try:
        c.start('task')
        def capture():raise ValueError('camera failed')
        with pytest.raises(RuntimeError,match='camera failed'):
            c.run(capture,lambda target:None,lambda:waited.append(True),duration_s=.2)
        assert waited
    finally:c.close();s.close()
