"""Trajectory rendering and inference input isolation, without a training GPU."""
import copy
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from data_utils.data_raw import DataRawVL
from data_utils.visualize import draw_ee_axis, draw_ee_dots, draw_state_actions
from models.m0512_fm.visualize_lerobot import (choose_indices, episode_groups,
    load_checkpoint, predict_sample, trajectory_metrics)
from test_lerobot_dual import synthetic_batch


def test_projection_drops_behind_camera_nonfinite_and_outside_points():
    image = np.zeros((64, 64, 3), dtype=np.uint8)
    k = np.array([[20., 0, 32], [0, 20, 32], [0, 0, 1]])
    positions = np.array([[0., 0, 1], [.5, 0, -1], [0, 0, 0], [np.nan, 0, 1], [1e10, 0, 1]])
    result = draw_ee_dots(image, k, np.eye(4), positions, (0, 255, 0))
    assert result[32, 32, 1] == 255
    assert not result[32, 22].any()  # The point behind the camera would project here.
    behind = np.eye(4)
    behind[2, 3] = -1
    assert not draw_ee_axis(np.zeros_like(image), k, np.eye(4), behind).any()
    front = np.eye(4)
    front[2, 3] = 1
    assert draw_ee_axis(np.zeros_like(image), k, np.eye(4), front).any()


def test_projection_respects_future_action_masks():
    raw = DataRawVL(K=torch.tensor([[[20., 0, 32], [0, 20, 32], [0, 0, 1]]]),
                    rgb=[torch.zeros(1, 3, 64, 64, dtype=torch.uint8)],
                    pose=[torch.eye(4)[None]], fps=30., prompt="test")
    action = torch.zeros(1, 2, 73)
    action[..., 2] = 1
    action[..., 3] = action[..., 7] = 1
    action[0, 1, 0] = .5
    mask = torch.zeros_like(action, dtype=torch.bool)
    mask[:, 0, :10] = True
    image = draw_state_actions(raw, actions=[action], colors=[(0, 255, 0)], action_masks=[mask])[0]
    assert image[32, 32, 1] == 255
    assert not image[32, 42].any()


def test_predict_uses_no_target_values_and_preserves_raw_sample_and_rng():
    batch, _ = synthetic_batch(horizon=32)
    sample = SimpleNamespace(action=batch.action[0].clone(), action_mask=batch.action_mask[0].clone())
    original = sample.action.clone()

    def collator(items):
        # Even a mutating collator/model must not alter the displayed target.
        items[0].action.add_(100)
        return vars(copy.deepcopy(batch))

    def model(inputs, inference, fp16):
        assert inference and fp16 and not torch.is_grad_enabled()
        assert not inputs.action.any()
        assert inputs.action_mask[..., :10].all()
        inputs.state.zero_()
        return torch.randn(2, 2, 32, 80)

    rng = torch.get_rng_state().clone()
    result = predict_sample(model, collator, sample, torch.device("cpu"), 42)
    assert result.shape == (2, 32, 73)
    torch.testing.assert_close(result, predict_sample(model, collator, sample, torch.device("cpu"), 42))
    torch.testing.assert_close(sample.action, original)
    assert torch.equal(rng, torch.get_rng_state())


def test_metrics_separate_arms_respect_masks_and_use_physical_units():
    batch, _ = synthetic_batch(horizon=3)
    sample = SimpleNamespace(action=batch.action[0], action_mask=batch.action_mask[0].clone())
    sample.action_mask[0, -1] = False
    pred = sample.action.clone()
    pred[0, :, 0] += .01
    pred[0, -1, 0] += 100  # Masked value must not affect metrics.
    pred[1, :, 1] += .02
    pred[1, :, 9] += .25
    result = trajectory_metrics(sample, pred)
    assert result['left']['position_mean_mm'] == pytest.approx(10., abs=1e-4)
    assert result['left']['valid_steps'] == 2
    assert result['right']['position_mean_mm'] == pytest.approx(20., abs=1e-4)
    assert result['right']['gripper_mae'] == pytest.approx(.25)
    assert result['right']['rotation_mean_deg'] == pytest.approx(0.)


def test_reviewed_navigation_keeps_episode_windows_and_covers_sources():
    dataset = SimpleNamespace(segments=[dict(dataset_id='a', episode_index=2),
                                       dict(dataset_id='a', episode_index=2),
                                       dict(dataset_id='a', episode_index=3),
                                       dict(dataset_id='b', episode_index=0)], ends=[2, 5, 8, 10])
    groups = episode_groups(dataset)
    assert [key for key, _ in groups] == [('a', 2), ('a', 3), ('b', 0)]
    np.testing.assert_array_equal(groups[0][1], np.arange(5))
    assert choose_indices(dataset, 2) == [2, 9]


def test_incomplete_checkpoint_is_rejected_before_model_loading(tmp_path):
    with pytest.raises(ValueError, match="complete"):
        load_checkpoint(tmp_path)


def test_interactive_navigation_without_a_display(monkeypatch):
    import models.m0512_fm.visualize_lerobot as viewer
    visited = []

    class Dataset:
        segments = [dict(dataset_id='a', episode_index=2), dict(dataset_id='a', episode_index=2),
                    dict(dataset_id='a', episode_index=3)]
        ends = [2, 5, 8]
        fps = 30.
        config = SimpleNamespace(num_future_actions=32, frame_stride=1, action_offset=0, camera_keys=[])

        def __getitem__(self, index):
            visited.append(index)
            return SimpleNamespace(_review_metadata=dict(dataset_id='a', episode_index=2, frame=index),
                                   raw_vl=SimpleNamespace(prompt='test'))

    keys = iter([ord('d'), ord('n'), ord('p'), 65361, ord('i'), ord('q')])
    monkeypatch.setattr(viewer, 'render_projection', lambda *a: np.zeros((16, 16, 3), dtype=np.uint8))
    monkeypatch.setattr(viewer.cv2, 'imshow', lambda *a: None)
    monkeypatch.setattr(viewer.cv2, 'waitKeyEx', lambda *a: next(keys))
    monkeypatch.setattr(viewer.cv2, 'destroyAllWindows', lambda: None)
    viewer.interactive(Dataset(), None, None, torch.device('cpu'), 42, 2)
    assert visited == [2, 3, 5, 0, 4, 4]
