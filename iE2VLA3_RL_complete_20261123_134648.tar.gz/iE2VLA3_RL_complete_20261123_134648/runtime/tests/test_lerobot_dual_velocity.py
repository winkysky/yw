"""Four-factor FiLM and full-Qwen training without external weights."""
from types import SimpleNamespace
import pytest
import torch
from models.speed_factor import FACTORS,factor_tensor,SpeedFactorEmbedding
from models.m0512_fm.action_expert import ActionExpert,pad_or_trunc_inputs
from models.m0512_fm.action_transform import ActionTransform
from models.m0512_fm.vla_lerobot_dual_velocity import DualVelocityActionExpert
from test_lerobot_dual import synthetic_batch
from test_lerobot_original import local_qwen


@pytest.fixture(autouse=True)
def threads():
    torch.set_num_threads(2)


def factor_batch():
    data,features=synthetic_batch(horizon=32)
    data._aux_data['speed_factor']=torch.tensor([.8,2.])
    return data,features


def actor():
    return DualVelocityActionExpert(32,64,1,2,inference_timesteps=2,velocity_dropout=0.)


def test_strict_labels_and_distinct_condition_vectors():
    encoded=SpeedFactorEmbedding(32)(factor_tensor(FACTORS,4,'cpu'))
    assert all(not torch.allclose(encoded[i],encoded[j]) for i in range(4) for j in range(i))
    for value in (None,.3,3.,float('nan'),[.8,1.,2.]):
        with pytest.raises(ValueError): factor_tensor(value,2,'cpu')


@pytest.mark.parametrize('repeats',[1,3])
def test_factor_film_both_arms_gradients_and_conditioned_generation(repeats):
    torch.manual_seed(11)
    model=actor()
    torch.nn.init.normal_(model.dp_head.act_head.weight,std=.01)
    data,features=factor_batch()
    observed=[]
    hook=model.dp_head.velocity_enc.register_forward_pre_hook(lambda m,args:observed.append(args[0].clone()))
    arms=[]
    def capture(m,args,out):
        out.retain_grad(); arms.append(out)
    ah=model.dp_head.action_enc.register_forward_hook(capture)
    optimizer=torch.optim.AdamW(model.parameters(),lr=.003)
    # FiLM modulation weights start at zero, as in the original model. Gradients
    # reach its input embedding after the first modulation update.
    for _ in range(3):
        optimizer.zero_grad(set_to_none=True)
        loss,metrics=model(data,features,False,False,n_repeats=repeats)
        loss.backward()
        optimizer.step()
    assert torch.isfinite(loss) and 'velocity_loss' not in metrics
    torch.testing.assert_close(observed[-1],torch.tensor([.8,2.]*repeats))
    assert sum(p.grad.abs().sum() for p in model.dp_head.velocity_enc.parameters())>0
    assert (arms[-1].grad.abs().sum(dim=(0,2,3))>0).all()
    assert data.action.shape[-1]==73 and data.action_mask[...,3:9].all()
    hook.remove(); ah.remove()
    model.eval()
    noise=torch.randn(2,2,32,80)
    with torch.no_grad():
        outputs=[model(data,features,True,False,speed_factor=f,initial_noise=noise) for f in FACTORS]
    assert outputs[0].shape==(2,2,32,80)
    assert all(torch.isfinite(o).all() for o in outputs)
    assert all(not torch.allclose(outputs[i],outputs[j]) for i in range(4) for j in range(i))


def test_cached_and_full_attention_equal_and_zero_condition_matches_original():
    torch.manual_seed(6)
    base=ActionExpert(32,64,1,2,inference_timesteps=2).eval()
    torch.nn.init.normal_(base.dp_head.act_head.weight,std=.01)
    model=actor().eval()
    missing,unexpected=model.load_state_dict(base.state_dict(),strict=False)
    assert not unexpected and all(k.startswith('dp_head.velocity_enc.') for k in missing)
    data,features=factor_batch(); data=pad_or_trunc_inputs(data)
    fixed=dict(denoise_timestep=torch.tensor([.2,.7]),trajectory=torch.randn_like(data.action),
               history=ActionTransform.weT_to_ceT(data.action_ref_pose,data.state),latest_s=data.state[:,:,-1],
               action_ref_pose=data.action_ref_pose,fp16=False)
    with torch.no_grad():
        old=base.dp_head.forward_vla(**fixed,context_outputs=base.context_encoder(data,features))
        context=model.context_encoder(data,features)
        zero=model.dp_head.forward_vla(**fixed,context_outputs=context,speed_feature=torch.zeros(2,64))
        condition=model.dp_head.velocity_enc(torch.tensor([.8,2.]))
        full=model.dp_head.forward_vla(**fixed,context_outputs=context,speed_feature=condition)
        cache=model.dp_head.forward_vl(context,False)
        cached=model.dp_head.forward_a(**fixed,context_outputs=context,kv_caches=cache,speed_feature=condition)
    torch.testing.assert_close(old,zero,rtol=1e-5,atol=1e-6)
    torch.testing.assert_close(full,cached,rtol=1e-5,atol=1e-6)


def tiny_full_model(monkeypatch):
    from models.m0512_fm import vla_lerobot_dual_velocity as module
    from data_utils.tokenize import ModalityType
    monkeypatch.setitem(module.MODEL_SIZES,'tiny_factor_test',(64,1,1))
    model=module.LeRobotDualVelocityVLA(model='tiny_factor_test',velocity_dropout=0.,inference_timesteps=2)
    torch.nn.init.normal_(model.actor.dp_head.act_head.weight,std=.01)
    data,_=synthetic_batch(idim=64,horizon=32)
    ids=torch.tensor([[62,60,60,63]*3+[1,2]]).repeat(2,1)
    data.tokenized_vl=dict(input_ids=ids,attention_mask=torch.ones_like(ids),
                         pixel_values=torch.randn(48,3*2*16*16),image_grid_thw=torch.tensor([[1,2,4]]).repeat(6,1))
    data.modality=torch.where(ids==60,ModalityType.VISION,ModalityType.LANGUAGE)
    data._aux_data={'speed_factor':torch.tensor([.8,2.])}
    return model,data


def test_full_qwen_gradients_and_external_token_leaves_base_output_identical(local_qwen,monkeypatch):
    from rl_factor_sac.foundation import FrozenFoundation,state_features,action_targets,decode_prediction
    from rl_factor_sac.token import TokenConfig
    model,data=tiny_full_model(monkeypatch)
    assert model.vlm.full_qwen_features and all(p.requires_grad for p in model.vlm.parameters())
    loss,_=model(data.deepcopy(),False,fp16=True)
    loss.backward()
    assert any(p.grad is not None and p.grad.abs().sum()>0 for p in model.vlm.parameters())
    model.zero_grad(set_to_none=True)
    foundation=FrozenFoundation(model,TokenConfig(memory_dim=64,token_dim=16,hidden_dim=32,heads=4,layers=1))
    prepared=foundation.encode(data)
    context=model.actor.context_encoder(pad_or_trunc_inputs(prepared.batch.deepcopy()),prepared.vl_outputs)
    torch.testing.assert_close(prepared.memory,context['vl_highways'][-2])
    assert (prepared.geometry[:,:,1:5].sum(1)>0).all()
    assert state_features(prepared.batch)[0,10]==.5
    token_loss,_=foundation.token.loss(prepared.memory,prepared.geometry,prepared.valid,
        state_features(prepared.batch),data._aux_data['speed_factor'],action_targets(prepared.batch,8))
    token_loss.backward()
    assert all(p.grad is None for p in model.parameters())
    assert foundation.token.query.grad.abs().sum()>0
    noise=torch.randn(2,2,32,80)
    with torch.no_grad():
        direct=decode_prediction(model(data.deepcopy(),True,fp16=False,speed_factor=1.5,initial_noise=noise))
        cached=foundation.predict(prepared,1.5,noise)
    torch.testing.assert_close(direct,cached)


def test_full_factor_checkpoint_roundtrip_and_original_format_rejected(tmp_path):
    from models.m0512_fm.factor_checkpoint import save_full_checkpoint,read_full_checkpoint,FORMAT
    from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityConfig
    from models.m0512_fm.train_lerobot_dual_velocity import parser
    args=parser().parse_args([])
    assert args.train_qwen and args.nproc_per_node==4 and args.max_steps==100000
    assert args.batch_size*args.gradient_accumulation_steps*4==32
    model=actor(); opt=torch.optim.AdamW(model.parameters()); sched=torch.optim.lr_scheduler.LambdaLR(opt,lambda _:1.)
    cfg=LeRobotRetimedVelocityConfig('unused')
    path=tmp_path/'step1'
    save_full_checkpoint(path,model,[opt],[sched],1,SimpleNamespace(epoch=0,batch_in_epoch=1),cfg,{}, {},'test')
    saved,local=read_full_checkpoint(path,cfg,{}, {},'test')
    assert saved['format']==FORMAT and local['rank']==0
    assert set(p.name for p in path.iterdir())=={'model.pt','rank_00000.pt','complete.json'}
    import json
    marker=json.loads((path/'complete.json').read_text());marker['format']='lerobot_original_full_v2'
    (path/'complete.json').write_text(json.dumps(marker))
    with pytest.raises(ValueError,match='format'):
        read_full_checkpoint(path,cfg,{}, {},'test')
