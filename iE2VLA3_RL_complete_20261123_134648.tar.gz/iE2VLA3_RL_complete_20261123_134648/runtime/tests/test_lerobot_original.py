"""Original architecture, calibrated data flow and checkpoint regressions."""

from dataclasses import replace
from types import SimpleNamespace
import copy
import json

import pytest
import torch

from data_utils.tokenize import ModalityType
from dataset.lerobot_original import LeRobotOriginalConfig, LeRobotOriginalDataset, LeRobotOriginalCollator
from models.m0512_fm import vla as original
from models.m0512_fm.action_expert import ActionExpert, ContextEncoder, MaskedMLP
from models.m0512_fm.layers.pe import cRoPE
from models.m0512_fm.train_lerobot_dual import check_resume, save_checkpoint, restore_rng, parser
from models.m0512_fm.train_lerobot_dual import build_model
from test_lerobot_dual import dataset, synthetic_batch


@pytest.fixture(autouse=True)
def cpu_threads():
    torch.set_num_threads(2)


def transform(x=0., y=0., z=0.):
    value = torch.eye(4)
    value[:3, 3] = torch.tensor([x, y, z])
    return value.tolist()


def calibrated_config(config):
    keys = config.camera_keys
    cameras = {key: dict(K=[[100., 0., 63.5], [0., 100., 31.5], [0., 0., 1.]],
                         image_size=[64, 128], parent=parent, pose=transform(z=.2))
               for key, parent in zip(keys, ["world", "left_flange", "right_tcp"])}
    return LeRobotOriginalConfig(**config.to_dict(), geometry=dict(
        cameras=cameras, action_reference_cameras=[keys[1], keys[2]]))


def test_geometry_common_frame_moving_wrist_intrinsics_and_original_tokenizer(dataset, monkeypatch):
    config = calibrated_config(dataset.config)
    config.base_to_world = [transform(x=1.), transform(y=2.)]
    config.pose_to_tcp = [transform(z=.1), transform(z=.15)]
    reader = LeRobotOriginalDataset(config)
    try:
        reader.require_geometry()
        first, second = reader[0], reader[1]
        torch.testing.assert_close(first.state[:, -1, :3], torch.tensor([[1., 0., .1], [.1, 2., .15]]))
        torch.testing.assert_close(first.raw_vl.pose[1][0, :3, 3], torch.tensor([1., 0., .2]))
        torch.testing.assert_close(first.raw_vl.pose[2][0, :3, 3], torch.tensor([.1, 2., .35]))
        torch.testing.assert_close(second.raw_vl.pose[1][0, :3, 3], torch.tensor([1.01, 0., .2]))
        torch.testing.assert_close(first.action_ref_pose[0], first.raw_vl.pose[1][0])
        torch.testing.assert_close(first.action_ref_pose[1], first.raw_vl.pose[2][0])
        expected_k = torch.tensor([[50., 0., 31.5], [0., 50., 15.5], [0., 0., 1.]])
        torch.testing.assert_close(first.raw_vl.K, expected_k.repeat(3, 1, 1))
        # Inspect what the adapter passes to the unchanged tokenizer/collator.
        import dataset.lerobot_original as module
        captured = []
        monkeypatch.setattr(module, "tokenize_raw_vla", lambda sample, processor: captured.append(sample) or sample)
        monkeypatch.setattr(module, "collate_fn", lambda samples, return_dict: samples)
        result = LeRobotOriginalCollator(None)([first])
        assert result[0] is captured[0]
        assert first.raw_vl.prompt == "close the box"  # no mutation on repeated reads
        assert captured[0].raw_vl.prompt.startswith("Your task is to:")
        torch.testing.assert_close(captured[0].action_ref_pose, first.action_ref_pose)
    finally:
        reader.close()


def test_missing_geometry_is_not_silently_used_for_training(dataset):
    reader = LeRobotOriginalDataset(LeRobotOriginalConfig(**dataset.config.to_dict()))
    try:
        sample = reader[0]  # numeric/video diagnostics remain usable
        assert sample.action.shape == (2, 3, 73)
        with pytest.raises(ValueError, match="cRoPE"):
            reader.require_geometry()
        with pytest.raises(ValueError, match="calibrated"):
            LeRobotOriginalCollator(None)([sample])
    finally:
        reader.close()


def test_geometry_validation_and_explicit_base_mapping(dataset, tmp_path):
    config = calibrated_config(dataset.config)
    config.validate()
    bad = copy.deepcopy(config)
    bad.geometry["cameras"][config.camera_keys[0]]["pose"][0][0] = 2.
    with pytest.raises(ValueError, match="SE\\(3\\)"):
        bad.validate()
    values = config.to_dict()
    values.pop("base_to_world")
    path = tmp_path / "bad_config.json"
    path.write_text(json.dumps(values))
    with pytest.raises(ValueError, match="explicitly"):
        LeRobotOriginalConfig.load(path)
    path.write_text(json.dumps(dataset.config.to_dict()))
    calibration = tmp_path / "calibration.json"
    calibration.write_text(json.dumps(dict(base_to_world=config.base_to_world, geometry=config.geometry)))
    loaded = LeRobotOriginalConfig.load(path, geometry_config=calibration)
    assert loaded.geometry == config.geometry and loaded.root == dataset.config.root


@pytest.fixture
def local_qwen(monkeypatch):
    from transformers import Qwen3VLConfig, Qwen3VLForConditionalGeneration, Qwen3VLProcessor

    def load(*args, **kwargs):
        config = Qwen3VLConfig(
            text_config=dict(vocab_size=64, hidden_size=64, intermediate_size=128, num_hidden_layers=2,
                             num_attention_heads=1, num_key_value_heads=1, head_dim=64,
                             rope_scaling={"rope_type": "default", "mrope_section": [12, 10, 10]}),
            vision_config=dict(depth=2, hidden_size=64, intermediate_size=128, num_heads=1,
                               out_hidden_size=64, deepstack_visual_indexes=[0, 1]),
            image_token_id=60, video_token_id=61, vision_start_token_id=62, vision_end_token_id=63)
        config._attn_implementation = "sdpa"
        return Qwen3VLForConditionalGeneration(config).to(torch.bfloat16)

    monkeypatch.setattr(Qwen3VLForConditionalGeneration, "from_pretrained", load)
    monkeypatch.setattr(Qwen3VLProcessor, "from_pretrained",
                        lambda *a, **k: SimpleNamespace(tokenizer=object()))


@pytest.mark.parametrize("size", ["base", "large", "huge"])
def test_exact_original_model_types_parameters_and_trainable_flags(local_qwen, size):
    # Meta tensors cover the actual production-size modules without allocating GBs.
    with torch.device("meta"):
        restored = build_model(size, train_qwen=False)
        reference = getattr(original, "vla_" + size)()
    assert type(restored) is original.VLA
    assert type(restored.actor) is ActionExpert
    assert type(restored.actor.context_encoder) is ContextEncoder
    assert type(restored.actor.dp_head.state_enc) is MaskedMLP
    assert type(restored.actor.dp_head.action_enc) is MaskedMLP
    assert type(restored.vlm) is original.QwenVL3Extractor
    assert type(restored.vlm._qwen.visual.patch_embed.proj) is torch.nn.Conv3d
    assert restored.forward.__func__ is original.VLA.forward
    assert restored.train.__func__ is torch.nn.Module.train
    assert [(n, type(m)) for n, m in restored.named_modules()] == [(n, type(m)) for n, m in reference.named_modules()]
    assert [(n, p.shape, p.requires_grad) for n, p in restored.named_parameters()] == [
        (n, p.shape, p.requires_grad) for n, p in reference.named_parameters()]
    assert list(restored.state_dict()) == list(reference.state_dict())
    assert all(p.requires_grad for p in restored.actor.context_encoder.proj_vl[-1].parameters())
    assert not any("arm_embedding" in n or "camera_embedding" in n for n in restored.state_dict())


def test_runtime_layout_preserves_original_weights_output_and_checkpoint(local_qwen):
    from models.m0512_fm.lerobot_runtime import configure_conv3d_layout
    model = original.VLA(64, 1, 1)
    modules = [(name, type(module), id(module)) for name, module in model.named_modules()]
    parameters = [(name, id(p), p.requires_grad, p.dtype) for name, p in model.named_parameters()]
    before = {name: value.clone() for name, value in model.state_dict().items()}
    patch = model.vlm.qwen.visual.patch_embed
    pixels = torch.randn(12, 3 * 2 * 16 * 16)
    expected = patch(pixels)
    result = configure_conv3d_layout(model)
    assert result["conv3d_memory_format"] == "channels_last_3d"
    assert patch.proj.weight.is_contiguous(memory_format=torch.channels_last_3d)
    assert modules == [(name, type(module), id(module)) for name, module in model.named_modules()]
    assert parameters == [(name, id(p), p.requires_grad, p.dtype) for name, p in model.named_parameters()]
    assert all(torch.equal(value, model.state_dict()[name]) for name, value in before.items())
    torch.testing.assert_close(patch(pixels), expected, rtol=1e-5, atol=1e-6)
    assert not configure_conv3d_layout(model)["conv3d_layout_changed"]
    # Loading into an original contiguous model retains the exact same values.
    restored = original.VLA(64, 1, 1)
    restored.load_state_dict(model.state_dict(), strict=True)
    assert all(torch.equal(value, restored.state_dict()[name]) for name, value in before.items())
    configure_conv3d_layout(model, "contiguous")
    assert patch.proj.weight.is_contiguous()
    torch.testing.assert_close(patch(pixels), expected, rtol=1e-5, atol=1e-6)


def test_original_multimodal_forward_backward_two_arms_and_crope(local_qwen):
    torch.manual_seed(42)
    model = original.VLA(64, 1, 1, inference_timesteps=2)
    # The original output head is zero-initialized. Use nonzero test weights to
    # verify gradient flow into BOTH arms' token features in one update.
    torch.nn.init.normal_(model.actor.dp_head.act_head.weight, std=.01)
    action_tokens = []

    def retain_action_features(module, args, output):
        if output.requires_grad:
            output.retain_grad()
            action_tokens.append(output)

    hook = model.actor.dp_head.action_enc.register_forward_hook(retain_action_features)
    data, _ = synthetic_batch(idim=64)
    # Real tiny Qwen vision + language forward, with the original Conv3d module.
    ids = torch.tensor([[62, 60, 60, 63] * 3 + [1, 2]]).repeat(2, 1)
    data.tokenized_vl = dict(input_ids=ids, attention_mask=torch.ones_like(ids),
                             pixel_values=torch.randn(48, 3 * 2 * 16 * 16),
                             image_grid_thw=torch.tensor([[1, 2, 4]]).repeat(6, 1))
    data.modality = torch.where(ids == 60, ModalityType.VISION, ModalityType.LANGUAGE)
    data._aux_data = {}  # original model does not require camera IDs
    data.patch_pose[:, 0, 3] = torch.linspace(0., .2, 12)
    data.action_ref_pose[:, 1, 1, 3] = .3
    # The unchanged original forward pads/mutates its batch; a new call needs
    # a fresh 73-channel batch, exactly as the production loader supplies.
    inference_data = copy.deepcopy(data)
    loss, _ = model(data, inference=False, fp16=True)
    assert torch.isfinite(loss)
    loss.backward()
    assert (action_tokens[0].grad.abs().sum(dim=(0, 2, 3)) > 0).all()
    hook.remove()
    assert model.actor.dp_head.act_head.weight.grad.abs().sum() > 0
    assert all(p.grad is None for p in model.vlm.parameters())
    features = model.vlm.hidden_layer_features(data.tokenized_vl, model.vlm_layer_indices)
    context = model.actor.context_encoder(data, features)
    assert context["vla_pe_hybrid"][0].impl is cRoPE
    assert context["a_pe_hybrid"][0].impl is cRoPE
    with torch.no_grad():
        predicted = model(inference_data, inference=True, fp16=True)
    assert predicted.shape == (2, 2, 3, 80) and torch.isfinite(predicted).all()
    assert not predicted[..., 10:].any()


def test_original_checkpoint_next_update_and_legacy_rejection(tmp_path):
    config = LeRobotOriginalConfig("unused")

    def build():
        actor = ActionExpert(32, 64, 1, 2)
        opt = torch.optim.AdamW(actor.parameters(), lr=.001)
        sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda step: .9 ** step)
        return actor, opt, sched

    def update(actor, opt, sched):
        data, features = synthetic_batch()
        data._aux_data = {}
        opt.zero_grad(set_to_none=True)
        loss, _ = actor(data, features, inference=False, fp16=True)
        loss.backward()
        opt.step()
        sched.step()
        return loss.detach()

    torch.manual_seed(7)
    actor, opt, sched = build()
    update(actor, opt, sched)
    path = tmp_path / "original.pt"
    save_checkpoint(path, SimpleNamespace(actor=actor), opt, sched, 1,
                    SimpleNamespace(epoch=0, batch_in_epoch=1), config, {}, {})
    expected_loss = update(actor, opt, sched)
    expected_weights = copy.deepcopy(actor.state_dict())
    restored, opt2, sched2 = build()
    saved = torch.load(path, weights_only=False)
    assert saved["format"] == "lerobot_original_v1"
    check_resume(saved, config, {}, {})
    restored.load_state_dict(saved["actor"], strict=True)
    opt2.load_state_dict(saved["optimizer"])
    sched2.load_state_dict(saved["scheduler"])
    restore_rng(saved["rng"])
    torch.testing.assert_close(update(restored, opt2, sched2), expected_loss, rtol=0, atol=0)
    for key, value in restored.state_dict().items():
        torch.testing.assert_close(value, expected_weights[key], rtol=0, atol=0)
    with pytest.raises(ValueError, match="incompatible"):
        check_resume(dict(saved, format="lerobot_dual_v1"), config, {}, {})
    with pytest.raises(ValueError, match="conventions"):
        check_resume(saved, replace(config, geometry={}), {}, {})
    assert parser().parse_args([]).output.name == "lerobot_original_full_reviewed"
