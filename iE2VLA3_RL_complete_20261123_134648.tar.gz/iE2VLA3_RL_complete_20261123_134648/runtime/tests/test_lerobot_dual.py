"""Behavior checks for units, time alignment, episode boundaries and both arms.

No network or pretrained weights required. Requires the existing project environment
plus pyarrow and pytest.
"""

from dataclasses import replace
import json
from pathlib import Path
from types import SimpleNamespace

import cv2
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch

from action.parser import ProprioParser
from data_utils.tokenize import BatchDataTokenizedVLA, ModalityType
from dataset.lerobot_dual import LeRobotDualConfig, LeRobotDualDataset, decode_tcp, decode_gripper
from models.m0512_fm.action_transform import ActionTransform
from models.m0512_fm.train_lerobot_dual import (
    EpochBatchSampler, TrainingStream, check_resume, lr_multiplier, rng_state, restore_rng, save_checkpoint,
)
from models.m0512_fm.action_expert import ActionExpert


@pytest.fixture
def dataset(tmp_path):
    cfg = LeRobotDualConfig(str(tmp_path), image_size=[32, 64], num_history_states=2, num_future_actions=3)
    meta = tmp_path / "meta"
    meta.mkdir()
    info = dict(codebase_version="v2.1", fps=30, chunks_size=1000,
                data_path="data/chunk-{episode_chunk:03d}/episode_{episode_index:06d}.parquet",
                video_path="videos/chunk-{episode_chunk:03d}/{video_key}/episode_{episode_index:06d}.mp4",
                features={key: {"dtype": "video"} for key in cfg.camera_keys})
    (meta / "info.json").write_text(json.dumps(info))
    (meta / "episodes.jsonl").write_text('\n'.join(json.dumps(dict(episode_index=i, length=4)) for i in range(2)))
    (meta / "tasks.jsonl").write_text(json.dumps(dict(task_index=0, task="close the box")))
    for ep in range(2):
        pose = np.zeros((4, 12))
        pose[:, 0] = ep * 1000 + np.arange(4) * 10
        pose[:, 6] = ep * 1000 + 100 + np.arange(4) * 10
        commands = pose.copy()
        commands[:, [0, 6]] += 5  # Commands deliberately differ from future observations.
        state = np.zeros((4, 14))
        state[:, 13] = 1886
        action = np.zeros((4, 14))
        action[:, 6] = 1886
        table = pa.table({cfg.state_pose_key: pose.tolist(), cfg.action_pose_key: commands.tolist(),
                          cfg.state_gripper_key: state.tolist(), cfg.action_gripper_key: action.tolist(),
                          "timestamp": (np.arange(4) / 30).tolist(), "frame_index": list(range(4)),
                          "episode_index": [ep] * 4, "task_index": [0] * 4})
        path = tmp_path / info["data_path"].format(episode_chunk=0, episode_index=ep)
        path.parent.mkdir(parents=True, exist_ok=True)
        pq.write_table(table, path)
        for camera, key in enumerate(cfg.camera_keys):
            path = tmp_path / info["video_path"].format(episode_chunk=0, episode_index=ep, video_key=key)
            path.parent.mkdir(parents=True, exist_ok=True)
            writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 30, (64, 32))
            assert writer.isOpened()
            for frame in range(4):
                bgr = np.full((32, 64, 3), 20 + camera * 50 + frame * 10, dtype=np.uint8)
                writer.write(bgr)
            writer.release()
    result = LeRobotDualDataset(cfg)
    yield result
    result.close()


def test_command_alignment_arm_order_and_tail_masks(dataset):
    first = dataset[0]
    assert first.state.shape == (2, 2, 73)
    assert first.action.shape == (2, 3, 73)
    assert not first.state_mask[:, 0].any()
    assert first.state_mask[:, 1, :10].all()
    torch.testing.assert_close(first.state[:, -1, 0], torch.tensor([0., .1]))
    torch.testing.assert_close(first.action[:, 0, 0], torch.tensor([.005, .105]))
    torch.testing.assert_close(first.action[:, 1, 0], torch.tensor([.015, .115]))
    torch.testing.assert_close(first.state[:, -1, 9], torch.tensor([1., 0.]))
    torch.testing.assert_close(first.action[:, 0, 9], torch.tensor([0., 1.]))
    assert not first.action_mask[..., 10:].any()
    assert first.raw_vl.prompt == "close the box"
    assert all(x.shape == (1, 3, 32, 64) and x.dtype == torch.uint8 for x in first.raw_vl.rgb)
    assert first.raw_vl.rgb[2].float().mean() > first.raw_vl.rgb[0].float().mean() + 80
    last = dataset[3]
    assert last.action_mask[:, 0, :10].all()
    assert not last.action_mask[:, 1:].any()
    torch.testing.assert_close(last.action[:, :, 0], torch.tensor([[.035] * 3, [.135] * 3]))
    torch.testing.assert_close(dataset[4].state[:, -1, 0], torch.tensor([1., 1.1]))
    with pytest.raises(IndexError):
        dataset[len(dataset)]


def collate_states(samples):
    return {"state": torch.stack([sample.state for sample in samples])}


def test_workers_read_real_files_and_stop_mid_epoch(dataset):
    stream = TrainingStream(dataset, collate_states, batch_size=2, workers=2, seed=42)
    try:
        batch = stream.next()
        workers = list(stream.iterator._workers)
        expected_indices = next(iter(EpochBatchSampler(len(dataset), 2, 42, 0)))
        expected = collate_states([dataset[index] for index in expected_indices])
        torch.testing.assert_close(batch["state"], expected["state"])
    finally:
        stream.close()
    assert all(not worker.is_alive() for worker in workers)


def test_stride_offset_and_no_cross_episode(dataset):
    changed = LeRobotDualDataset(replace(dataset.config, action_offset=1, frame_stride=2))
    try:
        assert len(changed) == 6
        item = changed[0]
        torch.testing.assert_close(item.action[0, :2, 0], torch.tensor([.015, .035]))
        assert not item.action_mask[:, 2].any()
        assert changed[2].action_mask[0].any(-1).tolist() == [True, False, False]
        assert changed[3].state[0, -1, 0] == 1.
    finally:
        changed.close()


def test_mm_degrees_and_tool_offset():
    tool = np.repeat(np.eye(4)[None], 2, axis=0)
    tool[:, :3, 3] = [0, 0, .23]
    cfg = LeRobotDualConfig("unused", pose_to_tcp=tool.tolist())
    # Left Rx=90: tool +Z becomes base -Y. Right Rz=90: +X becomes +Y.
    raw = [[1000, 2000, 3000, 90, 0, 0, 100, 200, 300, 0, 0, 90]]
    poses = decode_tcp(raw, cfg)
    np.testing.assert_allclose(poses[0, 0, :3, 3], [1, 1.77, 3], atol=1e-6)
    np.testing.assert_allclose(poses[0, 1, :3, 3], [.1, .2, .53], atol=1e-6)
    np.testing.assert_allclose(poses[0, 1, :3, :3] @ [1, 0, 0], [0, 1, 0], atol=1e-6)
    np.testing.assert_allclose(decode_gripper([[0] * 6 + [1886] + [0] * 7], cfg), [[0, 1]])
    raw_grippers = np.zeros((3, 14))
    raw_grippers[:, [6, 13]] = [[0, 1886], [943, 943], [1886, 0]]
    np.testing.assert_array_equal(decode_gripper(raw_grippers, cfg), [[1, 0], [.5, .5], [0, 1]])
    with pytest.raises(ValueError, match="endpoints"):
        decode_gripper([[0] * 6 + [5000] + [0] * 7], cfg)


def test_relative_action_round_trip(dataset):
    item = dataset[1]
    relative, mask = ActionTransform.weT_to_ccT(item.action_ref_pose, item.state[:, -1],
                                              item.action, item.action_mask)
    absolute, _ = ActionTransform.ccT_to_weT(item.action_ref_pose, item.state[:, -1], relative, mask)
    torch.testing.assert_close(absolute[..., :10], item.action[..., :10])
    np.testing.assert_allclose(ProprioParser(item.state).posemat[..., :3, :3], np.broadcast_to(np.eye(3), (2, 2, 3, 3)))


def synthetic_batch(batch=2, horizon=3, layers=2, idim=32):
    vision_tokens, length = 6, 10
    modality = torch.full((batch, length), ModalityType.LANGUAGE)
    modality[:, :vision_tokens] = ModalityType.VISION
    state = torch.zeros(batch, 2, 1, 73)
    state[..., 3] = 1
    state[..., 7] = 1
    state[:, 1, :, 0] = .5
    action = state.expand(batch, 2, horizon, 73).clone()
    action[..., 0] += .01
    mask = torch.zeros_like(state, dtype=torch.bool)
    mask[..., :10] = True
    data = BatchDataTokenizedVLA(
        raw_vl=[None] * batch, tokenized_vl={}, modality=modality,
        patch_pose=torch.eye(4).repeat(batch * vision_tokens, 1, 1),
        patch_norm_xy=torch.rand(batch * vision_tokens, 2),
        state=state, state_mask=mask, action=action, action_mask=mask.expand_as(action).clone(),
        action_ref_pose=torch.eye(4).repeat(batch, 2, 1, 1),
        _aux_data={})
    features = dict(inputs_embeds=torch.randn(batch, length, idim),
                    hidden_states=[torch.randn(batch, length, idim) for _ in range(layers)],
                    position_ids=torch.zeros(3, batch, length, dtype=torch.long))
    return data, features


def test_resume_sample_order_conventions_and_rng():
    full = list(EpochBatchSampler(23, 4, seed=42, epoch=1))
    remaining = list(EpochBatchSampler(23, 4, seed=42, epoch=1, start_batch=2))
    assert remaining == full[2:]
    assert full != list(EpochBatchSampler(23, 4, seed=42, epoch=2))
    cfg = LeRobotDualConfig("first")
    checkpoint = dict(format="lerobot_original_v1", data_config=cfg.to_dict(), model_config={}, train_config={})
    check_resume(checkpoint, replace(cfg, root="moved"), {}, {})
    with pytest.raises(ValueError, match="conventions"):
        check_resume(checkpoint, replace(cfg, gripper_open=[1, 1]), {}, {})
    with pytest.raises(ValueError, match="conventions"):
        check_resume(checkpoint, replace(cfg, camera_keys=cfg.camera_keys[::-1]), {}, {})
    state = rng_state()
    expected = torch.randn(10)
    restore_rng(state)
    torch.testing.assert_close(expected, torch.randn(10))
    assert lr_multiplier(0, 10, 100) == .1
    assert lr_multiplier(100, 10, 100) == 0


def test_checkpoint_restores_optimizer_scheduler_and_next_update(tmp_path):
    torch.set_num_threads(2)

    def build():
        actor = ActionExpert(32, 64, 1, 2)
        optimizer = torch.optim.AdamW([p for p in actor.parameters() if p.requires_grad], lr=1e-3)
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda s: lr_multiplier(s, 1, 4))
        return actor, optimizer, scheduler

    def update(actor, optimizer, scheduler):
        optimizer.zero_grad(set_to_none=True)
        data, features = synthetic_batch()
        loss, _ = actor(data, features, inference=False, fp16=True)
        loss.backward()
        optimizer.step()
        scheduler.step()
        return loss.detach()

    torch.manual_seed(42)
    actor, optimizer, scheduler = build()
    update(actor, optimizer, scheduler)
    path = tmp_path / "step_1.pt"
    save_checkpoint(path, SimpleNamespace(actor=actor), optimizer, scheduler, 1,
                    SimpleNamespace(epoch=2, batch_in_epoch=5), LeRobotDualConfig("unused"), {}, {})
    expected_loss = update(actor, optimizer, scheduler)
    expected = {key: value.clone() for key, value in actor.state_dict().items()}
    restored, new_optimizer, new_scheduler = build()
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    restored.load_state_dict(checkpoint["actor"])
    new_optimizer.load_state_dict(checkpoint["optimizer"])
    new_scheduler.load_state_dict(checkpoint["scheduler"])
    restore_rng(checkpoint["rng"])
    resumed_loss = update(restored, new_optimizer, new_scheduler)
    torch.testing.assert_close(resumed_loss, expected_loss, rtol=0, atol=0)
    for key, value in restored.state_dict().items():
        torch.testing.assert_close(value, expected[key], rtol=0, atol=0)
    assert (checkpoint["epoch"], checkpoint["batch_in_epoch"]) == (2, 5)
    assert new_scheduler.get_last_lr() == scheduler.get_last_lr()
