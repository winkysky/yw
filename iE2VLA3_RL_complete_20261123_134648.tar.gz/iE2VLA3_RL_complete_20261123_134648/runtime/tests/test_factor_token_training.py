"""Exercise token CLI, full foundation loading and exact interrupted resume."""
from dataclasses import asdict
import json
import torch
from test_lerobot_original import local_qwen
from test_lerobot_dual_velocity import tiny_full_model


def test_token_training_entrypoint_and_resume(local_qwen,monkeypatch,tmp_path):
    from rl_factor_sac.io import atomic_save
    from rl_factor_sac.token import TokenConfig
    from rl_factor_sac.train_token import main
    from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityConfig
    from models.m0512_fm.factor_checkpoint import FORMAT
    import dataset.lerobot_dual_velocity as dataset_module
    torch.set_num_threads(2)
    model,data=tiny_full_model(monkeypatch)
    cfg=LeRobotRetimedVelocityConfig('synthetic-test-only')
    base=tmp_path/'base';base.mkdir()
    model_config=dict(model='tiny_factor_test',velocity_dropout=0.,inference_timesteps=2,
                      action_horizon=32,train_qwen=True,full_qwen_features=True)
    atomic_save(dict(format=FORMAT,step=1,world_size=1,model_config=model_config,
                     data_config=asdict(cfg),model=model.state_dict()),base/'model.pt')
    (base/'complete.json').write_text(json.dumps(dict(format=FORMAT,step=1,world_size=1)))
    class Episodes:
        def __init__(self,c):
            self.config=c;self.fingerprint='fixed-test-data'
            self.blocks=[dict(episode_key=f'episode{ep}') for ep in range(20) for _ in range(4)]
            self.ends=list(range(1,81))
        def __len__(self):return 80
        def __getitem__(self,i):return i
        def close(self):pass
    class Collator:
        def __init__(self,processor):pass
        def __call__(self,items):
            assert len(items)==2
            return data.deepcopy().__dict__
    monkeypatch.setattr(dataset_module,'LeRobotRetimedVelocityDataset',Episodes)
    monkeypatch.setattr(dataset_module,'LeRobotRetimedVelocityCollator',Collator)
    tc=TokenConfig(memory_dim=64,token_dim=16,hidden_dim=32,layers=1,reconstruction_per_modality=2)
    config=tmp_path/'token.json';config.write_text(json.dumps(asdict(tc)))
    common=['--base',str(base),'--token-config',str(config),'--device','cpu','--batch-size','2',
            '--workers','0','--save-every','1','--validate-every','1','--validation-batches','1','--threads','2',
            '--validation-fraction','.5']
    main(['--steps','3','--output',str(tmp_path/'full'),*common])
    main(['--steps','2','--output',str(tmp_path/'split'),*common])
    main(['--steps','3','--output',str(tmp_path/'split'),
          '--resume',str(tmp_path/'split/token_000002.pt'),*common])
    full=torch.load(tmp_path/'full/token_000003.pt',weights_only=False)
    resumed=torch.load(tmp_path/'split/token_000003.pt',weights_only=False)
    assert full['stream']==resumed['stream'] and full['base_sha256']==resumed['base_sha256']
    for k,v in full['token'].items():torch.testing.assert_close(v,resumed['token'][k],rtol=0,atol=0)
    assert all(p.grad is None for p in model.parameters())
