"""Equal-group DDP batches, exact resume, and unchanged reviewed/raw samples."""
from dataclasses import replace
import json
from pathlib import Path
import pickle
import shutil
import sys
from types import ModuleType

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch

from dataset.balanced_sampler import BalancedGroupBatchSampler
from dataset.lerobot_reviewed import build_dataset, reviewed_handoff
from models.m0512_fm.train_lerobot_dual import TrainingStream
from test_lerobot_dual import dataset
from test_lerobot_original import calibrated_config


@pytest.mark.parametrize("batch_size", [1, 3, 4, 8])
def test_four_ranks_equal_groups_and_exact_resume(batch_size):
    ranges, world = [(0, 101), (101, 598)], 4
    parts = [list(BalancedGroupBatchSampler(ranges, batch_size, 42, 2, rank=r, world_size=world))
             for r in range(world)]
    expected = list(BalancedGroupBatchSampler(ranges, batch_size * world, 42, 2))
    combined = [[i for r in range(world) for i in parts[r][b]] for b in range(len(expected))]
    assert combined == expected
    for b in combined:
        assert sum(i < 101 for i in b) == sum(i >= 101 for i in b) == batch_size * 2
    if batch_size % 2 == 0:
        assert all(sum(i < 101 for i in b) == batch_size // 2 for p in parts for b in p)
    for r in range(world):
        for offset in (0, 2, len(expected) - 1, len(expected)):
            sampler = BalancedGroupBatchSampler(ranges, batch_size, 42, 2,
                                                start_batch=offset, rank=r, world_size=world)
            assert len(sampler) == len(parts[r][offset:])
            assert list(sampler) == parts[r][offset:]
    assert combined != list(BalancedGroupBatchSampler(ranges, batch_size * world, 42, 3))


def test_coverage_oversampling_and_group_internal_uniformity():
    sampler = BalancedGroupBatchSampler([(0, 17), (17, 127)], 4, 42, 0, world_size=4)
    batches = list(BalancedGroupBatchSampler(sampler.group_ranges, 16, 42, 0))
    a = [i for b in batches for i in b if i < 17]
    b = [i for chunk in batches for i in chunk if i >= 17]
    # Fourteen microbatches draw 112 samples/group and cover all 110 B windows.
    assert len(a) == len(b) == 112
    assert set(a) == set(range(17)) and set(b) == set(range(17, 127))
    for values, size in ((a, 17), (b, 110)):
        for start in range(0, len(values) - size + 1, size):
            assert len(set(values[start:start + size])) == size
    counts = np.bincount(a)
    assert counts.max() - counts.min() <= 1
    # Two accumulated microbatches preserve the exact 16 + 16 update batch.
    for i in range(0, len(batches), 2):
        update = batches[i] + batches[i + 1]
        assert sum(x < 17 for x in update) == 16
    sampler.stopped = True
    assert list(sampler) == []


def test_invalid_batch_and_empty_group_fail_early():
    with pytest.raises(ValueError, match="even global"):
        BalancedGroupBatchSampler([(0, 4), (4, 9)], 3, 42, 0)
    for ranges in ([(0, 0), (0, 9)], [(0, 4), (5, 9)]):
        with pytest.raises(ValueError, match="contiguous"):
            BalancedGroupBatchSampler(ranges, 4, 42, 0)
    with pytest.raises(ValueError, match="Resume batch"):
        BalancedGroupBatchSampler([(0, 4), (4, 9)], 4, 42, 0, start_batch=4)


@pytest.fixture
def grouped_config(dataset, tmp_path, monkeypatch):
    import dataset.lerobot_reviewed as reviewed
    # Two reviewed sources use distinct handoffs, and retain their segment prompt.
    root = tmp_path / "mixture"
    root.mkdir()
    raw = tmp_path / "raw_third"
    for name in ("meta", "data", "videos"):
        shutil.copytree(dataset.root / name, raw / name)
    path = raw / "data/chunk-000/episode_000000.parquet"
    pq.write_table(pq.read_table(path).append_column("prompt", pa.array(["frame prompt"] * 4)), path)
    sources = []
    for name in ("first", "second"):
        handoff = tmp_path / name
        (handoff / "filtered_data").mkdir(parents=True)
        (handoff / "task_manifest.json").write_text("{}")
        sources.append(dict(name=name, type="reviewed", root=str(handoff / "filtered_data"), expected_episodes=1))
    def view(root, cfg):
        name = Path(root).parent.name
        segment = dict(dataset_id="same_id", source_root=str(dataset.root), episode_index=0,
                       parquet_path=str(dataset._path("data_path", 0)), segment_id="same_segment_id",
                       frames=np.array([1]) if name == "first" else np.array([1, 2]),
                       instruction=name + " reviewed instruction", split_group="hash")
        return [segment], "fingerprint_" + name
    monkeypatch.setattr(reviewed, "load_reviewed_view", view)
    manifest = dict(format="lerobot_equal_groups_v1", groups=[
        dict(name="A", sources=sources),
        dict(name="B", sources=[dict(name="raw", type="lerobot", root=str(raw), expected_episodes=2)])])
    (root / "dataset_groups.json").write_text(json.dumps(manifest))
    return replace(calibrated_config(dataset.config), root=str(root), num_history_states=1, num_future_actions=2)


def test_grouped_reader_preserves_prompts_masks_geometry_and_source_identity(grouped_config):
    reader = build_dataset(grouped_config)
    try:
        assert len(reader) == 11 and len(reader.episodes) == 4
        assert reader.group_ranges == [(0, 3), (3, 11)]
        assert [g["probability"] for g in reader.sampling_summary["groups"]] == [0.5, 0.5]
        assert reader[0].raw_vl.prompt == "first reviewed instruction"
        assert reader[1].raw_vl.prompt == "second reviewed instruction"
        assert reader[3].raw_vl.prompt == "frame prompt"
        assert reader[7].raw_vl.prompt == "close the box"
        assert reader[0]._review_metadata["frame"] == 1
        for index, source, local in ((0, "first", 0), (1, "second", 0), (3, "raw", 0), (6, "raw", 3)):
            sample, reference = reader[index], reader.readers[source][local]
            for field in ("state", "action", "state_mask", "action_mask", "action_ref_pose"):
                torch.testing.assert_close(getattr(sample, field), getattr(reference, field), rtol=0, atol=0)
            for x, y in zip(sample.raw_vl.rgb, reference.raw_vl.rgb):
                torch.testing.assert_close(x, y, rtol=0, atol=0)
            assert sample._mixture_metadata["source"] == source
        assert reader[6].action_mask[0].any(-1).tolist() == [True, False]
        reader.require_geometry()
        restored = pickle.loads(pickle.dumps(reader))
        try:
            assert restored[1].raw_vl.prompt == "second reviewed instruction"
        finally:
            restored.close()
        for bad in (-1, len(reader)):
            with pytest.raises(IndexError):
                reader[bad]
    finally:
        reader.close()


def collate_identity(samples):
    return [(s._mixture_metadata, s.raw_vl.prompt, s.state.tolist()) for s in samples]


def test_actual_training_stream_spawn_prefetch_resume_and_epoch_boundary(grouped_config):
    reader = build_dataset(grouped_config)
    reference = TrainingStream(reader, collate_identity, batch_size=4, workers=0, seed=42)
    resumed = None
    try:
        expected = [reference.next() for _ in range(reference.batches_per_epoch + 2)]
        assert reference.epoch == 1 and reference.batch_in_epoch == 2
        spawned = TrainingStream(build_dataset(grouped_config), collate_identity, 4, 2, 42)
        try:
            assert spawned.next() == expected[0]
            assert spawned.next() == expected[1]
            epoch, offset = spawned.epoch, spawned.batch_in_epoch
            workers = list(spawned.iterator._workers)
        finally:
            spawned.close()
        assert all(not w.is_alive() for w in workers)
        resumed = TrainingStream(build_dataset(grouped_config), collate_identity, 4, 0, 42,
                                 epoch=epoch, batch_in_epoch=offset)
        assert [resumed.next() for _ in range(len(expected) - 2)] == expected[2:]
        for batch in expected:
            assert sum(s[0]["group"] == "A" for s in batch) == 2
    finally:
        reference.close()
        if resumed:
            resumed.close()


def test_source_count_and_fingerprint_protect_resume(grouped_config):
    reader = build_dataset(grouped_config)
    fingerprint = reader.fingerprint
    reader.close()
    path = Path(grouped_config.root) / "dataset_groups.json"
    manifest = json.loads(path.read_text())
    manifest["groups"][0]["name"] = "new_A"
    path.write_text(json.dumps(manifest))
    changed = build_dataset(grouped_config)
    assert fingerprint != changed.fingerprint
    changed.close()
    source = manifest["groups"][1]["sources"][0]
    source["expected_episodes"] = 694
    path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="expected 694 episodes, found 2"):
        build_dataset(grouped_config)
    source["expected_episodes"] = 2
    source["root"] = manifest["groups"][0]["sources"][0]["root"]
    path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="Duplicate grouped source"):
        build_dataset(grouped_config)


def test_existing_full_checkpoint_round_trip_restores_grouped_stream(grouped_config, tmp_path):
    from models.m0512_fm.lerobot_distributed import (
        save_full_checkpoint, read_full_checkpoint, restore_full_checkpoint,
    )
    reader = build_dataset(grouped_config)
    stream = TrainingStream(reader, collate_identity, 4, 0, 42)
    resumed = None
    try:
        model = torch.nn.Linear(2, 1)
        optimizer = torch.optim.AdamW(model.parameters())
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10)
        model(torch.ones(1, 2)).sum().backward()
        optimizer.step()
        scheduler.step()
        stream.next()
        model_config = dict(model="base", inference_timesteps=4, train_qwen=True)
        train_config = dict(world_size=1, batch_size=4, sampling=reader.sampling_mode)
        path = tmp_path / "step_0000001"
        save_full_checkpoint(path, model, [optimizer], [scheduler], 1, stream,
                             grouped_config, model_config, train_config, reader.fingerprint)
        expected = stream.next()
        saved, local = read_full_checkpoint(path, grouped_config, model_config, train_config, reader.fingerprint)
        assert saved["format"] == "lerobot_original_full_v2"
        assert set(p.name for p in path.iterdir()) == {"model.pt", "complete.json", "rank_00000.pt"}
        restored_model = torch.nn.Linear(2, 1)
        restored_optimizer = torch.optim.AdamW(restored_model.parameters())
        restored_scheduler = torch.optim.lr_scheduler.StepLR(restored_optimizer, step_size=10)
        restore_full_checkpoint(saved, local, restored_model, [restored_optimizer], [restored_scheduler])
        for a, b in zip(model.parameters(), restored_model.parameters()):
            torch.testing.assert_close(a, b, rtol=0, atol=0)
        resumed = TrainingStream(build_dataset(grouped_config), collate_identity, 4, 0, 42,
                                 epoch=saved["epoch"], batch_in_epoch=saved["batch_in_epoch"])
        assert resumed.next() == expected
        with pytest.raises(ValueError, match="snapshot differ"):
            read_full_checkpoint(path, grouped_config, model_config, train_config, "different_data")
    finally:
        stream.close()
        if resumed:
            resumed.close()


def test_each_review_handoff_uses_its_own_runtime_and_restores_imports(tmp_path, monkeypatch):
    old_path = list(sys.path)
    sentinel = ModuleType("data_cleaner")
    monkeypatch.setitem(sys.modules, "data_cleaner", sentinel)
    for name in ("one", "two"):
        handoff = tmp_path / name
        runtime = handoff / "training_runtime/data_cleaner"
        runtime.mkdir(parents=True)
        (runtime / "__init__.py").write_text("")
        (runtime / "value.py").write_text(f"VALUE = {name!r}\n")
        (handoff / "read_training.py").write_text(
            "from pathlib import Path\nimport sys\n"
            "sys.path.insert(0, str(Path(__file__).parent / 'training_runtime'))\n"
            "from data_cleaner.value import VALUE\n")
        with reviewed_handoff(handoff) as module:
            assert module.VALUE == name
        assert sys.modules["data_cleaner"] is sentinel
        assert sys.path == old_path
        assert "data_cleaner.value" not in sys.modules
    with pytest.raises(RuntimeError, match="failed validation"):
        with reviewed_handoff(handoff):
            raise RuntimeError("failed validation")
    assert sys.modules["data_cleaner"] is sentinel and sys.path == old_path
