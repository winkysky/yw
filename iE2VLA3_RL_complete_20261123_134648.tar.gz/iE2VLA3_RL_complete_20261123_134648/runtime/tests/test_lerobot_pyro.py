"""LeRobot live observations must match training geometry and remote contracts."""
import copy

import cv2
import numpy as np
import pyarrow.parquet as pq
import pytest
import torch

from dataset.lerobot_original import LeRobotOriginalDataset
from models.m0512_fm.lerobot_inference import observation_to_sample, world_observation_to_sample, prepare_raw, infer_batch
from test_lerobot_dual import dataset, synthetic_batch
from test_lerobot_original import calibrated_config, transform


@pytest.fixture
def observation_case(dataset):
    cfg = calibrated_config(dataset.config)
    cfg.base_to_world = [transform(x=1.), transform(y=2.)]
    cfg.base_to_world[1][1][1] = cfg.base_to_world[1][2][2] = -1.
    cfg.pose_to_tcp = [transform(z=.1), transform(z=.15)]
    reader = LeRobotOriginalDataset(cfg)
    try:
        expected = reader[1]
        table = pq.read_table(reader._path("data_path", 0)).to_pydict()
        observation = {cfg.state_pose_key: table[cfg.state_pose_key][:2],
                       cfg.state_gripper_key: table[cfg.state_gripper_key][:2],
                       "instruction": expected.raw_vl.prompt,
                       "images": {key: rgb[0].permute(1, 2, 0).numpy().copy()
                                  for key, rgb in zip(cfg.camera_keys, expected.raw_vl.rgb)}}
        yield cfg, observation, expected
    finally:
        reader.close()


def assert_same_observation(actual, expected):
    for key in ["state", "state_mask", "action_mask", "action_ref_pose"]:
        torch.testing.assert_close(getattr(actual, key), getattr(expected, key))
    torch.testing.assert_close(actual.raw_vl.K, expected.raw_vl.K)
    for a, b in zip(actual.raw_vl.pose, expected.raw_vl.pose):
        torch.testing.assert_close(a, b)
    for a, b in zip(actual.raw_vl.rgb, expected.raw_vl.rgb):
        torch.testing.assert_close(a, b)
    assert actual.raw_vl.prompt == expected.raw_vl.prompt
    assert actual._original_geometry_ready and not actual.action.any()


def test_live_recorded_bases_match_training_without_future_targets(observation_case):
    cfg, observation, expected = observation_case
    actual = observation_to_sample(observation, cfg)
    assert_same_observation(actual, expected)
    # Independent nonidentity base/tool expectation; wrong order or double map fails.
    torch.testing.assert_close(actual.state[:, -1, :3], torch.tensor([[1.01, 0, .1], [.11, 2, -.15]]))
    torch.testing.assert_close(actual.state[:, -1, 9], torch.tensor([1., 0.]))
    assert expected.action.any()  # No mutation of dataset GT.


def test_world_tcp_interface_skips_base_and_tool_transforms(observation_case):
    from action.parser import ProprioParser
    cfg, observation, expected = observation_case
    request = dict(instruction=observation["instruction"], images=observation["images"],
                   frame="left_recorded_arm_base",
                   world_tcp=ProprioParser(expected.state).posemat.numpy().swapaxes(0, 1),
                   gripper=expected.state[..., 9].numpy().T)
    assert_same_observation(world_observation_to_sample(request, cfg), expected)
    # ROS wire payload uses built-ins to support NumPy 1.x clients / 2.x hosts.
    wire = dict(request, world_tcp=request["world_tcp"].tolist(), gripper=request["gripper"].tolist(),
                images={key: dict(shape=list(rgb.shape), rgb_bytes=rgb.tobytes())
                        for key, rgb in request["images"].items()})
    assert_same_observation(world_observation_to_sample(wire, cfg), expected)
    wire["images"][cfg.camera_keys[0]]["rgb_bytes"] = b"invalid"
    with pytest.raises(ValueError, match="byte buffer"):
        world_observation_to_sample(wire, cfg)
    request["frame"] = "right_base"
    with pytest.raises(ValueError, match="left_recorded"):
        world_observation_to_sample(request, cfg)
    request["frame"] = "left_recorded_arm_base"
    request["gripper"] = np.full((cfg.num_history_states, 2), 1886.)
    with pytest.raises(ValueError, match="openness"):
        world_observation_to_sample(request, cfg)
    request["gripper"] = np.zeros((cfg.num_history_states, 2))
    request["world_tcp"] = request["world_tcp"].copy()
    request["world_tcp"][0, 1, :3, :3] *= -1
    with pytest.raises(ValueError, match="rigid"):
        world_observation_to_sample(request, cfg)


def test_raw_common_frame_not_transformed_twice_and_geometry_is_rebuilt(observation_case):
    cfg, _, expected = observation_case
    supplied = copy.deepcopy(expected)
    supplied.raw_vl.K.zero_()
    supplied.raw_vl.pose = [torch.zeros_like(pose) for pose in supplied.raw_vl.pose]
    supplied.action_ref_pose.zero_()
    supplied.action.fill_(float("nan"))  # Future target values are never consumed.
    actual = prepare_raw(supplied, cfg)
    assert_same_observation(actual, expected)
    assert torch.isnan(supplied.action).all() and not supplied.raw_vl.K.any()


def test_image_resize_and_camera_order(observation_case):
    cfg, observation, expected = observation_case
    # Reverse insertion order deliberately; camera_keys determines ordering.
    observation["images"] = {key: cv2.resize(rgb, None, fx=2, fy=2, interpolation=cv2.INTER_NEAREST)
                             for key, rgb in reversed(list(observation["images"].items()))}
    assert_same_observation(observation_to_sample(observation, cfg), expected)
    key = cfg.camera_keys[0]
    observation["images"][key] = np.zeros((13, 17, 3), dtype=np.uint8)
    with pytest.raises(ValueError, match="aspect ratio"):
        observation_to_sample(observation, cfg)


@pytest.mark.parametrize("bad", ["camera", "image_dtype", "history", "prompt", "nan", "gripper"])
def test_live_observation_rejects_incompatible_inputs(observation_case, bad):
    cfg, obs, _ = observation_case
    if bad == "camera":
        obs["images"].pop(cfg.camera_keys[0])
    elif bad == "image_dtype":
        obs["images"][cfg.camera_keys[0]] = obs["images"][cfg.camera_keys[0]].astype(float)
    elif bad == "history":
        obs[cfg.state_pose_key] = obs[cfg.state_pose_key][:1]
    elif bad == "prompt":
        obs["instruction"] = " "
    elif bad == "nan":
        obs[cfg.state_pose_key][0][0] = float("nan")
    elif bad == "gripper":
        obs[cfg.state_gripper_key][0][6] = 5000
    with pytest.raises(ValueError):
        observation_to_sample(obs, cfg)


def test_reject_wrong_horizon_and_centered_inputs(observation_case):
    cfg, _, sample = observation_case
    sample.action = sample.action[:, :-1]
    with pytest.raises(ValueError, match="Expected state"):
        prepare_raw(sample, cfg)
    sample.action = torch.zeros(2, cfg.num_future_actions, 73)
    sample._avg_pose = torch.eye(4)
    with pytest.raises(ValueError, match="CenterCamera"):
        prepare_raw(sample, cfg)


@pytest.mark.parametrize("seed", [-1, 2**63, 3.14, True])
def test_invalid_random_seed_rejected_before_model(seed):
    batch, _ = synthetic_batch()
    with pytest.raises(ValueError, match="seed"):
        infer_batch(None, batch, torch.device("cpu"), seed)


def test_remote_interactive_inference_toggle(monkeypatch):
    from types import SimpleNamespace
    from models.m0512_fm import visualize_lerobot as viewer
    predicted = []
    class Dataset:
        segments = [dict(dataset_id="test", episode_index=0)]
        ends = [1]
        fps = 30.
        config = SimpleNamespace(num_future_actions=32, frame_stride=1, action_offset=0, camera_keys=[])
        def __getitem__(self, index):
            return SimpleNamespace(_review_metadata=dict(dataset_id="test", episode_index=0, frame=0),
                                   raw_vl=SimpleNamespace(prompt="test"))
    keys = iter([ord("i"), ord("i"), ord("q")])
    monkeypatch.setattr(viewer, "render_projection", lambda *a: np.zeros((16, 16, 3), dtype=np.uint8))
    monkeypatch.setattr(viewer.cv2, "imshow", lambda *a: None)
    monkeypatch.setattr(viewer.cv2, "waitKeyEx", lambda *a: next(keys))
    monkeypatch.setattr(viewer.cv2, "destroyAllWindows", lambda: None)
    viewer.interactive(Dataset(), None, None, torch.device("cpu"), 42, 0,
                       predictor=lambda sample, seed: predicted.append(seed))
    assert predicted == [42, 42]
