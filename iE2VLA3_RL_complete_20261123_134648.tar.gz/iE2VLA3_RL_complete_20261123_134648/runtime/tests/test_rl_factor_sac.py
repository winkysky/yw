"""CPU checks of actual SAC updates, token bottleneck and execution bookkeeping."""
import copy
from dataclasses import asdict
import json
from types import SimpleNamespace
import numpy as np
import pytest
import torch
from torch import nn
from rl_factor_sac.config import SACConfig
from rl_factor_sac.networks import observation_shapes,FactorActor,ResidualActor
from rl_factor_sac.sac import DualSAC
from rl_factor_sac.replay import ReplayBuffer,IntervalRecorder,validate_batch,save_replay,load_replay
from rl_factor_sac.reward import RewardConfig
from rl_factor_sac.token import RLToken,TokenConfig
from rl_factor_sac.runtime import DualRateController,force_history,CommandLimitError
from rl_factor_sac.online import OnlineSession
from rl_factor_sac.geometry import compose_residual,residual_target


@pytest.fixture(autouse=True)
def cpu_threads():
    torch.set_num_threads(2)


def config():
    return SACConfig(token_dim=16,hidden_dim=32)


def observation(c=None,b=4):
    c=c or config()
    obs={k:torch.zeros(b,*shape) for k,shape in observation_shapes(c).items()}
    obs['token']=torch.randn(b,c.token_dim)
    obs['state']=torch.randn(b,20)*.1
    obs['wrench']=torch.randn(b,c.force_history,2,6)
    obs['reference_mask'].fill_(1)
    obs['execution'][:,0]=1;obs['execution'][:,5]=1
    obs['factor_mask'].fill_(1)
    return obs


def transition(branch,c=None,b=4):
    c=c or config()
    obs=observation(c,b)
    action=torch.ones(b,1,dtype=torch.long) if branch=='factor' else torch.zeros(b,12)
    return dict(obs=obs,next_obs=copy.deepcopy(obs),action=action,reward=torch.rand(b,1),
                discount=torch.full((b,1),c.discount(.5 if branch=='factor' else 1/30)),
                terminated=torch.zeros(b,1),truncated=torch.zeros(b,1))


def bindings():
    return dict(base_sha256='a'*64,token_sha256='b'*64,reward_config=asdict(RewardConfig()))


def test_discrete_mask_and_continuous_transformed_log_density():
    c=config();obs=observation(c)
    obs['factor_mask'][:]=torch.tensor([1.,0,1,0])
    actor=FactorActor(c)
    p,logp=actor.distribution(obs)
    assert torch.isfinite(p*logp).all() and not p[:,[1,3]].any()
    assert set(actor.act(obs).flatten().tolist())<={0,2}
    obs['previous_residual'][1]=.98;obs['previous_residual'][2]=-.98
    continuous=ResidualActor(c)
    action,actual,_,log_half=continuous.sample(obs)
    center,half=continuous.bounds(obs)
    unit=(action-center)/half
    raw=torch.atanh(unit)
    expected=(torch.distributions.Normal(torch.zeros_like(raw),torch.full_like(raw,np.exp(-2))).log_prob(raw)
              -torch.log1p(-unit.square())-half.log()).sum(-1,keepdim=True)
    torch.testing.assert_close(actual,expected,atol=3e-5,rtol=1e-5)
    assert (action.abs()<=1).all() and ((action-obs['previous_residual']).abs()<=.200001).all()
    torch.testing.assert_close(log_half,half.log().sum(-1,keepdim=True))


def test_discrete_target_exact_expectation_terminal_and_truncation():
    sac=DualSAC(config());branch=sac.factor
    class Policy(nn.Module):
        def distribution(self,obs):
            p=torch.tensor([[.1,.2,.3,.4]]).expand(len(obs['token']),-1)
            return p,p.log()
    class Critic(nn.Module):
        def forward(self,obs):
            q=torch.tensor([[1.,2.,3.,4.]]).expand(len(obs['token']),-1)
            return q,q+1
    branch.actor=Policy();branch.target=Critic()
    data=transition('factor',b=3)
    data['reward'].fill_(2);data['discount'].fill_(.5)
    data['terminated'][0]=1;data['truncated'][1]=1
    actual=branch.target_value(data)
    p,lp=branch.actor.distribution(data['next_obs'])
    expected=2+.5*(p[0]*(torch.arange(1,5)-branch.temperature*lp[0])).sum()
    assert actual[0]==2
    torch.testing.assert_close(actual[1],expected.reshape(1))
    torch.testing.assert_close(actual[2],actual[1])


def test_both_sac_branches_update_and_resume_next_update_exactly(tmp_path):
    torch.manual_seed(50)
    sac=DualSAC(config())
    data={k+'_batch':transition(k) for k in ('factor','residual')}
    snapshot=sac.actor_snapshot()
    original={k:copy.deepcopy(getattr(sac,k).state_dict()) for k in ('factor','residual')}
    for _ in range(2): metrics=sac.update(**data)
    for k in ('factor','residual'):
        now=getattr(sac,k)
        assert now.updates==2 and np.isfinite(list(metrics[k].values())).all()
        assert any(not torch.equal(v,original[k]['actor'][n]) for n,v in now.actor.state_dict().items())
        assert any(not torch.equal(v,original[k]['critic'][n]) for n,v in now.critic.state_dict().items())
        assert now.log_temperature!=original[k]['log_temperature']
        for n,v in snapshot[k].state_dict().items(): torch.testing.assert_close(v,original[k]['actor'][n])
    path=tmp_path/'sac.pt';sac.save(path,bindings())
    expected=sac.update(**data)
    loaded=DualSAC.load(path,bindings=bindings(),restore_rng=True)
    actual=loaded.update(**data)
    assert actual==expected
    for k in ('factor','residual'):
        for n,v in getattr(sac,k).actor.state_dict().items():
            torch.testing.assert_close(v,getattr(loaded,k).actor.state_dict()[n],rtol=0,atol=0)
    with pytest.raises(ValueError,match='mismatch'):
        DualSAC.load(path,bindings=dict(bindings(),token_sha256='c'*64))


def test_real_time_intervals_and_replay_versions(tmp_path):
    c=config();obs=observation(c,1)
    recorder=IntervalRecorder(c,obs,torch.ones(1,1,dtype=torch.long),10.,dict(factor=0,residual=0))
    recorder.activate(10.2)
    recorder.tick(1.,10.1);recorder.tick(2.,10.5)
    row=recorder.finish(obs,truncated=True)
    assert float(row['reward'])==pytest.approx(1+c.gamma_per_second**.1*2)
    assert float(row['discount'])==pytest.approx(c.gamma_per_second**.5)
    assert recorder.activation_delay==pytest.approx(.2)
    buffers={k:ReplayBuffer(c,k) for k in ('factor','residual')}
    buffers['factor'].add(row,versions=dict(factor=0,residual=0),timestamp=10,source='simulator')
    buffers['residual'].add(transition('residual',c,1),versions=dict(factor=0,residual=0),timestamp=10,source='simulator')
    with pytest.raises(ValueError,match='No eligible'):
        buffers['factor'].sample(1,versions=dict(factor=0,residual=2),max_policy_lag=1)
    path=tmp_path/'replay.pt';save_replay(path,buffers,bindings())
    assert all(len(b)==1 for b in load_replay(path,c,bindings()).values())
    bad=transition('residual',c,1);bad['next_obs']['reference_mask'].zero_()
    bad['truncated'].fill_(1)
    with pytest.raises(ValueError,match='bootstrap'): validate_batch(bad,c,'residual')
    bad['truncated'].zero_();bad['terminated'].fill_(1)
    validate_batch(bad,c,'residual')


def test_token_bottleneck_learns_without_target_feature_or_base_gradient_leak():
    torch.manual_seed(9)
    c=TokenConfig(memory_dim=16,token_dim=16,hidden_dim=32,layers=1,heads=4,reconstruction_per_modality=2)
    token=RLToken(c)
    # Each observation has a different scene vector. Geometry is identical across
    # observations, so a geometry-only decoder cannot solve this task.
    memory=torch.randn(8,1,16).repeat(1,8,1).requires_grad_()
    geometry=torch.zeros(8,8,19)
    for i in range(8): geometry[:,i,1+i%4]=1;geometry[:,i,0]=i/8
    valid=torch.ones(8,8,dtype=torch.bool)
    state=torch.zeros(8,20);factor=torch.ones(8);actions=torch.randn(8,8,20)
    optimizer=torch.optim.Adam(token.parameters(),lr=.003)
    initial=token.diagnostics(memory,geometry,valid)['normal']
    for _ in range(45):
        optimizer.zero_grad(set_to_none=True)
        loss,_=token.loss(memory,geometry,valid,state,factor,actions)
        loss.backward();optimizer.step()
    final=token.diagnostics(memory,geometry,valid)
    assert memory.grad is None and token.query.grad.abs().sum()>0
    assert final['normal']<initial*.6
    assert final['normal']<final['zero'] and final['normal']<final['shuffled']
    # Masked target changes cannot alter the token.
    valid[:,-1]=False
    before=token.encode(memory,geometry,valid)
    changed=memory.detach().clone();changed[:,-1]=10000
    torch.testing.assert_close(before,token.encode(changed,geometry,valid))


class FakeFoundation:
    """Static-reference simulator fixture; no real VLA or hardware claim."""
    def __init__(self,c):
        self.base=nn.Linear(1,1)
        self.token=SimpleNamespace(config=SimpleNamespace(token_dim=c.token_dim))
    def freeze_online(self):
        return self
    def predict(self,prepared,speed_factor,initial_noise=None,fp16=False):
        output=torch.zeros(1,32,2,17)
        output[...,:16]=torch.eye(4).flatten()
        return output


def runtime():
    c=config();learner=DualSAC(c)
    return DualRateController(FakeFoundation(c),learner),learner


def test_causal_force_history_and_tcp_local_residual_geometry():
    c=config();times=np.arange(40)/30;values=np.zeros((40,2,6));values[31:]=999
    history=force_history(times,values,1.,c)
    assert not history.any()
    with pytest.raises(ValueError,match='stale'):
        force_history(times[:20],values[:20],1.,c)
    reference=torch.eye(4).repeat(1,2,1,1)
    reference[...,:3,:3]=torch.tensor([[0.,-1,0],[1,0,0],[0,0,1]])
    a=torch.zeros(1,12);a[:,0]=.1;a[:,5]=.2
    target=compose_residual(reference,a,c)
    assert target[0,0,1,3]==pytest.approx(.0005)
    recovered,valid=residual_target(reference,target,c)
    assert valid.all();torch.testing.assert_close(recovered,a,atol=1e-6,rtol=1e-5)


def test_async_old_reference_snapshot_expiry_and_acknowledgement():
    controller,learner=runtime()
    pose=np.broadcast_to(np.eye(4),(2,4,4)).copy();grip=np.zeros(2);wrench=np.zeros((8,2,6))
    prepared=SimpleNamespace(token=torch.ones(1,16))
    with pytest.raises(ValueError,match='anchor'):
        controller.begin_plan(prepared,float('nan'),pose,grip,wrench,0.,factor_index=1)
    assert controller.token is None and controller.pending is None
    first=controller.begin_plan(prepared,0.,pose,grip,wrench,0.,factor_index=1)
    with pytest.raises(ValueError,match='finite'):
        controller.accept_plan(first,controller.generate(first),float('nan'))
    assert controller.pending is first and controller.active is None
    controller.accept_plan(first,controller.generate(first),.1)
    proposal=controller.propose_control(pose,grip,wrench,.1,True)
    assert controller.previous_command is None
    controller.acknowledge(proposal)
    with pytest.raises(ValueError,match='Stale'):controller.acknowledge(proposal)
    second=controller.begin_plan(prepared,.5,pose,grip,wrench,.5,factor_index=3)
    old=controller.propose_control(pose,grip,wrench,.5,True)
    assert old['request_id']==first.request_id
    assert old['observation']['execution'][0,1]==2
    controller.accept_plan(second,controller.generate(second),.7)
    assert controller.active[0].anchor==.5
    newer=controller.propose_control(pose,grip,wrench,.7,True)
    assert newer['request_id']==second.request_id
    controller.reset()
    with pytest.raises(ValueError,match='Stale'):controller.accept_plan(second,controller.generate(second),.8)
    third=controller.begin_plan(prepared,1.,pose,grip,wrench,1.,factor_index=0)
    with pytest.raises(ValueError,match='expired'):controller.accept_plan(third,controller.generate(third),2.1)
    assert controller.pending is None


def test_collector_simulated_feedback_updates_both_and_rejects_unexecuted_actions(tmp_path):
    controller,learner=runtime()
    session=OnlineSession(learner,source='simulator')
    pose=np.broadcast_to(np.eye(4),(2,4,4)).copy();grip=np.zeros(2);wrench=np.zeros((8,2,6))
    prepared=SimpleNamespace(token=torch.zeros(1,16))
    plan=controller.begin_plan(prepared,0.,pose,grip,wrench,0.,factor_index=1)
    session.on_factor_decision(plan)
    controller.accept_plan(plan,controller.generate(plan),0.);session.on_factor_effective(plan,0.)
    previous=np.zeros(12)
    for step in range(16):
        now=step/30
        proposal=controller.propose_control(pose,grip,wrench,now,True)
        controller.acknowledge(proposal);session.on_command_accepted(proposal)
        following=controller.observation(pose,grip,wrench,(step+1)/30)
        actual=proposal['action'].numpy()[0]
        if step==0:
            with pytest.raises(ValueError,match='Actual residual'):
                session.observe_tick(following,1/30,wrench[-1],np.ones(12),previous)
        session.observe_tick(following,(step+1)/30,wrench[-1],actual,previous,
                             outcome='success' if step==15 else None)
        previous=actual
    assert len(session.buffers['factor'])==1 and len(session.buffers['residual'])==16
    assert session.reward.ended
    row,meta=session.buffers['factor'].rows[0]
    assert row['terminated']==1 and row['discount']==pytest.approx(learner.config.discount(16/30))
    assert meta['activation_delay_s']==0
    metrics=session.update(batch_size=1)
    assert set(metrics)=={'factor','residual'} and learner.versions==dict(factor=1,residual=1)
    session.save_replay(tmp_path/'sim.pt',bindings())
    session.reset_episode()


def test_sac_cli_initialization_and_actual_replay_update(tmp_path):
    from rl_factor_sac.io import atomic_save,file_sha256
    from rl_factor_sac.train import main,artifact_bindings
    from models.m0512_fm.factor_checkpoint import FORMAT
    base=tmp_path/'base';base.mkdir()
    atomic_save(dict(format=FORMAT,step=1,world_size=1,model={}),base/'model.pt')
    (base/'complete.json').write_text(json.dumps(dict(format=FORMAT,step=1,world_size=1)))
    tc=TokenConfig(memory_dim=16,token_dim=16,hidden_dim=32,layers=1)
    token=RLToken(tc);token_path=tmp_path/'token.pt'
    atomic_save(dict(format='ie2vla_rl_token_v1',base_sha256=file_sha256(base),
                     token_config=asdict(tc),token=token.state_dict()),token_path)
    c=config();cfg=tmp_path/'sac.json';cfg.write_text(json.dumps(c.asdict()))
    common=['--base',str(base),'--token',str(token_path),'--config',str(cfg),'--device','cpu']
    main(['--stage','init','--output',str(tmp_path/'init'),*common])
    bound,_=artifact_bindings(base,token_path,RewardConfig())
    buffers={k:ReplayBuffer(c,k) for k in ('factor','residual')}
    for k,b in buffers.items():
        b.add(transition(k,c,1),versions=dict(factor=0,residual=0),timestamp=0,source='simulator')
    replay=tmp_path/'replay.pt';save_replay(replay,buffers,bound)
    main(['--stage','rl','--resume',str(tmp_path/'init/sac_init.pt'),'--replay',str(replay),
          '--output',str(tmp_path/'trained'),'--steps','2','--batch-size','2',*common])
    trained=DualSAC.load(tmp_path/'trained/sac_f000002_r000002.pt',bindings=bound)
    assert trained.versions==dict(factor=2,residual=2)
