import copy
import io
import pickle
from dataclasses import replace
import numpy as np
import pytest
import torch
from action.parser import ProprioParser
from dataset.lerobot_dual import decode_tcp
from lerobot_raw_inference.client import encode_observation
from lerobot_raw_inference.service import prepare_observation, decode_actions
from lerobot_raw_inference.observations import ObservationBuffer
from test_lerobot_dual import dataset
from test_lerobot_pyro import observation_case, assert_same_observation


def test_raw_wire_matches_training_and_keeps_input_units(observation_case):
    cfg, observation, expected = observation_case
    before = copy.deepcopy(observation)
    request = encode_observation(observation)
    actual, stamp = prepare_observation(request, cfg)
    assert stamp == 0.
    assert_same_observation(actual, expected)
    for key in (cfg.state_pose_key,cfg.state_gripper_key):
        np.testing.assert_array_equal(request[key], before[key])
        np.testing.assert_array_equal(observation[key], before[key])
    class BuiltinsOnly(pickle.Unpickler):
        def find_class(self, module, name):
            raise AssertionError(f"Unexpected imported pickle type {module}.{name}")
    BuiltinsOnly(io.BytesIO(pickle.dumps(request))).load()


def test_server_returns_each_arm_base_flange_and_raw_gripper(observation_case):
    cfg, obs, expected = observation_case
    actions = expected.action.numpy()
    result = decode_actions(actions, cfg, 10.)
    recovered = decode_tcp(np.asarray(result['flange_pose']).reshape(-1,12), cfg)
    np.testing.assert_allclose(recovered, np.asarray(result['world_tcp']), atol=1e-6)
    np.testing.assert_allclose(result['world_tcp'], ProprioParser(expected.action).posemat.numpy().swapaxes(0,1), atol=1e-6)
    np.testing.assert_allclose(result['gripper_raw'], np.array([1886.,0.])[None].repeat(3,0))
    assert result['timestamps'][0] == 10.
    assert result['timestamps'][-1] == pytest.approx(10+2/30)


def test_original_single_row_is_packed_on_server(observation_case):
    cfg, obs, _ = observation_case
    cfg = replace(cfg, num_history_states=1)
    for key in (cfg.state_pose_key, cfg.state_gripper_key):
        obs[key] = np.asarray(obs[key])[-1:]
    expected, _ = prepare_observation(obs,cfg)
    for key in (cfg.state_pose_key, cfg.state_gripper_key):
        obs[key] = obs[key][0]
    actual, _ = prepare_observation(encode_observation(obs),cfg)
    assert_same_observation(actual,expected)


@pytest.mark.parametrize('key,value', [('world_tcp',[]),('action',[]),('protocol','wrong'),('timestamp',float('nan'))])
def test_wrong_contract_rejected(observation_case,key,value):
    cfg, obs, _ = observation_case
    obs[key] = value
    with pytest.raises(ValueError):
        prepare_observation(obs,cfg)


def test_sensor_buffer_preserves_raw_values_and_rejects_stale_unsynced_frames():
    keys=['head','left','right']
    buf=ObservationBuffer(keys)
    packet={'timestamp':1.,'observation.tcp_pose':list(range(12)), 'observation.state':list(range(14))}
    buf.add_state(packet)
    for key in keys:
        buf.add_image(key,np.zeros((24,32,3),np.uint8),1.)
    snap=buf.snapshot(1.01)
    np.testing.assert_array_equal(snap['observation.tcp_pose'][0],packet['observation.tcp_pose'])
    np.testing.assert_array_equal(snap['observation.state'][0],packet['observation.state'])
    with pytest.raises(ValueError,match='Stale'):
        buf.snapshot(2.)
    with pytest.raises(ValueError,match='new observation'):
        buf.snapshot(1.01,1.)
    buf.add_image('head',np.zeros((24,32,3),np.uint8),1.1)
    with pytest.raises(ValueError,match='synchronized'):
        buf.snapshot(1.1)
