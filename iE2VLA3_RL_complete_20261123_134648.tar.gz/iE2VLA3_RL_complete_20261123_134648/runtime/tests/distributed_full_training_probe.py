"""Four-rank training/save/resume regression with a real tiny Qwen and VLA.

torchrun --standalone --nproc_per_node=4 tests/distributed_full_training_probe.py --output /tmp/probe
Use --cuda for NCCL; otherwise the test uses Gloo on CPU. No pretrained downloads.
"""
import argparse
from contextlib import nullcontext
from copy import deepcopy
from datetime import timedelta
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from data_utils.tokenize import ModalityType
from dataset.lerobot_original import LeRobotOriginalConfig
from models.m0512_fm.vla import VLA
from models.m0512_fm.lerobot_runtime import configure_conv3d_layout
from models.m0512_fm.lerobot_distributed import (make_optimizers, save_full_checkpoint,
    read_full_checkpoint, restore_full_checkpoint)
from test_lerobot_dual import synthetic_batch
from transformers import Qwen3VLConfig, Qwen3VLForConditionalGeneration, Qwen3VLProcessor


def tiny_qwen(*args, **kwargs):
    config = Qwen3VLConfig(
        text_config=dict(vocab_size=64, hidden_size=64, intermediate_size=128, num_hidden_layers=4,
                         num_attention_heads=1, num_key_value_heads=1, head_dim=64,
                         rope_scaling={"rope_type": "default", "mrope_section": [12, 10, 10]}),
        vision_config=dict(depth=2, hidden_size=64, intermediate_size=128, num_heads=1,
                           out_hidden_size=64, deepstack_visual_indexes=[0, 1]),
        image_token_id=60, video_token_id=61, vision_start_token_id=62, vision_end_token_id=63)
    config._attn_implementation = "sdpa"
    return Qwen3VLForConditionalGeneration(config).to(torch.bfloat16)


def batch(device):
    data, _ = synthetic_batch(batch=2, idim=64)
    ids = torch.tensor([[62, 60, 60, 63] * 3 + [1, 2]]).repeat(2, 1)
    data.tokenized_vl = dict(input_ids=ids, attention_mask=torch.ones_like(ids),
                           pixel_values=torch.randn(48, 3 * 2 * 16 * 16),
                           image_grid_thw=torch.tensor([[1, 2, 4]]).repeat(6, 1))
    data.modality = torch.where(ids == 60, ModalityType.VISION, ModalityType.LANGUAGE)
    data._aux_data = {}
    return data.to(device)


def build(device):
    model = VLA(64, 1, 1).to(device).train()
    model.vlm.requires_grad_(True)
    model.vlm.full_qwen_features = True
    torch.nn.init.normal_(model.actor.dp_head.act_head.weight, std=.01)
    configure_conv3d_layout(model)
    ddp = DistributedDataParallel(model, device_ids=[device.index] if device.type == "cuda" else None,
                                  find_unused_parameters=True, gradient_as_bucket_view=True)
    optimizers = make_optimizers(model, .001, 1e-5)
    schedulers = [torch.optim.lr_scheduler.LambdaLR(opt, lambda step: .9 ** step) for opt in optimizers]
    return model, ddp, optimizers, schedulers


def update(ddp, optimizers, schedulers, device):
    for opt in optimizers:
        opt.zero_grad(set_to_none=True)
    losses = []
    # Exercise unsynchronized accumulation, followed by a synchronized microbatch.
    for micro in range(2):
        with ddp.no_sync() if micro == 0 else nullcontext():
            loss, _ = ddp(batch(device), inference=False, fp16=True)
            assert torch.isfinite(loss)
            (loss / 2).backward()
        losses.append(float(loss.detach()))
    for parameter in [ddp.module.vlm.qwen.visual.patch_embed.proj.weight,
                      ddp.module.vlm.qwen.language_model.layers[-1].self_attn.q_proj.weight,
                      ddp.module.vlm.qwen.language_model.norm.weight]:
        assert parameter.grad is not None and parameter.grad.abs().max() > 0
    torch.nn.utils.clip_grad_norm_(ddp.parameters(), 1., error_if_nonfinite=True)
    for opt, sched in zip(optimizers, schedulers):
        opt.step()
        sched.step()
    return losses


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cuda", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(2)
    rank = int(os.environ["RANK"])
    device = torch.device("cuda", int(os.environ["LOCAL_RANK"])) if args.cuda else torch.device("cpu")
    if args.cuda:
        torch.cuda.set_device(device)
    dist.init_process_group("nccl" if args.cuda else "gloo", timeout=timedelta(seconds=120))
    try:
        Qwen3VLForConditionalGeneration.from_pretrained = tiny_qwen
        Qwen3VLProcessor.from_pretrained = lambda *a, **k: SimpleNamespace(tokenizer=object())
        torch.manual_seed(42)
        model, ddp, optimizers, schedulers = build(device)
        torch.manual_seed(100 + rank)
        update(ddp, optimizers, schedulers, device)
        cfg = LeRobotOriginalConfig("synthetic")
        model_config = dict(train_qwen=True)
        train_config = dict(world_size=dist.get_world_size(), batch_size=2, gradient_accumulation_steps=2)
        stream = SimpleNamespace(epoch=3, batch_in_epoch=7)
        save_full_checkpoint(args.output / "step_0000001", model, optimizers, schedulers, 1, stream,
                             cfg, model_config, train_config, "test_snapshot")
        expected_loss = update(ddp, optimizers, schedulers, device)
        expected = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        expected_opt = [deepcopy(opt.optim.state_dict()) for opt in optimizers]
        # Check all parameters, including the full Qwen, synchronize across ranks.
        for parameter in model.parameters():
            ref = parameter.detach().clone()
            dist.broadcast(ref, src=0)
            torch.testing.assert_close(parameter, ref, rtol=0, atol=0)
        del ddp, model, optimizers, schedulers
        model, ddp, optimizers, schedulers = build(device)
        saved, local = read_full_checkpoint(args.output / "step_0000001", cfg,
                                           model_config, train_config, "test_snapshot")
        assert (saved["epoch"], saved["batch_in_epoch"]) == (3, 7)
        restore_full_checkpoint(saved, local, model, optimizers, schedulers)
        actual_loss = update(ddp, optimizers, schedulers, device)
        torch.testing.assert_close(torch.tensor(actual_loss), torch.tensor(expected_loss), rtol=0, atol=0)
        for key, value in model.state_dict().items():
            torch.testing.assert_close(value.cpu(), expected[key], rtol=0, atol=0)
        for optimizer, expected_state in zip(optimizers, expected_opt):
            state = optimizer.optim.state_dict()
            assert state["param_groups"] == expected_state["param_groups"]
            for key in state["state"]:
                for field, value in state["state"][key].items():
                    torch.testing.assert_close(value, expected_state["state"][key][field], rtol=0, atol=0)
        result = dict(rank=rank, world_size=dist.get_world_size(), backend=dist.get_backend(),
                      full_qwen_gradients=True, replicas_equal=True, exact_next_update_after_resume=True,
                      optimizer_dtypes=[str(opt.param_groups[0]["params"][0].dtype) for opt in optimizers])
        (args.output / f"result_rank_{rank}.json").write_text(json.dumps(result, indent=2))
        if rank == 0:
            print(json.dumps(result), flush=True)
    finally:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
