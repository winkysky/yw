"""Chunk execution, real SAC updates, legacy protocol and ROS conversion tests."""
import copy
from dataclasses import asdict
import inspect
import json
import threading
from types import SimpleNamespace
import numpy as np
import pytest
import torch
from torch import nn
from action.parser import ProprioParser
from e2vla_compat.config import PlannerConfig
from e2vla_compat.policy import decode_prediction
from e2vla_compat.remote_service import Service as OriginalService
from rl_factor_sac.config import SACConfig
from rl_factor_sac.reward import RewardConfig
from rl_factor_sac.sac import DualSAC
from rl_chunk_service.artifacts import ChunkSAC, load_replay
from rl_chunk_service.feedback import FeedbackNotReady, FeedbackReader, append_event
from rl_chunk_service.policy import Policy
from rl_chunk_service.session import ChunkSession
from rl_chunk_service.service import Service
from rl_chunk_service.online import OnlineLearner
from test_e2vla_compat import FakePolicy, frame, legacy_batch
from test_e2vla_async import until


@pytest.fixture(autouse=True)
def threads():
    torch.set_num_threads(2)


class Foundation(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.base = nn.Linear(1, 1)
        self.base.actor = SimpleNamespace(pad_act_dim=80)
        self.token = SimpleNamespace(config=SimpleNamespace(token_dim=16))
        self.data_config = config
        self.calls = []

    def freeze_online(self):
        return self.eval().requires_grad_(False)

    def encode(self, batch):
        return SimpleNamespace(batch=batch, token=batch.state[:, :, -1, :8].flatten(1))

    def predict(self, prepared, factor, initial_noise=None, fp16=False):
        self.calls.append(factor)
        raw = prepared.batch.state[:, :, -1:].repeat(1, 1, 32, 1)
        raw[..., 0] += torch.arange(32)*.001*factor
        return decode_prediction(raw)


def collator(samples):
    s = samples[0]
    return dict(raw_vl=[s.raw_vl], tokenized_vl={}, modality=torch.zeros(1, 1),
        patch_pose=torch.eye(4)[None], patch_norm_xy=torch.zeros(1, 2), state=s.state[None],
        state_mask=torch.ones_like(s.state[None]), action=s.action[None],
        action_mask=torch.ones_like(s.action[None]), action_ref_pose=ProprioParser(s.state[:, -1]).posemat[None])


def setup(tmp_path, mode="collect", raw=False):
    old = FakePolicy()
    now = [100.]
    config = SACConfig(token_dim=16, hidden_dim=32)
    bindings = dict(base_sha256="a"*64, token_sha256="b"*64, reward_config=asdict(RewardConfig()))
    foundation = Foundation(old.config)
    session = ChunkSession(foundation, ChunkSAC(config), bindings, mode=mode,
        journal=tmp_path/"proposals.jsonl", clock=lambda: now[0], source="simulator")
    settings = PlannerConfig(task="close_box", prompt="close the box",
        input_pose_format="recorded" if raw else "tcp_world", input_gripper_format="raw" if raw else "openness")
    policy = Policy(settings, session, old.native_info, collator)
    return Service(policy, settings), session, now


def force(session, end, start=None):
    start = start if start is not None else (session.wrench.rows[-1][0]+.02 if session.wrench.rows else end-.3)
    for stamp in np.arange(start, end+1e-8, .02):
        session.handle(dict(type="wrench", timestamp=float(stamp), values=np.zeros((2,6)).tolist()))


def propose(service, session, now, stamp):
    now[0] = stamp
    force(session, stamp)
    service.add_obs_frame(frame(service.policy, stamp)[0])
    result = service.get_action(seed=42)
    return result, next(reversed(session.pending))


def activate(session, chunk, stamp):
    session.handle(dict(type="activate", timestamp=stamp, chunk_id=chunk, execution_matches_proposal=True))


def test_chunk_decisions_execution_credit_and_both_sac_updates(tmp_path):
    s, session, now = setup(tmp_path)
    try:
        first, p1 = propose(s, session, now, 100.)
        assert len(first) == 4 and first[0].shape == (32,2,4,4)
        np.testing.assert_allclose(np.diff(first[2]), 1/30)
        repeated = s.get_action(seed=42, draw_traj=True, compress_traj_img=True)
        np.testing.assert_array_equal(first[0], repeated[0])
        assert len(session.foundation.calls) == 1 and len(session.pending) == 1
        assert session.transitions == 0 and not len(session.buffers["factor"])
        plan = session.pending[p1]
        # Same residual for every reference point; one action for the entire chunk.
        from rl_factor_sac.geometry import residual_target
        offsets, valid = residual_target(torch.tensor(plan["reference"][...,:16].reshape(32,2,4,4)),
                                        torch.tensor(first[0]), session.config)
        torch.testing.assert_close(offsets, plan["residual_action"].expand(32,-1), atol=4e-5, rtol=1e-3)
        assert valid.all()
        with pytest.raises(ValueError, match="explicit confirmation"):
            session.handle(dict(type="activate", timestamp=100., chunk_id=p1))
        activate(session, p1, 100.)
        assert not len(session.buffers["residual"])
        second, p2 = propose(s, session, now, 100.5)
        activate(session, p2, 100.5)
        assert session.transitions == 1
        f = session.buffers["factor"].snapshot()[0][0]
        r = session.buffers["residual"].snapshot()[0][0]
        assert f["discount"].item() == pytest.approx(.99**.5)
        torch.testing.assert_close(f["discount"], r["discount"])
        torch.testing.assert_close(f["reward"], r["reward"])
        torch.testing.assert_close(r["next_obs"]["reference"], session.active["residual_obs"]["reference"])
        torch.testing.assert_close(r["next_obs"]["previous_residual"], plan["residual_action"])
        now[0] = 100.8; force(session, now[0])
        session.handle(dict(type="outcome", timestamp=100.8, chunk_id=p2, outcome="success"))
        assert session.ended and session.transitions == 2
        assert session.buffers["factor"].snapshot()[-1][0]["terminated"].item() == 1
        before = copy.deepcopy(session.learner.factor.actor.state_dict())
        metrics = session.learner.update(**{k+"_batch": b.sample(4) for k,b in session.buffers.items()})
        assert session.learner.versions == dict(factor=1,residual=1)
        assert all(np.isfinite(list(m.values())).all() for m in metrics.values())
        assert any(not torch.equal(v, session.learner.factor.actor.state_dict()[k]) for k,v in before.items())
        assert all(p.grad is None for p in session.foundation.parameters())
        path = tmp_path/"replay.pt"; session.save_replay(path)
        loaded = load_replay(path, session.config, session.bindings)
        assert len(loaded["factor"]) == len(loaded["residual"]) == 2
        session.learner.save(tmp_path/"sac.pt", session.bindings)
        restored = ChunkSAC.load(tmp_path/"sac.pt", bindings=session.bindings, restore_rng=True)
        batch = loaded["factor"].sample(3)
        seedstate = torch.get_rng_state()
        a = session.learner.update(factor_batch=batch)
        torch.set_rng_state(seedstate)
        b = restored.update(factor_batch=batch)
        assert a == b
        for k,v in restored.factor.actor.state_dict().items():
            torch.testing.assert_close(v, session.learner.factor.actor.state_dict()[k], atol=0, rtol=0)
        with pytest.raises(ValueError, match="format"):
            DualSAC.load(tmp_path/"sac.pt")
    finally:
        s.close()


def test_no_force_no_fake_rewards_reset_and_ambiguous_ack(tmp_path):
    s, session, now = setup(tmp_path)
    try:
        s.add_obs_frame(frame(s.policy)[0])
        assert s.get_action() is None
        assert "measured wrench" in s.get_status()["status"]
        force(session, 100.)
        s.get_action(seed=1); p1 = next(reversed(session.pending))
        s.get_action(seed=2)
        with pytest.raises(ValueError, match="ambiguous"):
            session.handle(dict(type="activate", timestamp=100., anchor=100., execution_matches_proposal=True))
        activate(session, p1, 100.)
        # No completion is manufactured by reset, abort or merely returning a trajectory.
        s.reset()
        assert not session.active and session.transitions == 0 and not session.pending
        with pytest.raises(ValueError, match="no proposal"):
            activate(session, p1, 100.)
        now[0] = 102.
        s.add_obs_frame(frame(s.policy, 102.)[0])
        assert s.get_action() is None
        assert session.transitions == 0
    finally:
        s.close()


def test_expired_wrong_parent_and_force_gap_never_pollute_replay(tmp_path):
    s, session, now = setup(tmp_path)
    try:
        _, first = propose(s, session, now, 100.)
        # This proposal was made before the first became active. A late ACK
        # cannot pretend its previous-residual state included the first action.
        _, second = propose(s, session, now, 100.1)
        activate(session, first, 100.)
        with pytest.raises(ValueError, match="parent"):
            activate(session, second, 100.1)
        now[0] = 100.7
        # History for a new decision can be complete while the earlier execution
        # interval had an unmeasured gap. Both transitions must be rejected.
        force(session,100.7,start=100.4)
        s.add_obs_frame(frame(s.policy,100.7)[0]); s.get_action()
        third = next(reversed(session.pending))
        with pytest.raises(FeedbackNotReady, match="Missing force"):
            activate(session,third,100.7)
        assert session.active["id"] == first
        assert all(len(b)==0 for b in session.buffers.values())
        now[0] = 102.
        with pytest.raises(ValueError, match="Stale"):
            activate(session,third,102.)
        assert session.transitions == 0
        saved=tmp_path/"wrong.pt";session.learner.save(saved,session.bindings)
        wrong=torch.load(saved,weights_only=False);wrong["semantics"]["reference_hz"]=15
        torch.save(wrong,saved)
        with pytest.raises(ValueError,match="semantics"):
            ChunkSAC.load(saved,bindings=session.bindings)
    finally:
        s.close()


def test_recorded_raw_and_legacy_batch_shapes_and_signatures(tmp_path):
    s, session, now = setup(tmp_path, "inference", raw=True)
    try:
        force(session, 100.)
        obs, recorded = frame(s.policy)
        raw = copy.deepcopy(obs)
        raw.update(ee_pose=recorded, gripper=np.array([1886., 0.]))
        s.add_obs_frame(raw)
        result = s.get_action(seed=1)
        np.testing.assert_allclose(result[0][0], obs["ee_pose"], atol=2e-6)
        np.testing.assert_allclose(result[1][0], obs["gripper"], atol=1e-6)
        info = s.get_info()
        assert info["protocol"] == "e2vla_lerobot_pyro_v1"
        assert info["variant"] == "no_speed" and info["rl"]["factors"] == [.8,1.,1.5,2.]
        assert s.get_planner_config()["input_gripper_format"] == "raw"
        batch = legacy_batch(s.policy, obs)
        cpu = s.run_inference(batch, contract_sha256=info["contract_sha256"])
        assert cpu.shape == (1,32,2,17) and cpu.dtype == torch.float32 and cpu.device.type == "cpu"
        doubled = {k: torch.cat([v,v]) if isinstance(v,torch.Tensor)
                   else v*2 if k == "prompt_text" else v for k,v in batch.items()}
        assert s.run_inference_numpy(doubled).shape == (2,32,2,17)
        with pytest.raises(ValueError, match="contract"):
            s.run_inference(batch, contract_sha256="wrong")
        with pytest.raises(ValueError): s.set_speed(.8)
        with pytest.raises(ValueError): s.get_action(speed_mps=.8)
        for name in ("get_info","get_config","get_planner_config","get_status","set_config","reset",
                     "set_prompt","set_speed","add_obs_frame","add_obs_frames","get_action",
                     "set_ensemble_nums","ensemble_traj","run_inference","run_inference_numpy"):
            assert inspect.signature(getattr(Service,name)) == inspect.signature(getattr(OriginalService,name))
    finally:
        s.close()


def test_async_new_observations_and_reset_cancel_inflight_chunk(tmp_path):
    s, session, now = setup(tmp_path, "inference")
    started, release = threading.Event(), threading.Event()
    predict = session.foundation.predict
    def gated(*args, **kwargs):
        started.set()
        assert release.wait(5.)
        return predict(*args, **kwargs)
    session.foundation.predict = gated
    try:
        force(session, 100.)
        s.add_obs_frame(frame(s.policy)[0]); s.start_async()
        assert started.wait(2.)
        now[0] = 100.1; force(session, 100.1)
        s.add_obs_frame(frame(s.policy,100.1)[0])
        assert s.get_status()["observation_count"] == 2
        s.reset(); release.set()
        until(lambda: s.get_status()["counts"]["discarded"] == 1)
        assert not session.pending and not session.buffers["factor"]
        s.add_obs_frame(frame(s.policy,100.1)[0]); s.start_async()
        result = until(lambda: s.get_latest_action()["result"])
        assert result["observation_timestamp"] == 100.1
        assert s.get_latest_action(result["sequence"])["result"] is None
    finally:
        release.set(); s.close()


def test_real_inbox_and_online_training_from_execution_events(tmp_path):
    s, session, now = setup(tmp_path, "train")
    inbox = tmp_path/"feedback.jsonl"
    # A restart must not replay old activation records.
    append_event(inbox, dict(type="activate", timestamp=1., chunk_id="old"))
    reader = FeedbackReader(inbox, session)
    trainer = OnlineLearner(session, tmp_path, warmup=1, batch_size=2, save_every=1)
    try:
        _, first = propose(s, session, now, 100.)
        append_event(inbox, dict(type="activate", timestamp=100., chunk_id=first, execution_matches_proposal=True))
        until(lambda: session.active)
        _, second = propose(s, session, now, 100.5)
        append_event(inbox, dict(type="activate", timestamp=100.5, chunk_id=second, execution_matches_proposal=True))
        until(lambda: session.learner.versions == dict(factor=1,residual=1))
        assert session.error is None
        until(lambda: (tmp_path/"sac_latest.pt").exists())
        saved = ChunkSAC.load(tmp_path/"sac_latest.pt", bindings=session.bindings)
        assert saved.versions == dict(factor=1,residual=1)
        append_event(inbox, dict(type="outcome", timestamp=100.5, chunk_id="bad", outcome="success"))
        until(lambda: session.error)
        assert "currently executed" in s.get_status()["rl"]["error"]
        assert len(session.buffers["factor"]) == 1
    finally:
        reader.close(); trainer.close(); s.close()


def test_ros_mapping_units_moment_arm_and_feedback():
    from rl_chunk_service.ros_bridge import Adapter
    cfg = dict(topic="wrench", message_type="geometry_msgs/msg/WrenchStamped", timestamp="header.stamp",
        expected_frame_id="sensor", fields=["wrench.force.x","wrench.force.y","wrench.force.z",
        "wrench.torque.x","wrench.torque.y","wrench.torque.z"], force_scale_to_n=2., torque_scale_to_nm=.001,
        sensor_to_tcp_rotation=np.eye(3).tolist(), tcp_to_sensor_translation_m=[0.,1.,0.], bias_si=[0.]*6)
    emitted = []
    adapter = Adapter(dict(wrench=dict(left=cfg,right=cfg)), emitted.append)
    message = SimpleNamespace(header=SimpleNamespace(stamp=SimpleNamespace(sec=100,nanosec=0), frame_id="sensor"),
        wrench=SimpleNamespace(force=SimpleNamespace(x=1.,y=0.,z=0.), torque=SimpleNamespace(x=0.,y=0.,z=1000.)))
    adapter.wrench("left",message); assert not emitted
    adapter.wrench("right",message)
    np.testing.assert_allclose(emitted[0]["values"], [[2,0,0,0,0,-1]]*2)
    adapter.feedback(dict(constants={"type":"activate"},fields={"timestamp":"t","anchor":"a",
                     "execution_matches_proposal":"ok"}),
                     SimpleNamespace(t=100.,a=SimpleNamespace(sec=100,nanosec=0),ok=True))
    assert emitted[-1] == dict(type="activate",timestamp=100.,anchor=100.,execution_matches_proposal=True)
    bad = copy.deepcopy(message); bad.header.frame_id="wrong"
    with pytest.raises(ValueError, match="frame"):
        adapter.wrench("left",bad)


def test_pyro_socket_and_shared_memory_wire_unchanged(tmp_path):
    import Pyro4
    import Pyro4.naming
    from shm_transport import get_shm_proxy, run_simple_server
    from shm_transport.shm_mng import register_cleanup_this_process
    register_cleanup_this_process()
    s, session, now = setup(tmp_path, "inference")
    force(session, 100.)
    stopped = threading.Event()
    _, ns_daemon, _ = Pyro4.naming.startNS(host="127.0.0.1", port=0, enableBroadcast=False)
    ns_port = ns_daemon.sock.getsockname()[1]
    ns_thread = threading.Thread(target=ns_daemon.requestLoop, daemon=True); ns_thread.start()
    errors = []
    def serve():
        try:
            run_simple_server(s, "chunk_test", ns_host="127.0.0.1", ns_port=ns_port,
                daemon_host="127.0.0.1", daemon_port=0, multiplex=False,
                loop_cond=lambda: not stopped.is_set(), replace_existing=False)
        except Exception as exc:
            errors.append(exc)
    worker = threading.Thread(target=serve, daemon=True); worker.start()
    proxies = []
    try:
        def registered():
            if errors:
                raise errors[0]
            with Pyro4.locateNS(host="127.0.0.1", port=ns_port) as ns:
                return ns.list().get("chunk_test")
        until(registered)
        for tcp in (True, False):
            proxy = get_shm_proxy("chunk_test", ns_host="127.0.0.1", ns_port=ns_port, force_use_socket=tcp,
                                  en_arg_sh_cuda=False)
            proxies.append(proxy)
            info = proxy.get_info()
            assert info["format"] == "e2vla_lerobot_no_force_no_speed_v1"
            if tcp:
                proxy.add_obs_frame(frame(s.policy)[0])
            result = proxy.get_action(seed=42)
            assert result[0].dtype == np.float32 and result[0].shape == (32,2,4,4)
            assert result[3] is None and len(result[2]) == 32
            batch = legacy_batch(s.policy, frame(s.policy)[0])
            assert proxy.run_inference_numpy(batch, seed=42).shape == (1,32,2,17)
            assert proxy.run_inference(batch, seed=42).device.type == "cpu"
            assert "rl" in proxy.get_status()
        assert not errors and session.transitions == 0
    finally:
        for proxy in proxies:
            proxy._pyro_proxy._pyroRelease()
        stopped.set(); worker.join(5.)
        ns_daemon.shutdown(); ns_daemon.close(); ns_thread.join(5.)
        s.close()
    assert not worker.is_alive() and not errors


from test_lerobot_original import local_qwen


def test_real_tiny_foundation_loading_inference_and_training_cli(local_qwen, monkeypatch, tmp_path):
    from test_lerobot_dual_velocity import tiny_full_model
    from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityConfig
    from models.m0512_fm.factor_checkpoint import FORMAT
    from rl_factor_sac.io import atomic_save, file_sha256
    from rl_factor_sac.token import RLToken, TokenConfig
    from rl_chunk_service.train import main
    import rl_chunk_service.policy as policy_module
    model, data = tiny_full_model(monkeypatch)
    base = tmp_path/"base"; base.mkdir()
    cfg = LeRobotRetimedVelocityConfig(**FakePolicy().config.to_dict())
    model_cfg = dict(model="tiny_factor_test", velocity_dropout=0., inference_timesteps=2,
                     action_horizon=32, train_qwen=True, full_qwen_features=True)
    atomic_save(dict(format=FORMAT, step=1, world_size=1, model_config=model_cfg,
        data_config=asdict(cfg), dataset_fingerprint="test-only", model=model.state_dict()), base/"model.pt")
    (base/"complete.json").write_text(json.dumps(dict(format=FORMAT,step=1,world_size=1)))
    tc = TokenConfig(memory_dim=64,token_dim=16,hidden_dim=32,layers=1)
    token = tmp_path/"token.pt"
    atomic_save(dict(format="ie2vla_rl_token_v1",base_sha256=file_sha256(base),
                     token_config=asdict(tc),token=RLToken(tc).state_dict()),token)
    # Untrained tiny model is used only for CPU wiring, not command-limit validation.
    config = SACConfig(token_dim=16,hidden_dim=32,max_command_speed_mps=1e6,max_command_angular_speed=1e6)
    config_path = tmp_path/"sac_config.json"; config_path.write_text(json.dumps(asdict(config)))
    common = ["--base",str(base),"--token",str(token),"--config",str(config_path),"--threads","2"]
    main(["--stage","init","--output",str(tmp_path/"init"),*common])
    # Real Qwen, token encoder and flow actor; supply synthetic tokenized RGB to
    # avoid a network tokenizer download in this small checkpoint integration test.
    data.raw_vl = data.raw_vl[:1]
    for key in ("state","state_mask","action","action_mask","action_ref_pose","modality"):
        setattr(data,key,getattr(data,key)[:1])
    data.patch_pose = data.patch_pose[:6]; data.patch_norm_xy = data.patch_norm_xy[:6]
    data.tokenized_vl = {k: v[:24 if k=="pixel_values" else 3 if k=="image_grid_thw" else 1]
                         for k,v in data.tokenized_vl.items()}
    data._aux_data = {}
    monkeypatch.setattr(policy_module,"LeRobotOriginalCollator",lambda _: lambda samples:data.deepcopy().__dict__)
    settings = PlannerConfig(checkpoint=str(base),task="close_box",device="cpu",prompt="test",
                             input_pose_format="tcp_world",input_gripper_format="openness")
    policy = Policy.load(settings,token,tmp_path/"init/sac_init.pt",mode="collect",source="simulator")
    s = Service(policy,settings); session = policy.session; now=[100.]; session.clock=lambda:now[0]
    frozen = {k:v.clone() for k,v in session.foundation.state_dict().items()}
    try:
        force(session,100.); s.add_obs_frame(frame(policy)[0]); result=s.get_action(seed=2)
        assert result[0].shape==(32,2,4,4) and np.isfinite(result[0]).all()
        first=next(reversed(session.pending)); activate(session,first,100.)
        now[0]=100.2; force(session,100.2)
        session.handle(dict(type="outcome",timestamp=100.2,chunk_id=first,outcome="failure"))
        replay=tmp_path/"real_replay.pt";session.save_replay(replay)
        main(["--stage","rl","--resume",str(tmp_path/"init/sac_init.pt"),"--replay",str(replay),
              "--steps","2","--batch-size","2","--save-every","1","--output",str(tmp_path/"trained"),*common])
        trained=ChunkSAC.load(tmp_path/"trained/sac_f000002_r000002.pt",bindings=session.bindings)
        assert trained.versions==dict(factor=2,residual=2)
        for key,value in session.foundation.state_dict().items():
            torch.testing.assert_close(value,frozen[key],atol=0,rtol=0)
        assert not any(p.requires_grad for p in session.foundation.parameters())
    finally:
        s.close()
