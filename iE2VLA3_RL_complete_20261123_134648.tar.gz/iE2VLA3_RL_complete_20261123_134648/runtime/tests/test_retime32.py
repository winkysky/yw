"""32-step retiming, continuous conditioning and inference contracts."""
import json
from pathlib import Path
from types import SimpleNamespace
import cv2
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch
from scipy.spatial.transform import Rotation
from data_utils.trajectory_factor32 import retime_sample, valid_anchors
from models.speed_factor import FACTORS

@pytest.fixture(autouse=True)
def cpu_threads():
    torch.set_num_threads(2)


def columns(n=130):
    t = np.arange(n, dtype=np.float64) / 30
    pose = np.broadcast_to(np.eye(4), (n, 2, 4, 4)).copy()
    pose[:, 0, 0, 3] = .1 * t
    pose[:, 1, 0, 3] = .05 * t
    pose[:, :, :3, :3] = Rotation.from_euler("z", 170 + 20 * t, degrees=True).as_matrix()[:, None]
    grip = np.zeros((n, 2), dtype=np.float32)
    grip[t >= 1.] = 1
    return dict(timestamp=t, action_pose=pose.astype(np.float32), state_pose=pose.astype(np.float32),
                action_gripper=grip, state_gripper=grip, task_index=np.zeros(n, dtype=int))



@pytest.fixture
def retimed_dataset(tmp_path):
    camera = "observation.images.head_image"
    (tmp_path / "meta").mkdir()
    (tmp_path / "data").mkdir()
    (tmp_path / "videos").mkdir()
    n=130
    info=dict(codebase_version="v2.1", fps=30, chunks_size=1000,
              data_path="data/episode_{episode_index:06d}.parquet",
              video_path="videos/{video_key}_{episode_index:06d}.mp4",
              features={camera:dict(dtype="video")})
    (tmp_path / "meta/info.json").write_text(json.dumps(info))
    (tmp_path / "meta/episodes.jsonl").write_text("\n".join(json.dumps(dict(episode_index=i,length=n)) for i in range(2)))
    (tmp_path / "meta/tasks.jsonl").write_text(json.dumps(dict(task_index=0,task="close box")))
    for ep in range(2):
        poses=np.zeros((n,12),dtype=np.float32)
        poses[:,0]=np.arange(n) * (1 if ep==0 else 0)
        poses[:,6]=np.arange(n) * (2 if ep==0 else 0)
        commands=poses.copy(); commands[:,[0,6]] += 10
        grip=np.zeros((n,14)); grip[:,6]=1886
        table=pa.table({"observation.tcp_pose":poses.tolist(),"action.tcp_pose_cmd":commands.tolist(),
            "observation.state":grip.tolist(),"action.joint":grip.tolist(),
            "timestamp":(np.arange(n)/30).astype(np.float32).tolist(),"frame_index":list(range(n)),
            "episode_index":[ep]*n,"task_index":[0]*n})
        pq.write_table(table,tmp_path / f"data/episode_{ep:06d}.parquet")
        writer=cv2.VideoWriter(str(tmp_path / f"videos/{camera}_{ep:06d}.mp4"),cv2.VideoWriter_fourcc(*"mp4v"),30,(64,64))
        assert writer.isOpened()
        for i in range(n): writer.write(np.full((64,64,3),i%255,np.uint8))
        writer.release()
    geometry=dict(cameras={camera:dict(K=[[50,0,31.5],[0,50,31.5],[0,0,1]],image_size=[64,64],
                                       parent="world",pose=np.eye(4).tolist())}, action_reference_cameras=[camera,camera])
    from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityConfig as Config, LeRobotRetimedVelocityDataset as Dataset
    cfg=Config(root=str(tmp_path),camera_keys=[camera],image_size=[64,64],geometry=geometry,
               num_history_states=5,num_future_actions=32,speed_factors=list(FACTORS),history_mode="observed")
    reader=Dataset(cfg)
    yield reader
    reader.close()


def test_four_factors_change_future_not_history_or_current_observation():
    c=columns()
    values=[retime_sample(c,10,f,5) for f in FACTORS]
    assert [float(v['speed_factor']) for v in values]==pytest.approx(FACTORS)
    for f,v in zip(FACTORS,values):
        assert not any('mps' in k for k in v)
        assert v['action_pose'].shape==(32,2,4,4)
        np.testing.assert_allclose(v['action_pose'][:,0,0,3],.1*v['source_times'],atol=1e-7)
        np.testing.assert_allclose(v['history_pose'],c['state_pose'][6:11],atol=1e-7)
        np.testing.assert_allclose(np.linalg.det(v['action_pose'][...,:3,:3]),1,atol=1e-6)
        np.testing.assert_array_equal(v['action_gripper'][:,0],v['source_times']>=1-1e-6)
        assert v['source_times'][-1]-v['source_times'][0]==pytest.approx(f*31/30)
    np.testing.assert_allclose(values[1]['action_pose'],c['action_pose'][10:42],atol=1e-6)
    assert all(not np.allclose(values[i]['action_pose'],values[j]['action_pose'])
               for i in range(4) for j in range(i))


def test_paired_anchors_exclude_boundaries_holes_and_extrapolation():
    c=columns()
    np.testing.assert_array_equal(valid_anchors(c,np.arange(130),5),np.arange(4,68))
    c['task_index'][70:]=1
    np.testing.assert_array_equal(valid_anchors(c,np.arange(130),5),np.arange(4,8))
    c['task_index'][:]=0
    c['prompt']=np.array(['a']*70+['b']*60)
    np.testing.assert_array_equal(valid_anchors(c,np.arange(130),5),np.arange(4,8))
    c.pop('prompt')
    assert not len(valid_anchors(c,np.delete(np.arange(130),[50,100]),5))
    with pytest.raises(ValueError,match='extrapolate'):
        retime_sample(c,100,2.)
    for f in (.5,3.,float('nan')):
        with pytest.raises(ValueError): retime_sample(c,10,f)


def test_stationary_rotation_and_gripper_data_keep_all_labels():
    c=columns()
    c['action_pose'][...,:3,3]=0
    assert len(valid_anchors(c,np.arange(130)))==68
    poses=[retime_sample(c,10,f)['action_pose'] for f in FACTORS]
    assert not np.allclose(poses[0],poses[-1])
    c['action_pose'][:]=np.eye(4)
    assert len(valid_anchors(c,np.arange(130)))==68


def test_real_parquet_video_preserves_geometry_prompt_and_paired_factors(retimed_dataset):
    reader=retimed_dataset
    assert len(set(reader.counts.values()))==1 and len(reader.blocks)==8
    samples=[reader[i] for i in [0]+reader.ends[:-1]]
    for i,sample in enumerate(samples):
        assert sample.action.shape==(2,32,73) and sample.state.shape==(2,5,73)
        assert sample.action_mask[:,:,:10].all()
        assert sample.raw_vl.prompt=='close box' and sample._original_geometry_ready
        assert sample.action[0,0,0]-sample.state[0,-1,0]==pytest.approx(.01,abs=1e-6)
        assert float(sample._retime_metadata['speed_factor'])==pytest.approx(FACTORS[i%4])
        if i%4:
            torch.testing.assert_close(sample.state,samples[i-i%4].state)
            torch.testing.assert_close(sample.action_ref_pose,samples[i-i%4].action_ref_pose)
    assert not torch.allclose(samples[0].action,samples[3].action)
    reader[len(reader)-1]


def test_episode_split_groups_all_factors_of_physical_episode(retimed_dataset):
    from rl_factor_sac.train_token import EpisodeSplit
    for seed in range(100):
        try:
            train=EpisodeSplit(retimed_dataset,False,.5,seed)
            val=EpisodeSplit(retimed_dataset,True,.5,seed)
            break
        except ValueError:
            continue
    else: raise AssertionError('No nonempty deterministic split')
    assert len(train)+len(val)==len(retimed_dataset)
    assert not train.episode_keys & val.episode_keys
    assert len(train.spans)==len(val.spans)==4
    assert train[0]._retime_metadata['episode_key'] not in val.episode_keys


def test_reviewed_plus_raw_keep_prompts_exclusions_and_group_balance(retimed_dataset,tmp_path,monkeypatch):
    from dataclasses import replace
    import shutil
    import dataset.lerobot_reviewed as reviewed
    from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityDataset
    from dataset.balanced_sampler import BalancedGroupBatchSampler
    original=retimed_dataset.readers[0]
    raw=tmp_path/'third'
    for name in ('meta','data','videos'):shutil.copytree(original.root/name,raw/name)
    sources=[]
    for name in ('first','dagger'):
        handoff=tmp_path/name;(handoff/'filtered_data').mkdir(parents=True)
        (handoff/'task_manifest.json').write_text('{}')
        sources.append(dict(name=name,type='reviewed',root=str(handoff/'filtered_data'),expected_episodes=1))
    def reviewed_view(root,cfg):
        name=Path(root).parent.name
        frames=np.arange(130) if name=='first' else np.arange(120)
        return [dict(dataset_id='source',source_root=str(original.root),episode_index=0,
            parquet_path=str(original._path('data_path',0)),segment_id=name,frames=frames,
            instruction=name+' prompt',split_group='physical_episode_0')],name
    monkeypatch.setattr(reviewed,'load_reviewed_view',reviewed_view)
    mixture=tmp_path/'groups';mixture.mkdir()
    (mixture/'dataset_groups.json').write_text(json.dumps(dict(format='lerobot_equal_groups_v1',groups=[
        dict(name='A',sources=sources),dict(name='B',sources=[dict(name='raw',type='lerobot',root=str(raw))])])))
    reader=LeRobotRetimedVelocityDataset(replace(retimed_dataset.config,root=str(mixture)))
    try:
        assert len(set(reader.counts.values()))==1
        starts=[0]+reader.ends[:-1]
        assert reader[starts[0]].raw_vl.prompt=='first prompt'
        assert reader[starts[4]].raw_vl.prompt=='dagger prompt'
        assert reader[starts[8]].raw_vl.prompt=='close box'
        for block in reader.blocks[4:8]: assert (block['frames']<=57).all()
        boundary=reader.group_ranges[0][1]
        batches=list(BalancedGroupBatchSampler(reader.group_ranges,16,42,0))
        assert all(sum(i<boundary for i in batch)==8 for batch in batches)
        # Distinct reviewed exports of the same physical episode share split identity.
        assert reader.blocks[0]['episode_key']==reader.blocks[4]['episode_key']
    finally:reader.close()


def test_raw_source_prompt_overrides_survive_factor_expansion(retimed_dataset,tmp_path):
    from dataclasses import replace
    from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityDataset
    manifest=tmp_path/'raw_manifest';manifest.mkdir()
    (manifest/'raw_sources.json').write_text(json.dumps(dict(format='lerobot_raw_sources_v1',sources=[
        dict(name='task',root=str(retimed_dataset.readers[0].root),instruction='explicit override')])) )
    reader=LeRobotRetimedVelocityDataset(replace(retimed_dataset.config,root=str(manifest)))
    try:
        assert len(reader)==len(retimed_dataset)
        for index in [0]+reader.ends[:-1]:assert reader[index].raw_vl.prompt=='explicit override'
    finally:reader.close()

