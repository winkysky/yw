# LeRobot 原始观测 → iE2VLA3 双臂 Pyro4 推理

这是新增的无速度版入口，原来的训练、模型、Pyro4、ROS2 客户端和可视化文件均保留。它沿用原版的“客户端上传观测 → 服务端返回一个动作块”方式，将当前 HW LeRobot 数据的转换全部放到服务端。支持当前全量 Qwen3-VL-2B、LoRA 关闭的 `lerobot_original_full_v2` checkpoint，预测长度由 checkpoint 决定，当前为双臂各 32 步。

## 职责

```text
机器人 / LeRobot 文件
  原始 observation.tcp_pose + observation.state + 三路 RGB + 任务指令
       ↓ Client（只打包字节和数值，普通 TCP/Pyro4）
  Service：单位换算 → 各臂 base 统一到左臂 base → 法兰转 TCP
           → 夹爪归一化 → checkpoint 相机内外参 → 图像处理/分词
           → 完整模型推理 → 动作块与位姿解码
       ↓
  客户端收到动作块 / TCP 轨迹 / 各臂原始 base 法兰轨迹和夹爪值
       ↓
  用户现有机器人控制器负责轨迹选择、时序和实际执行
```

推理是无状态的，每次请求带指令和完整观测；不需要 `reset/set_prompt/add_obs/get_action` 会话。原版 `ac/` 的 MPC 类保留，本入口没有自动接入 MPC 或 MoveIt，也不会直接驱动机器人。

## 输入约定

| 字段 | 形状及含义 |
| --- | --- |
| `observation.tcp_pose` | `[H,12]`，左 6 维后右 6 维；当前 H=1，也接受原始单行 `[12]` |
| `observation.state` | `[H,14]`；当前也接受单行 `[14]`，按原数据完整传入 |
| `images` | 三路以相机名称为键的 RGB `uint8 [height,width,3]` |
| `instruction` | 非空任务字符串 |
| `timestamp` | 可选，最新观测的采样时间，单位秒；离线省略时为 0 |

**当前数据中名为 `tcp_pose` 的字段实际记录法兰位姿**：`[x,y,z,rx,ry,rz]` 的平移为毫米、姿态为外旋 `xyz` 欧拉角（度）；左臂在左臂记录 base，右臂在右臂记录 base。直接上传与训练数据相同的数值，不要事先变成米、TCP 或统一左臂 base。`observation.state` 中下标 6 和 13 是夹爪，1886 为闭合、0 为张开，其他关节列仍保持原样。

服务端读取 checkpoint 的 `position_scale/euler_order/angle_degrees/base_to_world/pose_to_tcp/gripper_*` 及 `geometry`，复用训练读取器：

```text
T_left_base_tcp = T_left_base_arm_base @ T_arm_base_recorded_flange @ T_flange_tcp
```

三路相机固定按以下名称传入，不必上传 K、外参或 TF：

- `observation.images.head_image`
- `observation.images.left_wrist_image`
- `observation.images.right_wrist_image`

头部相机用固定外参，腕部相机根据当前法兰位姿计算；全部使用 checkpoint 内的标定。上传 RGB，不能把 BGR 直接当 RGB；应使用标定对应的完整视场和相同比例，不要裁剪或翻转。当前可传 640×480，也可传训练尺寸 256×192（宽×高），缩放由服务端处理。H>1 时需按 checkpoint 的 `frame_stride/30` 秒间隔提供从旧到新的历史，图像对应最新状态。

## 服务端启动

在完整代码根目录、已有模型环境中执行：

```bash
bash lerobot_raw_inference/serve.sh \
  --checkpoint /path/to/step_0100000 \
  --device cuda:0 \
  --ns-host 192.168.1.10 --ns-port 19092 \
  --host 192.168.1.10 --port 19093
```

将两个 IP 改为推理服务器的实际可达地址。脚本自动启动名称服务，默认注册名为 `ie2vla3_raw_lerobot`；同名服务已经存在时退出。客户端与服务器需要能访问这两个 TCP 端口。Pyro4 使用 pickle，仅在受信任网络中使用。CPU 调试改为 `--device cpu --threads 4`；解释器可通过 `IE2VLA_PYTHON` 指定。

依赖使用完整项目环境及打包的 `requirements_snapshot.txt`。推理需要单独提供完整 checkpoint 的 `model.pt` 和 `complete.json`，不需要 `rank_*.pt` 优化器文件。现有模型构造器还会加载 `Qwen/Qwen3-VL-2B-Instruct` 基础模型和 processor；需另行准备该目录或对应 Hugging Face 缓存。代码包不含这些权重。

## 机器人 Python 客户端

客户端只需 NumPy 和 Pyro4：

```bash
python -m pip install -r lerobot_raw_inference/requirements-client.txt
```

可以单独复制整个 `lerobot_raw_inference` 目录到机器人工作目录，在其父目录启动 Python。`client.py` 不加载 Torch、模型或服务端代码。

```python
from lerobot_raw_inference.client import Client

# raw_pose/raw_state 直接来自与 LeRobot 一致的采集字段；无需任何几何换算。
observation = {
    "observation.tcp_pose": raw_pose,     # 12 个原始数值，或 [1,12]
    "observation.state": raw_state,      # 14 个原始数值，或 [1,14]
    "images": {
        "observation.images.head_image": head_rgb,
        "observation.images.left_wrist_image": left_wrist_rgb,
        "observation.images.right_wrist_image": right_wrist_rgb,
    },
    "instruction": "把盒子盖上",
    "timestamp": sensor_timestamp_seconds,
}
with Client(ns_host="192.168.1.10", ns_port=19092) as client:
    prediction = client.infer(observation)
    flange_trajectory = prediction["flange_pose"]  # [32,2,6]，各臂自身 base，毫米/度
    gripper_trajectory = prediction["gripper_raw"] # [32,2]，原始 1886/0 编码范围
    # 只需要原版动作块时，改用 client.inference_raw(observation)，不要再调用一次 infer。
```

`inference_raw` 返回 NumPy `[2,T,73]`。这是新增服务的原始字段接口，与旧服务同名方法接收 `DataRawVLA` 的协议不同，必须使用此目录下的 Client 和服务注册名配套连接。

`infer` 一次推理返回：

| 字段 | 含义 |
| --- | --- |
| `actions` | `[2,T,73]` 原版动作表示；仅前 10 维有效：xyz 米、旋转矩阵前两行 6D、夹爪张开度 |
| `world_tcp` | `[T,2,4,4]`，两个 TCP 都表达在左臂记录 base，平移米 |
| `gripper` | `[T,2]`，限制到 [0,1] 的张开度 |
| `flange_pose` | `[T,2,6]`，服务端逆变换回各臂记录 base 的法兰位姿，单位/欧拉角约定与输入一致 |
| `gripper_raw` | `[T,2]`，服务端逆变换回原始夹爪编码，连续浮点数 |
| `time_offsets/timestamps` | `[T]`，相对最新观测时间 / 加上传入 timestamp 后的采样时间 |
| `gripper_clipped_count` | 预测张开度越过 [0,1] 后被截断的元素数量 |

臂顺序始终左、右。当前 `action_offset=0`、30 Hz，因此 32 步覆盖 0 至 31/30 秒；第一点是观测时刻，不应把网络返回时刻重新当作第一个目标时刻。实际控制器需要处理推理延迟和已经过期的点。欧拉角存在等价表示，不能把相邻角度的数值差直接当作旋转距离。

## 文件回放与 ROS2

离线 NPZ 包含原始 `observation.tcp_pose`、`observation.state`、`rgb_0/1/2`（头、左腕、右腕）和可选标量 `timestamp`：

```bash
python -m lerobot_raw_inference.replay \
  --input raw_observation.npz --output prediction.npz \
  --prompt "把盒子盖上" --ns-host 192.168.1.10 --ns-port 19092
```

新增 ROS2 桥接器只采集、推理和发布预测：

```bash
python -m lerobot_raw_inference.ros2_client \
  --config lerobot_raw_inference/ros2.example.json \
  --prompt "把盒子盖上" --steps 0 --output-dir predictions
```

需要 ROS2、`sensor_msgs/std_msgs`、`cv_bridge`，并填写实际相机话题。状态话题是本版本新增的 **`std_msgs/String` JSON 契约**：包含 `timestamp`、`observation.tcp_pose`（12 个值）和 `observation.state`（14 个值），与上面 Python 观测字典的数值一致。它不是对现有机器人话题格式的猜测；机器人采集程序需要发布这三个字段，或直接调用 Python Client。三路图像使用 `sensor_msgs/Image`，状态时间和图像 header 时间必须同一时钟且同步；超时、陈旧或不同步输入会被拒绝。预测输出为 `std_msgs/String` JSON，字段与 `infer` 一致。本 ROS 桥当前针对 H=1。

## 验证

```bash
python -m pytest tests/test_lerobot_raw_inference.py tests/test_lerobot_pyro.py tests/test_hw_base_alignment.py -q
python -m lerobot_raw_inference.probe \
  --checkpoint /path/to/step_0100000 --output audits/raw_probe
```

probe 使用真实复核数据、完整 checkpoint、临时本地 Pyro4 服务及独立客户端进程，在 CPU 上比较原始字段路径和训练读取器路径的预测，并验证法兰/夹爪逆变换、时间、异常请求和客户端不加载 Torch。它不连接机器人。源码测试与实际机器人闭环测试是不同范围；此版本的机器人运动执行需在用户现有控制栈完成。
