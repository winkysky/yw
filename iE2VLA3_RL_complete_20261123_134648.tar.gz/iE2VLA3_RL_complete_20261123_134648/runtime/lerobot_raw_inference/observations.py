"""Sensor synchronization without base/tool/gripper conversion."""
import copy
import math
import threading
import numpy as np


class ObservationBuffer:
    def __init__(self, camera_keys, max_age=.5, max_skew=.02):
        self.camera_keys = list(camera_keys)
        if not all(math.isfinite(x) and x > 0 for x in [max_age,max_skew]):
            raise ValueError("max_age/max_skew must be positive")
        self.max_age, self.max_skew = max_age, max_skew
        self.lock, self.state, self.images = threading.Lock(), None, {}

    def add_state(self, packet):
        t = float(packet["timestamp"])
        poses, states = (np.asarray(packet[k]) for k in ["observation.tcp_pose", "observation.state"])
        if (not math.isfinite(t) or t < 0 or poses.shape not in [(12,),(1,12)]
                or states.shape not in [(14,),(1,14)] or not np.isfinite(poses).all() or not np.isfinite(states).all()):
            raise ValueError("Expected timestamp and one raw 12-value pose / 14-value state")
        with self.lock:
            if self.state is not None and t < self.state["timestamp"]:
                raise ValueError("Source state timestamp moved backwards")
            self.state = dict(timestamp=t, **{"observation.tcp_pose": poses.reshape(1,12).copy(),
                                            "observation.state": states.reshape(1,14).copy()})

    def add_image(self, key, rgb, timestamp):
        if key not in self.camera_keys or not math.isfinite(timestamp) or timestamp < 0:
            raise ValueError("Invalid camera key/timestamp")
        if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[-1] != 3 or 0 in rgb.shape:
            raise ValueError("Expected RGB uint8 HWC")
        with self.lock:
            self.images[key] = (float(timestamp), np.ascontiguousarray(rgb).copy())

    def snapshot(self, now, after=-1.):
        with self.lock:
            if self.state is None or set(self.images) != set(self.camera_keys):
                raise ValueError("Waiting for raw state and all three images")
            stamps = [self.state["timestamp"]] + [self.images[k][0] for k in self.camera_keys]
            if self.state["timestamp"] <= after:
                raise ValueError("Waiting for a new observation")
            if not math.isfinite(now) or now-min(stamps) > self.max_age or max(stamps)-now > self.max_skew:
                raise ValueError("Stale sensors or mismatched clocks")
            if max(stamps)-min(stamps) > self.max_skew:
                raise ValueError("Raw state and cameras are not synchronized")
            packet = copy.deepcopy(self.state)
            packet["images"] = {key:self.images[key][1].copy() for key in self.camera_keys}
            return packet
