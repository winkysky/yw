#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname -- "${BASH_SOURCE[0]}")/.."
exec "${IE2VLA_PYTHON:-python}" -u -m lerobot_raw_inference.service --start-ns "$@"
