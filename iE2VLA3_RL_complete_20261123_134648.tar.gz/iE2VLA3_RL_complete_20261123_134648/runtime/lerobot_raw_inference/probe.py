"""CPU full-checkpoint/socket test against real reviewed LeRobot observations.

python -m lerobot_raw_inference.probe --checkpoint ... --output audits/raw_probe
Owns temporary localhost servers; never connects to ROS or a robot.
"""
import argparse
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import threading

import numpy as np
import pyarrow.parquet as pq
import Pyro4
import Pyro4.naming
import torch

from dataset.lerobot_dual import decode_tcp, decode_gripper
from dataset.lerobot_reviewed import build_dataset
from .client import Client, encode_observation
from .service import Service, prepare_observation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--index", type=int, default=214)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    import cv2
    cv2.setNumThreads(1)
    print("Loading full checkpoint on CPU", flush=True)
    service = Service(args.checkpoint, "cpu")
    cfg = service.engine.data_config
    dataset = build_dataset(cfg)
    daemon = ns_daemon = None
    workers = []
    try:
        sample = dataset[args.index]
        before = copy.deepcopy(sample)
        metadata = sample._review_metadata
        reader = dataset.readers[metadata["dataset_id"]]
        table = pq.read_table(reader._path("data_path", metadata["episode_index"]),
                              columns=[cfg.state_pose_key, cfg.state_gripper_key]).to_pydict()
        frames = metadata["frame"] + np.arange(1-cfg.num_history_states, 1)*cfg.frame_stride
        observation = {key: np.asarray(table[key])[frames] for key in table}
        observation.update(instruction=sample.raw_vl.prompt, timestamp=1234.5,
                           images={key:rgb[0].permute(1,2,0).numpy()
                                   for key,rgb in zip(cfg.camera_keys,sample.raw_vl.rgb)})
        prepared, _ = prepare_observation(encode_observation(observation), cfg)
        for key in ["state", "state_mask", "action_mask", "action_ref_pose"]:
            torch.testing.assert_close(getattr(prepared,key),getattr(sample,key),rtol=0,atol=0)
        torch.testing.assert_close(prepared.raw_vl.K,sample.raw_vl.K,rtol=0,atol=0)
        for field in ["pose", "rgb"]:
            for a,b in zip(getattr(prepared.raw_vl,field),getattr(sample.raw_vl,field)):
                torch.testing.assert_close(a,b,rtol=0,atol=0)
        assert not prepared.action.any()
        seed = args.index + 42
        print("Comparing the dataset path with the raw-observation path", flush=True)
        expected = service.engine.inference_raw(sample,seed)
        np.testing.assert_array_equal(service.inference_raw(encode_observation(observation),seed),expected)
        arrays = {key:observation[key] for key in table}
        arrays.update(timestamp=observation["timestamp"], **{f"rgb_{i}":observation["images"][key]
                      for i,key in enumerate(cfg.camera_keys)})
        input_path, result_path = output/"observation.npz", output/"prediction.npz"
        np.savez_compressed(input_path, **arrays)
        Pyro4.config.SERIALIZERS_ACCEPTED = set(Pyro4.config.SERIALIZERS_ACCEPTED) | {"pickle"}
        _, ns_daemon, _ = Pyro4.naming.startNS(host="127.0.0.1",port=0,enableBroadcast=False)
        daemon = Pyro4.Daemon(host="127.0.0.1",port=0)
        name = "ie2vla3_raw_probe"
        ns_daemon.nameserver.register(name,daemon.register(service))
        for server in [ns_daemon,daemon]:
            worker = threading.Thread(target=server.requestLoop,daemon=True)
            worker.start()
            workers.append(worker)
        port = ns_daemon.sock.getsockname()[1]
        env = dict(os.environ)
        env.pop("PYTHONPATH",None)
        print("Calling through an independent NumPy-only TCP client", flush=True)
        process = subprocess.run([sys.executable,"-m","lerobot_raw_inference.replay",
            "--input",str(input_path),"--output",str(result_path),"--prompt",sample.raw_vl.prompt,
            "--uri",name,"--ns-port",str(port),"--seed",str(seed)],
            cwd=Path(__file__).resolve().parents[1],env=env,capture_output=True,text=True,timeout=120)
        (output/"client.log").write_text(process.stdout+process.stderr)
        if process.returncode:
            raise RuntimeError(process.stdout+process.stderr)
        client_info = json.loads(process.stdout.strip().splitlines()[-1])
        assert client_info["torch_loaded"] is False
        with np.load(result_path) as result:
            np.testing.assert_array_equal(result["actions"],expected)
            restored = decode_tcp(result["flange_pose"].reshape(-1,12),cfg)
            np.testing.assert_allclose(restored,result["world_tcp"],atol=1e-6)
            state = np.zeros((cfg.num_future_actions,14))
            state[:,cfg.gripper_indices] = result["gripper_raw"]
            np.testing.assert_allclose(decode_gripper(state,cfg),result["gripper"],atol=1e-7)
            np.testing.assert_allclose(result["timestamps"],1234.5+np.arange(cfg.num_future_actions)/30.,atol=1e-12)
            assert result["time_offsets"][0] == 0.
        with Client(name,ns_port=port) as client:
            # A raw single LeRobot row also works; history dimension is packed on the server.
            single = dict(observation)
            if cfg.num_history_states == 1:
                for key in table:
                    single[key] = single[key][0]
            np.testing.assert_array_equal(client.inference_raw(single,seed),expected)
            for key,value in [("world_tcp",[]),("action",[]),("observation.state",[[0.]])]:
                try:
                    client.inference_raw(dict(observation,**{key:value}),seed)
                except ValueError:
                    pass
                else:
                    raise AssertionError(f"Accepted invalid field: {key}")
            assert client.proxy.get_policy_info()["step"] == service.engine.policy_info["step"]
        torch.testing.assert_close(sample.state,before.state,rtol=0,atol=0)
        torch.testing.assert_close(sample.action,before.action,rtol=0,atol=0)
        report = dict(checkpoint_step=service.engine.policy_info["step"],sample_index=args.index,
                      seed=seed,client=client_info,device="cpu",raw_prediction_max_abs_diff=0.,
                      state_and_camera_geometry_exactly_match_training=True,
                      flange_and_gripper_inverse_roundtrip=True,invalid_requests_rejected=True,
                      timestamp_zero_offset_preserved=True,input_unchanged=True,hardware_connected=False)
        (output/"validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
        print(json.dumps(report,ensure_ascii=False),flush=True)
    finally:
        dataset.close()
        for server in [daemon,ns_daemon]:
            if server is not None:
                server.shutdown()
                server.close()
        for worker in workers:
            worker.join(timeout=3.)


if __name__ == "__main__":
    main()
