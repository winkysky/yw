"""File client: original observation.tcp_pose/state and rgb_0..2 in an NPZ."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
from .client import Client


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prompt", required=True)
    parser.add_argument("--uri", default="ie2vla3_raw_lerobot")
    parser.add_argument("--ns-host", default="127.0.0.1")
    parser.add_argument("--ns-port", type=int, default=19092)
    parser.add_argument("--seed", type=int)
    args = parser.parse_args(argv)
    with Client(args.uri, args.ns_host, args.ns_port) as client:
        with np.load(args.input, allow_pickle=False) as packet:
            observation = {key: packet[key] for key in ["observation.tcp_pose", "observation.state"]}
            observation.update(instruction=args.prompt, timestamp=float(packet["timestamp"]) if "timestamp" in packet else 0.,
                               images={key: packet[f"rgb_{i}"] for i,key in enumerate(client.data_config["camera_keys"])})
            result = client.infer(observation, args.seed)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(args.output, **{k:v for k,v in result.items() if isinstance(v,np.ndarray)})
        print(json.dumps(dict(output=str(args.output), shape=list(result['actions'].shape),
                              step=client.info["step"], torch_loaded="torch" in sys.modules)), flush=True)


if __name__ == "__main__":
    main()
