"""Robot-side client: pass original numeric fields and RGB, with no geometry math."""
import copy
import math

import numpy as np

PROTOCOL = "ie2vla3_raw_lerobot_v1"


def encode_observation(observation):
    """Only change wire representation; all numeric values retain their units."""
    request = dict(observation)
    request["protocol"] = PROTOCOL
    for key in ("observation.tcp_pose", "observation.state"):
        request[key] = np.asarray(request[key]).tolist()
    images = {}
    for key, image in request["images"].items():
        rgb = np.asarray(image)
        if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[-1] != 3 or 0 in rgb.shape:
            raise ValueError(f"{key}: expected RGB uint8 [H,W,3]")
        images[key] = dict(shape=list(rgb.shape), rgb_bytes=np.ascontiguousarray(rgb).tobytes())
    request["images"] = images
    if "timestamp" in request:
        request["timestamp"] = float(request["timestamp"])
    return request


class Client:
    def __init__(self, uri_name="ie2vla3_raw_lerobot", ns_host="127.0.0.1", ns_port=19092, timeout=30.):
        import Pyro4
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be positive")
        old = Pyro4.config.COMMTIMEOUT
        self.proxy = None
        try:
            Pyro4.config.COMMTIMEOUT = timeout
            with Pyro4.locateNS(host=ns_host, port=ns_port) as ns:
                address = ns.lookup(uri_name)
            self.proxy = Pyro4.Proxy(address)
            self.proxy._pyroSerializer = "pickle"
            self.proxy._pyroTimeout = timeout
            self.info = self.proxy.get_policy_info()
            if self.info.get("protocol") != PROTOCOL:
                raise ValueError("Use python -m lerobot_raw_inference.service")
        except BaseException:
            self.close()
            raise
        finally:
            Pyro4.config.COMMTIMEOUT = old

    @property
    def data_config(self):
        return copy.deepcopy(self.info["data_config"])

    def inference_raw(self, observation, seed=None):
        """Original-style action block API, float32 [2,horizon,73]."""
        value = np.asarray(self.proxy.inference_raw(encode_observation(observation), seed=seed), dtype=np.float32)
        if list(value.shape) != self.info["output_shape"] or not np.isfinite(value).all():
            raise ValueError("Invalid action block returned by server")
        return value

    def infer(self, observation, seed=None):
        """Also return server-decoded TCPs, raw-base flange commands and timing."""
        response = self.proxy.infer(encode_observation(observation), seed=seed)
        if response.get("protocol") != PROTOCOL:
            raise ValueError("Response protocol mismatch")
        for key in ("actions", "world_tcp", "gripper", "flange_pose", "gripper_raw", "time_offsets", "timestamps"):
            response[key] = np.asarray(response[key], dtype=np.float32 if key == "actions" else np.float64)
            if not np.isfinite(response[key]).all():
                raise ValueError(f"Nonfinite response: {key}")
        h = self.info["data_config"]["num_future_actions"]
        shapes = dict(actions=(2,h,73), world_tcp=(h,2,4,4), gripper=(h,2),
                      flange_pose=(h,2,6), gripper_raw=(h,2), time_offsets=(h,), timestamps=(h,))
        if any(response[key].shape != shape for key, shape in shapes.items()):
            raise ValueError("Response shape mismatch")
        return response

    def close(self):
        if self.proxy is not None:
            self.proxy._pyroRelease()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
