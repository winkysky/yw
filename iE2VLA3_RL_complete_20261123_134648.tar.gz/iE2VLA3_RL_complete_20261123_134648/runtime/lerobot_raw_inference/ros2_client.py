"""Subscribe to raw LeRobot JSON + RGB; return predictions without robot motion."""
import argparse
import json
from pathlib import Path
import threading
import time
import numpy as np
from .client import Client
from .observations import ObservationBuffer


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--prompt", required=True)
    parser.add_argument("--steps", type=int, default=1, help="0: repeat until Ctrl-C")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--seed", type=int)
    args = parser.parse_args(argv)
    if args.steps < 0 or not args.prompt.strip():
        parser.error("steps must be nonnegative and prompt nonempty")
    config = json.loads(args.config.read_text())
    import rclpy
    from rclpy.node import Node
    from rclpy.executors import SingleThreadedExecutor
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import Image
    from std_msgs.msg import String
    from cv_bridge import CvBridge

    with Client(**config["server"]) as client:
        if client.data_config["num_history_states"] != 1:
            raise ValueError("This ROS bridge captures one state; use the Python client for longer histories")
        keys = client.data_config["camera_keys"]
        if set(config["image_topics"]) != set(keys):
            raise ValueError("image_topics must match checkpoint camera_keys")
        timeout = float(config["observation_timeout_s"])
        if not np.isfinite(timeout) or timeout <= 0:
            raise ValueError("observation_timeout_s must be positive")
        buffer = ObservationBuffer(keys, config["max_sensor_age_s"], config["max_sensor_skew_s"])
        rclpy.init()
        node = Node("ie2vla3_raw_observation_client")
        bridge = CvBridge()
        errors = []

        def on_state(message):
            try:
                buffer.add_state(json.loads(message.data))
            except Exception as exc:
                node.get_logger().error(str(exc))

        def on_image(message, key):
            try:
                stamp = message.header.stamp.sec + message.header.stamp.nanosec / 1e9
                buffer.add_image(key, bridge.imgmsg_to_cv2(message, desired_encoding="rgb8"), stamp)
            except Exception as exc:
                node.get_logger().error(str(exc))

        subscriptions = [node.create_subscription(String, config["state_topic"], on_state, qos_profile_sensor_data)]
        subscriptions += [node.create_subscription(Image, config["image_topics"][key],
                          lambda msg,key=key:on_image(msg,key), qos_profile_sensor_data) for key in keys]
        publisher = node.create_publisher(String, config["prediction_topic"], 10)
        executor = SingleThreadedExecutor()
        executor.add_node(node)
        def spin():
            try:
                executor.spin()
            except BaseException as exc:
                errors.append(exc)
        worker = threading.Thread(target=spin, daemon=True)
        worker.start()
        try:
            cycle, last = 0, -1.
            while rclpy.ok() and (args.steps == 0 or cycle < args.steps):
                deadline = time.monotonic() + timeout
                while True:
                    if errors:
                        raise RuntimeError("ROS executor failed") from errors[0]
                    try:
                        packet = buffer.snapshot(node.get_clock().now().nanoseconds / 1e9, last)
                        break
                    except ValueError as exc:
                        if time.monotonic() >= deadline:
                            raise TimeoutError(str(exc)) from exc
                        time.sleep(.02)
                packet["instruction"] = args.prompt
                result = client.infer(packet, args.seed)
                message = String()
                message.data = json.dumps({k:v.tolist() if isinstance(v,np.ndarray) else v for k,v in result.items()})
                publisher.publish(message)
                if args.output_dir:
                    args.output_dir.mkdir(parents=True, exist_ok=True)
                    np.savez_compressed(args.output_dir / f"prediction_{cycle:06d}.npz",
                                        **{k:v for k,v in result.items() if isinstance(v,np.ndarray)})
                last = packet["timestamp"]
                print(f"cycle={cycle} observation={last:.6f} shape={result['actions'].shape}", flush=True)
                cycle += 1
        except KeyboardInterrupt:
            pass
        finally:
            executor.shutdown(timeout_sec=3.)
            worker.join(timeout=3.)
            node.destroy_node()
            if rclpy.ok():
                rclpy.shutdown()


if __name__ == "__main__":
    main()
