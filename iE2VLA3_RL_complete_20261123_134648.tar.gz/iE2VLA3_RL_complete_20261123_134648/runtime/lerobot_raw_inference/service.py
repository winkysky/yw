"""New raw-observation service; the existing training/inference files are reused read-only."""
import argparse
import math
import signal
import threading
import time

import numpy as np
import Pyro4
import Pyro4.naming
from scipy.spatial.transform import Rotation
import torch

from action.parser import ProprioParser
from data_utils.tokenize import BatchDataTokenizedVLA
from models.m0512_fm.service_lerobot import Service as FullModel
from models.m0512_fm.lerobot_inference import observation_to_sample, infer_batch
from shm_transport import expose, run_simple_server
from .client import PROTOCOL


def prepare_observation(observation, config):
    if not isinstance(observation, dict) or observation.get("protocol", PROTOCOL) != PROTOCOL:
        raise ValueError("Expected raw LeRobot observation protocol")
    allowed = {"protocol", "observation.tcp_pose", "observation.state", "images", "instruction", "timestamp"}
    if set(observation) - allowed:
        raise ValueError("Only original LeRobot numeric fields, images, instruction and optional timestamp are accepted")
    timestamp = observation.get("timestamp", 0.)
    if isinstance(timestamp, bool) or not isinstance(timestamp, (float, int)) or not math.isfinite(timestamp) or timestamp < 0:
        raise ValueError("timestamp must be a finite nonnegative number of seconds")
    observation = dict(observation)
    for key, width in [("observation.tcp_pose", 12), ("observation.state", 14)]:
        if key not in observation:
            raise ValueError(f"Missing observation field: {key}")
        values = np.asarray(observation[key], dtype=np.float64)
        if values.shape == (width,) and config.num_history_states == 1:
            values = values[None]
        if values.shape != (config.num_history_states, width) or not np.isfinite(values).all():
            raise ValueError(f"{key} must be finite [{config.num_history_states},{width}] raw values")
        observation[key] = values
    # decode_tcp applies units -> base_to_world -> tool offset exactly once;
    # decode_gripper and apply_geometry match the training data reader.
    sample = observation_to_sample(observation, config)
    return sample, float(timestamp)


def decode_actions(actions, config, timestamp):
    poses = ProprioParser(torch.from_numpy(actions)).posemat.numpy().swapaxes(0, 1)
    grip_original = actions[..., 9].T
    grip = np.clip(grip_original, 0., 1.)
    flange = np.linalg.inv(np.asarray(config.base_to_world))[None] @ poses @ np.linalg.inv(np.asarray(config.pose_to_tcp))[None]
    euler = Rotation.from_matrix(flange[..., :3, :3].reshape(-1,3,3)).as_euler(config.euler_order, degrees=config.angle_degrees)
    flange_pose = np.concatenate([flange[..., :3,3] / config.position_scale, euler.reshape(len(poses),2,3)], axis=-1)
    gripper_raw = np.asarray(config.gripper_closed) + grip * (np.asarray(config.gripper_open) - config.gripper_closed)
    offsets = (config.action_offset + np.arange(len(poses)) * config.frame_stride) / 30.
    return dict(protocol=PROTOCOL, actions=actions.tolist(), world_tcp=poses.tolist(),
                gripper=grip.tolist(), flange_pose=flange_pose.tolist(), gripper_raw=gripper_raw.tolist(),
                time_offsets=offsets.tolist(), timestamps=(timestamp + offsets).tolist(),
                gripper_clipped_count=int(np.count_nonzero(grip_original != grip)),
                output_frame="left_recorded_arm_base", flange_frame="each_arm_recorded_base",
                arm_order=["left", "right"])


class Service:
    def __init__(self, checkpoint, device="cpu"):
        self.engine = FullModel(checkpoint, device)
        cfg = self.engine.data_config
        if (cfg.pose_format != "xyz_euler" or cfg.state_pose_key != "observation.tcp_pose"
                or cfg.state_gripper_key != "observation.state"):
            raise ValueError("This entry requires the current HW xyz_euler LeRobot convention")

    @expose(en_ret_sh_cuda=False)
    def get_policy_info(self):
        info = self.engine.get_policy_info()
        for key in ("world_observation_contract", "world_observation_wire"):
            info.pop(key, None)
        info.update(protocol=PROTOCOL, input_contract=PROTOCOL,
                    input_frame="each_arm_recorded_base", input_pose="recorded_flange",
                    preprocessing="server", stateless=True)
        return info

    @expose(en_ret_sh_cuda=False)
    def get_data_config(self):
        return self.engine.data_config.to_dict()

    def _predict(self, observation, seed):
        sample, timestamp = prepare_observation(observation, self.engine.data_config)
        with self.engine.model_lock:
            batch = BatchDataTokenizedVLA(**self.engine.collator([sample]))
            actions = infer_batch(self.engine.model, batch, self.engine.device, seed)[0].numpy()
        return actions, timestamp

    @expose(en_ret_sh_cuda=False)
    def inference_raw(self, observation, seed=None):
        return self._predict(observation, seed)[0].tolist()

    @expose(en_ret_sh_cuda=False)
    def infer(self, observation, seed=None):
        started = time.monotonic()
        actions, timestamp = self._predict(observation, seed)
        result = decode_actions(actions, self.engine.data_config, timestamp)
        result["inference_seconds"] = time.monotonic() - started
        return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--uri", default="ie2vla3_raw_lerobot")
    parser.add_argument("--ns-host", default="127.0.0.1")
    parser.add_argument("--ns-port", type=int, default=19092)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=19093)
    parser.add_argument("--start-ns", action="store_true")
    args = parser.parse_args(argv)
    if args.threads < 1:
        parser.error("threads must be positive")
    torch.set_num_threads(args.threads)
    import cv2
    cv2.setNumThreads(1)
    owned_ns = None
    stop = threading.Event()
    previous = signal.signal(signal.SIGTERM, lambda *_: stop.set())
    try:
        try:
            ns = Pyro4.locateNS(host=args.ns_host, port=args.ns_port)
        except Pyro4.errors.NamingError:
            if not args.start_ns:
                raise
            _, owned_ns, _ = Pyro4.naming.startNS(host=args.ns_host, port=args.ns_port, enableBroadcast=False)
            threading.Thread(target=owned_ns.requestLoop, daemon=True).start()
            ns = Pyro4.locateNS(host=args.ns_host, port=args.ns_port)
        with ns:
            if args.uri in ns.list():
                raise ValueError("Service name already registered; choose another --uri")
        service = Service(args.checkpoint, args.device)
        print(f"Loaded step {service.engine.policy_info['step']}; raw LeRobot service {args.uri}", flush=True)
        run_simple_server(service, uri_name=args.uri, ns_host=args.ns_host, ns_port=args.ns_port,
                          daemon_host=args.host, daemon_port=args.port, replace_existing=False,
                          loop_cond=lambda: not stop.is_set())
    finally:
        signal.signal(signal.SIGTERM, previous)
        if owned_ns is not None:
            owned_ns.shutdown()
            owned_ns.close()


if __name__ == "__main__":
    main()
