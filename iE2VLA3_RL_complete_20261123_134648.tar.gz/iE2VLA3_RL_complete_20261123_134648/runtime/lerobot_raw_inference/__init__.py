"""Additive raw LeRobot -> Pyro4 -> full iE2VLA3 inference entry points."""
