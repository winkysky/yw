"""No-speed VLA plus independently trainable chunk residual SAC."""
