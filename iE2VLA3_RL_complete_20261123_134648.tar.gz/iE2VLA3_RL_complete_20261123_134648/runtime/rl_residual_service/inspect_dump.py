"""Inspect the exact baseline/corrected trajectories from one server inference."""
import argparse
import json
import numpy as np


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("path")
    p.add_argument("--expect-mm",type=float)
    p.add_argument("--arm",choices=["left","right"],default="left")
    p.add_argument("--axis",choices=["x","y","z"],default="x")
    args=p.parse_args(argv)
    with np.load(args.path,allow_pickle=False) as saved:
        base,corrected=saved["base_actions"],saved["corrected_actions"]
        a,b=base[...,:16].reshape(32,2,4,4),corrected[...,:16].reshape(32,2,4,4)
        delta=(a[...,:3,:3].swapaxes(-1,-2)@(b[...,:3,3]-a[...,:3,3])[...,None])[...,0]*1000
        if args.expect_mm is not None:
            expected=np.zeros_like(delta)
            expected[:,0 if args.arm=="left" else 1,"xyz".index(args.axis)]=args.expect_mm
            np.testing.assert_allclose(delta,expected,atol=.002,rtol=.001)
        print(json.dumps(dict(chunk_id=str(saved["chunk_id"]),anchor=float(saved["anchor"]),
            local_translation_mm_mean=delta.mean(0).tolist(),local_translation_mm_min=delta.min(0).tolist(),
            local_translation_mm_max=delta.max(0).tolist(),
            rotation_unchanged=bool(np.array_equal(a[...,:3,:3],b[...,:3,:3])),
            gripper_unchanged=bool(np.array_equal(base[...,16],corrected[...,16])),
            expected_translation_passed=args.expect_mm is not None),indent=2))


if __name__=="__main__":
    main()
