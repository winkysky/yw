"""No-speed base + residual SAC; zero/probe modes need only the base checkpoint."""
import argparse
from dataclasses import replace
import json
import math
from pathlib import Path
import signal
import threading
import cv2
import torch
import Pyro4
import Pyro4.naming
from e2vla_compat.config import PlannerConfig
from models.m0512_fm.lerobot_inference import load_checkpoint
from rl_factor_sac.config import SACConfig
from rl_factor_sac.reward import RewardConfig
from rl_chunk_service.feedback import FeedbackReader
from rl_chunk_service.online import OnlineLearner
from rl_chunk_service.service import Service
from shm_transport import run_simple_server
from .policy import Policy


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path)
    p.add_argument("--checkpoint", "--ckpt", required=True)
    p.add_argument("--mode", choices=["zero","probe","inference","collect","train"], default="zero")
    p.add_argument("--token", type=Path)
    p.add_argument("--rl-checkpoint", type=Path)
    p.add_argument("--feedback", type=Path)
    p.add_argument("--output", type=Path, required=True, help="New directory for this run")
    p.add_argument("--sac-config", type=Path)
    p.add_argument("--reward-config", type=Path)
    p.add_argument("--source", choices=["robot","simulator"], default="robot")
    p.add_argument("--probe-mm", type=float, default=.25)
    p.add_argument("--probe-arm", choices=["left","right"], default="left")
    p.add_argument("--probe-axis", choices=["x","y","z"], default="x")
    p.add_argument("--dump-predictions", action="store_true")
    p.add_argument("--task", choices=["close_box","open_box","place_phone"])
    for name in ("device","prompt","uri","host","ns-host","input-pose-format","input-gripper-format"):
        p.add_argument("--"+name)
    for name in ("port","ns-port","threads","seed","inference-timesteps"):
        p.add_argument("--"+name,type=int)
    p.add_argument("--variant",choices=["no_speed"])
    p.add_argument("--bf16",action="store_true",default=None)
    p.add_argument("--speed-mps",type=float)
    p.add_argument("--guidance-scale",type=float)
    p.add_argument("--start-ns",action="store_true")
    p.add_argument("--autostart",action="store_true")
    p.add_argument("--max-inference-hz",type=float,default=0.)
    p.add_argument("--batch-size",type=int,default=32)
    p.add_argument("--warmup",type=int,default=32)
    p.add_argument("--save-every",type=int,default=100)
    p.add_argument("--max-policy-lag",type=int,default=1000)
    p.add_argument("--check-config",action="store_true")
    args=p.parse_args(argv)
    diagnostic=args.mode in ("zero","probe")
    if diagnostic and any((args.token,args.rl_checkpoint,args.feedback)):
        p.error("zero/probe use no token/SAC/feedback; use inference/collect/train for real policies")
    if not diagnostic and not all((args.token,args.rl_checkpoint,args.feedback)):
        p.error("inference/collect/train require --token, --rl-checkpoint and --feedback")
    if not math.isfinite(args.probe_mm) or not 0<abs(args.probe_mm)<=.5:
        p.error("--probe-mm must be nonzero and at most 0.5 mm in magnitude")
    if (not math.isfinite(args.max_inference_hz) or args.max_inference_hz<0
            or min(args.batch_size,args.warmup,args.save_every)<1 or args.max_policy_lag<0):
        p.error("Invalid rate/training parameters")
    config=PlannerConfig.load(args.config) if args.config else PlannerConfig(uri="e2vla_residual",port=9103)
    config=replace(config,**{k:v for k,v in vars(args).items() if k in config.__dataclass_fields__ and v is not None}).validate()
    if not config.task or (args.autostart and not config.prompt):
        p.error("Supply --task and --prompt when using --autostart")
    reward=RewardConfig(**json.loads(args.reward_config.read_text())) if args.reward_config else RewardConfig()
    sac_config=SACConfig.load(args.sac_config) if args.sac_config else None
    if args.check_config:
        saved,path=load_checkpoint(config.checkpoint)
        if not diagnostic:
            from .artifacts import artifact_bindings, ResidualSAC
            bindings,_=artifact_bindings(config.checkpoint,args.token,reward)
            ResidualSAC.load(args.rl_checkpoint,"cpu",bindings)
        print(json.dumps(dict(mode=args.mode,checkpoint=str(path),step=saved["step"],planner=config.to_dict()),indent=2))
        return
    if args.feedback and args.feedback.resolve().is_relative_to(args.output.resolve()):
        p.error("Keep the feedback inbox outside the output directory")
    args.output.mkdir(parents=True,exist_ok=False)
    torch.set_num_threads(config.threads);cv2.setNumThreads(1)
    from shm_transport.shm_mng import register_cleanup_this_process
    register_cleanup_this_process()
    stopped=threading.Event()
    handlers={sig:signal.signal(sig,lambda *_:stopped.set()) for sig in (signal.SIGINT,signal.SIGTERM)}
    owned_ns=service=reader=trainer=None
    try:
        try:
            ns=Pyro4.locateNS(host=config.ns_host,port=config.ns_port)
        except Pyro4.errors.NamingError:
            if not args.start_ns: raise
            _,owned_ns,_=Pyro4.naming.startNS(host=config.ns_host,port=config.ns_port,enableBroadcast=False)
            threading.Thread(target=owned_ns.requestLoop,daemon=True).start()
            ns=Pyro4.locateNS(host=config.ns_host,port=config.ns_port)
        with ns:
            if config.uri in ns.list():
                raise ValueError(f"Service name occupied: {config.uri}; refusing to replace it")
        policy=Policy.load(config,args.token,args.rl_checkpoint,mode=args.mode,source=args.source,
            journal=args.output/"proposals.jsonl",reward=reward,sac_config=sac_config,
            probe_mm=args.probe_mm,probe_arm=args.probe_arm,probe_axis=args.probe_axis,
            dump_path=args.output/"last_prediction.npz" if args.dump_predictions else None)
        service=Service(policy,config,max_inference_hz=args.max_inference_hz)
        (args.output/"service.json").write_text(json.dumps(service.get_info(),indent=2))
        if not diagnostic:
            reader=FeedbackReader(args.feedback,policy.session)
            trainer=OnlineLearner(policy.session,args.output,batch_size=args.batch_size,warmup=args.warmup,
                save_every=args.save_every,max_policy_lag=args.max_policy_lag)
        if args.autostart: service.start_async()
        print(json.dumps(dict(status="ready",mode=args.mode,uri=config.uri,output=str(args.output))),flush=True)
        run_simple_server(service,uri_name=config.uri,daemon_host=config.host,daemon_port=config.port,
            ns_host=config.ns_host,ns_port=config.ns_port,multiplex=False,replace_existing=False,
            loop_cond=lambda:not stopped.is_set())
    finally:
        try:
            if reader is not None: reader.close()
            if trainer is not None: trainer.close()
        finally:
            try:
                if service is not None: service.close()
            finally:
                if owned_ns is not None:
                    owned_ns.shutdown();owned_ns.close()
                for sig,handler in handlers.items():signal.signal(sig,handler)


if __name__=="__main__":
    main()
