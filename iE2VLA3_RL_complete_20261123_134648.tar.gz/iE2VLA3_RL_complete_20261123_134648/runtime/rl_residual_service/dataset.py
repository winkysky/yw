"""Native 32-row windows for token training, with no tempo augmentation."""
import hashlib
import numpy as np
from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityConfig, LeRobotRetimedVelocityDataset


class NativeTokenDataset(LeRobotRetimedVelocityDataset):
    def __init__(self, config):
        # Reuse calibrated source discovery and episode/group bookkeeping.
        # _add and numeric_sample below replace ALL four-factor window logic.
        super().__init__(LeRobotRetimedVelocityConfig(**config.to_dict()))
        self.fingerprint = hashlib.sha256((self.fingerprint+":native_rows32_v1").encode()).hexdigest()

    def _add(self, reader, ep, frames, prompt, episode_key):
        if not any(x is reader for x in self.readers):
            self.readers.append(reader)
        rid = next(i for i,x in enumerate(self.readers) if x is reader)
        columns = self.columns(reader, ep)
        allowed = np.zeros(len(columns["timestamp"]), dtype=bool)
        allowed[frames] = True
        frames = np.asarray(frames, np.int64)
        frames = frames[(frames >= self.config.num_history_states-1) & (frames+31 < len(allowed))]
        lo, hi = frames-self.config.num_history_states+1, frames+31
        invalid = np.r_[0, np.cumsum(~allowed)]
        changes = np.r_[0, np.cumsum(np.diff(columns["task_index"]) != 0)]
        valid = (invalid[hi+1] == invalid[lo]) & (changes[hi] == changes[lo])
        if prompt is None and columns.get("prompt") is not None:
            text = np.asarray(columns["prompt"], str)
            changes = np.r_[0, np.cumsum(text[1:] != text[:-1])]
            valid &= changes[hi] == changes[lo]
        frames = frames[valid].astype(np.int32)
        if len(frames):
            self.blocks.append(dict(reader=rid, ep=ep, frames=frames, factor=1., prompt=prompt, episode_key=episode_key))
            self.ends.append(len(self)+len(frames))
            self.counts["1.0"] += len(frames)

    def numeric_sample(self, index):
        block, frame = self.locate(index)
        reader = self.readers[block["reader"]]
        c = self.columns(reader, block["ep"])
        history = np.arange(frame-self.config.num_history_states+1, frame+1)
        future = np.arange(frame, frame+32)
        return dict(history_pose=c["state_pose"][history], history_gripper=c["state_gripper"][history],
                    action_pose=c["action_pose"][future], action_gripper=c["action_gripper"][future],
                    speed_factor=np.float32(1.), frame=frame, episode_key=block["episode_key"])
