# 基础模型独立运行：残差联调与只训练连续 SAC

这版可以直接加载已有**无速度全量 checkpoint**，不需要先训练倍率 VLA。原模型、原服务端、正在运行的训练及已有 checkpoint 都不修改。新增入口是 `python -m rl_residual_service.remote_service`，客户端原同步/异步接口和数据格式保留，默认 recorded/raw。

## 现在没有 RL token，怎样最快验证迁移

先用 `zero` 或 `probe`。这两种模式**只需要基础模型 checkpoint**，不需要 RL token 权重、SAC 权重、ROS 力话题、执行反馈或奖励。它们不会训练，也不能保存训练回放/策略权重。

| 模式 | 返回轨迹 | 所需文件/反馈 |
|---|---|---|
| `zero`（默认） | SAC actor 均值为零，返回基础轨迹，用于接口对照 | 基础 checkpoint |
| `probe` | SAC actor 的输出头设置可复现的小偏移，经正常 actor、残差合成和 Pyro4 路径返回 | 基础 checkpoint |
| `inference` | 已训练残差策略的确定性输出 | 基础 ckpt、对应 token、残差 SAC、真实力；执行 ACK 用于跟踪上一段 |
| `collect` | 随机策略采样，只收集执行回放 | 上述权重、力、执行 ACK、任务结果 |
| `train` | 随机策略采样并更新**仅连续残差 SAC** | 同 collect |

`probe` 默认左臂 **TCP 局部 x 方向固定 +0.25 mm**，同一 chunk 的 32 点各施加一次。0.25 mm 是可观察的测试信号，**不是正式 SAC 的最大残差**。右臂、旋转和夹爪不变。它通过设置未训练 actor 的输出偏置产生，不能理解为已经学会修正。不会在服务器内部把这个偏移逐 chunk 累加。

正式残差 SAC 默认：平移每轴 ±5 mm，旋转向量每轴 ±0.05 rad；相邻**已执行** chunk 之间每轴最多变化 1 mm / 0.01 rad。`probe` 参数单独限制为绝对值不超过 0.5 mm；这也是联调限制，不改变正式训练的边界。

在测试机器进入完整代码根目录，沿用原模型环境。目录名可以不同，需包含 `e2vla_compat`、`e2vla_async`、模型、数据和通信依赖；**只复制 `rl_residual_service` 一个目录不够**。新增代码依赖 `rl_chunk_service`、`rl_factor_sac`、`models/speed_factor.py`；token 训练还使用当前数据读取/窗口代码。最稳妥的是同步当前完整代码（排除 checkpoint），权重路径继续指向测试机器已有基础模型。

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3
python -m rl_residual_service.remote_service --help

BASE=/绝对路径/现有基础模型/step_0100000
```

先启动零残差服务：

```bash
python -m rl_residual_service.remote_service \
  --checkpoint "$BASE" --task close_box --device cuda:0 \
  --mode zero --seed 42 \
  --uri e2vla --host 127.0.0.1 --port 9101 \
  --ns-host 127.0.0.1 --ns-port 9090 --start-ns \
  --input-pose-format recorded --input-gripper-format raw \
  --dump-predictions --output runs/residual_zero_001
```

URI/地址/端口使用**现有客户端原来连接的值**；上面只是旧服务的默认值。新服务拒绝占用已经注册的服务名，不自动停止或替换旧服务。若只旁路部署、不接原客户端，可以不传 URI/port，默认是 `e2vla_residual:9103`。`--output` 必须是尚不存在的新目录。

客户端继续执行原来的 `set_prompt → add_obs_frame(s) → get_action`，或原 batch/异步调用。`--task` 与客户端任务路由保持一致，任务文字仍由原客户端设置。原客户端若已经发送 world TCP/openness，则保持它原来的 `--input-pose-format tcp_world --input-gripper-format openness`，不能重复做 recorded/raw 转换。

确认连接和返回正常后，退出**本测试服务**，将上面命令中的参数改为：

```text
--mode probe --probe-mm 0.25 --probe-arm left --probe-axis x
--output runs/residual_probe_001
```

其余参数相同。这时客户端收到的就是带测试偏移的轨迹；先在客户端已有可视化或不下发机器人命令的流程检查。服务器不会新增一个机器人控制通道。

不用靠肉眼判断 0.25 mm：每次推理可在 `last_prediction.npz` 中保留**同一次推理**的基础/修正轨迹。它只保留最近一次，不会不断堆积文件。

```bash
# zero：期望全零差异
python -m rl_residual_service.inspect_dump \
  runs/residual_zero_001/last_prediction.npz --expect-mm 0

# probe：期望左臂局部 x 每点 +0.25 mm，右臂和其他轴为零
python -m rl_residual_service.inspect_dump \
  runs/residual_probe_001/last_prediction.npz \
  --expect-mm 0.25 --arm left --axis x
```

脚本打印局部位移的均值/最小/最大值、旋转/夹爪是否保持不变；误差超过容差会失败。右臂测试使用 `--probe-arm right`，负方向使用负 `--probe-mm`。日志中的 `proposal` 表示生成的候选动作，不表示机器人已经执行。

验收分三层：服务 `ready` 说明模型和程序加载成功；客户端收到正确 shape/时间戳且对照数值正确，说明推理接口已通；机器人是否按期望执行还取决于客户端插值、融合、IK 和控制器。前两层无需 RL token；它们不验证奖励或学习效果。

## 正式只训练残差 SAC

倍率 SAC 完全不构建、不更新、不保存；内部保留的 `factor=1`/`versions.factor=0` 只是复用执行账本的接口常量，不向基础模型增加速度条件。

正式策略输入为：已训练 token、双臂真实绝对 state、过去 8 点力/力矩、当前基础轨迹和执行上下文。输出每个 chunk 一组双臂 12 维局部 TCP 残差，不改变夹爪。基础 VLA 和 RL token 在在线 SAC 阶段冻结；轨迹仍为 32 点、30 Hz，残差按 chunk 决策。

### 1. 单独训练基础模型对应的 RL token

无需重新训练基础 VLA。该入口只训练外部 token 编码器/解码器，用当前基础模型的视觉语言特征重建损失和动作辅助损失。数据使用原始 32 行动作窗口，**不做倍率增强**，按物理 episode 划分验证集；分组数据仍保留组间等频采样。

```bash
python -m rl_residual_service.train_token \
  --base "$BASE" --output /绝对路径/no_speed_token_run \
  --steps 10000 --batch-size 4 --workers 2 --device cuda:0

# 可选：数据目录不在原 checkpoint 配置位置时，追加 --data-root /实际数据目录。
# 恢复 token 训练：追加 --resume /.../token_005000.pt，--steps 表示总目标步数。
```

10000 是命令示例，不是保证收敛的步数，应看验证损失。保存格式为 `ie2vla_no_speed_rl_token_v1`，绑定基础模型 SHA256；不能随意换另一个 ckpt 的 token。

### 2. 初始化独立连续 SAC

```bash
TOKEN=/绝对路径/no_speed_token_run/token_010000.pt

python -m rl_residual_service.train --stage init \
  --base "$BASE" --token "$TOKEN" --device cpu \
  --output /绝对路径/no_speed_residual_init
```

输出 `residual_init.pt`。初始确定性残差为零；`collect/train` 采用有界随机采样探索。此 checkpoint 仅包含残差 actor、双 Q/target、温度、优化器、RNG 和绑定信息，不保存 VLA 副本。

若要修改残差上限，初始化时传 `--config /path/sac.json`；字段见 [默认 SAC 配置](../rl_factor_sac/default_config.json)，重点是 `translation_bound_m`、`rotation_bound_rad`、`residual_change_fraction`。训练/推理保持与该 SAC checkpoint 一致，不通过 `--probe-mm` 调正式策略边界。

### 3. 接入 ROS 2 并在线训练

ROS 2 桥接程序、标定模板、执行 ACK、success/failure 事件与前一版相同，详见 [反馈接入说明](../rl_chunk_service/README.md)。目前话题名未知，须在部署机器填写 [ROS 2 模板](../rl_chunk_service/ros2.example.json)。正式训练不能用 probe 的零力/零 token 占位。

```bash
python -m rl_residual_service.remote_service \
  --checkpoint "$BASE" --token "$TOKEN" \
  --rl-checkpoint /绝对路径/no_speed_residual_init/residual_init.pt \
  --mode train --task close_box --device cuda:0 \
  --uri e2vla --host 127.0.0.1 --port 9101 \
  --ns-host 127.0.0.1 --ns-port 9090 --start-ns \
  --feedback /tmp/ie2vla_residual_feedback.jsonl \
  --output /绝对路径/residual_online_001 \
  --warmup 32 --batch-size 32 --save-every 100

# 在已经 source ROS 2 的服务器终端运行；仍不改客户端。
python3 -m rl_chunk_service.ros_bridge \
  --config /绝对路径/ros2.actual.json \
  --output /tmp/ie2vla_residual_feedback.jsonl
```

两条命令供部署时执行；本次实现不启动生产模型训练或机器人。

执行反馈必须确认实际采用哪段动作以及真实时间。返回轨迹不等于执行成功；未采用、缺测、无法配对、过期、reset/abort 丢弃的区间不作为样本。奖励由真实力惩罚、时间代价和任务结果构成，不从演示数据伪造 reward。执行区间结束才生成一条残差 transition，discount 按实际秒数计算。

默认至少 32 条闭合 transition 后更新；后台只更新 residual，一次发现新 transition 最多一轮更新。改成 `--mode collect` 可只收集、以后离线训练。批量 API 无采集时间/返回 chunk ID 的原有限制、ROS 时钟一致性、融合后实际动作关联要求，与 [前一版说明](../rl_chunk_service/README.md) 相同。

输出仍为 `loss.jsonl`、`proposals.jsonl`、`status.json`、`sac_latest.pt`、`replay_latest.pt`。其中权重格式是 `ie2vla_no_speed_residual_sac_v1`，回放只有 residual 分支。正常 SIGINT/SIGTERM 会保存；新服务运行用新输出目录。

### 4. 离线继续训练与部署

```bash
python -m rl_residual_service.train --stage rl \
  --base "$BASE" --token "$TOKEN" \
  --resume /绝对路径/residual_online_001/sac_latest.pt \
  --replay /绝对路径/residual_online_001/replay_latest.pt \
  --output /绝对路径/residual_offline_001 \
  --steps 1000 --batch-size 32 --save-every 100 --device cuda:0
```

随后用 `--mode inference --rl-checkpoint /.../residual_001000.pt` 部署确定性残差。仍需要真实力输入；不再使用联调占位。RL loss 下降不能替代真实成功率、轨迹和接触力的验证。

## 检查范围

CPU 测试覆盖：零/非零探针、左右臂局部坐标、旋转/夹爪保持、无 token 无力时的协议推理、探针拒绝训练与保存、只有 residual 更新、原始窗口无变速、实际小型 Qwen 的原推理逐元素一致、token 训练/精确恢复、残差初始化/离线更新、TCP/共享内存。

本机没有实际部署客户端、生产 ROS 2 话题或机器人。本次验证不等于现网真机联调完成。默认路径、checkpoint 和端口要替换成测试机器的实际值。
