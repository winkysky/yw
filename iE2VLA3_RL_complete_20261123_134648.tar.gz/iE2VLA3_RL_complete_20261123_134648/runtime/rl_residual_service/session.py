"""One residual transition per actually executed chunk; no factor replay."""
import math
from pathlib import Path
import numpy as np
import torch
from rl_chunk_service.session import ChunkSession
from rl_chunk_service.feedback import FeedbackNotReady
from rl_factor_sac.replay import ReplayBuffer, validate_batch
from rl_factor_sac.reward import EpisodeReward, RewardConfig
from .artifacts import save_replay


class ProbeWrench:
    """Explicit test placeholders, inaccessible to collection/training modes."""
    def __init__(self, config):
        self.config = config

    def history(self, stamp):
        return np.zeros((self.config.force_history, 2, 6), np.float32)


class ResidualSession(ChunkSession):
    def __init__(self, *args, probe_mode=None, probe_mm=.25, probe_arm="left", probe_axis="x",
                 dump_path=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.dump_path = Path(dump_path) if dump_path else None
        if probe_mode not in (None, "zero", "probe"):
            raise ValueError("Invalid diagnostic mode")
        self.probe_mode = probe_mode
        self.buffers = {"residual": ReplayBuffer(self.config, "residual", kwargs.get("capacity",10000))}
        if probe_mode:
            if self.mode != "inference" or not self.learner.probe_only:
                raise ValueError("Probe placeholders may never be used for training")
            if (probe_arm not in ("left", "right") or probe_axis not in ("x", "y", "z")
                    or not math.isfinite(probe_mm) or not 0 < abs(probe_mm) <= .5):
                raise ValueError("Probe uses left/right TCP x/y/z and a nonzero offset of at most 0.5 mm")
            self.wrench = ProbeWrench(self.config)
            self.foundation.probe_only = True
            if probe_mode == "probe":
                index = (0 if probe_arm == "left" else 6)+"xyz".index(probe_axis)
                ratio = probe_mm/1000/self.config.translation_bound_m/self.config.residual_change_fraction
                if abs(ratio) >= 1:
                    raise ValueError("Probe offset exceeds configured residual slew bounds")
                # Run the real ResidualActor through its normal tanh/bounded
                # output path; controlled head bias makes the untrained result
                # reproducible and observable. This is not a learned correction.
                with torch.no_grad():
                    self.learner.residual.actor.head.bias[index] = math.atanh(ratio)

    def propose(self, *args, **kwargs):
        actions, chunk_id = super().propose(*args, **kwargs)
        if self.dump_path:
            with self.lock:
                plan = self.pending.get(chunk_id)
                if plan is not None:
                    self.dump_path.parent.mkdir(parents=True, exist_ok=True)
                    temp = self.dump_path.with_suffix(".tmp")
                    with temp.open("wb") as stream:
                        np.savez(stream, base_actions=plan["reference"], corrected_actions=actions,
                            normalized_residual=plan["residual_action"].numpy(), anchor=plan["anchor"],
                            chunk_id=chunk_id, state=plan["residual_obs"]["state"].numpy())
                    temp.replace(self.dump_path)
        return actions, chunk_id

    def _observation(self, prepared, anchor, now):
        obs = super()._observation(prepared, anchor, now)
        obs["factor_mask"][:] = obs["factor_mask"].new_tensor([0,1,0,0])
        return obs

    def status(self):
        return dict(super().status(), enabled_branches=["residual"], factor_policy=False,
                    probe_mode=self.probe_mode, feedback_placeholders=bool(self.probe_mode))

    def handle(self, event):
        if self.probe_mode:
            raise ValueError("Probe modes never consume execution feedback or create training transitions")
        return super().handle(event)

    def _finish(self, next_plan, stamp, outcome=None):
        old = self.active
        start = old["activated"]
        if stamp <= start or stamp > old["anchor"]+31/self.config.control_hz+2e-6:
            raise ValueError("Unreported execution gap/expired trajectory; abort this interval")
        segments = self.wrench.interval(start, stamp)
        reward_fn = EpisodeReward(RewardConfig(**self.bindings["reward_config"]))
        action = old["residual_action"][0].numpy()
        prev = old["residual_obs"]["previous_residual"][0].numpy()
        reward = 0.
        for i, (left, right, wrench) in enumerate(segments):
            r, _ = reward_fn.step(right-left, wrench, action, prev, outcome if i == len(segments)-1 else None)
            reward += self.config.gamma_per_second**(left-start)*r
        obs = old["residual_obs"]
        scalar = lambda v: torch.tensor([[float(v)]], dtype=torch.float32)
        row = dict(obs=obs, next_obs=obs if outcome else next_plan["residual_obs"], action=old["residual_action"],
            reward=scalar(reward), discount=scalar(self.config.discount(stamp-start)),
            terminated=scalar(outcome is not None), truncated=scalar(False))
        validate_batch(row, self.config, "residual")
        if self.mode != "inference":
            self.buffers["residual"].add(row, versions=old["versions"], timestamp=start,
                source=self.source, activation_delay_s=start-old["decision_time"])
            self.transitions += 1
        self.emit(dict(type="transition", chunk_id=old["id"], timestamp=stamp, elapsed=stamp-start,
                       reward=reward, outcome=outcome, collected=self.mode != "inference", branch="residual"))

    def save_replay(self, path):
        if self.probe_mode:
            raise ValueError("Probe output is not RL replay")
        with self.lock:
            save_replay(path, self.buffers, self.bindings)
