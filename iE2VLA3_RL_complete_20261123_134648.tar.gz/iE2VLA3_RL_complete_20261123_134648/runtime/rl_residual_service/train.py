"""Initialize/update just continuous SAC against a frozen no-speed VLA."""
from dataclasses import replace
import json
import torch
from rl_factor_sac.train import parser
from rl_factor_sac.config import SACConfig
from rl_factor_sac.reward import RewardConfig
from .artifacts import ResidualSAC, artifact_bindings, load_replay


def main(argv=None):
    args = parser().parse_args(argv)
    if min(args.steps,args.batch_size,args.save_every,args.threads) < 1 or args.max_policy_lag < 0:
        raise ValueError("Invalid training counts")
    if args.stage == "init" and (args.resume or args.replay):
        raise ValueError("Use rl for replay/resume")
    if args.stage == "rl" and not args.replay:
        raise ValueError("RL needs real execution replay")
    if args.output.exists() and any(args.output.iterdir()) and not args.resume:
        raise FileExistsError("Use a new output directory or --resume")
    torch.set_num_threads(args.threads); torch.manual_seed(args.seed)
    reward = RewardConfig(**json.loads(args.reward_config.read_text())) if args.reward_config else RewardConfig()
    bindings, dim = artifact_bindings(args.base,args.token,reward)
    learner = ResidualSAC.load(args.resume,args.device,bindings,restore_rng=True) if args.resume else ResidualSAC(
        SACConfig.load(args.config) if args.config else replace(SACConfig(),token_dim=dim),args.device)
    if learner.config.token_dim != dim or (args.config and SACConfig.load(args.config) != learner.config):
        raise ValueError("Residual/token/config mismatch")
    if args.stage == "init":
        learner.save(args.output/"residual_init.pt",bindings)
        print(json.dumps(dict(status="initialized_only",checkpoint=str(args.output/"residual_init.pt"))),flush=True)
        return
    replay = load_replay(args.replay,learner.config,bindings)["residual"]
    if not len(replay):
        raise ValueError("No executed residual transitions")
    for step in range(1,args.steps+1):
        metrics = learner.update(residual_batch=replay.sample(args.batch_size,args.device,learner.versions,args.max_policy_lag))
        if step == 1 or step%10 == 0:
            print(json.dumps(metrics),flush=True)
        if step%args.save_every == 0 or step == args.steps:
            learner.save(args.output/f"residual_{learner.residual.updates:06d}.pt",bindings)


if __name__ == "__main__":
    main()
