"""Read-only bridge to the existing no-speed full checkpoint."""
from pathlib import Path
import torch
from action.define import START_END_INDICES
from dataset.lerobot_original import LeRobotOriginalConfig
from models.m0512_fm.lerobot_inference import load_checkpoint, load_inference_model
from models.m0512_fm.action_expert import pad_or_trunc_inputs
from models.m0512_fm.action_transform import ActionTransform
from rl_factor_sac.foundation import FrozenFoundation, decode_prediction
from rl_factor_sac.token import TokenConfig
from rl_factor_sac.io import file_sha256

TOKEN_FORMAT = "ie2vla_no_speed_rl_token_v1"


class NoSpeedFoundation(FrozenFoundation):
    @classmethod
    def load(cls, checkpoint, device="cpu", token_checkpoint=None):
        saved, path = load_checkpoint(checkpoint)
        base = load_inference_model(saved, torch.device(device))
        base_hash = file_sha256(path)
        token = torch.load(token_checkpoint, map_location="cpu", weights_only=False) if token_checkpoint else None
        if token and (token.get("format") != TOKEN_FORMAT or token["base_sha256"] != base_hash):
            raise ValueError("No-speed token/base checkpoint mismatch")
        result = cls(base, TokenConfig(**token["token_config"]) if token else None)
        result.base_sha256 = base_hash
        result.data_config = LeRobotOriginalConfig(**saved["data_config"])
        result.data_config.validate()
        result.native_info = {k: saved[k] for k in ("format", "step", "model_config", "data_config", "dataset_fingerprint")}
        result.native_info.update(checkpoint=str(path), device=str(device), fps=30.)
        if token:
            result.token.load_state_dict(token["token"], strict=True)
        result.probe_only = False
        return result

    def encode(self, batch, with_token=True):
        context = super().encode(batch, with_token and not self.probe_only)
        if self.probe_only and with_token:
            context.token = torch.zeros(len(batch.state), self.token.config.token_dim, device=batch.state.device)
        return context

    @torch.no_grad()
    def predict(self, prepared, speed_factor=1., initial_noise=None, fp16=False):
        if speed_factor != 1.:
            raise ValueError("No-speed base cannot change tempo")
        # Match the existing no-speed infer_batch, including CPU autocast.
        fp16 = True
        # Same inference operations as ActionExpert.forward, with explicit noise
        # passed to its existing denoiser. No patches to the base model, global
        # RNG fork or shared methods (the learner can run on another thread).
        actor = self.base.actor
        data = pad_or_trunc_inputs(prepared.batch.deepcopy())
        context = actor.context_encoder(data, prepared.vl_outputs)
        lo, _ = START_END_INDICES["rot6d"]
        context["a_mask"][..., lo+3:lo+6] = False
        state = data.state[:, :, -1]
        fixed = dict(history=ActionTransform.weT_to_ceT(cur_wcT=data.action_ref_pose, a=data.state),
                     latest_s=state, action_ref_pose=data.action_ref_pose, context_outputs=context, fp16=fp16)
        cache = actor.dp_head.forward_vl(context_outputs=context, fp16=fp16)
        actions = actor.iterative_denoise(data.action.shape, fixed, initial_noise=initial_noise, kv_caches=cache)
        prediction, mask = ActionTransform.ccT_to_weT(cur_wcT=data.action_ref_pose, s=state,
                                                     a=actions, a_mask=data.action_mask)
        if data._avg_pose is not None:
            prediction = actor.decenter(avg_pose=data._avg_pose, raw=prediction)
        return decode_prediction(prediction*mask.float())
