"""Server-local feedback. Nothing is added to the legacy client's RPC payload."""
from collections import deque
import fcntl
import json
import math
from pathlib import Path
import threading
import time
import numpy as np


class FeedbackNotReady(RuntimeError):
    pass


def append_event(path, event):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(event, allow_nan=False, separators=(",", ":")) + "\n"
    with path.open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        stream.write(line)
        stream.flush()
        fcntl.flock(stream, fcntl.LOCK_UN)


class WrenchBuffer:
    def __init__(self, config, capacity=30000):
        self.config = config
        self.rows = deque(maxlen=capacity)
        self.lock = threading.RLock()

    def add(self, stamp, values):
        values = np.asarray(values, np.float32)
        if not math.isfinite(stamp) or stamp < 0 or values.shape != (2, 6) or not np.isfinite(values).all():
            raise ValueError("Expected timestamp and calibrated left/right wrench (2,6), N and Nm")
        with self.lock:
            if self.rows and stamp <= self.rows[-1][0]:
                raise ValueError("Wrench timestamps must increase")
            self.rows.append((float(stamp), values.copy()))

    def history(self, now):
        from rl_factor_sac.runtime import force_history
        with self.lock:
            rows = list(self.rows)
        try:
            return force_history([r[0] for r in rows], [r[1] for r in rows], now, self.config)
        except ValueError as exc:
            raise FeedbackNotReady(str(exc)) from exc

    def interval(self, start, end):
        """Left-held measured wrench, with a bounded tail; never fill long gaps."""
        with self.lock:
            rows = list(self.rows)
        before = [r for r in rows if r[0] <= start]
        if end <= start or not before:
            raise FeedbackNotReady("No measured force at execution interval start")
        rows = [before[-1]] + [r for r in rows if start < r[0] < end]
        if (start - rows[0][0] > self.config.max_history_gap_s
                or any(b[0] - a[0] > self.config.max_history_gap_s for a, b in zip(rows, rows[1:]))
                or end - rows[-1][0] > self.config.max_history_gap_s):
            raise FeedbackNotReady("Missing force samples in executed interval")
        times = [start] + [r[0] for r in rows[1:]] + [end]
        return [(times[i], times[i+1], row[1]) for i, row in enumerate(rows)]


class FeedbackReader:
    """Tail a fresh local inbox. Invalid feedback is visible and stops collection.

    Start at EOF: a restarted server must never consume an old episode's ACKs.
    Wrench can arrive slightly later than its execution event; retry only missing
    force, for at most two seconds, without treating time passing as an ACK.
    """
    def __init__(self, path, session, retry_seconds=2.):
        self.path, self.session = Path(path), session
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.stream = self.path.open("a+")
        self.stream.seek(0, 2)
        self.retry_seconds = retry_seconds
        self.stopped = threading.Event()
        self.worker = threading.Thread(target=self._work, name="chunk-feedback", daemon=True)
        self.worker.start()

    def _work(self):
        pending = deque()
        while not self.stopped.is_set():
            offset = self.stream.tell()
            line = self.stream.readline()
            if line and not line.endswith("\n"):
                self.stream.seek(offset)
                line = ""
            if line:
                try:
                    event = json.loads(line)
                    if event.get("type") == "wrench":
                        self.session.handle(event)
                    else:
                        pending.append((event, time.monotonic()))
                except Exception as exc:
                    self.session.fault(f"feedback: {type(exc).__name__}: {exc}")
            while pending:
                event, added = pending[0]
                try:
                    self.session.handle(event)
                except FeedbackNotReady as exc:
                    if time.monotonic() - added < self.retry_seconds:
                        break
                    self.session.fault(f"feedback timed out: {exc}")
                except Exception as exc:
                    self.session.fault(f"feedback: {type(exc).__name__}: {exc}")
                pending.popleft()
            if not line:
                self.stopped.wait(.01)

    def close(self):
        self.stopped.set()
        self.worker.join(5.)
        self.stream.close()
