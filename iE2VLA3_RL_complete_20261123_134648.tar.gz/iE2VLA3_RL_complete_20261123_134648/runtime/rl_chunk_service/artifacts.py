"""Separate formats prevent accidentally training chunk actors on 30 Hz replay."""
import torch
from rl_factor_sac.config import SACConfig
from rl_factor_sac.sac import DualSAC
from rl_factor_sac.io import atomic_save, validate_bindings
from rl_factor_sac.replay import ReplayBuffer

SEMANTICS = dict(decisions="one_factor_and_one_residual_per_vla_chunk",
                 residual="constant_local_tcp_offset_per_chunk",
                 feedback="measured_wrench_and_explicit_execution_v1",
                 discount="gamma_per_second_to_actual_activation_interval",
                 reference_hz=30, factors=[0.8, 1.0, 1.5, 2.0])


class ChunkSAC(DualSAC):
    def save(self, path, bindings):
        validate_bindings(bindings)
        with self.lock:
            atomic_save(dict(format="ie2vla_chunk_sac_v1", semantics=SEMANTICS,
                config=self.config.asdict(), bindings=bindings,
                factor=self.factor.state_dict(), residual=self.residual.state_dict(),
                rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all()
                if torch.cuda.is_available() else None), path)

    @classmethod
    def load(cls, path, device="cpu", bindings=None, restore_rng=False):
        saved = torch.load(path, map_location=device, weights_only=False)
        if (saved.get("format") != "ie2vla_chunk_sac_v1" or saved.get("semantics") != SEMANTICS
                or (bindings is not None and saved["bindings"] != bindings)):
            raise ValueError("Chunk SAC format/semantics/base/token/reward mismatch")
        validate_bindings(saved["bindings"])
        result = cls(SACConfig(**saved["config"]), device)
        for branch in ("factor", "residual"):
            getattr(result, branch).load_state_dict(saved[branch])
        if restore_rng:
            torch.set_rng_state(saved["rng"].cpu())
            if torch.cuda.is_available() and saved["cuda_rng"] is not None:
                torch.cuda.set_rng_state_all([x.cpu() for x in saved["cuda_rng"]])
        return result


def save_replay(path, buffers, bindings):
    validate_bindings(bindings)
    if set(buffers) != {"factor", "residual"} or buffers["factor"].config != buffers["residual"].config:
        raise ValueError("Expected matching dual replay buffers")
    atomic_save(dict(format="ie2vla_chunk_replay_v1", semantics=SEMANTICS,
        config=buffers["factor"].config.asdict(), bindings=bindings,
        buffers={k: v.snapshot() for k, v in buffers.items()}), path)


def load_replay(path, config, bindings):
    saved = torch.load(path, map_location="cpu", weights_only=False)
    validate_bindings(bindings)
    if (saved.get("format") != "ie2vla_chunk_replay_v1" or saved.get("semantics") != SEMANTICS
            or saved["config"] != config.asdict() or saved["bindings"] != bindings
            or set(saved["buffers"]) != {"factor", "residual"}):
        raise ValueError("Chunk replay format/semantics/base/token/reward/config mismatch")
    result = {k: ReplayBuffer(config, k, max(1, len(rows))) for k, rows in saved["buffers"].items()}
    for branch, rows in saved["buffers"].items():
        for row, meta in rows:
            result[branch].add(row, **meta)
    return result
