# iE2VLA3：chunk 同频双 SAC 与兼容 Pyro4 服务

新增实现，2026-11-23。这个目录复用现有四倍率 VLA、RL token 和 SAC 网络，提供新的服务入口。原 `e2vla_compat`、`e2vla_async`、所有已有模型/训练文件及 checkpoint 不作修改。**客户端代码不需要增加倍率、残差、力或 reward 字段。**

本机完成 CPU 测试，包括真实 localhost Pyro4 TCP/共享内存、小型真实 Qwen+动作网络加载推理、双 SAC 更新与恢复。没有启动生产训练，没有连接机器人。部署服务器是 **ROS 2**；实际话题、字段、力传感器标定尚未提供，需按下文映射，不能把示例话题当成已接通的传感器。

## 行为与接口

一次新观测触发的推理：

1. 冻结 VLA 提取三路图像/语言特征，冻结已训练 RL token 编码器生成 token。
2. 离散 SAC 读 token、**双臂绝对 TCP state**、过去的力/力矩和执行上下文，选 `0.8 / 1 / 1.5 / 2`。
3. 倍率进入 VLA 原 FiLM 路径，生成 32 点基准轨迹。
4. 连续 SAC 再读取本次基准轨迹和选中倍率，输出**一组双臂 12 维残差**。每臂为局部 TCP 坐标系的平移 3 维、旋转向量 3 维，整段 32 点使用同一组修正；不改夹爪。
5. 返回原格式的轨迹。ROS 执行反馈确认实际采用哪一段后，才开始为该段记执行区间；下一段实际接管或收到 success/failure 时，分别产生一条倍率和一条残差 transition。

**两路策略都按 VLA chunk 更新，没有 30 Hz 残差策略循环。** 轨迹仍为 32 点、30 Hz，首尾相隔 `31/30` 秒。倍率改变预测的运动进度，不改变时间戳间隔。`--max-inference-hz 0` 默认无额外推理限速；实际 chunk 频率由新观测、计算耗时和客户端取用决定。旧 `SACConfig.control_hz=30` 在本版用于轨迹/力历史采样，`replan_seconds` 不控制本服务的请求频率。

默认残差每轴不超过 ±5 mm / ±0.05 rad；相邻已采用 chunk 的残差变化，每轴不超过 1 mm / 0.01 rad。整段 TCP 线速度/角速度上限默认 0.5 m/s / 1 rad/s，超出则拒绝输出，不偷偷裁剪策略动作。连续性仍取决于 VLA 预测、客户端原有插值/融合与机器人控制器；本版不保证 chunk 切换位置天然连续。

原 RPC 方法及签名保留：

| 接口 | 行为 |
|---|---|
| `get_info/get_config/get_planner_config/get_status` | 原字段保留；info/status 增加 `rl` 信息 |
| `set_config/reset/set_prompt/set_speed` | 原调用形式；`reset` 丢弃未闭合区间，不伪造失败奖励 |
| `add_obs_frame/add_obs_frames` | 原始 LeRobot 位姿/夹爪、三路 RGB、任务文字；默认 **recorded/raw** |
| `get_action(...)` | 原 `(poses, grippers, times, image)`，形状 `(32,2,4,4)/(32,2)/(32,)` |
| `run_inference(...)` | 原 batch 输入，CPU float32 Tensor `(B,32,2,17)` |
| `run_inference_numpy(...)` | 同形状 NumPy 输出 |
| `set_ensemble_nums/ensemble_traj` | 原轨迹融合接口保留 |
| `start_async/pause_async/get_latest_action` | 原异步 envelope、sequence、generation 规则保留 |

单位、工具偏移、左右基座、三相机几何继续走原适配器，由 checkpoint 配置决定。输出 TCP 统一在左臂 recorded base 下。旧客户端识别用的顶层 `variant="no_speed"` 和 wire format 保留；`backend`、`checkpoint_format`、`checkpoint_metadata`、`rl` 如实标识倍率模型。`speed_mps` 仍不是倍率，非空值会被拒绝；不要给旧客户端传 `speed_mps=1.5`。

同一 planner 观测和 seed 的重复 `get_action`/画图复用同一决策。新观测可在旧 chunk 执行时上传/推理。未采用、重复、重置时过期的 proposal 不会自动进入回放。

## 所需权重与初始化

需要三个匹配文件：

- 已训练的四倍率 VLA：`lerobot_factor_full_v3`，含 `model.pt`、`complete.json`。
- 针对该 VLA 训练的 `ie2vla_rl_token_v1`。
- 本目录创建的 `ie2vla_chunk_sac_v1`，初始或已训练均可。

**现有无速度 100k checkpoint 不能直接当作倍率 VLA。** 本服务复用的是客户端协议，不会给无速度 checkpoint 凭空增加可训练的倍率能力。原 30 Hz 残差 SAC 权重/回放格式也不直接载入本版，以免语义混用。

从头训练倍率 VLA 的入口和参数仍见 [速度分支说明](../models/m0512_fm/README_lerobot_dual_velocity.md)，RL token 的架构和独立训练见 [RL token 说明](../rl_factor_sac/README.md)。示例训练顺序如下，下面是供部署时执行的命令，本次没有执行 GPU 训练：

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

# 四倍率基础 VLA；需要空闲 GPU，使用新的输出目录。
CUDA_VISIBLE_DEVICES=0,1,2,3 TOKENIZERS_PARALLELISM=false \
python -m models.m0512_fm.train_lerobot_dual_velocity \
  --output /nas_data_new/hq/98qwenvla/ie2vla3_factor_sft_new

# 以下路径替换成实际完成的倍率 VLA 和 token checkpoint。
BASE=/absolute/path/to/factor_sft/step_0100000
python -m rl_factor_sac.train_token \
  --base "$BASE" --output /absolute/path/to/token_run \
  --steps 20000 --device cuda:0

TOKEN=/absolute/path/to/token_run/token_020000.pt
python -m rl_chunk_service.train --stage init \
  --base "$BASE" --token "$TOKEN" \
  --output /absolute/path/to/chunk_sac_init --device cpu
```

token 步数是启动示例，需根据验证集重建/动作辅助损失选择 checkpoint。SAC 初始化只建立网络，不表示已学会任务。默认初始化偏好 1x；`inference` 取离散最大概率与连续策略均值，`collect/train` 使用随机策略采样。两路 SAC 各有双 Q、目标网络、温度优化器；在线学习始终冻结 VLA 和 token。

可给 init 传 `--config /absolute/sac_config.json` 调整网络/残差边界；结构见原 [SAC 配置](../rl_factor_sac/default_config.json)。奖励可用 `--reward-config`，此配置必须在 init、服务端和离线学习时完全一致。权重绑定 base/token SHA256、奖励配置、chunk 语义；不支持静默换模型继续用旧 replay。

## 启动服务

旧客户端的 URI、地址、端口不改时，新服务必须监听原来的注册名和端口。**原服务还占用该名字时，新服务会报错退出，不覆盖或停止原服务。** 当前正在运行的服务不在本次操作范围内；实际切换部署时由运维安排。下面 `e2vla:9101` 是原默认值，如果部署客户端使用别的值，就使用其原值。

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

BASE=/absolute/path/to/factor_sft/step_0100000
TOKEN=/absolute/path/to/token_run/token_020000.pt
SAC=/absolute/path/to/chunk_sac_init/sac_init.pt

python -m rl_chunk_service.remote_service \
  --checkpoint "$BASE" --token "$TOKEN" --rl-checkpoint "$SAC" \
  --task close_box --device cuda:0 \
  --uri e2vla --host 127.0.0.1 --port 9101 \
  --ns-host 127.0.0.1 --ns-port 9090 --start-ns \
  --input-pose-format recorded --input-gripper-format raw \
  --feedback /tmp/ie2vla_rl_feedback.jsonl \
  --output /absolute/path/to/rl_session_001 \
  --mode inference
```

`--task` 保持与客户端原任务路由一致，可选 close_box/open_box/place_phone，实际任务文字仍由客户端 `set_prompt` 或 `--prompt` 设置。原客户端若上传的是已经转换的 world TCP/openness，应继续用它之前的 `--input-pose-format tcp_world --input-gripper-format openness`，避免重复转换。

未指定 URI/port 时，新服务默认 `e2vla_rl:9102`，方便旁路验证。`--output` 必须是**尚不存在的新目录**，避免覆盖已有训练产物。`--check-config` 可仅校验权重绑定而不加载 Qwen/GPU；其他必填参数仍需提供。

客户端原来用同步方法就继续同步；原来用异步方法就继续异步。服务端可加 `--autostart --prompt '任务指令'` 启动后台推理。调试可用 `--max-inference-hz 2` 限制最多每秒两次新观测推理，不改轨迹点的 30 Hz 时基。

## ROS 2 力与执行反馈接入

在部署机器、已经 source ROS 2 环境的终端查询：

```bash
ros2 topic list -t
ros2 topic info /实际话题名 -v
ros2 topic echo /实际话题名 --once
ros2 interface show geometry_msgs/msg/WrenchStamped
```

复制 [ros2.example.json](ros2.example.json) 到部署配置，填写左右话题、消息类型、字段路径、frame_id、单位和传感器到 TCP 的标定。示例中的 `/REPLACE/...`、单位阵、零偏均为占位，**不是 E03 的力传感器标定**。

- 输出顺序固定 left/right，单臂 `[Fx,Fy,Fz,Tx,Ty,Tz]`，单位 N/Nm。
- `bias_si` 是传感器坐标系、换算为 SI 后减去的静态零偏。运动相关重力/工具载荷补偿应由已有传感器通路提供，桥接器不假装有这份模型。
- `sensor_to_tcp_rotation=R`；`tcp_to_sensor_translation_m=p` 为 TCP 原点指向传感器原点、用 TCP 轴表达。转换为 `F_tcp=R F_sensor`、`τ_tcp=R τ_sensor + p×F_tcp`。
- ROS header 时间、客户端 planner timestamp、执行反馈时间必须是**同一 Unix 秒时钟**。本服务默认 `time.time()`，不自动推断 ROS 仿真时钟偏移。
- 左右测力配对最大偏差默认 20 ms；策略读取过去 8 点、以 30 Hz 重采样的历史，最大缺测间隔默认 100 ms。缺力不会用零冒充测量；planner 等待足够历史再输出。

桥接程序只读 ROS，不发机器人控制命令。ROS Python 与模型 Conda 环境可以不同，桥接器只需 ROS 对应 Python + NumPy，不需要 PyTorch：

```bash
# ROS 2 终端（先 source 现场的 ROS/setup.bash）
cd /home/hq/code/iE2VLA3
python3 -m rl_chunk_service.ros_bridge \
  --config /absolute/path/to/ros2.actual.json \
  --output /tmp/ie2vla_rl_feedback.jsonl --check-config

python3 -m rl_chunk_service.ros_bridge \
  --config /absolute/path/to/ros2.actual.json \
  --output /tmp/ie2vla_rl_feedback.jsonl
```

先启动服务端，再运行桥接器/客户端；服务启动时从 inbox 文件末尾开始读，避免误收上一次运行的执行 ACK。一个 inbox 只对应一个服务实例。反馈文件是追加日志，应在服务停止后归档/轮换。

执行反馈可来自已有 ROS 消息的字段映射，无需客户端新增 RPC。例如已有消息能给出实际接管时间、该轨迹首时间戳和采用状态时：

```json
{
  "topic": "/现场已有的轨迹采用反馈",
  "message_type": "your_msgs/msg/TrajectoryFeedback",
  "constants": {"type": "activate"},
  "fields": {
    "timestamp": "header.stamp",
    "anchor": "trajectory_start_time",
    "execution_matches_proposal": "accepted"
  }
}
```

字段名只是映射示例。`anchor` 必须是对应 `get_action` 返回的 **times[0]**，不是 ROS 收到消息的时刻。若实际驱动话题需要复杂关联、状态枚举判断或多个消息才能确认执行，在服务器侧另行适配成下列 JSON 事件即可；不能仅凭“推理已完成/轨迹已收到”就映射成执行确认。

### 规范化事件

ROS bridge 或服务器其他传感器程序可向 inbox 按行追加 JSON：

```json
{"type":"wrench","timestamp":1795400000.0,"values":[[1,2,3,0.1,0.2,0.3],[4,5,6,0.4,0.5,0.6]]}
{"type":"activate","timestamp":1795400000.2,"anchor":1795400000.0,"execution_matches_proposal":true}
{"type":"outcome","timestamp":1795400000.7,"chunk_id":"从 proposals.jsonl 中找到的当前已执行 chunk ID","outcome":"success"}
```

上面的时间与数值仅展示结构，不能作为真实反馈使用。

每个 proposal 的 ID、anchor、倍率、残差、策略版本、`trajectory_sha256` 写入 `--output/proposals.jsonl`，**该记录只表示提案，绝不是已执行**。反馈需识别实际采用的提案；可使用 `chunk_id`、唯一的原 planner `anchor` 或唯一 `trajectory_sha256`。SHA256 对返回 `(32,2,17)` 动作的 C 连续 little-endian float32 bytes 计算，顺序为 16 项 TCP 矩阵+夹爪。相同值的重复 batch 可能有相同 digest，此时必须用 ID，不猜测是哪次请求。

`execution_matches_proposal=true` 表示执行通路确认该提案开始被机器人采用，允许原有时间插值/IK。若被其他动作替换、人工接管，或无法确定融合/裁剪后的动作来源，应发 `abort`，不能把它算作这条策略的执行。在已有客户端存在 chunk 融合时，服务器侧反馈必须能追踪实际采用的 chunk；本服务不会假设客户端没有融合。

`run_inference` 的旧 batch 格式没有采集时间，也没有 chunk ID 返回字段。本版保持原返回结构，使用**服务端接收各行时刻**作为内部 anchor，必须通过服务器日志和执行通路按 ID/digest 关联。不能用这个接收时刻冒充精确采集时刻；批量 API 的时延/关联需部署侧核实。若无法可靠关联，只能推理，不能声称已取得可用 RL 回放。多行 batch 的每行是独立候选，只有被执行确认的一行记入训练。

任务成功/失败可以由服务器的任务判定通路提供，也可人工标注：

```bash
python -m rl_chunk_service.feedback_cli \
  --output /tmp/ie2vla_rl_feedback.jsonl \
  --outcome success --chunk-id ACTUAL_ACTIVE_CHUNK_ID \
  --timestamp ACTUAL_OUTCOME_UNIX_SECONDS

# 人工接管、缺测、时间上限但没有可靠 bootstrap 等：丢弃未闭合段。
python -m rl_chunk_service.feedback_cli \
  --output /tmp/ie2vla_rl_feedback.jsonl --abort
```

outcome 要用真实完成时刻，不能把数秒后的按键时刻算成轨迹执行时长。`reset/pause/改配置/abort` 均丢弃未闭合段，不产生伪 success、failure 或时间截断标签。可靠时间截断 bootstrap 在本版未提供；此类区间丢弃，已经闭合的 transitions 保留。结束一轮后用客户端原来的 `reset` 开始下一轮。

反馈时间不递增、标识歧义、采用的父 chunk 与策略输入不一致、整段过期、执行区间缺力、错误 outcome 等会拒绝记录；`get_status()['rl']['error']` 和日志可见，需修正反馈后 reset/abort。允许力消息比执行事件稍晚到达，最多等待 2 秒补齐；不会因等待超时而推定已执行。

## 在线与离线训练

上述服务命令改为 `--mode train`，就会一边返回轨迹，一边训练两路 SAC；`--mode collect` 只随机策略采样、收集回放，`--mode inference` 采用确定性动作、不写训练 transitions。

在线训练默认累计至少 32 条**已闭合的实际执行区间**后开始，每次发现新的 transition 最多进行一轮双 SAC 更新，batch=32，限制策略版本差不超过 1000。没有真实执行回放就不更新。可以加：

```text
--mode train --warmup 32 --batch-size 32 --save-every 100 --max-policy-lag 1000
```

两路 replay 使用同一真实时间区间的奖励，discount=`gamma_per_second ** 实际执行秒数`。倍率 next_obs 是下一次倍率决策输入；残差 next_obs 是下一次残差决策输入，包含下一次倍率生成的基准轨迹。记录 decision→activation 的实际延迟。该方案仍受视觉延迟和异步执行影响；不能把未知执行延迟当成零，策略快照/版本用于限制陈旧回放。

默认奖励为 success `+10`、failure `-5`，加耗时、超阈值力/力矩、残差幅度与变化惩罚。力接触不自动等于成功。共享奖励让两路策略合作，但也带来联合训练的非平稳性；需要在机器人上检查成功率、接触力和倍率分布，不能仅凭 SAC loss 下降判断动作变好。

每 100 条 transition（或正常 SIGINT/SIGTERM 退出）保存：

```text
rl_session_001/
  service.json          # 权重绑定和协议元信息
  proposals.jsonl       # 提案、确认、区间、错误审计
  loss.jsonl            # factor/residual critic、actor、temperature 等
  status.json
  sac_latest.pt         # 两路 actor/Q/target/温度/优化器/版本/RNG
  replay_latest.pt      # 仅执行确认且反馈完整的双路 chunk replay
```

输出目录不包含 VLA 副本，不覆盖原 base/token checkpoint。回放默认每路保留 10000 条，实时写入不可变 CPU 副本；保存时有短时 I/O 和锁等待。模型与 SAC 同 GPU 并发时会竞争计算资源，实际推理延迟需在部署 5090 上测量；可以先 collect，再离线学习。

离线继续训练：

```bash
python -m rl_chunk_service.train --stage rl \
  --base "$BASE" --token "$TOKEN" \
  --resume /absolute/path/to/rl_session_001/sac_latest.pt \
  --replay /absolute/path/to/rl_session_001/replay_latest.pt \
  --output /absolute/path/to/rl_offline_001 \
  --steps 1000 --batch-size 32 --save-every 100 --device cuda:0
```

之后重启新服务，`--rl-checkpoint` 指向新 SAC 文件、`--output` 使用新目录。在线重启不会恢复上一轮尚未执行/未闭合的 chunk；磁盘旧 replay 可供离线训练，新在线会重新采集。旧策略回放超过 `max-policy-lag` 会拒绝更新，需新采集数据。

## 验证

```bash
cd /home/hq/code/iE2VLA3
PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 \
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \
python -m pytest -q tests/test_rl_chunk_service.py
```

测试覆盖 recorded/raw 坐标路径、原同步与异步签名/返回、TCP/共享内存、重复请求、reset 与并发推理、无确认不收集、force 缺失、实际时长折扣、terminal、SAC 更新/恢复、ROS 单位/力矩力臂转换，以及小型真实 Qwen/token/VLA checkpoint 的加载推理和训练 CLI。socket/共享内存测试需要操作系统允许本机 IPC。

尚未验证：不可直接访问的现网客户端进程、未知 ROS 2 话题映射、完整生产权重的 GPU 时延、真实机器人闭环与成功率。完成话题映射和真实执行关联后，才能进入在线 RL 实验。
