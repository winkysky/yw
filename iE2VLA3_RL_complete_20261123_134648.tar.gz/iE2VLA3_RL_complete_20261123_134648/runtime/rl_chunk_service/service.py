"""Inherit all existing exposed signatures and serialization wrappers unchanged."""
import time
import numpy as np
from shm_transport import expose
from e2vla_async.remote_service import Service as ExistingService
from e2vla_compat.planner import draw_prediction
from e2vla_compat.observations import HistoryNotReady
from .feedback import FeedbackNotReady


class Service(ExistingService):
    def __init__(self, policy, config=None, *, max_inference_hz=0.):
        super().__init__(policy=policy, config=config, max_inference_hz=max_inference_hz)

    def _invalidate(self):
        super()._invalidate()
        self.policy.session.reset("planner_generation_changed")
        self.policy.cache = None

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_status(self):
        result = super().get_status()
        result["rl"] = self.policy.session.status()
        return result

    def _predict(self, snapshot, seed=None, speed_mps=None, draw_traj=False, compress=False):
        sampler, settings, generation, sequence = snapshot
        with self.lock:
            if generation != self.generation or self.closed:
                raise RuntimeError("Planner changed before inference")
            epoch = self.policy.session.epoch
        sample = sampler.sample(settings.prompt)
        stamp = sampler.latest["timestamp"]
        started = time.monotonic()
        try:
            actions = self.policy.predict_at(sample, stamp, settings.seed if seed is None else seed,
                settings.speed_mps if speed_mps is None else speed_mps, settings.guidance_scale,
                expected_epoch=epoch)[0].numpy()
        except FeedbackNotReady as exc:
            raise HistoryNotReady(f"Waiting for measured wrench: {exc}") from exc
        poses, grippers = actions[..., :16].reshape(-1, 2, 4, 4), actions[..., 16]
        times = stamp + np.arange(len(actions))/self.policy.fps
        return dict(stream_id=self.stream_id, generation=generation, observation_sequence=sequence,
            observation_timestamp=stamp, inference_seconds=time.monotonic()-started,
            poses=poses.copy(), grippers=grippers.copy(), times=times,
            image=draw_prediction(sample, poses, compress) if draw_traj else None), sample

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        with self.compute_lock:
            with self.lock:
                settings, generation, epoch = self.settings, self.generation, self.policy.session.epoch
            result = self.policy.run_batch(obs_data, settings.seed if seed is None else seed, contract_sha256,
                settings.speed_mps if speed_mps is None else speed_mps,
                settings.guidance_scale if guidance_scale is None else guidance_scale, epoch)
            with self.lock:
                if generation != self.generation or self.closed:
                    raise RuntimeError("Planner changed during inference; result discarded")
            return result
