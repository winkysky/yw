"""Launch the additive Pyro4 service; default name/port do not replace existing services."""
import argparse
from dataclasses import replace
import json
from pathlib import Path
import signal
import threading
import cv2
import torch
import Pyro4
import Pyro4.naming
from e2vla_compat.config import PlannerConfig
from rl_factor_sac.reward import RewardConfig
from shm_transport import run_simple_server
from .policy import Policy
from .service import Service
from .feedback import FeedbackReader
from .online import OnlineLearner


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path, help="Existing PlannerConfig JSON, optional")
    p.add_argument("--checkpoint", "--ckpt", required=True, help="Completed factor VLA checkpoint")
    p.add_argument("--token", type=Path, required=True)
    p.add_argument("--rl-checkpoint", type=Path, required=True)
    p.add_argument("--reward-config", type=Path)
    p.add_argument("--output", type=Path, required=True, help="New directory for this service session")
    p.add_argument("--feedback", type=Path, required=True, help="Server-local JSONL inbox, written by ROS bridge")
    p.add_argument("--mode", choices=["inference", "collect", "train"], default="inference")
    p.add_argument("--source", choices=["robot", "simulator"], default="robot")
    p.add_argument("--task", choices=["close_box", "open_box", "place_phone"])
    for name in ("device", "prompt", "uri", "host", "ns-host", "input-pose-format", "input-gripper-format"):
        p.add_argument("--"+name)
    for name in ("port", "ns-port", "threads", "seed", "inference-timesteps"):
        p.add_argument("--"+name, type=int)
    p.add_argument("--variant", choices=["no_speed"], help="Legacy wire discriminator, not backend type")
    p.add_argument("--bf16", action="store_true", default=None)
    p.add_argument("--speed-mps", type=float)
    p.add_argument("--guidance-scale", type=float)
    p.add_argument("--start-ns", action="store_true")
    p.add_argument("--autostart", action="store_true")
    p.add_argument("--max-inference-hz", type=float, default=0.)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--warmup", type=int, default=32)
    p.add_argument("--save-every", type=int, default=100)
    p.add_argument("--max-policy-lag", type=int, default=1000)
    p.add_argument("--check-config", action="store_true")
    args = p.parse_args(argv)
    config = PlannerConfig.load(args.config) if args.config else PlannerConfig(uri="e2vla_rl", port=9102)
    overrides = {k: v for k, v in vars(args).items() if k in config.__dataclass_fields__ and v is not None}
    config = replace(config, **overrides).validate()
    if not config.task or (args.autostart and not config.prompt):
        p.error("Specify --task, and --prompt when using --autostart")
    import math
    if (not math.isfinite(args.max_inference_hz) or args.max_inference_hz < 0
            or min(args.batch_size, args.warmup, args.save_every) < 1 or args.max_policy_lag < 0):
        p.error("Invalid rate or learner settings")
    reward = RewardConfig(**json.loads(args.reward_config.read_text())) if args.reward_config else RewardConfig()
    if args.check_config:
        from rl_factor_sac.train import artifact_bindings
        from .artifacts import ChunkSAC
        bindings, _ = artifact_bindings(config.checkpoint, args.token, reward)
        learner = ChunkSAC.load(args.rl_checkpoint, "cpu", bindings)
        print(json.dumps(dict(planner=config.to_dict(), rl_config=learner.config.asdict(),
                             bindings=bindings, mode=args.mode), indent=2))
        return
    # Never reuse training output directories or touch an old checkpoint.
    args.output.mkdir(parents=True, exist_ok=False)
    if args.feedback.resolve().is_relative_to(args.output.resolve()):
        # Allowed, but it must be a distinct file from our output journal.
        if args.feedback.resolve() == (args.output/"proposals.jsonl").resolve():
            raise ValueError("Feedback inbox and proposal journal must differ")
    torch.set_num_threads(config.threads)
    cv2.setNumThreads(1)
    # shm_transport installs signal handlers on first use. Register it first so
    # our SIGTERM/SIGINT handlers below can drain and save the learner reliably.
    from shm_transport.shm_mng import register_cleanup_this_process
    register_cleanup_this_process()
    stopped = threading.Event()
    handlers = {sig: signal.signal(sig, lambda *_: stopped.set()) for sig in (signal.SIGINT, signal.SIGTERM)}
    owned_ns = service = reader = trainer = None
    try:
        try:
            ns = Pyro4.locateNS(host=config.ns_host, port=config.ns_port)
        except Pyro4.errors.NamingError:
            if not args.start_ns:
                raise
            _, owned_ns, _ = Pyro4.naming.startNS(host=config.ns_host, port=config.ns_port, enableBroadcast=False)
            threading.Thread(target=owned_ns.requestLoop, daemon=True).start()
            ns = Pyro4.locateNS(host=config.ns_host, port=config.ns_port)
        with ns:
            if config.uri in ns.list():
                raise ValueError(f"Service already registered: {config.uri}; refusing to replace it")
        policy = Policy.load(config, args.token, args.rl_checkpoint, mode=args.mode, source=args.source,
                             journal=args.output/"proposals.jsonl", reward=reward)
        service = Service(policy, config, max_inference_hz=args.max_inference_hz)
        (args.output/"service.json").write_text(json.dumps(service.get_info(), indent=2))
        reader = FeedbackReader(args.feedback, policy.session)
        trainer = OnlineLearner(policy.session, args.output, batch_size=args.batch_size,
            warmup=args.warmup, save_every=args.save_every, max_policy_lag=args.max_policy_lag)
        if args.autostart:
            service.start_async()
        print(json.dumps(dict(status="ready", uri=config.uri, output=str(args.output))), flush=True)
        run_simple_server(service, uri_name=config.uri, daemon_host=config.host, daemon_port=config.port,
            ns_host=config.ns_host, ns_port=config.ns_port, multiplex=False, replace_existing=False,
            loop_cond=lambda: not stopped.is_set())
    finally:
        # Stop ingestion/learning before reset clears the live execution ledger.
        try:
            if reader is not None:
                reader.close()
            if trainer is not None:
                trainer.close()
        finally:
            if service is not None:
                service.close()
            if owned_ns is not None:
                owned_ns.shutdown()
                owned_ns.close()
            for sig, handler in handlers.items():
                signal.signal(sig, handler)


if __name__ == "__main__":
    main()
