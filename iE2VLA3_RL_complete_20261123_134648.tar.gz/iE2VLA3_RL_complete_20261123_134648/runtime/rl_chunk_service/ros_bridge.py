"""Read server-local ROS topics and append normalized feedback; no robot writes."""
import argparse
import json
import math
from pathlib import Path
import threading
import numpy as np
from .feedback import append_event


def field(message, path):
    for key in path.split("."):
        message = message[key] if isinstance(message, dict) else (
            message[int(key)] if key.isdigit() else getattr(message, key))
    return message


def timestamp(value):
    if isinstance(value, (float, int)):
        result = float(value)
    elif hasattr(value, "sec"):
        result = float(value.sec) + float(value.nanosec)*1e-9
    elif hasattr(value, "secs"):
        result = float(value.secs) + float(value.nsecs)*1e-9
    else:
        raise ValueError("Expected seconds or ROS1/ROS2 timestamp")
    if not math.isfinite(result) or result < 0:
        raise ValueError("Invalid timestamp")
    return result


class Adapter:
    def __init__(self, config, emit):
        self.config, self.emit = config, emit
        self.lock = threading.RLock()
        self.latest = {}
        self.last_pair = -math.inf
        if set(config["wrench"]) != {"left", "right"}:
            raise ValueError("Both left and right measured wrench topics are required")
        self.skew = float(config.get("pair_tolerance_s", .02))
        if not 0 < self.skew <= .1:
            raise ValueError("Invalid wrench pairing tolerance")
        for cfg in config["wrench"].values():
            r = np.asarray(cfg["sensor_to_tcp_rotation"], float)
            p = np.asarray(cfg["tcp_to_sensor_translation_m"], float)
            bias = np.asarray(cfg.get("bias_si", [0]*6), float)
            if (r.shape != (3, 3) or p.shape != (3,) or bias.shape != (6,)
                    or not all(np.isfinite(x).all() for x in (r, p, bias))
                    or not np.allclose(r.T@r, np.eye(3), atol=1e-5)
                    or not np.isclose(np.linalg.det(r), 1., atol=1e-5)
                    or not cfg.get("expected_frame_id")):
                raise ValueError("Explicit wrench frame, SI tare and sensor-to-TCP transform required")
            for key in ("force_scale_to_n", "torque_scale_to_nm"):
                if not math.isfinite(cfg[key]) or cfg[key] <= 0:
                    raise ValueError("Invalid wrench unit conversion")

    def wrench(self, arm, message):
        cfg = self.config["wrench"][arm]
        stamp = timestamp(field(message, cfg["timestamp"]))
        if field(message, cfg.get("frame_id", "header.frame_id")) != cfg["expected_frame_id"]:
            raise ValueError(f"{arm} wrench frame differs from configured calibration")
        values = np.array([field(message, p) for p in cfg["fields"]], float)
        if values.shape != (6,) or not np.isfinite(values).all():
            raise ValueError("Invalid measured wrench")
        values *= [cfg["force_scale_to_n"]]*3 + [cfg["torque_scale_to_nm"]]*3
        values -= np.asarray(cfg.get("bias_si", [0]*6))
        r = np.asarray(cfg["sensor_to_tcp_rotation"])
        p = np.asarray(cfg["tcp_to_sensor_translation_m"])
        force = r@values[:3]
        values = np.r_[force, r@values[3:] + np.cross(p, force)]
        with self.lock:
            if arm in self.latest and stamp <= self.latest[arm][0]:
                raise ValueError(f"{arm} force clock moved backwards or duplicated")
            self.latest[arm] = stamp, values
            if len(self.latest) < 2:
                return
            left, right = self.latest["left"], self.latest["right"]
            pair_time = max(left[0], right[0])
            if abs(left[0]-right[0]) <= self.skew and pair_time > self.last_pair:
                self.emit(dict(type="wrench", timestamp=pair_time, values=[left[1].tolist(), right[1].tolist()]))
                self.last_pair = pair_time

    def feedback(self, cfg, message):
        if "json_field" in cfg:
            event = json.loads(field(message, cfg["json_field"]))
        else:
            event = dict(cfg.get("constants", {}))
            event.update({key: field(message, path) for key, path in cfg["fields"].items()})
        if event.get("type") not in ("activate", "outcome", "abort"):
            raise ValueError("Feedback topic must report activate/outcome/abort")
        for key in ("timestamp", "anchor"):
            if key in event:
                event[key] = timestamp(event[key])
        self.emit(event)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--check-config", action="store_true")
    args = p.parse_args(argv)
    config = json.loads(args.config.read_text())
    adapter = Adapter(config, lambda event: append_event(args.output, event))
    if config["ros_version"] not in (1, 2):
        raise ValueError("ros_version must be 1 or 2")
    if args.check_config:
        print("ROS mapping validated; topics/calibration still require deployment verification")
        return
    subscriptions = [(cfg, lambda msg, arm=arm: adapter.wrench(arm, msg))
                     for arm, cfg in config["wrench"].items()]
    subscriptions += [(cfg, lambda msg, cfg=cfg: adapter.feedback(cfg, msg)) for cfg in config.get("feedback", [])]
    # Import ROS only here. The bridge can run in the system ROS Python while
    # the VLA server runs in its Conda environment, exchanging local JSONL.
    if config["ros_version"] == 2:
        import rclpy
        from rclpy.node import Node
        from rclpy.qos import qos_profile_sensor_data
        from rosidl_runtime_py.utilities import get_message
        rclpy.init()
        node = Node("ie2vla_chunk_feedback")
        try:
            handles = [node.create_subscription(get_message(cfg["message_type"]), cfg["topic"], cb,
                       qos_profile_sensor_data if cfg in config["wrench"].values() else 100)
                       for cfg, cb in subscriptions]
            rclpy.spin(node)
        finally:
            node.destroy_node()
            rclpy.shutdown()
    else:
        import rospy
        from roslib.message import get_message_class
        rospy.init_node("ie2vla_chunk_feedback")
        handles = [rospy.Subscriber(cfg["topic"], get_message_class(cfg["message_type"]), cb, queue_size=100)
                   for cfg, cb in subscriptions]
        rospy.spin()


if __name__ == "__main__":
    main()
