"""Chunk decisions and execution ledger, independent of Pyro and ROS."""
from collections import OrderedDict
import hashlib
import math
import threading
import time
import uuid
import numpy as np
import torch
from models.speed_factor import FACTORS
from rl_factor_sac.foundation import state_features
from rl_factor_sac.geometry import check_se3, compose_residual, pose_features, so3_log
from rl_factor_sac.networks import validate_observation
from rl_factor_sac.replay import ReplayBuffer, copy_obs, validate_batch
from rl_factor_sac.reward import EpisodeReward, RewardConfig
from .feedback import WrenchBuffer, append_event
from .artifacts import save_replay


def trajectory_digest(actions):
    return hashlib.sha256(np.asarray(actions, dtype="<f4").tobytes(order="C")).hexdigest()


class ChunkSession:
    def __init__(self, foundation, learner, bindings, *, mode="inference", source="robot",
                 journal=None, capacity=10000, clock=time.time):
        if mode not in ("inference", "collect", "train") or source not in ("robot", "simulator"):
            raise ValueError("Invalid session mode/source")
        self.foundation = foundation.freeze_online()
        self.learner, self.config, self.bindings = learner, learner.config, bindings
        self.device = next(learner.factor.actor.parameters()).device
        if next(foundation.base.parameters()).device != self.device:
            raise ValueError("Foundation and SAC must use the same device")
        if foundation.token.config.token_dim != self.config.token_dim:
            raise ValueError("Token dimension mismatch")
        self.mode, self.source, self.journal, self.clock = mode, source, journal, clock
        self.lock = threading.RLock()
        self.wrench = WrenchBuffer(self.config)
        self.buffers = {k: ReplayBuffer(self.config, k, capacity) for k in ("factor", "residual")}
        self.pending = OrderedDict()
        self.active = None
        self.epoch = uuid.uuid4().hex
        self.error = None
        self.ended = False
        self.accepted = self.transitions = self.discarded = 0

    def emit(self, event):
        if self.journal:
            append_event(self.journal, dict(epoch=self.epoch, **event))

    def status(self):
        with self.lock:
            return dict(mode=self.mode, epoch=self.epoch, error=self.error, ended=self.ended,
                active_chunk=None if self.active is None else self.active["id"],
                proposed=len(self.pending), accepted=self.accepted, transitions=self.transitions,
                discarded=self.discarded, replay={k: len(v) for k, v in self.buffers.items()},
                policies=self.learner.versions)

    def reset(self, reason="planner_reset"):
        with self.lock:
            self.discarded += int(self.active is not None) + len(self.pending)
            self.active = None
            self.pending.clear()
            self.emit(dict(type="aborted", reason=reason))
            self.epoch = uuid.uuid4().hex
            self.error, self.ended = None, False

    def fault(self, message):
        with self.lock:
            self.error = message
            self.emit(dict(type="error", message=message))

    def _reference(self, actions):
        a = torch.as_tensor(actions, device=self.device, dtype=torch.float32)
        return pose_features(a[..., :16].reshape(32, 2, 4, 4), a[..., 16]).flatten(-2)[None]

    def _observation(self, prepared, anchor, now):
        c = self.config
        tensor = lambda x: torch.as_tensor(x, device=self.device, dtype=torch.float32)
        obs = dict(token=prepared.token.detach(), state=state_features(prepared.batch),
            wrench=tensor(self.wrench.history(anchor))[None],
            reference=torch.zeros(1, 32, 20, device=self.device),
            reference_mask=torch.zeros(1, 32, device=self.device),
            execution=tensor([[0, 0, 0, 0, now-anchor, 0, 0]]),
            previous_residual=torch.zeros(1, 12, device=self.device),
            factor_mask=torch.ones(1, 4, device=self.device))
        if self.active is not None:
            p = self.active
            from data_utils.trajectory_retime32 import sample_poses, sample_grippers
            times = np.arange(32)/c.control_hz
            query = anchor - p["anchor"] + times
            mask = (query >= 0) & (query <= times[-1])
            if mask.any():
                a = p["reference"]
                poses = sample_poses(times, a[..., :16].reshape(32, 2, 4, 4), query[mask])
                grips = sample_grippers(times, a[..., 16], query[mask])
                obs["reference"][0, mask] = pose_features(tensor(poses), tensor(grips)).flatten(-2)
                obs["reference_mask"][0, mask] = 1
            age = max(0., anchor-p["anchor"])
            obs["execution"] = tensor([[p["factor"], 0, min(1., age/times[-1]), age,
                                        now-anchor, float(mask[0]), 0]])
            obs["previous_residual"] = p["residual_action"].to(self.device)
        validate_observation(obs, c)
        return obs

    @torch.no_grad()
    def propose(self, prepared, anchor, *, expected_epoch=None, deterministic=True, initial_noise=None,
                locator="planner_timestamp"):
        """One factor action -> one VLA chunk -> one 12-D residual action.

        This method never acknowledges execution. It also does not hold the
        feedback lock across VLA inference, so ROS ACKs can continue arriving.
        """
        now = self.clock()
        if (not math.isfinite(anchor) or anchor < 0 or not math.isfinite(now)
                or now < anchor-2e-6 or now > anchor+31/self.config.control_hz):
            raise ValueError("Observation clock differs or the whole chunk has expired")
        with self.lock:
            if self.error or self.ended:
                raise RuntimeError(self.error or "Episode ended; reset the planner")
            if expected_epoch is not None and self.epoch != expected_epoch:
                raise RuntimeError("Planner changed during encoding")
            epoch = self.epoch
            parent = None if self.active is None else self.active["id"]
            obs = self._observation(prepared, anchor, now)
        # Immutable actors give both decisions a well-defined pair of versions.
        actors = self.learner.actor_snapshot()
        factor_action = actors["factor"].act(obs, deterministic)
        factor = FACTORS[int(factor_action.item())]
        reference = self.foundation.predict(prepared, factor, initial_noise,
            fp16=self.device.type == "cuda").detach().float().cpu().numpy()[0]
        if reference.shape != (32, 2, 17) or not np.isfinite(reference).all():
            raise ValueError("Invalid VLA output")
        check_se3(reference[..., :16].reshape(32, 2, 4, 4))
        # Gripper is left untouched, matching the existing VLA wire endpoint.
        residual_obs = copy_obs(obs)
        residual_obs["reference"] = self._reference(reference)
        residual_obs["reference_mask"].fill_(1)
        residual_obs["execution"][:, 1] = factor
        residual_obs["execution"][:, 6] = 1
        validate_observation(residual_obs, self.config)
        residual_action = actors["residual"].act(residual_obs, deterministic)
        poses = torch.as_tensor(reference[..., :16].reshape(32, 2, 4, 4), device=self.device)
        corrected = compose_residual(poses, residual_action.expand(32, -1), self.config)
        linear = torch.linalg.vector_norm(corrected[1:, :, :3, 3]-corrected[:-1, :, :3, 3], dim=-1)*30
        angular = torch.linalg.vector_norm(so3_log(corrected[:-1, :, :3, :3].transpose(-1,-2)
                                                 @ corrected[1:, :, :3, :3]), dim=-1)*30
        if ((linear > self.config.max_command_speed_mps).any()
                or (angular > self.config.max_command_angular_speed).any()):
            raise ValueError("Composed trajectory exceeds configured linear/angular command limits")
        actions = reference.copy()
        actions[..., :16] = corrected.cpu().numpy().reshape(32, 2, 16)
        completed = self.clock()
        with self.lock:
            if epoch != self.epoch or self.error or self.ended:
                raise RuntimeError("Planner changed during generation; proposal discarded")
            if completed > anchor+31/self.config.control_hz:
                raise ValueError("VLA result expired; timestamps are not shifted forward")
            plan = dict(id=uuid.uuid4().hex, epoch=epoch, parent=parent, anchor=float(anchor),
                decision_time=now, completed=completed, factor=factor, reference=reference,
                actions=actions, factor_action=factor_action.cpu(), residual_action=residual_action.cpu(),
                factor_obs=copy_obs(obs, "cpu"), residual_obs=copy_obs(residual_obs, "cpu"),
                versions=actors["versions"], digest=trajectory_digest(actions), locator=locator)
            self.pending[plan["id"]] = plan
            while len(self.pending) > 256:
                self.pending.popitem(last=False)
                self.discarded += 1
            self.emit(dict(type="proposal", chunk_id=plan["id"], anchor=anchor,
                completed=completed, factor=factor, residual=residual_action[0].cpu().tolist(),
                parent=parent, trajectory_sha256=plan["digest"], locator=locator,
                versions=plan["versions"]))
        return actions.copy(), plan["id"]

    def _resolve(self, event):
        if event.get("chunk_id"):
            matches = [p for p in self.pending.values() if p["id"] == event["chunk_id"]]
        elif event.get("trajectory_sha256"):
            matches = [p for p in self.pending.values() if p["digest"] == event["trajectory_sha256"]]
        elif "anchor" in event:
            anchor = float(event["anchor"])
            matches = [p for p in self.pending.values() if p["locator"] == "planner_timestamp"
                       and abs(p["anchor"]-anchor) < 1e-6]
        else:
            raise ValueError("Execution feedback needs chunk_id, trajectory_sha256 or original planner anchor")
        if len(matches) != 1:
            raise ValueError("Execution feedback identifies no proposal or is ambiguous")
        return matches[0]

    def _finish(self, next_plan, stamp, outcome=None):
        old = self.active
        start = old["activated"]
        if stamp <= start or stamp > old["anchor"]+31/self.config.control_hz+2e-6:
            raise ValueError("Unreported execution gap/expired trajectory; abort this interval")
        segments = self.wrench.interval(start, stamp)
        reward_fn = EpisodeReward(RewardConfig(**self.bindings["reward_config"]))
        action = old["residual_action"][0].numpy()
        prev = old["residual_obs"]["previous_residual"][0].numpy()
        reward = 0.
        for i, (left, right, wrench) in enumerate(segments):
            r, _ = reward_fn.step(right-left, wrench, action, prev,
                                 outcome if i == len(segments)-1 else None)
            reward += self.config.gamma_per_second**(left-start)*r
        rows = {}
        for branch in ("factor", "residual"):
            obs = old[branch+"_obs"]
            # Terminal states do not bootstrap. Nonterminal states are the next
            # actual factor/residual decision, including its new reference.
            next_obs = obs if outcome else next_plan[branch+"_obs"]
            scalar = lambda v: torch.tensor([[float(v)]], dtype=torch.float32)
            rows[branch] = dict(obs=obs, next_obs=next_obs, action=old[branch+"_action"],
                reward=scalar(reward), discount=scalar(self.config.discount(stamp-start)),
                terminated=scalar(outcome is not None), truncated=scalar(False))
            validate_batch(rows[branch], self.config, branch)
        if self.mode != "inference":
            for branch, row in rows.items():
                self.buffers[branch].add(row, versions=old["versions"], timestamp=start,
                    source=self.source, activation_delay_s=start-old["decision_time"])
            self.transitions += 1
        self.emit(dict(type="transition", chunk_id=old["id"], timestamp=stamp,
            elapsed=stamp-start, reward=reward, outcome=outcome, collected=self.mode != "inference"))

    def handle(self, event):
        kind = event.get("type")
        if kind == "wrench":
            self.wrench.add(float(event["timestamp"]), event["values"])
            return
        with self.lock:
            if kind == "abort":
                self.reset(event.get("reason", "external_abort"))
                return
            if self.error:
                raise RuntimeError(self.error)
            stamp = float(event["timestamp"])
            if not math.isfinite(stamp) or stamp < 0 or stamp > self.clock()+.05:
                raise ValueError("Execution timestamp is invalid/in the future")
            if kind == "activate":
                if self.ended or event.get("execution_matches_proposal") is not True:
                    raise ValueError("Need explicit confirmation of the selected proposal's execution")
                plan = self._resolve(event)
                if (stamp < plan["completed"]-2e-6 or stamp > plan["anchor"]+31/self.config.control_hz
                        or plan["parent"] != (None if self.active is None else self.active["id"])):
                    raise ValueError("Stale execution ACK or parent differs from the policy observation")
                if self.active is not None:
                    self._finish(plan, stamp)
                self.pending.pop(plan["id"])
                self.active = dict(plan, activated=stamp)
                self.accepted += 1
                self.emit(dict(type="activated", chunk_id=plan["id"], timestamp=stamp))
            elif kind == "outcome":
                if self.active is None or self.ended or event.get("outcome") not in ("success", "failure"):
                    raise ValueError("Outcome requires a live executed chunk and success/failure")
                if event.get("chunk_id") != self.active["id"]:
                    raise ValueError("Outcome must identify the currently executed chunk")
                self._finish(None, stamp, event["outcome"])
                self.active = None
                self.pending.clear()
                self.ended = True
            else:
                raise ValueError(f"Unknown feedback event: {kind}")

    def save_replay(self, path):
        with self.lock:
            save_replay(path, self.buffers, self.bindings)
