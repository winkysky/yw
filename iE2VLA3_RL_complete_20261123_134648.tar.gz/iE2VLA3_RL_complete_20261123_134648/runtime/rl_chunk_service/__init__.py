"""Additive, chunk-rate dual-SAC service; legacy services remain unchanged."""
