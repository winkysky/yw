"""Bounded background updates: one paired learner step per new transition."""
import json
from pathlib import Path
import threading
from .feedback import append_event


class OnlineLearner:
    def __init__(self, session, output, *, batch_size=32, warmup=32, save_every=100, max_policy_lag=1000):
        if min(batch_size, warmup, save_every) < 1 or max_policy_lag < 0:
            raise ValueError("Invalid online learner settings")
        self.session, self.output = session, Path(output)
        self.batch_size, self.warmup = batch_size, warmup
        self.save_every, self.max_policy_lag = save_every, max_policy_lag
        self.stopped = threading.Event()
        self.seen = 0
        self.last_saved = 0
        self.worker = threading.Thread(target=self._work, name="chunk-sac-learner", daemon=True)
        self.worker.start()

    def _work(self):
        try:
            while not self.stopped.wait(.05):
                s = self.session
                with s.lock:
                    count = s.transitions
                    if s.error or count <= self.seen:
                        continue
                    buffers = s.buffers
                    ready = min(len(b) for b in buffers.values()) >= self.warmup
                if s.mode == "train" and ready:
                    learner = s.learner
                    batches = {k+"_batch": b.sample(self.batch_size, s.device, learner.versions,
                                                    self.max_policy_lag) for k, b in buffers.items()}
                    metrics = learner.update(**batches)
                    append_event(self.output/"loss.jsonl", dict(transitions=count, **metrics))
                # Warmup transitions do not create a backlog of GPU updates.
                self.seen = count
                if count-self.last_saved >= self.save_every:
                    self.save()
                    self.last_saved = count
        except Exception as exc:
            self.session.fault(f"learner: {type(exc).__name__}: {exc}")

    def save(self):
        s = self.session
        s.save_replay(self.output/"replay_latest.pt")
        s.learner.save(self.output/"sac_latest.pt", s.bindings)
        (self.output/"status.json").write_text(json.dumps(s.status(), indent=2))

    def close(self):
        self.stopped.set()
        self.worker.join(30.)
        if self.worker.is_alive():
            raise TimeoutError("SAC learner is still finishing")
        self.save()
