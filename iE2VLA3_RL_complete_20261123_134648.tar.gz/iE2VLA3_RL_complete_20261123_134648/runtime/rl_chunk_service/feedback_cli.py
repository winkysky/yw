"""Manual terminal labels or normalized adapter events; never fake execution ACKs."""
import argparse
import json
from pathlib import Path
import time
from .feedback import append_event


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--event", help="Normalized JSON from a measured execution adapter")
    p.add_argument("--outcome", choices=["success", "failure"])
    p.add_argument("--chunk-id")
    p.add_argument("--timestamp", type=float)
    p.add_argument("--abort", action="store_true")
    args = p.parse_args(argv)
    if sum((args.event is not None, args.outcome is not None, args.abort)) != 1:
        p.error("Select exactly one of --event, --outcome, --abort")
    if args.outcome and not args.chunk_id:
        p.error("--outcome requires the currently executed --chunk-id")
    event = json.loads(args.event) if args.event else dict(
        type="abort" if args.abort else "outcome", timestamp=time.time() if args.timestamp is None else args.timestamp,
        outcome=args.outcome, chunk_id=args.chunk_id)
    append_event(args.output, event)


if __name__ == "__main__":
    main()
