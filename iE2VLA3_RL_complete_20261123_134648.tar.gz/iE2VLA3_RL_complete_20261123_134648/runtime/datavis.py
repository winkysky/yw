import cv2
import argparse
import sys
from typing import Optional

from client import Client
import data_utils.transforms as TF
from data_utils.registry import find_marked_classes
from data_utils.tokenize import DataRawVLA, collate_fn
from data_utils.dataset_base import DatasetBase, DataConfig
from data_utils.visualize import draw_state_actions, concat_bgrs, resize_to_fit


MAX_IMAGE_WH = (960, 640)


def list_dataset():
    classes = find_marked_classes("dataset")
    classes.sort(key=lambda c: c.__name__)
    return {c.__name__: c for c in classes}


def visualize_dataset(dataset: DatasetBase, model_proxy: Optional[Client] = None):
    episode_idx = 0
    frame_index = 0

    handler, episode_len = dataset.get_handler(episode_idx)

    step = 1
    model_infer_enabled = True

    if model_proxy is not None:
        data_transforms = TF.Compose([
            TF.CenterCamera(), 
            TF.MakeInstruction(), 
            TF.SmartResize(patch_size=32),
            TF.Tokenize(preserve_raw_vl=False), 
        ])
    else:
        data_transforms = None
    
    while True:
        print("-"*61)
        print("[INFO] Usage:")
        print("q: quit")
        print("p: previous episode")
        print("n: next episode")
        print("<-: previous frame")
        print("->: next frame")
        print("a: toggle step size between 1 and 10")
        print("i: toggle model inference mode")
        print()

        print("[INFO] Step size: {}".format(step))
        print("[INFO] Model inference mode: {}".format(model_infer_enabled))
        print("[INFO] Episode: {}/{}, frame: {}/{}".format(
            episode_idx+1, len(dataset), frame_index, episode_len))
        

        data_raw: DataRawVLA = dataset.sample_episode(handler, episode_len, frame_index)
        print("[INFO] Prompt text: {}".format(data_raw.raw_vl.prompt))
        

        actions = [data_raw.action.clone()]
        traj_colors = [(0, 255, 0)]
        
        if model_infer_enabled and (model_proxy is not None):
            batch_data = collate_fn([data_transforms(data_raw)])
            action_pred = model_proxy.inference_batch(batch_data)  # (B, Nee, Ta, 17+?)
            
            actions.append(action_pred[0])  # remove batch dimension
            traj_colors.append((255, 0, 0))
        
        bgrs = draw_state_actions(
            raw_vl=data_raw.raw_vl, 
            state=data_raw.state,
            state_mask=data_raw.state_mask, 
            actions=actions,  
            colors=traj_colors
        )
        bgrs = concat_bgrs(bgrs)
        print("[INFO] bgrs shape = {}".format(bgrs.shape))
        bgrs = resize_to_fit(bgrs, *MAX_IMAGE_WH)

        cv2.imshow("gt traj", bgrs)
        key = cv2.waitKey(0)
        
        if key == ord("n"):
            dataset.close_handler(handler)
            episode_idx = (episode_idx + 1) % len(dataset)
            frame_index = 0
            handler, episode_len = dataset.get_handler(episode_idx)
        elif key == ord('p'):
            dataset.close_handler(handler)
            episode_idx = (episode_idx - 1) % len(dataset.h5_filelist)
            frame_index = 0
            handler, episode_len = dataset.get_handler(episode_idx)
        elif key == 83:
            frame_index = (frame_index + step) % episode_len
        elif key == 81:
            frame_index = (frame_index - step) % episode_len
        elif key == ord('q'):
            dataset.close_handler(handler)
            break
        elif key == ord('a'):
            step = {1: 10, 10: 1}[step]
        elif key == ord('i'):
            model_infer_enabled = (not model_infer_enabled) and (model_proxy is not None)


def main():
    if "--lerobot" in sys.argv[1:]:
        from models.m0512_fm.visualize_lerobot import main as lerobot_main
        lerobot_main([arg for arg in sys.argv[1:] if arg != "--lerobot"])
        return
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", type=str, nargs="?")
    parser.add_argument("-l", "--list", action="store_true", default=False,
                        help="list the available datasets")
    parser.add_argument("--uri", type=str, default="")
    parser.add_argument("--ns_host", type=str, default="localhost")
    parser.add_argument("--ns_port", type=int, default=9090)
    parser.add_argument("--tcp", action="store_true", default=False)
    parser.add_argument("--lerobot", action="store_true",
                        help="LeRobot dual-arm visualization; use --lerobot --help for checkpoint/export options")
    opt = parser.parse_args()
    
    classes = list_dataset()
    if len(classes) == 0:
        print("[INFO] No datasets available.")
        quit()
    
    if opt.uri:
        model_proxy = Client(
            uri_name=opt.uri, 
            ns_host=opt.ns_host, 
            ns_port=opt.ns_port, 
            force_tcp=opt.tcp
        )
    else:
        model_proxy = None

    if opt.list:
        print("[INFO] Available datasets:")
        for i, c in enumerate(classes):
            print(" - [{}] {}".format(i, c))
        quit()
    
    dataset_name = opt.dataset
    if dataset_name is None:
        print("[INFO] Available datasets:")
        for i, c in enumerate(classes):
            print(" - [{}] {}".format(i, c))
        
        print()
        idx = input("[INFO] Please specify the dataset by its index: ")
        idx = int(idx)
        dataset_name = list(classes.keys())[idx]

    dataset_cls: type[DatasetBase] = classes[dataset_name]
    dataset = dataset_cls.inst(DataConfig(), None)

    # disable shuffle_cameras and random ref action pose for custom hdf5 datasets
    from dataset.custom_hdf5.map_base import H5DatasetMapBase
    if isinstance(dataset, H5DatasetMapBase):
        dataset.unique_config.shuffle_cameras = False
        print("[INFO] In dataset visualization, set shuffle_cameras to False")
        for ee_ind, cam_names in dataset.unique_config.ee_ref_cams.items():
            if isinstance(cam_names, (list, tuple)) and len(cam_names) > 1:
                dataset.unique_config.ee_ref_cams[ee_ind] = (cam_names[0],)  # only choose the first one
                print("[INFO] In dataset visualization, set ref cam of ee_ind {} to {}"
                    .format(ee_ind, cam_names[0]))

    visualize_dataset(dataset, model_proxy)


if __name__ == "__main__":
    main()


