import os

os.environ["TORCHINDUCTOR_CACHE_DIR"] = "./.cache/torchinductor"
os.environ["TORCHINDUCTOR_FX_GRAPH_CACHE"] = "1"
os.environ["TRITON_CACHE_DIR"] = "./.cache/triton"
os.environ["TORCH_LOGS"] = "inductor,dynamo,guards"
