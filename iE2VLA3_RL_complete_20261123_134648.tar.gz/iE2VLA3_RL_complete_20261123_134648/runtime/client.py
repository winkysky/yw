import copy
import torch
import threading
import numpy as np
from torch import Tensor
from dataclasses import dataclass
from collections import defaultdict
from typing import Optional, List, Dict, Union

from action import align
from action.define import ORDERED_ACTION_SPACE
from action.parser import ProprioParser, ProprioData
from data_utils.visualize import draw_state_actions, concat_bgrs, resize_to_fit
from data_utils.data_raw import CompressedImage, DataRawVL, DataRawVLA
from shm_transport import get_shm_proxy


@dataclass
class ImageObservation(object):
    K: np.ndarray        # (3, 3)
    pose: np.ndarray     # (4, 4)
    color: Union[np.ndarray, Tensor]    # (H, W, 3) or 1D array (compressed via jpeg)
    encoding: str                       # rgb, bgr, rgb_compressed, bgr_compressed


def parse_batch_proprio(
    proprio: Dict[str, ProprioData]
):
    mask: Dict[str, np.ndarray] = {}
    data: Dict[str, np.ndarray] = {}

    for k, v in proprio.items():
        x, m = v.to_raw()
        data[k] = x
        mask[k] = m
    
    return data, mask


def query_images(
    query_time: np.ndarray, 
    camera_time: Dict[str, np.ndarray], 
    camera_data: Dict[str, List[ImageObservation]], 
):
    """
    Args:
        query_time (np.ndarray): (Tq,)
        camera_time (Dict[str, np.ndarray]): key is camera name, value has shape (To,)
        camera_data (Dict[str, List[ImageObservation]]): key is camera name
    """
    Ks = []
    rgbs = []
    camera_poses = []
    camera_names = []
    
    for camera_name in camera_time:
        camera_names.append(camera_name)
        train_time = camera_time[camera_name]
        camera_indices: List[int] = align.find_closest_ind(train_time, query_time)

        mframe_poses = []
        mframe_colors = []
        for i in camera_indices:
            obs = camera_data[camera_name][i]
            mframe_poses.append(obs.pose)
            mframe_colors.append(CompressedImage(obs.color, obs.encoding))
        
        Ks.append(obs.K)
        rgbs.append(mframe_colors)
        camera_poses.append(np.stack(mframe_poses, axis=0))  # (T, 4, 4)
    
    Ks = np.stack(Ks, axis=0)
    return camera_names, Ks, rgbs, camera_poses


def interp_states(
    query_time: np.ndarray, 
    train_time: np.ndarray, 
    parser: ProprioParser
):
    """
    Args:
        query_time (np.ndarray): (Tq,)
        train_time (np.ndarray): (Tr,)
        parser (ProprioParser): contains state with shape (Tr, ..., D)
    
    Returns:
        parser (ProprioParser): contains state with shape (Tq, ..., D)
    """
    train_data = {}
    interp_funcs = {}
    for attr in ORDERED_ACTION_SPACE:
        attr_mask = parser._get_mask(attr)  # (T, D_attr)
        if not np.any(attr_mask):
            continue
        
        interp_funcs[attr] = ORDERED_ACTION_SPACE[attr][1]
        train_data[attr] = parser._get_slice(attr)  # (T, D_attr)
    
    query_data = align.align_data(
        query_time=query_time,
        train_time=train_time,
        train_data=train_data,
        interp_funcs=interp_funcs
    )
    return ProprioParser(*ProprioData(**query_data).to_raw())


def query_states(
    query_time: np.ndarray, 
    state_time: Dict[str, np.ndarray], 
    state_data: Dict[str, np.ndarray], 
    state_mask: Dict[str, np.ndarray], 
):
    """
    Args:
        query_time (np.ndarray): (Tq,)
        state_time (Dict[str, np.ndarray]): key is ee name, value has shape (Ts,)
        state_data (Dict[str, np.ndarray]): key is ee name, value has shape (Ts, D)
        state_mask (Dict[str, np.ndarray]): key is ee name, value has shape (Ts, D)
    
    Returns
    -------
        ee_names (List[str]): list of ee names
        all_states (np.ndarray): shape (Nee, Tq, D)
        all_masks (np.ndarray): shape (Nee, Tq, D)
    """
    ee_names = []
    all_states, all_masks = [], []
    
    for ee_name in state_time:
        ee_names.append(ee_name)
        train_time = state_time[ee_name]
        train_states = state_data[ee_name]  # (T, D)
        train_masks = state_mask[ee_name]   # (T, D)
        parser = ProprioParser(train_states, train_masks)
        
        queries = interp_states(query_time, train_time, parser)
        all_states.append(queries.raw)  # (Tq, D)
        all_masks.append(queries.mask)  # (Tq, D)
    
    all_states = np.stack(all_states, axis=0)  # (Nee, Tq, D)
    all_masks = np.stack(all_masks, axis=0)    # (Nee, Tq, D)
    return ee_names, all_states, all_masks


class DataBuffer(object):

    @dataclass
    class SampleConfig(object):
        ee_ref_cams: Dict[str, str]
        num_history_images: int = 1
        num_history_states: int = 1
        num_future_actions: int = 32
        image_dt: float = 0.1
        state_dt: float = 0.1

    def __init__(self, sample_config: SampleConfig):
        self.sample_config = sample_config

        self.camera_time: Dict[str, List[float]] = defaultdict(list)
        self.camera_data: Dict[str, List[ImageObservation]] = defaultdict(list)
        self.camera_lock = threading.Lock()

        self.state_time: Dict[str, List[float]] = defaultdict(list)
        self.state_data: Dict[str, List[np.ndarray]] = defaultdict(list)
        self.state_mask: Dict[str, List[np.ndarray]] = defaultdict(list)
        self.state_lock = threading.Lock()
    
    def clear(self):
        with self.camera_lock:
            self.camera_time.clear()
            self.camera_data.clear()
        
        with self.state_lock:
            self.state_time.clear()
            self.state_data.clear()
            self.state_mask.clear()        
        return self
    
    def add_image(self, t: float, camera_name: str, image: ImageObservation):
        with self.camera_lock:
            self.camera_time[camera_name].append(t)
            self.camera_data[camera_name].append(image)
            
            timestamps = self.camera_time[camera_name]
            dt_tol = self.sample_config.num_history_images * self.sample_config.image_dt
            while len(timestamps) > 3 and timestamps[-1] - timestamps[1] > dt_tol:
                timestamps.pop(0)
                self.camera_data[camera_name].pop(0)

        return self
    
    def add_state(self, t: float, ee_name: str, state: np.ndarray, mask: Optional[np.ndarray]):
        if mask is None:
            mask = np.ones_like(state, dtype=bool)
        
        with self.state_lock:
            self.state_time[ee_name].append(t)
            self.state_data[ee_name].append(state)
            self.state_mask[ee_name].append(mask)
            
            timestamps = self.state_time[ee_name]
            dt_tol = self.sample_config.num_history_states * self.sample_config.state_dt
            while len(timestamps) > 3 and timestamps[-1] - timestamps[1] > dt_tol:
                timestamps.pop(0)
                self.state_data[ee_name].pop(0)
                self.state_mask[ee_name].pop(0)

        return self
    
    def _get_images(self, t: float):
        with self.camera_lock:
            camera_time = {k: np.asarray(v) for k, v in self.camera_time.items()}
            camera_data = {k: copy.copy(v) for k, v in self.camera_data.items()}

        query_time = t + np.arange(-self.sample_config.num_history_images + 1, 1) * self.sample_config.image_dt
        camera_names, Ks, rgbs, camera_poses = query_images(
            query_time=query_time,
            camera_time=camera_time,
            camera_data=camera_data
        )
        return Ks, rgbs, camera_poses, camera_names
    
    def _get_states(self, t: float):
        with self.state_lock:
            state_time = {k: np.asarray(v) for k, v in self.state_time.items()}
            state_data = {k: np.asarray(v) for k, v in self.state_data.items()}
            state_mask = {k: np.asarray(v) for k, v in self.state_mask.items()}
        
        query_time = t + np.arange(-self.sample_config.num_history_states + 1, 1) * self.sample_config.state_dt
        ee_names, all_states, all_masks = query_states(
            query_time=query_time,
            state_time=state_time,
            state_data=state_data,
            state_mask=state_mask
        )
        return all_states, all_masks, ee_names

    def get(self, t: float):
        Ks, rgbs, camera_poses, camera_names = self._get_images(t)
        states, state_masks, ee_names = self._get_states(t)

        actions = states[:, -1:].repeat(self.sample_config.num_future_actions, axis=1)
        action_masks = state_masks[:, -1:].repeat(self.sample_config.num_future_actions, axis=1)

        ref_poses = []
        for ee_name in ee_names:
            ref_camera_name = self.sample_config.ee_ref_cams[ee_name]
            index = camera_names.index(ref_camera_name)
            ref_poses.append(camera_poses[index][-1])  # (4, 4)
        ref_poses = np.stack(ref_poses, axis=0)  # (Nee, 4, 4)

        return DataRawVLA(
            raw_vl=DataRawVL(
                K=torch.from_numpy(Ks).float(),
                rgb=rgbs,
                pose=[torch.from_numpy(T).float() for T in camera_poses],
                fps=1.0 / self.sample_config.image_dt,
                prompt=None
            ),
            state=torch.from_numpy(states).float(),
            state_mask=torch.from_numpy(state_masks).bool(),
            action=torch.from_numpy(actions).float(),
            action_mask=torch.from_numpy(action_masks).bool(),
            action_ref_pose=torch.from_numpy(ref_poses).float(), 
        )


class Client(object):
    def __init__(
        self, 
        uri_name: str,              # alias name of the launched service
        ns_host: str = "localhost", # host of naming server
        ns_port: int = 9090,        # port of naming server
        force_tcp: bool = False, 
    ):
        self._proxy = get_shm_proxy(
            uri_name=uri_name,
            ns_host=ns_host,
            ns_port=ns_port,
            force_use_socket=force_tcp
        )
    
    @property
    def data_config(self) -> dict:
        return self._proxy.get_data_config()

    @property
    def policy_info(self) -> dict:
        """Checkpoint and input contract exposed by the LeRobot service."""
        return self._proxy.get_policy_info()
    
    def insert_resize_transform(self, h: int, w: int):
        self._proxy.insert_resize_transform(h, w)
    
    def inference_raw(self, req: DataRawVLA, seed=None) -> np.ndarray:
        """Returns actions with shape (Nee, Ta, D)"""
        if seed is None:
            return self._proxy.inference_raw(req)
        return self._proxy.inference_raw(req, seed=seed)

    def inference_batch(self, batch, seed=None):
        if seed is None:
            return self._proxy.inference_batch(batch)
        return self._proxy.inference_batch(batch, seed=seed)

    def inference_observation(self, observation: dict, seed=None) -> np.ndarray:
        """LeRobot recorded TCP/state fields and named RGB images -> [2, T, 73]."""
        return self._proxy.inference_observation(observation, seed=seed)

    def inference_world_observation(self, observation: dict, seed=None) -> np.ndarray:
        """Common-frame TCP matrices/metres and normalized grippers -> [2,T,73]."""
        return self._proxy.inference_world_observation(observation, seed=seed)

    def close(self):
        self._proxy._pyro_proxy._pyroRelease()


def draw_trajectory(req: DataRawVLA, actions: np.ndarray):
    req.decompress_()
    bgrs = draw_state_actions(
        raw_vl=req.raw_vl,
        state=req.state,
        state_mask=req.state_mask, 
        actions=[torch.from_numpy(actions)],
        colors=[(0, 0, 255)]
    )
    bgrs = concat_bgrs(bgrs)
    bgrs = resize_to_fit(bgrs, 960, 640)
    return bgrs

