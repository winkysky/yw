"""Real checkpoint + original e2vla clients over TCP; no ROS/robot commands."""
import argparse
import copy
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

import cv2
import numpy as np
import pyarrow.parquet as pq
import Pyro4
import Pyro4.naming
import torch

from dataset.lerobot_dual import decode_tcp, decode_gripper
from dataset.lerobot_reviewed import build_dataset
from shm_transport import run_simple_server
from shm_transport.shm_mng import register_cleanup_this_process
from .config import PlannerConfig
from .observations import camera_pose
from .policy import Policy, decode_prediction
from .remote_service import Service


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint',required=True)
    parser.add_argument('--reference-root',type=Path,default=Path('/home/hq/code/e2vla'))
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--device',default='cpu')
    parser.add_argument('--index',type=int,default=214)
    args=parser.parse_args()
    output=args.output.resolve(); output.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(4); cv2.setNumThreads(1)
    ns_daemon=None; workers=[]; failures=[]; dataset=None
    stopped=threading.Event()
    old_signals={s:signal.getsignal(s) for s in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP,signal.SIGQUIT)}
    try:
        # Fail early if localhost sockets are unavailable, before model loading.
        _,ns_daemon,_=Pyro4.naming.startNS(host='127.0.0.1',port=0,enableBroadcast=False)
        thread=threading.Thread(target=ns_daemon.requestLoop,daemon=True); thread.start(); workers.append(thread)
        port=ns_daemon.sock.getsockname()[1]; name='ie2vla3_e2compat_probe'
        print('Loading unchanged full iE2VLA3 checkpoint',flush=True)
        policy=Policy(PlannerConfig(checkpoint=args.checkpoint,task='close_box',device=args.device))
        service=Service(policy=policy)
        assert policy.engine.model.vlm.full_qwen_features is True
        assert not any(p.requires_grad for p in policy.engine.model.parameters())
        cfg=policy.config
        dataset=build_dataset(cfg); sample=dataset[args.index]; before=copy.deepcopy(sample)
        metadata=(sample._raw_metadata if hasattr(sample,'_raw_metadata') else sample._review_metadata)
        reader=dataset.readers[metadata['dataset_id']]
        table=pq.read_table(reader._path('data_path',metadata['episode_index']),
            columns=[cfg.state_pose_key,cfg.state_gripper_key]).to_pydict()
        pose=np.asarray(table[cfg.state_pose_key])[metadata['frame']:metadata['frame']+1]
        state=np.asarray(table[cfg.state_gripper_key])[metadata['frame']:metadata['frame']+1]
        tcp=decode_tcp(pose,cfg)[0]; grip=decode_gripper(state,cfg)[0]; timestamp=1234.5
        frame=dict(timestamp=timestamp,ee_pose=tcp,gripper=grip)
        arrays=dict(timestamp=timestamp,tcp=tcp,gripper=grip,recorded_pose=pose[0],recorded_gripper=state[0,cfg.gripper_indices])
        for i,key in enumerate(cfg.camera_keys):
            path=str(reader._path('video_path',metadata['episode_index'],key))
            cap=cv2.VideoCapture(path,cv2.CAP_FFMPEG,[cv2.CAP_PROP_N_THREADS,1])
            try:
                cap.set(cv2.CAP_PROP_POS_FRAMES,metadata['frame']); ok,bgr=cap.read()
                if not ok: raise RuntimeError(f'Cannot read {path}')
            finally:
                cap.release()
            rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
            cam=cfg.geometry['cameras'][key]; wcT=camera_pose(tcp,cfg,cam)
            frame[key]=dict(camera=dict(K=cam['K']),data=dict(color=rgb,encoding='rgb',timestep=timestamp,wcT=wcT))
            arrays.update({f'rgb_{i}':rgb,f'K_{i}':np.asarray(cam['K']),f'wcT_{i}':wcT})
        assert service.get_planner_config()['input_pose_format']=='recorded'
        assert service.get_planner_config()['input_gripper_format']=='raw'
        recorded_frame=dict(frame,ee_pose=pose[0],gripper=state[0,cfg.gripper_indices])
        service.set_prompt(sample.raw_vl.prompt); service.add_obs_frame(recorded_frame)
        prepared=service.sampler.sample(sample.raw_vl.prompt)
        for key in ['state','state_mask','action_mask','action_ref_pose']:
            torch.testing.assert_close(getattr(prepared,key),getattr(sample,key),rtol=0,atol=0)
        torch.testing.assert_close(prepared.raw_vl.K,sample.raw_vl.K,rtol=0,atol=0)
        for field in ['pose','rgb']:
            for a,b in zip(getattr(prepared.raw_vl,field),getattr(sample.raw_vl,field)):
                torch.testing.assert_close(a,b,rtol=0,atol=0)
        service.reset()
        # The reference ROS TF client explicitly requires world TCPs. Select
        # that mode only for its checks; production defaults stay recorded/raw.
        service.set_config(dict(input_pose_format='tcp_world',input_gripper_format='openness'))
        seed=args.index+42
        print('Computing reference using the existing dataset/inference path',flush=True)
        expected_raw=policy.engine.inference_raw(sample,seed)
        expected=decode_prediction(torch.from_numpy(expected_raw)[None])[0].numpy()
        np.savez_compressed(output/'observation.npz',**arrays)
        (output/'observation.json').write_text(json.dumps(dict(camera_keys=cfg.camera_keys,prompt=sample.raw_vl.prompt)))
        # Register cleanup on the main thread, then use the production server
        # runner (including its unchanged shm_transport handshake) in a worker.
        register_cleanup_this_process()
        def serve():
            try:
                run_simple_server(service,uri_name=name,ns_host='127.0.0.1',ns_port=port,
                    daemon_host='127.0.0.1',daemon_port=0,multiplex=False,replace_existing=False,
                    loop_cond=lambda:not stopped.is_set())
            except BaseException as exc:
                failures.append(exc)
        thread=threading.Thread(target=serve,daemon=True); thread.start(); workers.append(thread)
        deadline=time.monotonic()+15
        while name not in ns_daemon.nameserver.list():
            if failures: raise failures[0]
            if time.monotonic()>deadline: raise TimeoutError('Probe server did not register')
            time.sleep(.05)
        print('Calling through unchanged e2vla clients in an independent process',flush=True)
        env=dict(os.environ); env.pop('PYTHONPATH',None)
        process=subprocess.run([sys.executable,str(Path(__file__).with_name('legacy_probe_client.py')),
            '--reference-root',str(args.reference_root),'--input',str(output/'observation.npz'),
            '--output',str(output/'client_prediction.npz'),'--uri',name,'--ns-port',str(port),'--seed',str(seed)],
            cwd=args.reference_root,env=env,capture_output=True,text=True,timeout=600)
        (output/'client.log').write_text(process.stdout+process.stderr)
        if process.returncode: raise RuntimeError(process.stdout+process.stderr)
        with np.load(output/'client_prediction.npz') as result:
            np.testing.assert_array_equal(result['poses'],expected[...,:16].reshape(32,2,4,4))
            np.testing.assert_array_equal(result['grippers'],expected[...,16])
            np.testing.assert_array_equal(result['times'],timestamp+np.arange(32)/30.)
        torch.testing.assert_close(sample.state,before.state,rtol=0,atol=0)
        torch.testing.assert_close(sample.action,before.action,rtol=0,atol=0)
        if failures: raise failures[0]
        report=dict(checkpoint_step=policy.native_info['step'],device=args.device,sample_index=args.index,seed=seed,
            planner_prediction_max_abs_diff=0.,state_images_camera_geometry_exactly_match_training=True,
            full_qwen_features_unchanged=True,all_inference_parameters_frozen=True,
            default_input_mode='recorded/raw',reference_ros_client_mode='tcp_world/openness',
            history=cfg.num_history_states,horizon=cfg.num_future_actions,trajectory_fps=30.,
            client=json.loads((output/'client_prediction.json').read_text()),hardware_connected=False)
        (output/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(report),flush=True)
    finally:
        stopped.set()
        # Let the production runner unregister before closing the nameserver.
        if len(workers)>1: workers[-1].join(timeout=5.)
        if ns_daemon is not None: ns_daemon.shutdown(); ns_daemon.close()
        for thread in workers: thread.join(timeout=3.)
        if dataset is not None: dataset.close()
        for sig,handler in old_signals.items(): signal.signal(sig,handler)


if __name__=='__main__':
    main()
