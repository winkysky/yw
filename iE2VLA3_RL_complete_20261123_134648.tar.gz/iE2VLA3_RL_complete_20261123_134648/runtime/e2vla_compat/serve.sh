#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
exec "${IE2VLA_PYTHON:-python}" -m e2vla_compat.remote_service "$@"
