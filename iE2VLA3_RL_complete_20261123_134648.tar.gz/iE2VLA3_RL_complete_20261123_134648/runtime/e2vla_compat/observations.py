"""e2vla observation wire formats -> existing iE2VLA3 calibrated samples.

No imports from the e2vla repository. Geometry belongs to the loaded checkpoint.
"""
from collections import deque

import cv2
import numpy as np
import torch
from scipy.spatial.transform import Rotation

from dataset.lerobot_dual import decode_tcp, decode_gripper
from models.m0512_fm.lerobot_inference import world_observation_to_sample


class HistoryNotReady(ValueError):
    pass


def check_poses(value, name):
    value = np.asarray(value, dtype=np.float32)
    if value.shape[-2:] != (4, 4) or not np.isfinite(value).all():
        raise ValueError(f"{name} must contain finite 4x4 transforms")
    r = value[..., :3, :3]
    if (not np.allclose(value[..., 3, :], [0, 0, 0, 1], atol=1e-5)
            or not np.allclose(r.swapaxes(-1, -2) @ r, np.eye(3), atol=2e-3)
            or not np.allclose(np.linalg.det(r), 1, atol=2e-3)):
        raise ValueError(f"{name} must contain rigid transforms")
    return value


def camera_pose(tcp, cfg, camera):
    # Same float32 operations as dataset.lerobot_original.apply_geometry.
    tcp = torch.as_tensor(tcp, dtype=torch.float32)
    parent = camera["parent"]
    pose = torch.eye(4)
    if parent != "world":
        arm = 0 if parent.startswith("left_") else 1
        pose = tcp[arm]
        if parent.endswith("_flange"):
            pose = pose @ torch.linalg.inv(torch.tensor(cfg.pose_to_tcp[arm], dtype=torch.float32))
    return (pose @ torch.tensor(camera["pose"], dtype=torch.float32)).numpy()


def camera_rays(cfg, size):
    h, w = size
    v, u = torch.meshgrid(torch.arange(h), torch.arange(w), indexing="ij")
    pixels = torch.stack([u, v, torch.ones_like(u)]).float().reshape(3, -1)
    rays = []
    for key in cfg.camera_keys:
        cam = cfg.geometry["cameras"][key]
        h0, w0 = cam["image_size"]
        resize = torch.tensor([[w/w0, 0, .5*w/w0-.5], [0, h/h0, .5*h/h0-.5], [0, 0, 1.]])
        xyz = torch.linalg.solve(resize @ torch.tensor(cam["K"], dtype=torch.float32), pixels)
        rays.append((xyz[:2]/xyz[2:]).reshape(2, h, w))
    return torch.stack(rays)[None, None]


def make_sample(cfg, poses, grippers, images, prompt):
    return world_observation_to_sample(dict(world_tcp=poses, gripper=grippers,
        frame="left_recorded_arm_base", images=images, instruction=prompt), cfg)


class ObservationBuffer:
    def __init__(self, cfg, settings, fps=30.):
        self.cfg, self.settings = cfg, settings
        self.interval = cfg.frame_stride / fps
        self.tolerance = settings.history_tolerance_s
        if self.tolerance is None:
            self.tolerance = .4*self.interval
        if not 0 < self.tolerance < self.interval/2:
            raise ValueError("history_tolerance_s must be below half the model interval")
        self.states = deque(maxlen=max(120, 4*cfg.num_history_states*cfg.frame_stride))
        self.latest = None

    def reset(self):
        self.states.clear()
        self.latest = None

    def add_obs_frame(self, frame):
        if not isinstance(frame, dict):
            raise ValueError("An observation frame must be a dict")
        cfg = self.cfg
        timestamp = float(frame["timestamp"])
        if not np.isfinite(timestamp) or timestamp < 0:
            raise ValueError("Observation timestamp must be finite and nonnegative")
        if self.states and timestamp <= self.states[-1]["timestamp"]:
            raise ValueError("Observation timestamps must increase; reset between episodes")
        raw = np.asarray(frame["ee_pose"])
        tcp = decode_tcp(raw.reshape(1, -1), cfg)[0] if self.settings.input_pose_format == "recorded" else raw
        if tcp.shape != (2, 4, 4):
            raise ValueError("Expected left and right TCPs with shape (2,4,4)")
        tcp = check_poses(tcp, "ee_pose").copy()
        grip = np.asarray(frame["gripper"], dtype=np.float32)
        if grip.shape != (2,):
            raise ValueError("gripper must contain two values, left then right")
        if self.settings.input_gripper_format == "raw":
            packed = np.zeros((1, max(cfg.gripper_indices)+1), dtype=np.float32)
            packed[0, cfg.gripper_indices] = grip
            grip = decode_gripper(packed, cfg)[0]
        if not np.isfinite(grip).all() or np.any((grip < 0) | (grip > 1)):
            raise ValueError("gripper openness must be in [0,1]")
        images = {}
        for key in cfg.camera_keys:
            cam, incoming = cfg.geometry["cameras"][key], frame[key]
            meta, data = incoming["camera"], incoming["data"]
            k = np.asarray(meta["K"], dtype=float).reshape(3, 3)
            if not np.allclose(k, cam["K"], atol=.05, rtol=0):
                raise ValueError(f"{key}: intrinsics differ from checkpoint")
            stamp = float(data.get("timestep", timestamp))
            if not np.isfinite(stamp) or abs(stamp-timestamp) > .035:
                raise ValueError(f"{key}: image/state timestamps differ by more than 35 ms")
            if "wcT" in data:
                pose = check_poses(data["wcT"], key)
                if pose.shape != (4, 4):
                    raise ValueError(f"{key}: wcT must be (4,4)")
                expected = camera_pose(tcp, cfg, cam)
                angle = Rotation.from_matrix(expected[:3, :3].T @ pose[:3, :3]).magnitude()
                if np.linalg.norm(pose[:3, 3]-expected[:3, 3]) > .01 or angle > np.deg2rad(2):
                    raise ValueError(f"{key}: camera pose differs from checkpoint calibration")
            encoding = data.get("encoding", self.settings.color_order)
            if "color_jpeg" in data:
                image = cv2.imdecode(np.frombuffer(data["color_jpeg"], np.uint8), cv2.IMREAD_COLOR)
                encoding = "bgr"
                if image is None:
                    raise ValueError(f"{key}: invalid JPEG")
            else:
                image = np.asarray(data["color"])
            if image.dtype != np.uint8 or image.shape != (*cam["image_size"], 3):
                raise ValueError(f"{key}: expected calibrated uint8 HWC image resolution")
            if encoding not in ("rgb", "bgr"):
                raise ValueError(f"{key}: encoding must be rgb or bgr")
            if encoding == "bgr":
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            # Keep source pixels: the EXISTING iE2VLA3 reader performs one resize.
            images[key] = np.ascontiguousarray(image).copy()
        state = dict(timestamp=timestamp, ee_pose=tcp, gripper=grip.copy())
        self.states.append(state)
        self.latest = dict(state, images=images)

    def sample(self, prompt):
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("Set a nonempty task prompt before inference")
        count = self.cfg.num_history_states
        if len(self.states) < count:
            raise HistoryNotReady("Collecting measured observation history")
        times = np.asarray([s["timestamp"] for s in self.states])
        wanted = times[-1] + np.arange(1-count, 1)*self.interval
        selected = np.abs(times[:, None]-wanted).argmin(axis=0)
        if np.any(np.diff(selected) <= 0) or np.any(np.abs(times[selected]-wanted) > self.tolerance):
            raise HistoryNotReady("Missing continuous measured history at training intervals")
        return make_sample(self.cfg, np.stack([self.states[i]["ee_pose"] for i in selected]),
            np.stack([self.states[i]["gripper"] for i in selected]), self.latest["images"], prompt)


def batch_to_samples(obs, cfg, wire_size):
    """Support e2vla's optional model-ready batch endpoint (not the Planner path)."""
    keys = ("obs_rgbs", "obs_masks", "obs_norm_xys", "obs_extrinsics",
            "current_ee_pose", "history_ee_states", "valid_ee_mask")
    if not isinstance(obs, dict) or set(keys + ("prompt_text",))-set(obs):
        raise ValueError("Missing batched e2vla observation fields")
    data = {}
    for key in keys:
        if not isinstance(obs[key], (torch.Tensor, np.ndarray)):
            raise ValueError(f"{key} must be a CPU tensor or NumPy array")
        value = torch.as_tensor(obs[key]).detach().cpu()
        if not torch.isfinite(value).all():
            raise ValueError(f"{key} contains NaN/Inf")
        if key in ("obs_masks", "valid_ee_mask"):
            if value.dtype != torch.bool or not value.all():
                raise ValueError(f"{key} must be bool and all valid for this checkpoint")
        else:
            value = value.float()
        data[key] = value
    rgb = data["obs_rgbs"]
    if rgb.ndim != 6 or rgb.shape[0] < 1:
        raise ValueError("obs_rgbs must be (B,1,cameras,3,H,W)")
    b, nc, nh = rgb.shape[0], len(cfg.camera_keys), cfg.num_history_states
    h, w = wire_size
    shapes = dict(obs_rgbs=(b,1,nc,3,h,w), obs_masks=(b,1,nc,h,w),
        obs_norm_xys=(b,1,nc,2,h,w), obs_extrinsics=(b,1,nc,4,4),
        current_ee_pose=(b,2,4,4), history_ee_states=(b,nh,2,17), valid_ee_mask=(b,2))
    for key, shape in shapes.items():
        if tuple(data[key].shape) != shape:
            raise ValueError(f"{key}: expected {shape}, got {tuple(data[key].shape)}")
    if rgb.min() < 0 or rgb.max() > 1:
        raise ValueError("obs_rgbs must be RGB floats in [0,1]")
    prompts = obs["prompt_text"]
    if not isinstance(prompts, (tuple, list)) or len(prompts) != b or any(not isinstance(p,str) or not p.strip() for p in prompts):
        raise ValueError("prompt_text must contain one nonempty string per batch item")
    history = data["history_ee_states"].numpy()
    poses = check_poses(history[..., :16].reshape(b, nh, 2, 4, 4), "history_ee_states")
    current = check_poses(data["current_ee_pose"].numpy(), "current_ee_pose")
    if not np.allclose(poses[:, -1], current, atol=2e-5, rtol=1e-5):
        raise ValueError("Last history pose must equal current_ee_pose")
    if not torch.allclose(data["obs_norm_xys"], camera_rays(cfg, wire_size).expand(b,-1,-1,-1,-1,-1), atol=2e-6, rtol=1e-5):
        raise ValueError("Camera rays differ from checkpoint intrinsics/resize/order")
    samples = []
    for row in range(b):
        images = {}
        for i, key in enumerate(cfg.camera_keys):
            expected = camera_pose(current[row], cfg, cfg.geometry["cameras"][key])
            if not np.allclose(data["obs_extrinsics"][row,0,i].numpy(), expected, atol=2e-5, rtol=1e-5):
                raise ValueError("Camera poses disagree with checkpoint calibration")
            pixels = (rgb[row,0,i].permute(1,2,0).numpy()*255).round().astype(np.uint8)
            # A pre-resized legacy square batch cannot recover the source RGB.
            # Adapt to native size explicitly; ordinary Planner frames bypass this.
            images[key] = cv2.resize(pixels, (cfg.image_size[1], cfg.image_size[0]), interpolation=cv2.INTER_AREA)
        samples.append(make_sample(cfg, poses[row], history[row,...,16], images, prompts[row]))
    return samples
