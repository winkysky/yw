"""e2vla-compatible Pyro4 Planner; inference uses the current iE2VLA3 checkpoint."""
import argparse
from dataclasses import replace
import json
from pathlib import Path
import signal
import threading

import cv2
import torch
import Pyro4
import Pyro4.naming

from shm_transport import expose, run_simple_server
from .planner import Planner
from .config import PlannerConfig


class Service(Planner):
    def __init__(self, policy=None, config=None):
        super().__init__(config, policy=policy)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_info(self):
        return super().get_info()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_config(self):
        return super().get_config()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_planner_config(self):
        return super().get_planner_config()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_status(self):
        return super().get_status()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def set_config(self, config):
        return super().set_config(config)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def reset(self):
        return super().reset()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def set_prompt(self, prompt_text):
        return super().set_prompt(prompt_text)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def set_speed(self, speed_mps, guidance_scale=1.):
        return super().set_speed(speed_mps, guidance_scale)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def add_obs_frame(self, obs_frame):
        return super().add_obs_frame(obs_frame)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def add_obs_frames(self, obs_frames):
        return super().add_obs_frames(obs_frames)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_action(self, draw_traj=False, compress_traj_img=False, seed=None, speed_mps=None):
        return super().get_action(draw_traj, compress_traj_img, seed, speed_mps)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def set_ensemble_nums(self, n):
        return super().set_ensemble_nums(n)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def ensemble_traj(self, future_ee_poses, future_grippers, future_time):
        return super().ensemble_traj(future_ee_poses, future_grippers, future_time)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        return super().run_inference(obs_data, seed, contract_sha256, speed_mps, guidance_scale)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def run_inference_numpy(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        return super().run_inference_numpy(obs_data, seed, contract_sha256, speed_mps, guidance_scale)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--task", choices=("close_box", "open_box", "place_phone"))
    parser.add_argument("--variant", choices=("no_speed",))
    parser.add_argument("--checkpoint", "--ckpt", type=str)
    parser.add_argument("--device")
    parser.add_argument("--bf16", action="store_true", default=None)
    parser.add_argument("--inference-timesteps", type=int)
    parser.add_argument("--threads", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--speed-mps", type=float)
    parser.add_argument("--guidance-scale", type=float)
    parser.add_argument("--prompt")
    parser.add_argument("--uri")
    parser.add_argument("--host")
    parser.add_argument("--port", type=int)
    parser.add_argument("--ns-host", "--ns_host", dest="ns_host")
    parser.add_argument("--ns-port", "--ns_port", dest="ns_port", type=int)
    parser.add_argument("--input-pose-format", choices=("tcp_world", "recorded"))
    parser.add_argument("--input-gripper-format", choices=("openness", "raw"))
    parser.add_argument("--start-ns", action="store_true")
    parser.add_argument("--check-config", action="store_true", help="Validate config/checkpoint path without loading weights")
    args = parser.parse_args(argv)
    path = args.config or Path(__file__).with_name("planner.json")
    config = PlannerConfig.load(path)
    overrides = {key: value for key, value in vars(args).items() if key not in ("config", "check_config", "start_ns") and value is not None}
    config = replace(config, **overrides).validate()
    if config.checkpoint is None or config.task is None:
        parser.error("Specify the current iE2VLA3 --checkpoint and --task matching the existing client")
    from models.m0512_fm.lerobot_inference import load_checkpoint
    saved, resolved = load_checkpoint(config.checkpoint)
    if config.inference_timesteps not in (None, saved["model_config"]["inference_timesteps"]):
        parser.error("Keep the checkpoint inference_timesteps unchanged")
    if args.check_config:
        print(json.dumps(dict(config=config.to_dict(), resolved_checkpoint=str(resolved),
            checkpoint_step=saved["step"], checkpoint_format=saved["format"], model_config=saved["model_config"],
            native_image_size=saved["data_config"]["image_size"],
            history=saved["data_config"]["num_history_states"], horizon=saved["data_config"]["num_future_actions"]), ensure_ascii=False, indent=2))
        return
    del saved
    torch.set_num_threads(config.threads)
    cv2.setNumThreads(1)
    owned_ns = None
    stopped = threading.Event()
    old_handler = signal.signal(signal.SIGTERM, lambda *_: stopped.set())
    try:
        try:
            ns = Pyro4.locateNS(host=config.ns_host, port=config.ns_port)
        except Pyro4.errors.NamingError:
            if not args.start_ns:
                raise
            _, owned_ns, _ = Pyro4.naming.startNS(host=config.ns_host, port=config.ns_port, enableBroadcast=False)
            threading.Thread(target=owned_ns.requestLoop, daemon=True).start()
            ns = Pyro4.locateNS(host=config.ns_host, port=config.ns_port)
        with ns:
            if config.uri in ns.list():
                raise ValueError(f"Service name already registered: {config.uri}; stop the old service first")
        service = Service(config=config)
        print(json.dumps(dict(status="model_loaded", **service.get_info()), ensure_ascii=False), flush=True)
        run_simple_server(service, uri_name=config.uri, daemon_host=config.host, daemon_port=config.port,
            ns_host=config.ns_host, ns_port=config.ns_port, multiplex=False, replace_existing=False,
            loop_cond=lambda: not stopped.is_set())
    finally:
        signal.signal(signal.SIGTERM, old_handler)
        if owned_ns is not None:
            owned_ns.shutdown()
            owned_ns.close()


if __name__ == "__main__":
    main()
