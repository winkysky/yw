"""Protocol projection around the unchanged full-checkpoint inference engine."""
import copy
import hashlib
import json

import torch

from action.parser import ProprioParser
from data_utils.tokenize import BatchDataTokenizedVLA
from models.m0512_fm.lerobot_inference import infer_batch
from models.m0512_fm.service_lerobot import Service as FullModel
from .observations import batch_to_samples


TASKS = {
    "close_box": ["close_box_1112_2/success"],
    "open_box": ["open_the_box_1109_60/success"],
    "place_phone": ["place_phone_1111_60_2/success", "place_phone_1112_10/success"],
}
WIRE_FORMAT = "e2vla_lerobot_no_force_no_speed_v1"


def signature(values):
    values = copy.deepcopy(values)
    for key in ("root", "cache_episodes", "cache_videos"):
        values.pop(key, None)
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def decode_prediction(prediction):
    """B,arms,T,73 -> B,T,arms,17, without changing coordinates or grippers."""
    poses = ProprioParser(prediction).posemat.permute(0, 2, 1, 3, 4)
    grippers = prediction[..., 9].permute(0, 2, 1)
    return torch.cat((poses.flatten(-2), grippers[..., None]), -1).float().cpu().contiguous()


class Policy:
    def __init__(self, settings, *, engine=None):
        settings.validate()
        if settings.task not in TASKS:
            raise ValueError("Select --task close_box, open_box or place_phone to match the existing client")
        device = settings.device
        if device == "auto":
            device = "cuda:0" if torch.cuda.is_available() else "cpu"
        self.engine = engine or FullModel(settings.checkpoint, device)
        self.config = self.engine.data_config
        self.native_info = self.engine.get_policy_info()
        self.task, self.variant = settings.task, "no_speed"
        self.fps = float(self.native_info["fps"])
        if self.fps != 30. or self.config.num_future_actions != 32 or self.config.num_history_states != 1:
            raise ValueError("This adapter targets the current H=1, T=32, 30 Hz checkpoint")
        if settings.inference_timesteps not in (None, self.native_info["model_config"]["inference_timesteps"]):
            raise ValueError("Keep the checkpoint's inference_timesteps; this adapter does not change the model")
        self.wire_size = [settings.batch_image_size]*2
        # This is an API view for old clients, NOT the checkpoint data_config.
        # Old clients require a task-specific dataset list and square batch RGB.
        self.wire_config = self.config.to_dict()
        self.wire_config.update(image_size=self.wire_size, success_key=None, speed_factors=None,
            target_fps=self.fps/self.config.frame_stride, source_fps=self.fps, history_mode="observed",
            reviewed_datasets=TASKS[self.task],
            review_manifest_sha256=signature(dict(data_config=self.config.to_dict(),
                dataset_fingerprint=self.native_info["dataset_fingerprint"])))
        self.wire_config["convention_notes"] = dict(self.wire_config["convention_notes"],
            e2vla_compatibility="API view only: reviewed_datasets selects a client task, image_size is the legacy batch wire size, "
            "review_manifest_sha256 identifies this view's backend contract. See checkpoint_metadata for actual training metadata.")
        self.signature = signature(self.wire_config)

    def get_info(self):
        return copy.deepcopy(dict(protocol="e2vla_lerobot_pyro_v1", format=WIRE_FORMAT,
            variant=self.variant, task=self.task, checkpoint=self.native_info["checkpoint"],
            checkpoint_step=self.native_info["step"], data_config=self.wire_config,
            model_config=self.native_info["model_config"], contract_sha256=self.signature,
            device=self.native_info["device"], bf16=True,
            world_frame="left_recorded_arm_base", arm_order=["left", "right"],
            output_shape=["B", self.config.num_future_actions, 2, 17],
            output="CPU float32 TCP matrices in metres plus model gripper openness; no joint commands",
            backend="iE2VLA3", checkpoint_format=self.native_info["format"],
            checkpoint_metadata=self.native_info,
            compatibility=dict(format_is_wire_discriminator=True, task_is_client_route=True,
                reviewed_datasets_are_client_task_scope=True, checkpoint_is_not_task_filtered=True,
                planner_image_size=self.config.image_size, batch_wire_image_size=self.wire_size,
                preprocessing="Planner: original calibrated RGB -> native checkpoint size once; "
                "batch API: caller's pre-resized RGB -> native size (source pixels cannot be recovered)",
                bf16="The unchanged iE2VLA3 infer_batch uses fp16=True (BF16 autocast); --bf16 does not recast weights")))

    def predict_samples(self, samples, seed=None, speed_mps=None, guidance_scale=1.):
        if speed_mps is not None or guidance_scale != 1.:
            raise ValueError("The no-speed checkpoint does not accept speed conditioning")
        with self.engine.model_lock:
            batch = BatchDataTokenizedVLA(**self.engine.collator(samples))
            prediction = infer_batch(self.engine.model, batch, self.engine.device, seed)
        return decode_prediction(prediction)

    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=1.):
        if contract_sha256 is not None and contract_sha256 != self.signature:
            raise ValueError("Client task/data/calibration contract differs from this service")
        if speed_mps is not None or guidance_scale != 1.:
            raise ValueError("The no-speed checkpoint does not accept speed conditioning")
        samples = batch_to_samples(obs_data, self.config, self.wire_size)
        return self.predict_samples(samples, seed, speed_mps, guidance_scale)
