# e2vla remote_service 兼容服务端（当前 iE2VLA3 后端）

这是新增服务端，复用本库已有的 `models/m0512_fm/service_lerobot.py`、checkpoint 加载器、数据转换、tokenizer 和推理函数。部署时不需要 `/home/hq/code/e2vla` 或它的 `e03_lerobot_client`。原客户端继续运行在原来的环境中，不需要修改代码。

不修改训练代码、模型实现、权重、checkpoint 文件或旧推理入口。加载当前 `model_config.train_qwen=true`，保留当前 `full_qwen_features=True` 特征接入；加载后按原推理入口关闭参数梯度。没有回退原始特征路径，没有重新训练。

## 启动

使用当前 iE2VLA3 环境，从项目根目录启动。默认配置 `e2vla_compat/planner.json` 已指向 100k checkpoint；默认输入为 `recorded/raw`，名称 `e2vla`、服务端口 `9101`、名称服务端口 `9090`、任务接口 `close_box`。

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

# 先核对配置，不加载模型、不创建网络服务
python -m e2vla_compat.remote_service --check-config

# 本机调试
python -m e2vla_compat.remote_service --device cuda:0 --start-ns
```

客户端在另一台机器时，把下面的 IP、URI、端口、task 设置成客户端现在使用的值；客户端配置和代码均可保持不动。先停止占用同一 URI/端口的旧服务；新服务不会自动覆盖仍注册的同名服务。

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3
SERVER_IP="替换成推理服务器的局域网IP"
python -m e2vla_compat.remote_service \
  --device cuda:0 \
  --task close_box \
  --uri e2vla \
  --host "$SERVER_IP" --port 9101 \
  --ns-host "$SERVER_IP" --ns-port 9090 \
  --start-ns
```

`--start-ns` 在指定地址没有名称服务时创建；已有名称服务会复用。已有同名注册时明确报错，需先正常停止旧服务；不会抢占客户端连接。`--host` 应为客户端可达的实际 IP。`--uri` 保持客户端原值（例如 `e2vla` 或 `e2vla_close_box`）；`--task` 不会自动改 URI。

其他任务用 `--task open_box` 或 `--task place_phone`。它只是匹配客户端任务检查的接口名称，所有任务仍使用同一个当前多任务 checkpoint，并由客户端 `set_prompt()` 提供真实任务指令。更换模型存放位置用 `--checkpoint /绝对路径/step_0100000`，也接受目录中的 `model.pt`。必须保留同目录 `complete.json`；推理不读取 `rank_*.pt`。

也可以直接读取已有 e2vla 服务配置，然后在命令行覆盖 checkpoint、task 和网络参数：

```bash
python -m e2vla_compat.remote_service \
  --config /旧服务配置的绝对路径/planner.json \
  --checkpoint /当前iE2VLA3检查点的绝对路径/step_0100000 \
  --task close_box --device cuda:0
```

旧配置若是 `recorded/raw`，会保留该约定。若现有客户端上传 ROS TF 公共坐标系 TCP，应在**服务端**传 `--input-pose-format tcp_world --input-gripper-format openness`。不要猜测或重复转换客户端已经转换的位姿。可用 `--device cpu` 做 CPU 验证。

本库 `planner.json` 和 Python `PlannerConfig` 的默认值均为 `recorded/raw`，服务端不会自动猜测输入模式。客户端上传原始记录值时，不再需要额外的模式参数，可直接核对实际生效配置：

```bash
# 核对实际生效配置；去掉 --check-config，并补充所需网络参数即可启动
python -m e2vla_compat.remote_service --check-config
```

这两个参数只改变观测解码：输入为各自基座下的记录法兰位姿和原始夹爪值，输出仍为左臂 base 下的双臂 TCP 矩阵和 openness，保持旧 `remote_service` 的返回约定。它们不修改模型或 checkpoint，也不要求客户端改成 `observation.tcp_pose/observation.state` 键；仍使用原接口的 `ee_pose/gripper` 字段。

本地原 e2vla 仓库中的 ROS TF 客户端会明确要求 `tcp_world/openness`；若使用那份客户端，需要在服务端显式指定这两个值。已经适配为上传原始记录值的客户端使用新的 `recorded/raw` 默认值。原客户端代码保持不动。

## 接口与坐标

公开方法名、参数和默认值对齐 `e2vla/infer_utils/remote_service.py`：

- `get_info / get_config / get_planner_config / get_status`
- `reset / set_config / set_prompt / set_speed`
- `add_obs_frame / add_obs_frames / get_action`
- `set_ensemble_nums / ensemble_traj`
- `run_inference / run_inference_numpy`

继续使用原 `shm_transport.get_shm_proxy` / Pyro4 协议。常用流程：`reset → set_prompt → add_obs_frames → get_action`。

`add_obs_frame` 接收旧协议字典：`timestamp`、`ee_pose`、`gripper`，以及三个顶层相机键。每个相机仍为 `camera.K` 和 `data.color / encoding / timestep / wcT`；支持原有 `color_jpeg`。相机键和顺序：

1. `observation.images.head_image`
2. `observation.images.left_wrist_image`
3. `observation.images.right_wrist_image`

| 服务端输入配置 | 客户端字段 | 服务端处理 |
| --- | --- | --- |
| `tcp_world` | `ee_pose[2,4,4]`，左臂 base 下的双臂 TCP，米 | 不再做左右基座/工具转换 |
| `recorded`（默认） | `ee_pose[12]` 或 `[2,6]`，各自 base 下的记录位姿，毫米、XYZ 外旋欧拉角度 | 复用当前训练 decoder，转换单位、完整左右基座变换、工具偏移，各一次 |
| `openness` | `gripper[2]`，0 闭合、1 张开 | 原样传入 |
| `raw`（默认） | `gripper[2]`，原始双夹爪值 | 按 checkpoint 的 1886 闭合、0 张开归一化 |

输入图像为标定分辨率 480×640（H×W）的 RGB/BGR uint8，服务端校验相机 K 和可选 wcT，图像与状态时间偏差上限沿用旧服务的 35 ms。三路 RGB 直接经过当前 iE2VLA3 的一次缩放，成为训练时的 192×256；相机姿态和参考相机保持当前 checkpoint 的约定。

`get_action()` 返回旧四元组：

```python
poses, grippers, times, image = proxy.get_action(seed=42)
# poses:    float32 [32, 2, 4, 4]，左 base 下的 TCP，米
# grippers: float32 [32, 2]，模型预测的 openness，不额外截断
# times:    float64 [32]，观测 timestamp + arange(32)/30
# image:    None；draw_traj=True 时为 BGR 图或 JPEG uint8 字节数组
```

夹爪保留原预测数值；客户端已有的执行范围处理继续生效。当前模型 H=1，无须积攒 5 帧；多帧上传时取最新一帧。未来步数 32，轨迹 30 Hz，首点偏移为 0，推理去噪步数保持 checkpoint 的 4。传不同的 `--inference-timesteps` 会报错；不在兼容层改变模型行为。`--bf16` 接受旧参数，但不会重铸权重：实际始终沿用当前 `infer_batch(fp16=True)` 的 BF16 行为。

`reset` 清除缓存和融合历史，保留任务指令/运行设置。一次 `add_obs_frames` 中若有坏帧，整批回滚。当前模型没有速度条件，`set_speed`、非空 `speed_mps` 或不同于 1 的 guidance 会明确拒绝。`ensemble_traj` 沿用旧实现，只融合位置与夹爪；默认关闭、需客户端显式调用。服务不执行机器人运动、IK 或 MoveIt。

与旧 Planner 一样，每个进程共享一份观测缓存和 prompt。独立机器人/会话使用独立服务进程与 URI。

## 频率和输入检查

服务端按请求推理，没有固定 Hz 的后台推理循环；模型锁串行处理推理请求。机器人控制循环由客户端负责，服务端不规定控制器的运行频率。当前 H=1，只要求上传的时间戳递增，不要求相邻观测恰好相隔 1/30 秒。

轨迹时间约定则在现有代码中固定为 30 Hz：`service_lerobot.py` 提供 `fps=30`，兼容层检查 H=1、T=32、fps=30，并生成 `timestamp + (action_offset + i*frame_stride)/30`。当前 offset=0、stride=1，因此首点到末点为 31/30 秒。去噪迭代次数 4 是模型生成过程的计算步数，不是推理 Hz 或控制 Hz；兼容层目前拒绝覆盖为其他次数。仅更改时间戳会改变轨迹的执行速度含义，不会让模型学会另一种采样间隔。

普通 Planner 帧接口的重要检查如下，失败时拒绝该次输入；整批上传会回滚：

| 检查 | 当前要求 |
| --- | --- |
| 相机 K | 每个元素与 checkpoint 的绝对差不超过 0.05，rtol=0 |
| 图像大小/类型 | 三路标定分辨率 H×W=480×640、uint8、RGB/BGR 或可解码 JPEG |
| 图像与状态时间 | 提供的 `data.timestep` 与状态 `timestamp` 相差不超过 35 ms；省略时按状态时间处理 |
| 相机外参 | 提供 `wcT` 时，平移差不超过 1 cm、旋转差不超过 2°；不提供则由 checkpoint 重建 |
| 位姿 | 两臂齐全、数值有限、转换后为有效的 4×4 刚体变换 |
| 夹爪 | raw 解码允许端点范围外 5% 的误差并裁剪；超过则拒绝；openness 输入必须在 [0,1] |
| 状态时间 | 非负、有限、每次上传严格递增；reset 后重新开始 |
| 指令/批次 | 推理前须设置非空 prompt；一次批量上传 1–240 帧 |

K、图像分辨率、35 ms 和 1 cm/2° 这些阈值目前不是运行配置项。历史对齐容差 `history_tolerance_s` 可配置且必须小于半个采样间隔，但当前 H=1 总是取最新观测，不因此强制上传频率。服务端没有相对于当前墙钟的观测过期检查，也没有工作空间、碰撞、速度或加速度可执行性校验；本表是输入一致性检查。

批量 `run_inference` 接口另有固定形状、相机射线/外参一致性、全有效 mask 和可选 `contract_sha256` 校验。模型加载检查完整 checkpoint 标记和严格权重匹配。切换默认输入模式不会放宽上述检查。

## 兼容元数据与批量接口

旧客户端不仅调用方法，还检查 e2vla 格式标签、单任务数据集列表、方形批量图像。为保持旧代码可运行，`get_info()` 明确区分**接口视图**与**真实 checkpoint 信息**：

- `protocol/planner_protocol` 沿用 e2vla 的协议名，`format` 是旧客户端需要的 e2vla **通信格式标签**；`backend="iE2VLA3"` 和 `checkpoint_format="lerobot_original_full_v2"` 标明真实模型。
- `checkpoint_metadata` 完整保留当前后端返回的实际模型配置、训练数据配置、100k 步数和数据指纹。
- `data_config.reviewed_datasets` 按 `--task` 提供旧客户端要求的任务视图，**不声称 checkpoint 只在这些数据上训练，也不筛选/修改权重**。`compatibility` 中有显式标志。
- `data_config.review_manifest_sha256` 是兼容视图对应后端配置和训练指纹的哈希，不是原始训练目录某个 manifest 文件的哈希。真实 `dataset_fingerprint` 在 `checkpoint_metadata` 内。
- `data_config.image_size=[256,256]` 仅描述旧 `run_inference` 批量输入的方形图像。真实模型大小在 `checkpoint_metadata.data_config.image_size=[192,256]`；常用 `add_obs_frames/get_action` 不经过方形缩放。

批量接口接受原来的八个观测字段：`obs_rgbs / obs_masks / obs_norm_xys / obs_extrinsics / prompt_text / current_ee_pose / history_ee_states / valid_ee_mask`，返回 `[B,32,2,17]`，最后一维是展平的 TCP 4×4 矩阵加夹爪。`run_inference` 返回 CPU tensor，`run_inference_numpy` 返回 NumPy。相机射线、外参和双臂有效标志会校验，任何未来真值字段均不用于推理。

旧客户端如果已经在本地把图像缩成 256×256，服务器只能把收到的图像再缩放到 192×256，无法恢复被丢弃的原始像素；因此**不承诺这种批量模式与原始 RGB 的 Planner 模式预测相同**。正常机器人 Planner 流程使用原始三路 RGB，已对照当前数据加载/推理路径验证逐项一致。批量客户端若使用旧模型自己的硬编码校验配置，应读取本服务 `get_config()`；旧模型的 H=5/15 Hz 参数不属于当前 checkpoint 的输入约定。

## 验证与复现

新增单元测试：

```bash
python -m pytest tests/test_e2vla_compat.py -q
```

真实 checkpoint / 独立旧客户端 / localhost Pyro4 测试：

```bash
python -m e2vla_compat.probe \
  --checkpoint checkpoints/lerobot_original_full_reviewed_h32_20261116_021607/step_0100000 \
  --reference-root /home/hq/code/e2vla \
  --output audits/e2vla_compat_100k
```

仅这个验证工具需要旧 e2vla 仓库，用于导入其未经修改的两个客户端和通信库。部署服务端不需要它。测试先用默认 recorded/raw 读取真实审核样本，与当前数据路径对比；随后将测试服务显式切为 tcp_world/openness，以运行未经修改的 ROS TF 客户端，再验证 world/recorded 两种输入、全部公开方法、批量 tensor/NumPy 返回、可视化、时间戳及速度拒绝，最后自动关闭服务。

测试报告位于 `audits/e2vla_compat_100k/validation.json`。本地验证不连接 ROS 或机器人，也不代表已在不可观测的另一台服务器上完成部署。没有打包或上传。
