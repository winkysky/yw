"""Additive e2vla Planner protocol adapter for the current iE2VLA3 checkpoint."""
