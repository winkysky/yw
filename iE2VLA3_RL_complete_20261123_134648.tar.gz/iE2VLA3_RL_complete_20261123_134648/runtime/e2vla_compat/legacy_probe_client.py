"""Test driver only: import and exercise the ORIGINAL e2vla clients, unchanged.

Executed in an independent process with --reference-root first on sys.path.
Not needed to deploy the server or to run the robot client.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-root',type=Path,required=True)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--uri',required=True)
    parser.add_argument('--ns-port',type=int,required=True)
    parser.add_argument('--seed',type=int,required=True)
    args=parser.parse_args()
    reference=args.reference_root.resolve()
    sys.path.insert(0,str(reference))
    import cv2
    import numpy as np
    import torch
    torch.set_num_threads(2)
    cv2.setNumThreads(1)
    from e03_lerobot_client.clients.lerobot_policy import connect_policy
    from e03_lerobot_client.clients.e03_protocol import observation_frame
    from lerobot_inference import RemoteLeRobotPolicy, make_data_config, validate_inputs, camera_rays
    from data_utils.lerobot_observation import LeRobotDataSampler
    from data_utils.lerobot_vel_no_force import collate_lerobot_no_force
    import shm_transport
    assert Path(shm_transport.__file__).resolve().is_relative_to(reference)
    metadata=json.loads(args.input.with_suffix('.json').read_text())
    arrays=np.load(args.input)
    keys=metadata['camera_keys']; timestamp=float(arrays['timestamp'])
    cameras={key:dict(rgb=arrays[f'rgb_{i}'],K=arrays[f'K_{i}'],wcT=arrays[f'wcT_{i}'],timestamp=timestamp)
             for i,key in enumerate(keys)}
    observation=observation_frame(arrays['tcp'],arrays['gripper'],timestamp,cameras)
    client=legacy=None
    results={}
    try:
        client=connect_policy(dict(uri=args.uri,ns_host='127.0.0.1',ns_port=args.ns_port,timeout_s=180.),keys,2,'close_box')
        client.start(metadata['prompt'])
        assert client.history_seconds==0.
        assert client.proxy.get_action() is None
        prediction=client.infer([observation],seed=args.seed)
        results.update(poses=prediction.poses,grippers=prediction.grippers,times=prediction.times)
        assert client.proxy.get_status()['status']=='ready'
        assert client.proxy.get_config()==client.info['data_config']
        assert client.proxy.get_planner_config()['input_pose_format']=='tcp_world'
        try:
            client.proxy.set_speed(.1)
        except ValueError:
            pass
        else:
            raise AssertionError('No-speed service accepted speed conditioning')
        client.proxy.set_ensemble_nums(2)
        positions,grippers=client.proxy.ensemble_traj(prediction.poses,prediction.grippers,prediction.times)
        # Legacy ensemble uses floating-point weighted sums even on its first
        # chunk; allow machine precision, not a change to model predictions.
        np.testing.assert_allclose(positions,prediction.poses,rtol=0,atol=1e-14)
        np.testing.assert_allclose(grippers,prediction.grippers,rtol=0,atol=1e-14)
        client.proxy.set_config(dict(input_pose_format='recorded',input_gripper_format='raw'))
        recorded=dict(observation,ee_pose=arrays['recorded_pose'],gripper=arrays['recorded_gripper'])
        client.proxy.add_obs_frame(recorded)
        response=client.proxy.get_action(seed=args.seed,draw_traj=True,compress_traj_img=True)
        for a,b in zip(response[:3],(prediction.poses,prediction.grippers,prediction.times)):
            np.testing.assert_array_equal(a,b)
        assert cv2.imdecode(response[3],cv2.IMREAD_COLOR) is not None
        client.proxy.reset()
        assert client.proxy.get_status()['observation_count']==0
        client.proxy.set_config(dict(input_pose_format='tcp_world',input_gripper_format='openness',seed=args.seed))
        # The general batched client also constructs/validates its original
        # dataclass and checks the original contract hash without modification.
        legacy=RemoteLeRobotPolicy(args.uri,ns_port=args.ns_port,timeout=180.)
        cfg=make_data_config(client.info['data_config'])
        sampler=LeRobotDataSampler(cfg)
        sampler.add_obs_frame(observation)
        batch=collate_lerobot_no_force([sampler.sample_framedict(metadata['prompt'])])
        validate_inputs(batch,cfg,camera_rays(cfg))
        legacy.check_config(cfg)
        tensor=legacy.run_inference(batch,seed=args.seed)
        numpy_batch={k:v.numpy() if torch.is_tensor(v) else v for k,v in batch.items()}
        numpy_result=client.proxy.run_inference_numpy(numpy_batch,contract_sha256=legacy.info['contract_sha256'])
        np.testing.assert_array_equal(tensor.numpy(),numpy_result)
        results['batch_prediction']=numpy_result
        np.savez_compressed(args.output,**results)
        report=dict(reference_root=str(reference),client_source_files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in [reference/'e03_lerobot_client/clients/lerobot_policy.py',reference/'lerobot_inference.py',
                      Path(shm_transport.__file__).resolve()]},
            original_e03_client=True,original_batched_client=True,original_shm_transport=True,
            protocol_and_contract_validation=True,world_and_recorded_predictions_identical=True,
            batch_tensor_and_numpy_identical=True,trajectory_jpeg=True,no_speed_rejected=True,
            reset_and_ensemble=True,hardware_connected=False)
        args.output.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(report),flush=True)
    finally:
        if legacy is not None: legacy.close()
        if client is not None: client.close()
        arrays.close()


if __name__=='__main__':
    main()
