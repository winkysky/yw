"""Stateful e2vla-compatible Planner with the current iE2VLA3 backend."""
from dataclasses import replace
import threading

import cv2
import numpy as np

from .config import PlannerConfig
from .ensemble import TrajEnsembler
from .observations import ObservationBuffer, HistoryNotReady
from .policy import Policy


def draw_prediction(sample, poses, compress=False):
    panels = []
    for i, pixels in enumerate(sample.raw_vl.rgb):
        panel = cv2.cvtColor(pixels[0].permute(1,2,0).numpy(), cv2.COLOR_RGB2BGR)
        k = sample.raw_vl.K[i].numpy()
        camera_T_world = np.linalg.inv(sample.raw_vl.pose[i][0].numpy())
        for arm, color in enumerate(((255,220,0), (0,150,255))):
            xyz = poses[:,arm,:3,3] @ camera_T_world[:3,:3].T + camera_T_world[:3,3]
            uvz = xyz @ k.T
            uv = uvz[:,:2] / np.maximum(uvz[:,2:], 1e-5)
            for j in range(1, len(uv)):
                if (xyz[j-1:j+1,2] > 1e-5).all() and np.max(np.abs(uv[j-1:j+1])) < 1e6:
                    cv2.line(panel, tuple(np.rint(uv[j-1]).astype(int)), tuple(np.rint(uv[j]).astype(int)), color, 2)
        panels.append(panel)
    image = np.concatenate(panels, axis=1)
    if compress:
        ok, image = cv2.imencode(".jpg", image)
        if not ok:
            raise RuntimeError("Cannot encode trajectory image")
    return image


class Planner:
    def __init__(self, config=None, *, policy=None):
        if isinstance(config, (str, bytes)) or hasattr(config, "__fspath__"):
            config = PlannerConfig.load(config)
        elif isinstance(config, dict):
            config = PlannerConfig(**config)
        if config is None:
            if policy is None:
                raise ValueError("Supply a Planner config or loaded policy")
            info = policy.get_info()
            config = PlannerConfig(checkpoint=info["checkpoint"], task=info["task"], device=info["device"])
        config.validate()
        self.policy = policy or Policy(config)
        info = self.policy.get_info()
        if config.task is not None and info["task"] != config.task:
            raise ValueError("Planner task differs from the policy route")
        self.settings = replace(config, checkpoint=info["checkpoint"], task=info["task"], variant="no_speed").validate()
        self.config = self.policy.config
        self.lock = threading.RLock()
        self.sampler = self._sampler(self.settings)
        self.pos_ensembler = TrajEnsembler(self.settings.ensemble)
        self.gripper_ensembler = TrajEnsembler(self.settings.ensemble)
        self.last_obs_data = None
        self.last_status = "waiting_for_observations"

    def _sampler(self, settings):
        return ObservationBuffer(self.config, settings, self.policy.fps)

    def get_info(self):
        return dict(self.policy.get_info(), planner_protocol="e2vla_lerobot_planner_v1",
            numpy_endpoint="run_inference_numpy", stateful=True, planner_config=self.get_planner_config())

    def get_config(self):
        return self.policy.get_info()["data_config"]

    def get_planner_config(self):
        with self.lock:
            return self.settings.to_dict()

    def get_status(self):
        with self.lock:
            return dict(status=self.last_status, observation_count=len(self.sampler.states),
                last_timestamp=None if self.sampler.latest is None else self.sampler.latest["timestamp"])

    def reset(self):
        with self.lock:
            self.sampler.reset()
            self.pos_ensembler.reset()
            self.gripper_ensembler.reset()
            self.last_obs_data = None
            self.last_status = "waiting_for_observations"

    def set_config(self, values):
        allowed = {"prompt", "speed_mps", "guidance_scale", "seed", "ensemble", "input_pose_format",
                   "input_gripper_format", "color_order", "history_tolerance_s"}
        if not isinstance(values, dict) or set(values)-allowed:
            raise ValueError("Only runtime Planner settings may change; restart to switch task/checkpoint")
        with self.lock:
            settings = replace(self.settings, **values).validate()
            sampler = self._sampler(settings)
            changed = {key for key in values if getattr(settings,key) != getattr(self.settings,key)}
            if changed & {"input_pose_format", "input_gripper_format", "color_order", "history_tolerance_s"}:
                self.sampler = sampler
                self.last_obs_data = None
                self.last_status = "waiting_for_observations"
            if changed:
                self.pos_ensembler = TrajEnsembler(settings.ensemble)
                self.gripper_ensembler = TrajEnsembler(settings.ensemble)
            self.settings = settings

    def set_prompt(self, prompt_text):
        if not isinstance(prompt_text, str) or not prompt_text.strip():
            raise ValueError("Supply a nonempty task prompt")
        self.set_config({"prompt": prompt_text})

    def set_speed(self, speed_mps, guidance_scale=1.):
        raise ValueError("This checkpoint has no speed condition")

    def set_ensemble_nums(self, n):
        self.set_config({"ensemble": n})

    def add_obs_frame(self, obs_frame):
        with self.lock:
            self.sampler.add_obs_frame(obs_frame)

    def add_obs_frames(self, obs_frames):
        if not isinstance(obs_frames, (list, tuple)) or not obs_frames or len(obs_frames) > 240:
            raise ValueError("Supply between 1 and 240 observation frames")
        with self.lock:
            previous, latest = self.sampler.states.copy(), self.sampler.latest
            try:
                for frame in obs_frames:
                    self.sampler.add_obs_frame(frame)
            except Exception:
                self.sampler.states, self.sampler.latest = previous, latest
                raise

    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        with self.lock:
            settings = self.settings
            return self.policy.run_inference(obs_data, settings.seed if seed is None else seed,
                contract_sha256, settings.speed_mps if speed_mps is None else speed_mps,
                settings.guidance_scale if guidance_scale is None else guidance_scale)

    def run_inference_numpy(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        return self.run_inference(obs_data, seed, contract_sha256, speed_mps, guidance_scale).numpy()

    def get_action(self, draw_traj=False, compress_traj_img=False, seed=None, speed_mps=None):
        with self.lock:
            if not self.sampler.states:
                return None
            try:
                sample = self.sampler.sample(self.settings.prompt)
            except HistoryNotReady as exc:
                self.last_status = str(exc)
                return None
            actions = self.policy.predict_samples([sample], self.settings.seed if seed is None else seed,
                self.settings.speed_mps if speed_mps is None else speed_mps, self.settings.guidance_scale)[0].numpy()
            poses, grippers = actions[...,:16].reshape(-1,2,4,4), actions[...,16]
            times = self.sampler.latest["timestamp"] + (self.config.action_offset
                + np.arange(len(actions))*self.config.frame_stride) / self.policy.fps
            image = draw_prediction(sample, poses, compress_traj_img) if draw_traj else None
            self.last_obs_data, self.last_status = sample, "ready"
            return poses, grippers, times, image

    def ensemble_traj(self, future_ee_poses, future_grippers, future_time):
        with self.lock:
            poses, grippers, times = (np.asarray(x).copy() for x in
                                     (future_ee_poses, future_grippers, future_time))
            if (times.ndim != 1 or len(times) < 2 or poses.shape != (len(times),2,4,4)
                    or grippers.shape != (len(times),2) or np.any(np.diff(times) <= 0)
                    or not all(np.isfinite(x).all() for x in (poses,grippers,times))):
                raise ValueError("Invalid dual-arm trajectory/timestamps")
            if self.settings.ensemble != 0:
                if self.pos_ensembler.history_time and times[0] < self.pos_ensembler.history_time[-1][0]:
                    raise ValueError("Ensemble trajectory time moved backwards; reset first")
                poses[...,:3,3] = self.pos_ensembler.update(poses[...,:3,3], times)
                grippers = self.gripper_ensembler.update(grippers, times)
            return poses, grippers
