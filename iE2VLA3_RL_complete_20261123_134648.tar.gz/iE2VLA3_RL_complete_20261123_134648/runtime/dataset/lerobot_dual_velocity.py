"""Four-factor LeRobot supervision over existing raw/reviewed/grouped views."""
import bisect
from dataclasses import asdict, dataclass, field
import hashlib
import json
import numpy as np
import torch
from torch.utils.data import Dataset
from .lerobot_original import LeRobotOriginalConfig, LeRobotOriginalCollator
from .lerobot_reviewed import build_dataset
from .lerobot_dual import pack_states
from data_utils.trajectory_factor32 import retime_sample, valid_anchors
from models.speed_factor import FACTORS


@dataclass
class LeRobotRetimedVelocityConfig(LeRobotOriginalConfig):
    num_future_actions: int = 32
    speed_factors: list[float] = field(default_factory=lambda: list(FACTORS))
    target_fps: float = 30.
    history_mode: str = 'observed'

    def validate(self):
        super().validate()
        if tuple(self.speed_factors) != FACTORS:
            raise ValueError('speed_factors must be [0.8, 1.0, 1.5, 2.0]')
        if (self.num_future_actions != 32 or self.frame_stride != 1 or self.action_offset != 0
                or self.target_fps != 30. or self.history_mode != 'observed'):
            raise ValueError('Factor training uses 32 targets, 30 Hz, offset 0 and observed history')


class LeRobotRetimedVelocityDataset(Dataset):
    """Same anchors for every factor; no padding, task leakage, or virtual forces."""
    def __init__(self, config):
        config.validate()
        self.config = config
        values = asdict(config)
        for key in ('speed_factors', 'target_fps', 'history_mode'):
            values.pop(key)
        # Existing readers select eligible individual rows. We check complete
        # retimed spans, including all interpolation-support rows, below.
        values.update(num_future_actions=1, num_history_states=1)
        self.base = build_dataset(LeRobotOriginalConfig(**values))
        self.fps, self.episodes = self.base.fps, self.base.episodes
        self.blocks, self.ends, self.readers = [], [], []
        self.counts = {str(f): 0 for f in FACTORS}
        try:
            self.base.require_geometry()
            if hasattr(self.base, 'group_ranges'):
                self.group_ranges, groups = [], []
                for source in self.base.sources:
                    if not groups or source['group'] != groups[-1]:
                        if groups:
                            self.group_ranges.append((start, len(self)))
                        groups.append(source['group'])
                        start = len(self)
                    self._collect(self.base.readers[source['name']])
                self.group_ranges.append((start, len(self)))
                if any(a == b for a, b in self.group_ranges):
                    raise ValueError('A group has no complete four-factor windows')
                self.sampling_mode = 'equal_groups_cycle_v1'
                self.sampling_summary = dict(mode=self.sampling_mode, groups=[
                    dict(name=n, probability=.5, windows=b-a) for n, (a,b) in zip(groups,self.group_ranges)])
            else:
                self._collect(self.base)
            if not len(self):
                raise ValueError('No complete paired four-factor windows fit the selected data')
            digest = hashlib.sha256(json.dumps(asdict(config), sort_keys=True).encode())
            if hasattr(self.base, 'fingerprint'):
                digest.update(self.base.fingerprint.encode())
            for reader in self.readers:
                for name in ('info.json', 'episodes.jsonl', 'tasks.jsonl'):
                    digest.update((reader.root/'meta'/name).read_bytes())
            self.fingerprint = digest.hexdigest()
        except BaseException:
            self.close()
            raise

    def _collect(self, base, prompt=None):
        if hasattr(base, 'segments'):
            for segment in base.segments:
                reader = base.readers[segment['dataset_id']]
                ep = next(i for i, e in enumerate(reader.episodes) if e['episode_index'] == segment['episode_index'])
                key = str(segment.get('split_group') or f"{segment['source_root']}:{segment['episode_index']}")
                self._add(reader, ep, segment['frames'], segment['instruction'], key)
        elif hasattr(base, 'raw_sources'):
            for source in base.raw_sources:
                self._collect(base.readers[source['name']], source['instruction'])
        else:
            for ep, item in enumerate(base.episodes):
                self._add(base, ep, np.arange(item['length']), prompt,
                          f"{base.root.resolve()}:{item['episode_index']}")

    @staticmethod
    def columns(reader, ep):
        result = reader._episode(ep)
        if 'timestamp' not in result:
            import pyarrow.parquet as pq
            path = reader._path('data_path', reader.episodes[ep]['episode_index'])
            with pq.ParquetFile(path) as stream:
                result['timestamp'] = np.asarray(stream.read(columns=['timestamp'], use_threads=False)
                                                  .column('timestamp').to_numpy(), dtype=np.float64)
        return result

    def _add(self, reader, ep, frames, prompt, episode_key):
        if not any(x is reader for x in self.readers):
            self.readers.append(reader)
        rid = next(i for i, x in enumerate(self.readers) if x is reader)
        columns = self.columns(reader, ep)
        checked = dict(columns, prompt=None) if prompt is not None else columns
        frames = valid_anchors(checked, frames, self.config.num_history_states)
        if not len(frames):
            return
        for factor in FACTORS:
            self.blocks.append(dict(reader=rid, ep=ep, frames=frames, factor=factor,
                                    prompt=prompt, episode_key=episode_key))
            self.ends.append(len(self) + len(frames))
            self.counts[str(factor)] += len(frames)

    def __len__(self):
        return self.ends[-1] if self.ends else 0

    def locate(self, index):
        if not 0 <= index < len(self):
            raise IndexError(index)
        i = bisect.bisect_right(self.ends, index)
        block = self.blocks[i]
        return block, int(block['frames'][index - (self.ends[i-1] if i else 0)])

    def numeric_sample(self, index):
        block, frame = self.locate(index)
        reader = self.readers[block['reader']]
        values = retime_sample(self.columns(reader, block['ep']), frame, block['factor'],
                               self.config.num_history_states)
        return dict(values, frame=frame, episode_key=block['episode_key'],
                    source_root=str(reader.root),
                    parquet_path=str(reader._path('data_path', reader.episodes[block['ep']]['episode_index'])))

    def __getitem__(self, index):
        block, frame = self.locate(index)
        reader, ep = self.readers[block['reader']], block['ep']
        sample = reader[(reader.ends[ep-1] if ep else 0) + frame]
        if block['prompt'] is not None:
            sample.raw_vl.prompt = block['prompt']
        values = self.numeric_sample(index)
        sample.state, sample.state_mask = pack_states(values['history_pose'], values['history_gripper'],
                                                      np.ones(self.config.num_history_states, dtype=bool))
        sample.action, sample.action_mask = pack_states(values['action_pose'], values['action_gripper'],
                                                        np.ones(32, dtype=bool))
        sample._retime_metadata = values
        return sample

    def require_geometry(self):
        self.base.require_geometry()

    def close(self):
        self.base.close()


class LeRobotRetimedVelocityCollator(LeRobotOriginalCollator):
    def __call__(self, samples):
        result = super().__call__(samples)
        result['_aux_data']['speed_factor'] = torch.tensor(
            [float(s._retime_metadata['speed_factor']) for s in samples], dtype=torch.float32)
        return result
