"""Two equally sampled groups of reviewed views and original LeRobot sources.

This dataset only maps indices. TrainingStream enforces the group ratio using
BalancedGroupBatchSampler; concatenating the sources alone is not sufficient.
"""
import bisect
from dataclasses import replace
import hashlib
import json
from pathlib import Path

from torch.utils.data import Dataset

from .lerobot_original import LeRobotOriginalDataset
from .lerobot_reviewed import LeRobotReviewedDataset


class LeRobotGroupedDataset(Dataset):
    sampling_mode = "equal_groups_cycle_v1"

    def __init__(self, config):
        config.validate()
        self.config = config
        manifest_path = Path(config.root).expanduser() / "dataset_groups.json"
        payload = manifest_path.read_bytes()
        manifest = json.loads(payload)
        if manifest.get("format") != "lerobot_equal_groups_v1":
            raise ValueError("Unsupported grouped dataset format")
        groups = manifest.get("groups")
        if not isinstance(groups, list) or len(groups) != 2:
            raise ValueError("Equal sampling requires exactly two groups")
        self.readers, self.sources, self.episodes, self.ends = {}, [], [], []
        self.group_ranges, summaries = [], []
        roots, names, rates = set(), set(), set()
        fingerprint = hashlib.sha256(payload)
        total = 0
        try:
            for group in groups:
                name, sources = group["name"], group["sources"]
                if not isinstance(name, str) or not name.strip() or name in names:
                    raise ValueError("Group names must be nonempty and unique")
                names.add(name)
                if not isinstance(sources, list) or not sources:
                    raise ValueError("Every group requires nonempty sources")
                start, episode_count, source_summaries = total, 0, []
                for source in sources:
                    source_name = source["name"]
                    if (not isinstance(source_name, str) or not source_name.strip()
                            or source_name in self.readers):
                        raise ValueError("Source names must be nonempty and globally unique")
                    root = Path(source["root"]).expanduser()
                    root = (root if root.is_absolute() else manifest_path.parent / root).resolve()
                    if root in roots:
                        raise ValueError("Duplicate grouped source root (including symlink aliases)")
                    roots.add(root)
                    cfg = replace(config, root=str(root))
                    if source["type"] == "reviewed":
                        if root.name != "filtered_data" or not (root.parent / "task_manifest.json").is_file():
                            raise ValueError("Reviewed sources must select a handoff's filtered_data")
                        reader = LeRobotReviewedDataset(cfg)
                    elif source["type"] == "lerobot":
                        reader = LeRobotOriginalDataset(cfg)
                    else:
                        raise ValueError("Source type must be reviewed or lerobot")
                    self.readers[source_name] = reader
                    expected = source.get("expected_episodes")
                    if expected is not None and expected != len(reader.episodes):
                        raise ValueError(f"{source_name}: expected {expected} episodes, found {len(reader.episodes)}")
                    if len(reader) < 1:
                        raise ValueError(f"Empty source: {source_name}")
                    self.sources.append(dict(name=source_name, group=name, root=str(root)))
                    self.episodes.extend((source_name, ep) for ep in reader.episodes)
                    total += len(reader)
                    self.ends.append(total)
                    episode_count += len(reader.episodes)
                    rates.add(reader.fps)
                    source_summaries.append(dict(name=source_name, root=str(root),
                                                 episodes=len(reader.episodes), windows=len(reader)))
                    fingerprint.update(source_name.encode() + b"\0")
                    if hasattr(reader, "fingerprint"):
                        fingerprint.update(reader.fingerprint.encode())
                    else:
                        for filename in ("info.json", "episodes.jsonl", "tasks.jsonl"):
                            fingerprint.update(filename.encode() + b"\0")
                            fingerprint.update(hashlib.sha256((root / "meta" / filename).read_bytes()).digest())
                self.group_ranges.append((start, total))
                summaries.append(dict(name=name, probability=0.5, episodes=episode_count,
                                      windows=total - start, sources=source_summaries))
            if len(rates) != 1:
                raise ValueError("Grouped sources must share a frame rate")
            self.fps = rates.pop()
            self.fingerprint = fingerprint.hexdigest()
            self.sampling_summary = dict(mode=self.sampling_mode, groups=summaries)
        except BaseException:
            self.close()
            raise

    def __len__(self):
        return self.ends[-1]

    def __getitem__(self, index):
        if not 0 <= index < len(self):
            raise IndexError(index)
        block = bisect.bisect_right(self.ends, index)
        source = self.sources[block]
        local = index - (self.ends[block - 1] if block else 0)
        sample = self.readers[source["name"]][local]
        sample._mixture_metadata = dict(group=source["group"], source=source["name"], index=local)
        return sample

    def require_geometry(self):
        for reader in self.readers.values():
            reader.require_geometry()

    def close(self):
        for reader in self.readers.values():
            reader.close()
