"""Reviewed Huawei Parquet views, with original-frame video/geometry loading."""
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import replace
import bisect
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import torch.distributed as dist
from torch.utils.data import Dataset

from .lerobot_original import LeRobotOriginalDataset


@contextmanager
def reviewed_handoff(handoff):
    """Keep separately exported data_cleaner runtimes from sharing imports."""
    saved_path = list(sys.path)
    def runtime_module(name):
        return name == "data_cleaner" or name.startswith("data_cleaner.")
    saved_modules = {name: module for name, module in sys.modules.copy().items() if runtime_module(name)}
    for name in saved_modules:
        del sys.modules[name]
    try:
        spec = importlib.util.spec_from_file_location("ie2vla_review_handoff", handoff / "read_training.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        yield module
    finally:
        for name in list(sys.modules):
            if runtime_module(name):
                del sys.modules[name]
        sys.modules.update(saved_modules)
        sys.path[:] = saved_path


def load_reviewed_view(root, config):
    """Run the handoff's integrity/keep checks once, then retain compact windows."""
    handoff = Path(root).resolve().parent
    with reviewed_handoff(handoff) as module:
        return _load_reviewed_view(root, config, handoff, module)


def _load_reviewed_view(root, config, handoff, module):
    segments = module.load_reviewed_segments(handoff)
    result = []
    fields = ("segment_id", "dataset_id", "episode_index", "source_root", "parquet_path",
              "start_frame", "stop_frame", "instruction", "excluded_intervals", "action_relation", "split_group")
    for segment in segments:
        path = Path(segment["parquet_path"])
        if not path.is_absolute():
            path = Path(segment["source_root"]) / path
        path = path.resolve()
        if segment.get("filtered_parquet") and not path.is_relative_to(Path(root).resolve()):
            raise ValueError(f"Reviewed numeric input is outside the configured filtered_data: {path}")
        frames = []
        for frame in range(segment["start_frame"], segment["stop_frame"]):
            history = frame + np.arange(1 - config.num_history_states, 1) * config.frame_stride
            actions = frame + config.action_offset + np.arange(config.num_future_actions) * config.frame_stride
            if module.sample_rows_valid(segment, history, actions):
                frames.append(frame)
        compact = {key: segment[key] for key in fields}
        compact["parquet_path"] = str(path)
        result.append(dict(compact, frames=np.array(frames, dtype=np.int32)))
    fingerprint = hashlib.sha256((handoff / "run_manifest.json").read_bytes()).hexdigest()
    return result, fingerprint


class _ReviewedSource(LeRobotOriginalDataset):
    def __init__(self, config, paths):
        self.reviewed_paths = paths
        super().__init__(config)

    def _jsonl(self, name):
        rows = super()._jsonl(name)
        if name == "episodes.jsonl":
            rows = [row for row in rows if int(row["episode_index"]) in self.reviewed_paths]
        return rows

    def _path(self, kind, ep_id, video_key=""):
        if kind == "data_path":
            return Path(self.reviewed_paths[int(ep_id)])
        return super()._path(kind, ep_id, video_key)


class LeRobotReviewedDataset(Dataset):
    def __init__(self, config):
        config.validate()
        self.config = config
        # Validate large source videos once on rank 0, before workers are spawned.
        distributed = dist.is_initialized()
        payload = [None]
        if not distributed or dist.get_rank() == 0:
            try:
                payload[0] = dict(view=load_reviewed_view(config.root, config))
            except Exception as exc:
                payload[0] = dict(error=f"{type(exc).__name__}: {exc}")
        if distributed:
            dist.broadcast_object_list(payload, src=0)
        if "error" in payload[0]:
            raise ValueError(payload[0]["error"])
        self.segments, self.fingerprint = payload[0]["view"]
        grouped = defaultdict(dict)
        roots = {}
        for segment in self.segments:
            key, ep = segment["dataset_id"], segment["episode_index"]
            roots[key] = segment["source_root"]
            grouped[key][ep] = segment["parquet_path"]
        self.readers = {key: _ReviewedSource(replace(config, root=roots[key]), paths)
                        for key, paths in grouped.items()}
        rates = {reader.fps for reader in self.readers.values()}
        if len(rates) != 1:
            raise ValueError("Reviewed sources must share a frame rate")
        self.fps = rates.pop()
        self.episodes = [(key, ep) for key, paths in grouped.items() for ep in paths]
        self.offsets = {}
        for key, reader in self.readers.items():
            for i, ep in enumerate(reader.episodes):
                self.offsets[key, ep["episode_index"]] = reader.ends[i - 1] if i else 0
        self.ends = np.cumsum([len(segment["frames"]) for segment in self.segments]).tolist()
        if not self.ends or not self.ends[-1]:
            raise ValueError("No reviewed windows fit the configured history/horizon")

    def require_geometry(self):
        for reader in self.readers.values():
            reader.require_geometry()

    def __len__(self):
        return self.ends[-1]

    def __getitem__(self, index):
        if not 0 <= index < len(self):
            raise IndexError(index)
        block = bisect.bisect_right(self.ends, index)
        segment = self.segments[block]
        frame = int(segment["frames"][index - (self.ends[block - 1] if block else 0)])
        key, ep = segment["dataset_id"], segment["episode_index"]
        sample = self.readers[key][self.offsets[key, ep] + frame]
        sample.raw_vl.prompt = segment["instruction"]
        sample._review_metadata = dict(segment_id=segment["segment_id"], dataset_id=key,
                                      episode_index=ep, frame=frame, split_group=segment["split_group"])
        return sample

    def close(self):
        for reader in self.readers.values():
            reader.close()


def build_dataset(config):
    root = Path(config.root).expanduser()
    if (root / "dataset_groups.json").is_file():
        from .lerobot_grouped import LeRobotGroupedDataset
        return LeRobotGroupedDataset(config)
    if (root / "raw_sources.json").is_file():
        from .lerobot_raw_multi import LeRobotRawMultiDataset
        return LeRobotRawMultiDataset(config)
    if root.name == "filtered_data" and (root.parent / "task_manifest.json").is_file():
        return LeRobotReviewedDataset(config)
    return LeRobotOriginalDataset(config)
