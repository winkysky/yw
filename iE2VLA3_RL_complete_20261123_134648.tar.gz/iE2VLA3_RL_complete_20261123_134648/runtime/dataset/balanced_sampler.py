"""Deterministic equal-group batches, shared across DDP ranks and resumable."""
import torch
from torch.utils.data import Sampler


class BalancedGroupBatchSampler(Sampler):
    """Half of every global microbatch comes from each contiguous index range.

    Shuffle without replacement within each group, reshuffling when exhausted.
    An epoch covers the larger group once (rounded up to a full batch). Smaller
    groups repeat as needed. Resuming replays the same index plan, independent
    of DataLoader prefetch and the model's random number generator.
    """
    def __init__(self, group_ranges, batch_size, seed, epoch, start_batch=0, rank=0, world_size=1):
        if not 0 <= rank < world_size or min(batch_size, world_size) < 1:
            raise ValueError("Invalid distributed sampler shape/rank")
        if (len(group_ranges) != 2 or group_ranges[0][0] != 0
                or group_ranges[0][1] != group_ranges[1][0]
                or any(stop <= start for start, stop in group_ranges)):
            raise ValueError("Expected two nonempty contiguous group ranges")
        self.global_batch = batch_size * world_size
        if self.global_batch % 2:
            raise ValueError("Equal groups require an even global batch_size * world_size")
        self.group_ranges = group_ranges
        self.batch_size, self.rank, self.world_size = batch_size, rank, world_size
        self.seed, self.epoch, self.start_batch = seed, epoch, start_batch
        quota = self.global_batch // 2
        largest = max(stop - start for start, stop in group_ranges)
        self.total_batches = (largest + quota - 1) // quota
        if not 0 <= start_batch <= self.total_batches:
            raise ValueError("Resume batch is outside the balanced epoch")
        self.stopped = False

    def __len__(self):
        return self.total_batches - self.start_batch

    def __iter__(self):
        if self.stopped or self.start_batch == self.total_batches:
            return
        generator = torch.Generator().manual_seed(self.seed + self.epoch)
        count = self.total_batches * (self.global_batch // 2)
        plans = []
        for start, stop in self.group_ranges:
            pieces, remaining = [], count
            while remaining:
                take = min(stop - start, remaining)
                pieces.append(torch.randperm(stop - start, generator=generator)[:take] + start)
                remaining -= take
            plans.append(torch.cat(pieces))
        # Alternating groups give every even-sized local batch a 50/50 split.
        # Flip order per batch so odd local sizes do not permanently favor one
        # group on a rank (e.g. four ranks with one sample each).
        batches = torch.stack(plans, dim=1).reshape(self.total_batches, self.global_batch)
        for batch in range(self.start_batch, self.total_batches):
            if self.stopped:
                break
            indices = batches[batch]
            if (self.epoch + batch) % 2:
                indices = indices.reshape(-1, 2).flip(1).reshape(-1)
            start = self.rank * self.batch_size
            yield indices[start:start + self.batch_size].tolist()
