import glob
import h5py
import random
import numpy as np
from typing import Optional, List
from torchvision.transforms import v2


from action import align
from dataset._location import get_loc
from data_utils.transforms import BaseTransform
from data_utils.registry import mark_offline_test
from data_utils.dataset_base import DatasetBase, DataConfig
from data_utils.video_decode import decode_video_frames_torchcodec
from client import ImageObservation, NumpyDataRawVLA, numpy2torch


mappings = {
    0: "Hand", 

    1: "ThumbKnuckle",
    2: "ThumbIntermediateBase",
    3: "ThumbIntermediateTip",
    4: "ThumbTip",

    5: "IndexFingerKnuckle",
    6: "IndexFingerIntermediateBase",
    7: "IndexFingerIntermediateTip",
    8: "IndexFingerTip",

    9: "MiddleFingerKnuckle",
    10: "MiddleFingerIntermediateBase",
    11: "MiddleFingerIntermediateTip",
    12: "MiddleFingerTip",

    13: "RingFingerKnuckle",
    14: "RingFingerIntermediateBase",
    15: "RingFingerIntermediateTip",
    16: "RingFingerTip",

    17: "LittleFingerKnuckle",
    18: "LittleFingerIntermediateBase",
    19: "LittleFingerIntermediateTip",
    20: "LittleFingerTip",
}


# @mark_offline_test()
class EgoDexBackup(DatasetBase):

    record_dt = 1.0/30
    sample_dt = 1.0/15

    def __init__(
        self, 
        h5_filelist: List[str], 
        data_config: DataConfig, 
        transforms: Optional[BaseTransform] = None
    ):
        super().__init__()
        self.h5_filelist = h5_filelist
        self.data_config = data_config
        self.transforms = transforms

    @classmethod
    def read_prompt(cls, h5: h5py.File):
        instructions = []

        if 'llm_description' in h5.attrs:
            instruction = h5.attrs['llm_description']
            if isinstance(instruction, bytes):
                instruction = instruction.decode('utf-8')
            instructions.append(instruction)
        
        # Extract second description (if exists)
        if 'llm_description2' in h5.attrs:
            instruction2 = h5.attrs['llm_description2']
            if isinstance(instruction2, bytes):
                instruction2 = instruction2.decode('utf-8')
            instructions.append(instruction2)
        
        return instructions
    
    @classmethod
    def sample_low_dim(
        cls, 
        h5: h5py.File, 
        episode_len: int, 
        frame_index: int, 
        data_config: DataConfig, 
    ):
        K: np.ndarray = h5["camera"]["intrinsic"][:]                # (3, 3)
        head_pose: np.ndarray = h5["transforms"]["camera"][:]       # (T, 4, 4)
        left_pose: np.ndarray = h5["transforms"]["leftHand"][:]     # (T, 4, 4)
        right_pose: np.ndarray = h5["transforms"]["rightHand"][:]   # (T, 4, 4)

        left_fingers = []
        right_fingers = []
        for i in range(21):
            left_fingers.append(h5["transforms"]["left" + mappings[i]][:, :3, 3])       # (T, 3)
            right_fingers.append(h5["transforms"]["right" + mappings[i]][:, :3, 3])     # (T, 3)
        left_fingers = np.concatenate(left_fingers, axis=-1)    # (T, 20 * 3)
        right_fingers = np.concatenate(right_fingers, axis=-1)  # (T, 20 * 3)

        train_data = {
            "head_pose": head_pose,
            "left_pose": left_pose, 
            "right_pose": right_pose, 
            "left_fingers": left_fingers, 
            "right_fingers": right_fingers
        }
        
        interp_funcs = {
            "head_pose": align.interp_SE3_sep, 
            "left_pose": align.interp_SE3_sep, 
            "right_pose": align.interp_SE3_sep, 
            "left_fingers": align.interp_linear, 
            "right_fingers": align.interp_linear
        }

        train_time = np.arange(episode_len).astype(np.float64) * cls.record_dt
        query_time = (np.arange(data_config.num_history_states + data_config.num_future_actions) - 
                      data_config.num_history_states + 1).astype(np.float64) * cls.sample_dt + frame_index * cls.record_dt
        query_time = query_time.clip(0, train_time[-1])
        query_data = align.align_data(
            query_time=query_time,
            train_time=train_time,
            train_data=train_data,
            interp_funcs=interp_funcs
        )

        # split history and future, history as states, future as actions
        history_data = {k: v[:data_config.num_history_states] for k, v in query_data.items()}
        future_data = {k: v[data_config.num_history_states:] for k, v in query_data.items()}
        
        state = [
            # {
            #     "posemat": history_data["head_pose"]
            # },
            {
                "posemat": history_data["left_pose"],
                "dexhand": history_data["left_fingers"],
            },
            {
                "posemat": history_data["right_pose"],
                "dexhand": history_data["right_fingers"]
            }
        ]

        action = [
            # {
            #     "posemat": future_data["head_pose"]
            # },
            {
                "posemat": future_data["left_pose"],
                "dexhand": future_data["left_fingers"],
            },
            {
                "posemat": future_data["right_pose"],
                "dexhand": future_data["right_fingers"]
            }
        ]

        obs = ImageObservation(
            K=K, 
            pose=history_data["head_pose"][-1],  # (4, 4)
            color=None,
            encoding=None
        )

        action_ref_pose = history_data["head_pose"][-1:].repeat(len(action), axis=0)  # (3, 4, 4)
        prompts = cls.read_prompt(h5)

        if len(prompts) == 0:
            prompt = None
        else:
            prompt = random.sample(prompts, k=1)[0]

        return NumpyDataRawVLA(
            fps=1.0 / cls.sample_dt, 
            images=[[obs]],
            prompt=prompt, 
            state=state,
            action=action, 
            action_ref_pose=action_ref_pose
        )

    def __len__(self):
        return len(self.h5_filelist)
    
    def get_handler(self, episode_id):
        h5_file = self.h5_filelist[episode_id]
        video_file = h5_file.replace(".hdf5", ".mp4")
        h5 = h5py.File(h5_file, "r")
        episode_len = len(h5["transforms"]["camera"])
        return (h5, video_file), episode_len

    def sample_episode(self, handler, episode_len: int, frame_index: int):
        h5, video_path = handler
        raw_data = self.sample_low_dim(h5, episode_len, frame_index, self.data_config)
        video_time = frame_index * self.record_dt
        rgb = decode_video_frames_torchcodec(
            video_path=video_path, 
            timestamps=[video_time],
            tolerance_s=self.record_dt,
        )[0]  # (C, H, W)

        H, W = rgb.shape[-2:]
        rgb = v2.Resize((H//3, W//3))(rgb)

        obs = raw_data.images[0][0]
        obs.K[:2] /= 3
        obs.color = rgb.cpu().numpy()
        obs.encoding = "rgb"

        data_torch = numpy2torch(raw_data)
        if self.transforms is not None:
            data_torch = self.transforms(data_torch)
        return data_torch

    def close_handler(self, handler):
        h5, video_path = handler
        h5.close()
    
    @classmethod
    def inst(
        cls,
        data_config: DataConfig, 
        transforms: Optional[BaseTransform] = None
    ):
        pattern = get_loc(cls.__name__)
        h5_files = glob.glob(pattern, recursive=True)
        assert len(h5_files) > 0
        h5_files.sort()
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        return cls(h5_files, data_config, transforms)

