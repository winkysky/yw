"""Local LeRobot v2.x -> existing VLA batches, with fixed left/right arm order.

This module does not import dataset._location or change the HDF5 loaders.
TCP positions are converted to metres; grippers to 0=closed, 1=open.
Use LeRobotOriginalDataset to attach calibrated geometry for the original VLA.
"""

from collections import OrderedDict
from dataclasses import asdict, dataclass, field
from pathlib import Path
import bisect
import json

import cv2
import numpy as np
import torch
from scipy.spatial.transform import Rotation
from torch.utils.data import Dataset

from action.define import ACTION_SPACE_SIZE
from data_utils.data_raw import DataRawVL, DataRawVLA


@dataclass
class LeRobotDualConfig:
    root: str
    state_pose_key: str = "observation.tcp_pose"
    action_pose_key: str = "action.tcp_pose_cmd"
    state_gripper_key: str = "observation.state"
    action_gripper_key: str = "action.joint"
    gripper_indices: list[int] = field(default_factory=lambda: [6, 13])
    gripper_closed: list[float] = field(default_factory=lambda: [1886., 1886.])
    gripper_open: list[float] = field(default_factory=lambda: [0., 0.])
    pose_format: str = "xyz_euler"
    euler_order: str = "xyz"  # SciPy: lower case = extrinsic rotations.
    angle_degrees: bool = True
    position_scale: float = 0.001
    # Translations in METRES. Identity means the source is already a TCP pose.
    pose_to_tcp: list = field(default_factory=lambda: [np.eye(4).tolist(), np.eye(4).tolist()])
    # ^world T_recorded_base, left then right. For HW, world is LEFT base;
    # the right mapping must rotate and translate, not just shift TCP xyz.
    base_to_world: list = field(default_factory=lambda: [np.eye(4).tolist(), np.eye(4).tolist()])
    convention_notes: dict[str, str] = field(default_factory=dict)
    camera_keys: list[str] = field(default_factory=lambda: [
        "observation.images.head_image",
        "observation.images.left_wrist_image",
        "observation.images.right_wrist_image",
    ])
    image_size: list[int] = field(default_factory=lambda: [192, 256])  # H, W
    num_history_states: int = 1
    num_future_actions: int = 20
    frame_stride: int = 1
    action_offset: int = 0  # Command at observation t is target step 0.
    cache_episodes: int = 2
    cache_videos: int = 6

    @classmethod
    def load(cls, path, **overrides):
        values = json.loads(Path(path).read_text())
        values.update({key: value for key, value in overrides.items() if value is not None})
        result = cls(**values)
        result.validate()
        return result

    def to_dict(self):
        return asdict(self)

    def validate(self):
        if not self.root:
            raise ValueError("A local LeRobot root is required")
        if self.pose_format not in {"xyz_euler", "xyz_rotvec", "xyz_quat_xyzw", "xyz_quat_wxyz", "matrix"}:
            raise ValueError(f"Unsupported pose_format: {self.pose_format}")
        if self.euler_order not in {"xyz", "xzy", "yxz", "yzx", "zxy", "zyx",
                                    "XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX"}:
            raise ValueError("euler_order must be a three-axis SciPy convention")
        if not np.isfinite(self.position_scale) or self.position_scale <= 0:
            raise ValueError("position_scale must convert raw positions to metres")
        if len(self.image_size) != 2 or any(x <= 0 or x % 32 for x in self.image_size):
            raise ValueError("image_size must be [height, width], both positive multiples of 32")
        if not self.camera_keys or len(set(self.camera_keys)) != len(self.camera_keys):
            raise ValueError("camera_keys must be nonempty, unique, and in a fixed order")
        for values in (self.gripper_indices, self.gripper_closed, self.gripper_open):
            if len(values) != 2 or not np.isfinite(values).all():
                raise ValueError("Gripper settings must have two finite entries: left, right")
        if any(i < 0 for i in self.gripper_indices) or len(set(self.gripper_indices)) != 2:
            raise ValueError("Set distinct nonnegative left/right gripper indices")
        if any(a == b for a, b in zip(self.gripper_closed, self.gripper_open)):
            raise ValueError("Gripper open and closed endpoints must differ")
        if min(self.num_history_states, self.num_future_actions, self.frame_stride,
               self.cache_episodes, self.cache_videos) < 1 or self.action_offset < 0:
            raise ValueError("History, horizon, stride and caches must be positive; offset >= 0")
        for name in ("pose_to_tcp", "base_to_world"):
            matrices = np.asarray(getattr(self, name), dtype=np.float64)
            if matrices.shape != (2, 4, 4) or not np.isfinite(matrices).all():
                raise ValueError(f"{name} requires two finite 4x4 matrices, left then right")
            r = matrices[..., :3, :3]
            if (not np.allclose(matrices[..., 3, :], [0, 0, 0, 1])
                    or not np.allclose(r.swapaxes(-1, -2) @ r, np.eye(3), atol=1e-4)
                    or not np.allclose(np.linalg.det(r), 1, atol=1e-4)):
                raise ValueError(f"{name} must contain valid SE(3) transforms")


def decode_tcp(values, cfg):
    """Per-arm recorded poses -> common-world TCPs (frames, 2, 4, 4).

    Used for both observations and action commands, before history slicing or
    retiming. ^W T_TCP = ^W T_base @ ^base T_recorded @ ^recorded T_TCP.
    The HW fields named tcp_pose actually record flange poses (see config).
    """
    widths = {"xyz_euler": 6, "xyz_rotvec": 6, "xyz_quat_xyzw": 7,
              "xyz_quat_wxyz": 7, "matrix": 16}
    width = widths[cfg.pose_format]
    raw = np.asarray(values, dtype=np.float64)
    if raw.ndim < 2 or raw.reshape(len(raw), -1).shape[1] != 2 * width or not np.isfinite(raw).all():
        raise ValueError(f"Expected finite left/right {cfg.pose_format} TCPs, got {raw.shape}")
    raw = raw.reshape(-1, 2, width)
    if cfg.pose_format == "matrix":
        poses = raw.reshape(-1, 2, 4, 4).copy()
        r = poses[..., :3, :3]
        if (not np.allclose(poses[..., 3, :], [0, 0, 0, 1])
                or not np.allclose(r.swapaxes(-1, -2) @ r, np.eye(3), atol=1e-4)
                or not np.allclose(np.linalg.det(r), 1, atol=1e-4)):
            raise ValueError("TCP matrices must be valid SE(3) transforms")
    else:
        poses = np.broadcast_to(np.eye(4), (*raw.shape[:2], 4, 4)).copy()
        poses[..., :3, 3] = raw[..., :3]
        angles = raw[..., 3:].reshape(-1, width - 3)
        if cfg.pose_format == "xyz_euler":
            rotation = Rotation.from_euler(cfg.euler_order, angles, degrees=cfg.angle_degrees)
        elif cfg.pose_format == "xyz_rotvec":
            rotation = Rotation.from_rotvec(angles, degrees=cfg.angle_degrees)
        else:
            if cfg.pose_format == "xyz_quat_wxyz":
                angles = angles[:, [1, 2, 3, 0]]
            rotation = Rotation.from_quat(angles)
        poses[..., :3, :3] = rotation.as_matrix().reshape(-1, 2, 3, 3)
    poses[..., :3, 3] *= cfg.position_scale
    poses = np.asarray(cfg.base_to_world)[None] @ poses @ np.asarray(cfg.pose_to_tcp)[None]
    return poses.astype(np.float32)


def decode_gripper(values, cfg):
    """Continuous openness: 0=closed, 1=open; E03 raw 1886=closed, 0=open."""
    raw = np.asarray(values, dtype=np.float64)
    if raw.ndim != 2 or raw.shape[1] <= max(cfg.gripper_indices):
        raise ValueError(f"Gripper column is incompatible with indices {cfg.gripper_indices}: {raw.shape}")
    raw = raw[:, cfg.gripper_indices]
    openness = (raw - cfg.gripper_closed) / (np.asarray(cfg.gripper_open) - cfg.gripper_closed)
    if not np.isfinite(openness).all() or np.any((openness < -0.05) | (openness > 1.05)):
        raise ValueError("Gripper values exceed configured endpoints; check units/indices")
    return np.clip(openness, 0, 1).astype(np.float32)


def pack_states(poses, grippers, valid):
    """(time, arms, ...) -> original (arms, time, 73) representation and mask."""
    values = np.zeros((2, len(poses), ACTION_SPACE_SIZE), dtype=np.float32)
    values[..., :3] = poses[..., :3, 3].swapaxes(0, 1)
    # Original ProprioParser uses the first TWO ROWS of the rotation matrix.
    values[..., 3:9] = poses[..., :2, :3].reshape(len(poses), 2, 6).swapaxes(0, 1)
    values[..., 9] = grippers.T
    mask = np.zeros_like(values, dtype=bool)
    mask[..., :10] = np.asarray(valid, dtype=bool)[None, :, None]
    return torch.from_numpy(values), torch.from_numpy(mask)


class LeRobotDualDataset(Dataset):
    def __init__(self, config: LeRobotDualConfig):
        config.validate()
        self.config = config
        self.root = Path(config.root).expanduser()
        info_path = self.root / "meta/info.json"
        if not info_path.is_file():
            raise FileNotFoundError(f"LeRobot metadata not found: {info_path}")
        self.info = json.loads(info_path.read_text())
        if not self.info.get("codebase_version", "").startswith("v2."):
            raise ValueError("This reader supports LeRobot v2.x episode Parquet/video files")
        self.fps = float(self.info["fps"])
        if not np.isfinite(self.fps) or self.fps <= 0:
            raise ValueError("Dataset fps must be finite and positive")
        self.episodes = self._jsonl("episodes.jsonl")
        self.tasks = {int(x["task_index"]): x["task"] for x in self._jsonl("tasks.jsonl")}
        if not self.episodes:
            raise ValueError("No episodes found")
        ids = [int(ep["episode_index"]) for ep in self.episodes]
        if len(set(ids)) != len(ids):
            raise ValueError("Duplicate episode indices in metadata")
        for key in config.camera_keys:
            if self.info["features"].get(key, {}).get("dtype") != "video":
                raise ValueError(f"Expected a video feature: {key}")
        self.sample_lengths = []
        for ep in self.episodes:
            n = int(ep["length"]) - config.action_offset
            if n <= 0:
                raise ValueError(f"Episode {ep['episode_index']} is shorter than action_offset")
            self.sample_lengths.append(n)
            for path in [self._path("data_path", ep["episode_index"])] + [
                    self._path("video_path", ep["episode_index"], key) for key in config.camera_keys]:
                if not path.is_file():
                    raise FileNotFoundError(f"Dataset file listed in metadata is missing: {path}")
        self.ends = np.cumsum(self.sample_lengths).tolist()
        self._episodes = OrderedDict()
        self._videos = OrderedDict()

    def _jsonl(self, name):
        return [json.loads(line) for line in (self.root / "meta" / name).read_text().splitlines() if line.strip()]

    def _path(self, kind, ep_id, video_key=""):
        return self.root / self.info[kind].format(
            episode_chunk=int(ep_id) // self.info.get("chunks_size", 1000),
            episode_index=int(ep_id), video_key=video_key)

    def __len__(self):
        return self.ends[-1]

    def _episode(self, index):
        if index in self._episodes:
            self._episodes.move_to_end(index)
            return self._episodes[index]
        try:
            import pyarrow.parquet as pq
        except ImportError as exc:
            raise ImportError("Install pyarrow to read LeRobot Parquet: python -m pip install pyarrow") from exc
        cfg = self.config
        ep = self.episodes[index]
        path = self._path("data_path", ep["episode_index"])
        required = {cfg.state_pose_key, cfg.action_pose_key, cfg.state_gripper_key,
                    cfg.action_gripper_key, "timestamp", "frame_index", "episode_index", "task_index"}
        # One small episode per file: avoid repeated opens and nested Arrow
        # scan/I/O thread pools inside each DataLoader worker.
        with pq.ParquetFile(path) as source:
            fields = set(source.schema_arrow.names)
            if not required <= fields:
                raise ValueError(f"Missing fields {sorted(required - fields)} in {path}; available: {sorted(fields)}")
            keys = required | ({"prompt"} if "prompt" in fields else set())
            columns = source.read(columns=sorted(keys), use_threads=False).to_pydict()
        n = int(ep["length"])
        times = np.asarray(columns["timestamp"], dtype=np.float64).reshape(-1)
        frames = np.asarray(columns["frame_index"]).reshape(-1)
        ep_ids = np.asarray(columns["episode_index"]).reshape(-1)
        if len(times) != n or not np.array_equal(frames, np.arange(n)) or not np.all(ep_ids == ep["episode_index"]):
            raise ValueError(f"Episode length/frame ordering mismatch: {path}")
        if not np.isfinite(times).all() or np.any(np.diff(times) <= 0):
            raise ValueError(f"Timestamps must be finite and strictly increasing: {path}")
        if not np.allclose(times, frames / self.fps, atol=0.5 / self.fps, rtol=0):
            raise ValueError(f"Timestamps do not match video frame indices at {self.fps} fps: {path}")
        result = dict(
            state_pose=decode_tcp(columns[cfg.state_pose_key], cfg),
            action_pose=decode_tcp(columns[cfg.action_pose_key], cfg),
            state_gripper=decode_gripper(columns[cfg.state_gripper_key], cfg),
            action_gripper=decode_gripper(columns[cfg.action_gripper_key], cfg),
            task_index=np.asarray(columns["task_index"]).reshape(-1),
            prompt=columns.get("prompt"),
        )
        if any(int(task) not in self.tasks for task in result["task_index"]):
            raise ValueError(f"Unknown task_index in {path}")
        self._episodes[index] = result
        while len(self._episodes) > cfg.cache_episodes:
            self._episodes.popitem(last=False)
        return result

    def _image(self, ep_id, camera, frame):
        path = str(self._path("video_path", ep_id, camera))
        if path not in self._videos:
            # Random seeks across short videos are faster with one decoder
            # thread per worker. cv2.setNumThreads does not control FFmpeg.
            if hasattr(cv2, "CAP_PROP_N_THREADS"):
                cap = cv2.VideoCapture(path, cv2.CAP_FFMPEG, [cv2.CAP_PROP_N_THREADS, 1])
            else:
                cap = cv2.VideoCapture(path)
            if not cap.isOpened():
                cap.release()
                raise OSError(f"Cannot open video: {path}")
            if not np.isclose(cap.get(cv2.CAP_PROP_FPS), self.fps, rtol=1e-3):
                cap.release()
                raise ValueError(f"Video fps differs from metadata: {path}")
            self._videos[path] = cap
        self._videos.move_to_end(path)
        while len(self._videos) > self.config.cache_videos:
            _, old = self._videos.popitem(last=False)
            old.release()
        cap = self._videos[path]
        if int(round(cap.get(cv2.CAP_PROP_POS_FRAMES))) != frame:
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame)
        ok, bgr = cap.read()
        if not ok:
            raise OSError(f"Cannot decode frame {frame}: {path}")
        h, w = self.config.image_size
        rgb = cv2.cvtColor(cv2.resize(bgr, (w, h), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
        return torch.from_numpy(np.ascontiguousarray(rgb.transpose(2, 0, 1)))[None]

    def __getitem__(self, index):
        if index < 0 or index >= len(self):
            raise IndexError(index)
        ep_index = bisect.bisect_right(self.ends, index)
        frame = index - (self.ends[ep_index - 1] if ep_index else 0)
        ep = self.episodes[ep_index]
        columns = self._episode(ep_index)
        cfg = self.config
        hist = frame + np.arange(1 - cfg.num_history_states, 1) * cfg.frame_stride
        future = frame + cfg.action_offset + np.arange(cfg.num_future_actions) * cfg.frame_stride
        hist_valid, future_valid = hist >= 0, future < ep["length"]
        hist = np.clip(hist, 0, ep["length"] - 1)
        future = np.clip(future, 0, ep["length"] - 1)
        state, state_mask = pack_states(columns["state_pose"][hist], columns["state_gripper"][hist], hist_valid)
        action, action_mask = pack_states(columns["action_pose"][future], columns["action_gripper"][future], future_valid)
        prompt = columns["prompt"][frame] if columns["prompt"] is not None else None
        if not isinstance(prompt, str) or not prompt.strip():
            prompt = self.tasks[int(columns["task_index"][frame])]
        images = [self._image(ep["episode_index"], key, frame) for key in cfg.camera_keys]
        h, w = cfg.image_size
        # These define normalized image coordinates. They are NOT calibration.
        image_coordinates = torch.tensor([[w / 2, 0., (w - 1) / 2],
                                          [0., h / 2, (h - 1) / 2], [0., 0., 1.]])
        return DataRawVLA(
            raw_vl=DataRawVL(K=image_coordinates.repeat(len(images), 1, 1), rgb=images,
                            pose=[torch.eye(4)[None] for _ in images], fps=self.fps, prompt=prompt),
            state=state, state_mask=state_mask, action=action, action_mask=action_mask,
            # Geometry-free placeholder; calibrated readers replace this with
            # camera poses in the same world frame as the decoded TCPs.
            action_ref_pose=torch.eye(4).repeat(2, 1, 1),
        )

    def close(self):
        for cap in self._videos.values():
            cap.release()
        self._videos.clear()
        self._episodes.clear()

    def __getstate__(self):
        state = dict(self.__dict__)
        state["_videos"] = OrderedDict()
        state["_episodes"] = OrderedDict()
        return state

