"""Concatenate whole original LeRobot sources with explicit per-source prompts.

The manifest selects roots and language only. Numeric rows, videos, calibration,
history and masked episode-tail handling use LeRobotOriginalDataset unchanged.
The checkpoint keeps the existing LeRobotOriginalConfig schema.
"""
import bisect
from dataclasses import replace
import hashlib
import json
from pathlib import Path

from torch.utils.data import Dataset

from .lerobot_original import LeRobotOriginalDataset


class LeRobotRawMultiDataset(Dataset):
    def __init__(self, config):
        config.validate()
        self.config = config
        manifest_path = Path(config.root).expanduser() / "raw_sources.json"
        payload = manifest_path.read_bytes()
        manifest = json.loads(payload)
        if manifest.get("format") != "lerobot_raw_sources_v1":
            raise ValueError("Unsupported raw source manifest format")
        sources = manifest.get("sources")
        if not isinstance(sources, list) or not sources:
            raise ValueError("Raw source manifest requires a nonempty sources list")
        self.raw_sources, self.readers, self.episodes, self.ends = [], {}, [], []
        fingerprint = hashlib.sha256(payload)
        roots, rates, total = set(), set(), 0
        try:
            for source in sources:
                name, instruction = source["name"], source["instruction"]
                if not isinstance(name, str) or not name.strip() or name in self.readers:
                    raise ValueError("Raw source names must be nonempty and unique")
                if not isinstance(instruction, str) or not instruction.strip():
                    raise ValueError("Every raw source requires an explicit nonempty instruction")
                root = Path(source["root"]).expanduser()
                root = (root if root.is_absolute() else manifest_path.parent / root).resolve()
                if root in roots:
                    raise ValueError("Duplicate raw source root (including symlink aliases)")
                roots.add(root)
                reader = LeRobotOriginalDataset(replace(config, root=str(root)))
                self.readers[name] = reader
                self.raw_sources.append(dict(name=name, root=str(root), instruction=instruction))
                self.episodes.extend((name, int(ep["episode_index"])) for ep in reader.episodes)
                rates.add(reader.fps)
                total += len(reader)
                self.ends.append(total)
                for filename in ("info.json", "episodes.jsonl", "tasks.jsonl"):
                    content = (root / "meta" / filename).read_bytes()
                    fingerprint.update(name.encode() + b"\0" + filename.encode() + b"\0")
                    fingerprint.update(hashlib.sha256(content).digest())
            if len(rates) != 1:
                raise ValueError("Raw sources must share a frame rate")
            self.fps = rates.pop()
            self.fingerprint = fingerprint.hexdigest()
        except BaseException:
            self.close()
            raise

    def __len__(self):
        return self.ends[-1]

    def __getitem__(self, index):
        if not 0 <= index < len(self):
            raise IndexError(index)
        block = bisect.bisect_right(self.ends, index)
        source = self.raw_sources[block]
        reader = self.readers[source["name"]]
        local = index - (self.ends[block - 1] if block else 0)
        ep = bisect.bisect_right(reader.ends, local)
        frame = local - (reader.ends[ep - 1] if ep else 0)
        sample = reader[local]
        sample.raw_vl.prompt = source["instruction"]
        sample._raw_metadata = dict(dataset_id=source["name"], source_root=source["root"],
            episode_index=int(reader.episodes[ep]["episode_index"]), frame=frame)
        return sample

    def require_geometry(self):
        for reader in self.readers.values():
            reader.require_geometry()

    def close(self):
        for reader in self.readers.values():
            reader.close()
