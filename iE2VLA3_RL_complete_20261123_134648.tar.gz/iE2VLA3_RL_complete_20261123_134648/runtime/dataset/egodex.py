import glob
import h5py
import torch
import random
import numpy as np
from typing import Optional, List
from torchvision.transforms import v2


from action.parser import ProprioData
from dataset._location import get_loc
from data_utils.transforms import BaseTransform
from data_utils.registry import mark_offline_test
from data_utils.data_raw import DataRawVL, DataRawVLA
from data_utils.dataset_base import DatasetBase, DataConfig
from data_utils.video_decode import decode_video_frames_torchcodec
from client import query_states, parse_batch_proprio


mappings = {
    0: "Hand", 

    1: "ThumbKnuckle",
    2: "ThumbIntermediateBase",
    3: "ThumbIntermediateTip",
    4: "ThumbTip",

    5: "IndexFingerKnuckle",
    6: "IndexFingerIntermediateBase",
    7: "IndexFingerIntermediateTip",
    8: "IndexFingerTip",

    9: "MiddleFingerKnuckle",
    10: "MiddleFingerIntermediateBase",
    11: "MiddleFingerIntermediateTip",
    12: "MiddleFingerTip",

    13: "RingFingerKnuckle",
    14: "RingFingerIntermediateBase",
    15: "RingFingerIntermediateTip",
    16: "RingFingerTip",

    17: "LittleFingerKnuckle",
    18: "LittleFingerIntermediateBase",
    19: "LittleFingerIntermediateTip",
    20: "LittleFingerTip",
}


@mark_offline_test()
class EgoDex(DatasetBase):

    record_dt = 1.0/30
    sample_dt = 1.0/15

    def __init__(
        self, 
        h5_filelist: List[str], 
        data_config: DataConfig, 
        transforms: Optional[BaseTransform] = None
    ):
        super().__init__()
        self.h5_filelist = h5_filelist
        self.data_config = data_config
        self.transforms = transforms

    @classmethod
    def read_prompt(cls, h5: h5py.File):
        instructions = []

        if 'llm_description' in h5.attrs:
            instruction = h5.attrs['llm_description']
            if isinstance(instruction, bytes):
                instruction = instruction.decode('utf-8')
            instructions.append(instruction)
        
        # Extract second description (if exists)
        if 'llm_description2' in h5.attrs:
            instruction2 = h5.attrs['llm_description2']
            if isinstance(instruction2, bytes):
                instruction2 = instruction2.decode('utf-8')
            instructions.append(instruction2)
        
        return instructions
    
    @classmethod
    def sample_low_dim(
        cls, 
        h5: h5py.File, 
        episode_len: int, 
        frame_index: int, 
        data_config: DataConfig, 
    ):
        
        head_pose: np.ndarray = h5["transforms"]["camera"][:]       # (T, 4, 4)
        left_pose: np.ndarray = h5["transforms"]["leftHand"][:]     # (T, 4, 4)
        right_pose: np.ndarray = h5["transforms"]["rightHand"][:]   # (T, 4, 4)

        left_fingers = []
        right_fingers = []
        for i in range(21):
            left_fingers.append(h5["transforms"]["left" + mappings[i]][:, :3, 3])       # (T, 3)
            right_fingers.append(h5["transforms"]["right" + mappings[i]][:, :3, 3])     # (T, 3)
        left_fingers = np.concatenate(left_fingers, axis=-1)    # (T, 20 * 3)
        right_fingers = np.concatenate(right_fingers, axis=-1)  # (T, 20 * 3)

        train_time = np.arange(episode_len).astype(np.float64) * cls.record_dt
        query_time = (np.arange(data_config.num_history_states + data_config.num_future_actions) - 
                      data_config.num_history_states + 1).astype(np.float64) * cls.sample_dt + frame_index * cls.record_dt
        query_time = query_time.clip(0, train_time[-1])

        # state_data, state_mask = parse_batch_proprio(
        #     {
        #         # "head": ProprioData(posemat=head_pose), 
        #         "left": ProprioData(posemat=left_pose, dexhand=left_fingers), 
        #         "right": ProprioData(posemat=right_pose, dexhand=right_fingers), 
        #     }
        # )
        
        # wrist pose only, no dexhand
        state_data, state_mask = parse_batch_proprio(
            {
                # "head": ProprioData(posemat=head_pose), 
                "left": ProprioData(posemat=left_pose), 
                "right": ProprioData(posemat=right_pose), 
            }
        )

        ee_names, all_states, all_masks = query_states(
            query_time=query_time, 
            state_time={k: train_time for k in state_data},
            state_data=state_data, 
            state_mask=state_mask
        )

        state, action = torch.split(torch.from_numpy(all_states).float(), 
                                    [data_config.num_history_states, data_config.num_future_actions], 
                                    dim=1)
        state_mask, action_mask = torch.split(torch.from_numpy(all_masks).bool(), 
                                              [data_config.num_history_states, data_config.num_future_actions], 
                                              dim=1)
        
        action_ref_pose = torch.from_numpy(head_pose[frame_index]).float()[None].expand(len(ee_names), 4, 4)

        return DataRawVLA(
            raw_vl=None, 
            state=state,
            state_mask=state_mask, 
            action=action, 
            action_mask=action_mask, 
            action_ref_pose=action_ref_pose
        )

    def __len__(self):
        return len(self.h5_filelist)
    
    def get_handler(self, episode_id):
        h5_file = self.h5_filelist[episode_id]
        video_file = h5_file.replace(".hdf5", ".mp4")
        h5 = h5py.File(h5_file, "r")
        episode_len = len(h5["transforms"]["camera"])
        return (h5, video_file), episode_len

    @classmethod
    def sample_vl(cls, h5: h5py.File, video_path: str, frame_index: int):
        # read images & language
        video_time = frame_index * cls.record_dt
        rgb = decode_video_frames_torchcodec(
            video_path=video_path, 
            timestamps=[video_time],
            tolerance_s=cls.record_dt,
        )[0]  # (C, H, W)

        H, W = rgb.shape[-2:]
        rgb = v2.Resize((H//3, W//3))(rgb)
        K: np.ndarray = h5["camera"]["intrinsic"][:] # (3, 3)
        K[:2] /= 3

        extr: np.ndarray = h5["transforms"]["camera"][frame_index]  # (4, 4)
        prompts = cls.read_prompt(h5)

        if len(prompts) == 0:
            prompt = None
        else:
            prompt = random.sample(prompts, k=1)[0]

        data_vl = DataRawVL(
            K=torch.from_numpy(K).float()[None],  # (Ncam=1, 3, 3)
            rgb=rgb[None, None],  # (Ncam=1, To=1, 3, H, W) 
            pose=torch.from_numpy(extr).float()[None, None],  # (Ncam=1, To=1, 4, 4)
            fps=1.0 / cls.sample_dt, 
            prompt=prompt
        )
        return data_vl

    def sample_episode(self, handler, episode_len: int, frame_index: int):
        h5, video_path = handler

        # read state & action
        data_vla = self.sample_low_dim(h5, episode_len, frame_index, self.data_config)

        if self.data_config.load_vl:
            data_vl = self.sample_vl(h5, video_path, frame_index)
            data_vla.raw_vl = data_vl

        if self.transforms is not None:
            data_vla = self.transforms(data_vla)
        
        return data_vla

    def close_handler(self, handler):
        h5, video_path = handler
        h5.close()
    
    @classmethod
    def inst(
        cls,
        data_config: DataConfig, 
        transforms: Optional[BaseTransform] = None
    ):
        pattern = get_loc(cls.__name__)
        h5_files = glob.glob(pattern, recursive=True)
        assert len(h5_files) > 0
        h5_files.sort()
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        return cls(h5_files, data_config, transforms)

