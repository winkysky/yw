import os
import sys
import json
import glob
import torch
import random
import inspect
import traceback
import numpy as np
from torch import Tensor
from typing import Dict, List, Optional

import data_utils.transforms as TF
from dataset._location import DSET, LOC, get_loc
from data_utils.dataset_base import DataConfig
from data_utils.registry import mark_offline_test
from .map_base import UniqueDataConfig, H5DatasetMapBase

"""
class Libero(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=None,
        sample_dt=1.0,
        ee_indices=(0,),
        camera_names=("agentview", "eye_in_hand"),
        ee_ref_cams={0: ("agentview", "eye_in_hand")}
    )

    @classmethod
    def inst(cls, task_suites: List[str], common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        if isinstance(task_suites, str):
            task_suites = [task_suites]
        
        h5_files = []
        for suite in task_suites:
            if suite == "spatial":
                h5_files.extend(glob.glob(LOC[DSET.LiberoSpatial], recursive=True))
            elif suite == "object":
                h5_files.extend(glob.glob(LOC[DSET.LiberoObject], recursive=True))
            elif suite == "goal":
                h5_files.extend(glob.glob(LOC[DSET.LiberoGoal], recursive=True))
            elif suite == "90":
                h5_files.extend(glob.glob(LOC[DSET.Libero90], recursive=True))
            elif suite == "10":
                h5_files.extend(glob.glob(LOC[DSET.Libero10], recursive=True))
            else:
                raise TypeError("Unknown task suite: {}".format(suite))
        
        # from IPython import embed; embed()
        
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)
    
    def modify_prompt(self, lang: str):
        # remove something like "LIVING ROOM SCENE6" in libero10 and libero90
        index = lang.find("SCENE")
        if index >= 0:
            lang = lang[index:]
            lang = " ".join(lang.split(" ")[1:])
        return lang
    
    def sample_from_hdf5(self, h5, latest = False, debug_sample_index = None):
        out = super().sample_from_hdf5(h5, latest, debug_sample_index)
        # out["prompt_text"] = self.modify_prompt(out["prompt_text"])
        out.raw_vl.prompt = self.modify_prompt(out.raw_vl.prompt)
        return out


@mark_offline_test()
class LiberoSpatial(Libero):
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        return super().inst(["spatial"], common_config, transforms)


@mark_offline_test()
class LiberoObject(Libero):
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        return super().inst(["object"], common_config, transforms)


@mark_offline_test()
class LiberoGoal(Libero):
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        return super().inst(["goal"], common_config, transforms)


@mark_offline_test()
class Libero10(Libero):
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        return super().inst(["10"], common_config, transforms)


@mark_offline_test()
class Libero90(Libero):
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        return super().inst(["90"], common_config, transforms)


@mark_offline_test()
class Maniskill(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=None,
        sample_dt=1.0,
        ee_indices=(0,),
        camera_names=("main_camera", "wrist_camera"),
        ee_ref_cams={0: ("main_camera", "wrist_camera")}
    )

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class MetaWorld(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=None,
        sample_dt=1.0,
        ee_indices=(0,),
        camera_names=("corner", "topview", "gripperPOV"),
        ee_ref_cams={0: ("corner", "topview", "gripperPOV")}
    )

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class Droid(H5DatasetMapBase):
    data_root = get_loc(__qualname__)

    unique_config = UniqueDataConfig(
        record_dt=1.0/15,
        sample_dt=1.0/15,
        ee_indices=(0,),
        camera_names=("exterior_2_left", "exterior_1_left", "wrist_left"),
        ee_ref_cams={0: ("exterior_2_left", "exterior_1_left", "wrist_left")}, 
        sample_state_gaps=2,
        video_root=data_root
    )

    @classmethod
    def filter_files(cls, filelist):
        filtered = []
        for f in filelist:
            # remove .h5 and episode_
            episode_index = int(os.path.split(f)[-1][:-3].replace("episode_", ""))
            if episode_index in [11907, 14419, 24440, 64837, 64871]:
                print("[INFO] in Droid dataset, remove file: {}".format(f))
            else:
                filtered.append(f)
        return filtered

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(os.path.join(cls.data_root, "data/*/*.h5"), recursive=True)
        h5_files = cls.filter_files(h5_files)
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()

        transforms = TF.Compose([
            TF.ForwardTcpOrigin("z", distance=0.15),
            transforms
        ])

        return cls(h5_files, common_config, transforms)
    
    def __getitem__(self, i):
        try:
            out = super().__getitem__(i)
        except Exception as e:
            # This occasionally fails when reading video files, I don't know why
            traceback.print_exc()
            with open("error_filelist.txt", "a") as fp:
                fp.write("Error in file reading: ")
                fp.write(self.h5_filelist[i] + "\n")
            print("[INFO] Retry another index")
            out = super().__getitem__((i+1)%len(self))
        
        return out


@mark_offline_test()
class PickPlaceCan(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=None,
        sample_dt=1.0,
        ee_indices=(0,),
        camera_names=("e2h_cam", "eih_cam"),
        ee_ref_cams={0: ("e2h_cam", "eih_cam")}
    )

    def enrich_prompt(self, lang: str):
        prompts = {
            "7up01": ["green can", "green bottle", "green soda"],
            "Coke01": ["red can", "red bottle", "red soda", "red Coca Cola"],
            "Pepsi01": ["blue can", "blue bottle", "blue soda", "blue Pepsi"],
            "Pepsi02": ["black can", "black bottle", "black soda", "black Pepsi"]
        }
        return random.sample(prompts[lang], k=1)[0]

    def sample_from_hdf5(self, h5, latest = False, debug_sample_index = None):
        out = super().sample_from_hdf5(h5, latest, debug_sample_index)
        if out.raw_vl is not None:
            template = "move the {} to the plate"
            out.raw_vl.prompt = template.format(self.enrich_prompt(out.raw_vl.prompt))
        return out

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class OpenDrawer(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=None,
        sample_dt=1.0,
        ee_indices=(0,),
        camera_names=("agent_camera",),
        ee_ref_cams={0: ("agent_camera",)}
    )

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class OpenOven(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=None,
        sample_dt=1.0,
        ee_indices=(0,),
        camera_names=("agent_camera",),
        ee_ref_cams={0: ("agent_camera",)}
    )

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class AgibotWorldAlpha(H5DatasetMapBase):
    
    data_root = get_loc(__qualname__)
    
    unique_config = UniqueDataConfig(
        record_dt=1.0/30,
        sample_dt=1.0/30,
        ee_indices=(1, 2),  # 0: head, 1: left, 2: right
        camera_names=("head_cam", "left_cam", "right_cam"),
        ee_ref_cams={1: ("head_cam", "left_cam"), 2: ("head_cam", "right_cam")}, 
        sample_state_gaps=3,
        video_root=data_root
    )

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        with open(f"{cls.data_root}/head_color_filelist.txt", "r") as fp:
            head_video_fname = [line.strip() for line in fp.readlines()]
        head_video_fname = [line for line in head_video_fname if len(line)]

        h5_root = f"{cls.data_root}/hdf5"
        h5_files = []
        for head_fname in head_video_fname:
            parts = head_fname.split("/")
            task_id = parts[1]  # 352
            episode_id = parts[3]  # 674501
            h5_files.append(os.path.join(h5_root, task_id, episode_id + ".h5"))
        # test file existence
        assert os.path.exists(h5_files[0]), f"{h5_files[0]} does not exist!"

        # remove file with short video length
        import numpy as np
        video_file_sizes = np.load(f"{cls.data_root}/video_sizes.npy")  # (num_f, 3), for 3 views
        video_file_sizes_MB = video_file_sizes / (1024.0 * 1024.0)
        valid_file_mask = np.all(video_file_sizes_MB > 0.01, axis=-1)  # (num_f,)

        assert len(valid_file_mask) == len(h5_files), f"{len(valid_file_mask)} vs {len(h5_files)}"
        h5_files = [f for i, f in enumerate(h5_files) if valid_file_mask[i]]

        assert len(h5_files) > 0
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))


        transforms = TF.Compose([
            TF.ForwardTcpOrigin("z", distance=0.08),
            transforms
        ])

        return cls(h5_files, common_config, transforms)

    def __getitem__(self, i):
        try:
            out = super().__getitem__(i)
        except Exception as e:
            traceback.print_exc()
            with open("error_filelist.txt", "a") as fp:
                fp.write("Error in file loading: ")
                fp.write(self.h5_filelist[i] + "\n")
            print("[INFO] Retry another index")
            out = super().__getitem__((i+1)%len(self))
        return out


@mark_offline_test()
class InternM1Franka(H5DatasetMapBase):
    data_root = get_loc(__qualname__)

    unique_config = UniqueDataConfig(
        record_dt=None,
        sample_dt=None,
        ee_indices=(0,),
        camera_names=("base_view", "base_view_2", "ego_view"),
        ee_ref_cams={0: ("base_view", "base_view_2", "ego_view")}, 
        sample_state_gaps=4,
        video_root=data_root
    )

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(os.path.join(cls.data_root, "**/*.h5"), recursive=True)
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()

        transforms = TF.Compose([
            TF.Resize((240, 320)),
            transforms
        ])

        return cls(h5_files, common_config, transforms)
    
    def __getitem__(self, i):
        try:
            out = super().__getitem__(i)
        except Exception as e:
            # This occasionally fails when reading video files, I don't know why
            traceback.print_exc()
            with open("error_filelist.txt", "a") as fp:
                fp.write("Error in file reading: ")
                fp.write(self.h5_filelist[i] + "\n")
            print("[INFO] Retry another index")
            out = super().__getitem__((i+1)%len(self))
        
        return out


@mark_offline_test()
class RoboTwin2(H5DatasetMapBase):
    
    data_root = get_loc(__qualname__)
    
    unique_config = UniqueDataConfig(
        record_dt=1.0/30,
        sample_dt=1.0/30,
        ee_indices=(0, 1),  # 0: left, 1: right
        # camera_names=("front_camera", "head_camera", "left_camera", "right_camera"),
        camera_names=("head_camera", "left_camera", "right_camera"),
        ee_ref_cams={0: ("head_camera", "left_camera"), 1: ("head_camera", "right_camera")}, 
        sample_state_gaps=2,
    )

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(os.path.join(cls.data_root, "*/*/data/*.h5"), recursive=True)
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)

    def modify_prompt(self, instruction_file_path: str):
        with open(os.path.join(self.data_root, instruction_file_path), "r") as f_instr:
            instruction_dict = json.load(f_instr)
        instructions = instruction_dict["seen"]
        instruction = np.random.choice(instructions)
        return instruction

    def sample_from_hdf5(self, h5, latest = False, debug_sample_index = None):
        out = super().sample_from_hdf5(h5, latest, debug_sample_index)
        out = TF.ForwardTcpOrigin("x", distance=0.13)(out)
        if out.raw_vl is not None:
            out.raw_vl.prompt = self.modify_prompt(out.raw_vl.prompt)
            out.raw_vl.pose = [torch.inverse(p) for p in out.raw_vl.pose]
        out.action_ref_pose = torch.inverse(out.action_ref_pose)
        return out

    def __getitem__(self, i):
        try:
            out = super().__getitem__(i)
        except Exception as e:
            # This occasionally fails when reading video files, I don't know why
            traceback.print_exc()
            with open("error_filelist.txt", "a") as fp:
                fp.write("Error in file reading: ")
                fp.write(self.h5_filelist[i] + "\n")
            print("[INFO] Retry another index")
            out = super().__getitem__((i+1)%len(self))
        
        return out


@mark_offline_test()
class AlohaPickPlace0905(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=1.0/10,
        sample_dt=1.0/10,
        ee_indices=(0,),  # right arm
        camera_names=("head_cam", "rh_cam"),
        ee_ref_cams={0: ("head_cam", "rh_cam")}, 
        sample_state_gaps=2
    )
    
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class AlohaTableStorage0905(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=1.0/10,
        sample_dt=1.0/10,
        ee_indices=(0,),  # right arm
        camera_names=("head_cam", "rh_cam"),
        ee_ref_cams={0: ("head_cam", "rh_cam")}, 
        sample_state_gaps=2
    )
    
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class AlohaPickPlace1031(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=1.0/10,
        sample_dt=1.0/10,
        ee_indices=(0,),  # right arm
        camera_names=("head_cam", "rh_cam"),
        ee_ref_cams={0: ("head_cam", "rh_cam")}, 
        sample_state_gaps=2
    )
    
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class AlohaPickPlace1111(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=1.0/10,
        sample_dt=1.0/10,
        ee_indices=(0,),  # right arm
        camera_names=("head_cam", "rh_cam"),
        ee_ref_cams={0: ("head_cam", "rh_cam")}, 
        sample_state_gaps=2
    )
    
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class AlohaFridge1108(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=1.0/10,
        sample_dt=1.0/10,
        ee_indices=(0,),  # right arm
        camera_names=("head_cam", "rh_cam"),
        ee_ref_cams={0: ("head_cam", "rh_cam")}, 
        sample_state_gaps=2
    )
    
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class AlohaMakeTea(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=1.0/10,
        sample_dt=1.0/10,
        ee_indices=(0, 1),
        camera_names=("head_cam", "lh_cam", "rh_cam"),
        ee_ref_cams={0: ("head_cam", "lh_cam"), 1: ("head_cam", "rh_cam")}, 
        sample_state_gaps=2
    )
    
    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class FrankaOpenMicrowave1120(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
        record_dt=0.02,
        sample_dt=0.02,
        ee_indices=(0,),
        camera_names=("external_cam", "wrist_cam"),
        ee_ref_cams={0: ("external_cam", "wrist_cam")},
    )

    def normalize_gripper_(self, x: Tensor):
        gripper = x[..., 6]  # original from -1 (close) to 1 (open)
        gripper = (gripper + 1) / 2.0  # we normalize it to 0 ~ 1
        x[..., 6] = gripper
        return x

    def sample_from_hdf5(self, h5, latest = False, debug_sample_index = None):
        out = super().sample_from_hdf5(h5, latest, debug_sample_index)
        self.normalize_gripper_(out.state)
        self.normalize_gripper_(out.action)
        return out

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob(get_loc(cls))
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)


@mark_offline_test()
class FrankaOpenMicrowave1120Dagger(FrankaOpenMicrowave1120):
    pass
"""

@mark_offline_test()
class TakeLabelOut(H5DatasetMapBase):
    unique_config = UniqueDataConfig(
    # config = DataConfig(
        record_dt=0.1,
        sample_dt=0.1,
        # output_image_hw=(256, 256),
        ee_indices=(0,),
        camera_names=("external_cam", "wrist_cam"),
        ee_ref_cams={0: ("external_cam", "wrist_cam")},
        shuffle_cameras=False
    )

    @classmethod
    def inst(cls, common_config: DataConfig, transforms: Optional[TF.BaseTransform]):
        h5_files = glob.glob("/home/hq/code/vla_datasets/e2vla_transitions/take_label_out/2026-06-05_18-07-48_org/*.hdf5")
        h5_files += glob.glob("/home/hq/code/vla_datasets/e2vla_transitions/take_label_out/2026-06-05_19-01-23_org/*.hdf5")
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(h5_files)))
        assert len(h5_files) > 0
        h5_files.sort()
        return cls(h5_files, common_config, transforms)
    
    def __getitem__(self, i):
        out = super().__getitem__(i)
        out["prompt_text"] = "Take the label out of the phone box"
        return out



# def get_subclasses(base_class):
#     current_module = sys.modules[__name__]
#     subclasses = []
#     for name, obj in inspect.getmembers(current_module, inspect.isclass):
#         if issubclass(obj, base_class) and obj is not base_class:
#             subclasses.append(obj)
#     return subclasses


# DATA_CONFIGS: Dict[str, UniqueDataConfig] = {
#     c.__name__: c.unique_config for c in get_subclasses(H5DatasetMapBase)
# }



if __name__ == "__main__":

    import torch
    from torch.utils.data import DataLoader
    dataset = LiberoSpatial.inst()
    dataloader = DataLoader(dataset, batch_size=4, shuffle=False)

    for data in dataloader:
        print("-"*61)
        for k, v in data.items():
            if isinstance(v, torch.Tensor):
                print("  - {}: {}".format(k, v.shape))
            else:
                print("  - {}: {}".format(k, v))
        
        input("[INFO] Press Enter to continue: ")

