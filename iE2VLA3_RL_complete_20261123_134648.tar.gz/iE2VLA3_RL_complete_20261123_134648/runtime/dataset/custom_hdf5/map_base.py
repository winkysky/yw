import h5py
import torch
import random
import numpy as np
from dataclasses import dataclass
from scipy.spatial.transform import Rotation
from typing import List, Dict, Tuple, Optional

from action.define import ACTION_SPACE_SIZE
from data_utils.dataset_base import DatasetBase, DataConfig
from data_utils.tokenize import DataRawVL, DataRawVLA
from data_utils.transforms import BaseTransform
from data_utils import align
from . import h5io


def infer_record_dt(t: np.ndarray, default: float = 1.0):
    if len(t) < 2:
        return default
    else:
        return (t[-1] - t[0]) / (len(t) - 1)


def find_closest_ind(train: np.ndarray, query: np.ndarray):
    bin_indices = np.digitize(query, train)
    sample_indices = []
    
    # query < train
    mask = (bin_indices == 0)
    if np.any(mask):
        sample_indices.append(np.array([0]*mask.sum(), dtype=bin_indices.dtype))
    
    # query in train
    mask = (bin_indices > 0) & (bin_indices < len(train))
    r_ind = bin_indices[mask]
    l_ind = r_ind - 1
    
    dist0 = np.abs(train[l_ind] - query[mask])
    dist1 = np.abs(train[r_ind] - query[mask])
    sample_indices.append(np.where(dist0 < dist1, l_ind, r_ind))

    # query > train
    mask = (bin_indices == len(train))
    if np.any(mask):
        sample_indices.append(np.array([len(train)-1]*mask.sum(), dtype=bin_indices.dtype))
    
    sample_indices = np.concatenate(sample_indices)
    return sample_indices


def make_state(pose: np.ndarray, gripper: Optional[np.ndarray], D: int):
    """
    Args:
        pose: (Nee, T, 4, 4)
        gripper: (Nee, T)
    """
    Nee, T = pose.shape[:2]
    x = np.zeros((Nee, T, D), dtype=np.float32)
    mask = np.zeros((Nee, T, D), dtype=bool)

    t3 = pose[:, :, :3, 3]
    r3 = pose[:, :, :2, :3].reshape(Nee, T, 6)

    x[:, :, 0:3] = t3
    x[:, :, 3:9] = r3
    mask[:, :, :9] = True
    
    if gripper is not None:
        g1 = gripper[:, :, None]
        x[:, :, 9:10] = g1
        mask[:, :, 9:10] = True
    
    return x, mask


class DataSampler(object):
    @classmethod
    def sample_framedict(
        cls,
        obs_traj: List[Dict[str, np.ndarray]], 
        ee_indices: List[int], 
        camera_names: List[str], 
        ee_ref_cams: Optional[Dict[str, Tuple[str]]], 
        num_history_cameras: int, 
        num_history_states: int, 
        num_future_states: int, 
        state_dim: int, 
        action_dim: int, 
        latest: bool = False, 
        sample_state_gaps: int = 1,
        sample_camera_gaps: int = 1, 
        sample_dt: float = 1.0,
        record_dt: Optional[float] = None, 
    ):
        """
        obs_traj is a list of dict containing necessary keys listed as followings.
        - ee_pose: np.ndarray of shape (4, 4) or (nee, 4, 4), ^{world}_{ee} T
        - gripper: float or np.ndarray of shape (nee,), value from [0 (close), 1 (open)]
        - timestamp: float, current timestamp
        - CAMERA_NAME_0: 
            - model: pinhole
            - camera:
                - width: int
                - height: int
                - K: np.ndarray of shape (3, 3) or (9,)
            - data:
                - color: np.ndarray, shape=(H, W, C)
                - seg: None | np.ndarray of shape (H, W) | isaacsim seg output
                - wcT: np.ndarray of shape (4, 4), ^{world}_{cam} T
        
        - CAMERA_NAME_1: similar as CAMERA_NAME_0
            - model: pinhole
            - ...
        """
        if not latest:
            last_obs_index = np.random.choice(len(obs_traj), 1)[0]
        else:
            last_obs_index = len(obs_traj) - 1

        all_timestamps = np.array([tau["timestamp"] for tau in obs_traj]).astype(np.float64)
        if record_dt is not None:
            # all_timestamps_calibrated = all_timestamps[-1] - np.arange(len(all_timestamps))[::-1] * record_dt
            all_timestamps_calibrated = all_timestamps
        else:
            all_timestamps_calibrated = all_timestamps
            record_dt = infer_record_dt(all_timestamps, default=sample_dt)
        
        if sample_dt is None:
            sample_dt = record_dt
        
        # we don't interpolate the images, but find the image with closest timestamp
        current_time = all_timestamps_calibrated[last_obs_index]
        prev_obs_sample_time = current_time + np.arange(-num_history_cameras+1, 1) * sample_camera_gaps * sample_dt
        prev_obs_sample_ind = find_closest_ind(all_timestamps_calibrated, prev_obs_sample_time)

        obs_across_cams: Dict[str, list] = {}  # property_name -> list[property], list len = num_cameras
        for cam_name in camera_names:
            obs_cam = h5io.gather_frames(obs_traj, cam_name, prev_obs_sample_ind, compress=False)
            for k, v in obs_cam.items():
                if k not in obs_across_cams:
                    obs_across_cams[k] = []
                obs_across_cams[k].append(v)

        K = np.stack(obs_across_cams["K"], axis=0)  # (ncam, 3, 3)
        rgbs: List[np.ndarray] = obs_across_cams["rgb"]               # list len = ncam, [(To, 3, H, W)]
        cam_poses: List[np.ndarray] = obs_across_cams["pose"]         # list len = ncam, [(To, 4, 4)]

        # interpolate the robot states
        all_ee_poses = np.stack([tau["ee_pose"] for tau in obs_traj], axis=0)  # (L, nee, 4, 4)
        all_grippers = np.array([tau["gripper"] for tau in obs_traj])  # (L, nee)
        all_states = {"ee_pose": all_ee_poses, "gripper": all_grippers}
        interp_funcs = {"ee_pose": align.interp_SE3_sep, "gripper": align.interp_linear}
        
        history_time = current_time + np.arange(-num_history_states+1, 1) * sample_state_gaps * sample_dt
        future_time = current_time + np.arange(1, num_future_states+1) * sample_state_gaps * sample_dt

        history_queries = align.align_data(
            query_time=history_time,
            train_time=all_timestamps_calibrated,
            train_data=all_states,
            interp_funcs=interp_funcs
        )
        history_ee_pose = history_queries["ee_pose"]  # (Ts, nee, 4, 4)
        history_gripper = history_queries["gripper"]  # (Ts, nee)

        future_queries = align.align_data(
            query_time=future_time,
            train_time=all_timestamps_calibrated,
            train_data=all_states,
            interp_funcs=interp_funcs,
        )
        future_ee_pose = future_queries["ee_pose"]  # (Ta, nee, 4, 4)
        future_gripper = future_queries["gripper"]  # (Ta, nee)

        # previous data has only one ee, therefore we preserve this for compatility
        if history_ee_pose.ndim == 3:
            history_ee_pose = history_ee_pose[:, None]  # (To, 4, 4) -> (To, Nee=1, 4, 4)
        if history_gripper.ndim == 1:
            history_gripper = history_gripper[:, None]  # (To,) -> (To, Nee=1)
        if future_ee_pose.ndim == 3:
            future_ee_pose = future_ee_pose[:, None]  # (To, 4, 4) -> (To, Nee=1, 4, 4)
        if future_gripper.ndim == 1:
            future_gripper = future_gripper[:, None]  # (To,) -> (To, Nee=1)

        # select ee by indices
        assert isinstance(ee_indices, (list, tuple))
        history_ee_pose = history_ee_pose.take(ee_indices, axis=1)
        history_gripper = history_gripper.take(ee_indices, axis=1)
        future_ee_pose = future_ee_pose.take(ee_indices, axis=1)
        future_gripper = future_gripper.take(ee_indices, axis=1)
        
        # read reference camera frame to express action
        action_ref_pose = cam_poses[0][-1:].copy().repeat(len(ee_indices), 0)  # (nee, 4, 4)
        if ee_indices is not None:
            for i, ee_ind in enumerate(ee_indices):
                candidate_cam_names = ee_ref_cams[ee_ind]
                if isinstance(candidate_cam_names, str):
                    sel_cam_name = candidate_cam_names
                else:
                    sel_cam_name = random.sample(candidate_cam_names, k=1)[0]
                sel_cam_idx = camera_names.index(sel_cam_name)
                action_ref_pose[i] = cam_poses[sel_cam_idx][-1]
        
        state, state_mask = make_state(history_ee_pose.swapaxes(0, 1), history_gripper.swapaxes(0, 1), state_dim)
        action, action_mask = make_state(future_ee_pose.swapaxes(0, 1), future_gripper.swapaxes(0, 1), action_dim)
        
        data = DataRawVLA(
            raw_vl=DataRawVL(
                K=torch.from_numpy(K).float(),                          # (ncam, 3, 3)
                rgb=[torch.from_numpy(rgb) for rgb in rgbs],            # [(To, 3, H, W)]
                pose=[torch.from_numpy(p).float() for p in cam_poses],  # [(To, 4, 4)]
                fps=1.0/(sample_camera_gaps * sample_dt),
                prompt=None
            ),
            state=torch.from_numpy(state).float(),      # (nee, Ts, state_dim)
            state_mask=torch.from_numpy(state_mask),    # (nee, Ts, state_dim)
            action=torch.from_numpy(action).float(),    # (nee, Ta, action_dim)
            action_mask=torch.from_numpy(action_mask),  # (nee, Ta, action_dim)
        )
        return data

    @classmethod
    def sample_hdf5(
        cls,
        obs_traj: h5py.File, 
        default_ee_indices: List[int], 
        camera_names: List[str], 
        ee_ref_cams: Optional[Dict[str, Tuple[str]]], 
        num_history_cameras: int, 
        num_history_states: int, 
        num_future_states: int, 
        action_dim: int, 
        state_dim: int, 
        latest: bool = False, 
        sample_state_gaps: int = 1,
        sample_camera_gaps: int = 1,
        sample_dt: float = 1.0,
        record_dt: Optional[float] = None, 
        video_root: Optional[str] = None,
        debug_sample_index: Optional[int] = None, 
        load_vl: bool = True
    ):
        """
        obs_traj is a tree-like data structure
        - ee_pose: np.ndarray of shape (T, nee, 4, 4)
        - gripper: np.ndarray of shape (T, nee)
        - ee_pose_desired (optional): np.ndarray of shape (T, nee, 4, 4)
        - gripper_desired (optional): np.ndarray of shape (T, nee)
        - timestamp: np.ndarray of shape (T,)
        - CAMERA_NAME_0:
            - rgb: np.ndarray of shape (T, 3, H, W) or list of bytes (jpeg encoding)
            - pose: np.ndarray of shape (T, 4, 4)
            - K: np.ndarray of shape (3, 3), camera intrinsic
        - CAMERA_NAME_1:
            - rgb: np.ndarray of shape (T, 3, H, W) or list of vlen
            - ...
        """
        obs_traj_len = obs_traj["ee_pose"].len()
        if debug_sample_index is not None:
            # print("[INFO] Debug sample index set, overwrite")
            last_obs_index = debug_sample_index
        elif not latest:
            last_obs_index = np.random.choice(obs_traj_len, 1)[0]
        else:
            last_obs_index = obs_traj_len - 1

        all_timestamps = obs_traj["timestamp"][:].astype(np.float64)  # (L,)
        if record_dt is not None:
            all_timestamps_calibrated = np.arange(len(all_timestamps)) * record_dt
        else:
            all_timestamps_calibrated = all_timestamps
            record_dt = infer_record_dt(all_timestamps, default=sample_dt)
        
        if sample_dt is None:
            sample_dt = record_dt

        # we don't interpolate the images, but find the image with closest timestamp
        current_time = all_timestamps_calibrated[last_obs_index]
        prev_obs_sample_time = current_time + np.arange(-num_history_cameras+1, 1) * sample_camera_gaps * sample_dt
        prev_obs_sample_ind = find_closest_ind(all_timestamps_calibrated, prev_obs_sample_time)

        obs_across_cams: Dict[str, list] = {}  # 
        for cam_name in camera_names:
            obs_cam = h5io.slice_encoded_frames(
                obs_traj[cam_name], 
                prev_obs_sample_ind,
                timestamp=all_timestamps,  # use original timestamp to iter video file
                video_root=video_root,
                load_pixels=load_vl
            )
            for k, v in obs_cam.items():
                if k not in obs_across_cams:
                    obs_across_cams[k] = []
                obs_across_cams[k].append(v)
        
        K = np.stack(obs_across_cams["K"], axis=0)  # (ncam, 3, 3)
        rgbs: List[np.ndarray] = obs_across_cams["rgb"] if load_vl else []  # list len = ncam, [(To, 3, H, W)]
        cam_poses: List[np.ndarray] = obs_across_cams["pose"]               # list len = ncam, [(To, 4, 4)]
        # K: (ncam, 3, 3); rgbs: (T, ncam, 3, H, W); masks: (T, ncam, H, W)

        # interpolate the robot states
        all_states = {
            "ee_pose": obs_traj["ee_pose"][:],  # (L, 4, 4)
            "gripper": obs_traj["gripper"][:],  # (L,)
        }

        interp_funcs = {
            "ee_pose": align.interp_SE3_sep, 
            "gripper": align.interp_linear
        }

        history_time = current_time + np.arange(-num_history_states+1, 1) * sample_state_gaps * sample_dt
        future_time = current_time + np.arange(1, num_future_states+1) * sample_state_gaps * sample_dt
        future_desired_time = current_time + np.arange(num_future_states) * sample_state_gaps * sample_dt
        # since desired has been given, this is one step behind future_time

        history_queries = align.align_data(
            query_time=history_time,
            train_time=all_timestamps_calibrated,
            train_data=all_states,
            interp_funcs=interp_funcs
        )
        history_ee_pose = history_queries["ee_pose"]  # (Ts, nee, 4, 4)
        history_gripper = history_queries["gripper"]  # (Ts, nee)
                
        if "gripper_desired" in obs_traj.keys():
            future_gripper = align.align_data(
                query_time=future_desired_time,
                train_time=all_timestamps_calibrated,
                train_data={"gripper": obs_traj["gripper_desired"][:]},
                interp_funcs={"gripper": align.interp_linear}
            )["gripper"]  # (L, nee)
        else:
            future_gripper = align.align_data(
                query_time=future_time,
                train_time=all_timestamps_calibrated,
                train_data={"gripper": all_states["gripper"]},
                interp_funcs={"gripper": align.interp_linear}
            )["gripper"]  # (L, nee)
        
        if "ee_pose_desired" in obs_traj.keys():
            future_ee_pose = align.align_data(
                query_time=future_desired_time,
                train_time=all_timestamps_calibrated,
                train_data={"ee_pose": obs_traj["ee_pose_desired"][:]},
                interp_funcs={"ee_pose": align.interp_SE3_sep}
            )["ee_pose"]  # (L, nee, 4, 4)
        else:
            future_ee_pose = align.align_data(
                query_time=future_time,
                train_time=all_timestamps_calibrated,
                train_data={"ee_pose": all_states["ee_pose"]},
                interp_funcs={"ee_pose": align.interp_SE3_sep}
            )["ee_pose"]  # (L, nee, 4, 4)
        
        # previous data has only one ee, therefore we preserve this for compatility
        if history_ee_pose.ndim == 3:
            history_ee_pose = history_ee_pose[:, None]  # (To, 4, 4) -> (To, Nee=1, 4, 4)
        if history_gripper.ndim == 1:
            history_gripper = history_gripper[:, None]  # (To,) -> (To, Nee=1)
        if future_ee_pose.ndim == 3:
            future_ee_pose = future_ee_pose[:, None]  # (To, 4, 4) -> (To, Nee=1, 4, 4)
        if future_gripper.ndim == 1:
            future_gripper = future_gripper[:, None]  # (To,) -> (To, Nee=1)
        
        # select ee by indices
        if "ee_indices" in obs_traj.attrs:
            # this overwrite the config's ee_indices by h5 data's ee_indices
            # allow sample specific enabling/disabling which ee pose to predict
            ee_indices = obs_traj.attrs["ee_indices"]
            assert len(ee_indices) <= len(default_ee_indices), (
                "sample use ee_indices = {}, while default_ee_indices = {}".format(
                    ee_indices, default_ee_indices
                )
            )
        else:
            ee_indices = default_ee_indices
        
        assert isinstance(ee_indices, (list, tuple, np.ndarray))
        history_ee_pose = history_ee_pose.take(ee_indices, axis=1)
        history_gripper = history_gripper.take(ee_indices, axis=1)
        future_ee_pose = future_ee_pose.take(ee_indices, axis=1)
        future_gripper = future_gripper.take(ee_indices, axis=1)
        
        if obs_traj.attrs.get("is_bgr", False):
            # revert bgr to rgb
            rgbs = [np.ascontiguousarray(np.flip(img, axis=-3)) for img in rgbs]
        
        # read reference camera frame to express action
        action_ref_pose = cam_poses[0][-1:].copy().repeat(len(ee_indices), 0)  # (nee, 4, 4)
        if ee_indices is not None:
            for i, ee_ind in enumerate(ee_indices):
                candidate_cam_names = ee_ref_cams[ee_ind]
                if isinstance(candidate_cam_names, str):
                    sel_cam_name = candidate_cam_names
                else:
                    sel_cam_name = random.sample(candidate_cam_names, k=1)[0]
                sel_cam_idx = camera_names.index(sel_cam_name)
                action_ref_pose[i] = cam_poses[sel_cam_idx][-1]
        
        state, state_mask = make_state(history_ee_pose.swapaxes(0, 1), history_gripper.swapaxes(0, 1), state_dim)
        action, action_mask = make_state(future_ee_pose.swapaxes(0, 1), future_gripper.swapaxes(0, 1), action_dim)
        
        # read subtask
        if "subtask_description" in obs_traj.keys():
            bin_ind = np.digitize(last_obs_index, obs_traj["subtask_start_index"]) - 1
            bin_ind = np.clip(bin_ind, None, len(obs_traj["subtask_description"]) - 1)

            if bin_ind < 0:
                description = ""
            else:
                description = obs_traj["subtask_description"][bin_ind]
                if isinstance(description, bytes):
                    description = description.decode("utf-8")
        else:
            description = ""
        
        data = DataRawVLA(
            raw_vl=DataRawVL(
                K=torch.from_numpy(K).float(),                          # (ncam, 3, 3)
                rgb=[torch.from_numpy(rgb) for rgb in rgbs],            # [(To, 3, H, W)]
                pose=[torch.from_numpy(p).float() for p in cam_poses],  # [(To, 4, 4)]
                fps=1.0/(sample_camera_gaps * sample_dt),
                prompt=None,
            ) if load_vl else None,
            state=torch.from_numpy(state).float(),      # (nee, Ts, state_dim)
            state_mask=torch.from_numpy(state_mask),    # (nee, Ts, state_dim)
            action=torch.from_numpy(action).float(),    # (nee, Ta, action_dim)
            action_mask=torch.from_numpy(action_mask),  # (nee, Ta, action_dim)
            action_ref_pose=torch.from_numpy(action_ref_pose).float(),  # (nee, 4, 4)
        )
        return data, description


@dataclass
class UniqueDataConfig(object):
    ### total traj time of gt future action is `sample_dt * num_future_states`
    sample_dt: float
    ### if None, inferenced from `timestamp` key from data, otherwise overwrite the data
    record_dt: Optional[float]

    ### used in training and real-world execution
    ee_indices: Tuple[int]
    ee_ref_cams: Optional[Dict[int, Tuple[str]]]  # which camera is chosen to express the action of ee
    camera_names: Tuple[str]

    sample_state_gaps: int = 1
    sample_camera_gaps: int = 4
    num_history_cameras: int = 1

    video_root: Optional[str] = None  # for those rgb key as string, which means load video from video_root/rgb
    shuffle_cameras: bool = True


class H5DatasetMapBase(DatasetBase):

    unique_config = UniqueDataConfig(
        sample_dt=1.0,
        record_dt=None,
        ee_indices=(),
        camera_names=(),
        ee_ref_cams=None,
    )

    def __init__(
        self, 
        h5_filelist: List[str], 
        common_config: DataConfig,
        transforms: Optional[BaseTransform]
    ):
        super().__init__()
        self.h5_filelist = h5_filelist
        self.data_sampler = DataSampler()
        self.common_config = common_config
        self.transforms = transforms

        if isinstance(self.unique_config.camera_names, str):
            # wrap to tuple
            self.unique_config.camera_names = (self.unique_config.camera_names,)
        
        if isinstance(self.unique_config.ee_indices, int):
            # wrap to tuple
            self.unique_config.ee_indices = (self.unique_config.ee_indices,)
    
    @classmethod
    def inst(cls, *, common_config: DataConfig, transforms: Optional[BaseTransform]) -> "H5DatasetMapBase":
        raise NotImplementedError

    def __len__(self):
        return len(self.h5_filelist)
    
    def sample_from_hdf5(
        self, 
        h5: h5py.File, 
        latest: bool = False, 
        debug_sample_index: Optional[int] = None
    ):
        prompt_candidates = []
        for k, v in h5.attrs.items():
            if "prompt_text" in k:
                v = v.strip()
                if len(v):
                    prompt_candidates.append(v)
        
        prompt_text = random.sample(prompt_candidates, 1)[0] if len(prompt_candidates) else ""
        # if len(prompt_text) == 0:
        #     prompt_text = "Do any possible actions"

        if self.unique_config.shuffle_cameras:
            camera_names = list(self.unique_config.camera_names).copy()
            random.shuffle(camera_names)
        else:
            camera_names = self.unique_config.camera_names

        (
            data_sample_raw, sub_task_description
        ) = self.data_sampler.sample_hdf5(
            obs_traj=h5, 
            default_ee_indices=self.unique_config.ee_indices,
            camera_names=camera_names, 
            ee_ref_cams=self.unique_config.ee_ref_cams, 
            num_history_cameras=self.unique_config.num_history_cameras, 
            num_history_states=self.common_config.num_history_states, 
            num_future_states=self.common_config.num_future_actions,
            action_dim=ACTION_SPACE_SIZE,
            state_dim=ACTION_SPACE_SIZE, 
            latest=latest, 
            sample_state_gaps=self.unique_config.sample_state_gaps, 
            sample_camera_gaps=self.unique_config.sample_camera_gaps, 
            sample_dt=self.unique_config.sample_dt,
            record_dt=self.unique_config.record_dt, 
            video_root=self.unique_config.video_root,
            debug_sample_index=debug_sample_index,
            load_vl=self.common_config.load_vl, 
        )

        # join prompt_text and sub_task_description
        if len(prompt_text) and not prompt_text.endswith("."):
            join_str = ". "
        else:
            join_str = " "
        if len(sub_task_description):
            prompt_text = prompt_text + join_str + sub_task_description
        
        if data_sample_raw.raw_vl is not None:
            data_sample_raw.raw_vl.prompt = prompt_text
        return data_sample_raw
    
    def get_handler(self, episode_id):
        h5_file = self.h5_filelist[episode_id]
        h5 = h5py.File(h5_file, "r")
        L = h5["ee_pose"].len()
        return h5, L
    
    def close_handler(self, h5: h5py.File):
        h5.close()

    def sample_episode(self, handler, episode_len, frame_index):
        data_sample_raw = self.sample_from_hdf5(handler, latest=False, debug_sample_index=frame_index)
        if self.transforms is None:
            data_sample = data_sample_raw
        else:
            data_sample = self.transforms(data_sample_raw)
        return data_sample

