"""Data-only LeRobot adapter for the unchanged m0512_fm VLA.

The original cRoPE consumes calibrated camera/arm poses in one common frame.
Geometry is supplied here; no model modules or positional encodings are changed.
"""

from dataclasses import dataclass, replace
import json
from pathlib import Path

import numpy as np
import torch

from action.parser import ProprioParser
from data_utils.tokenize import collate_fn, tokenize_raw_vla
from .lerobot_dual import LeRobotDualConfig, LeRobotDualDataset


def validate_transform(value, name):
    matrix = np.asarray(value, dtype=np.float64)
    if matrix.shape != (4, 4) or not np.isfinite(matrix).all():
        raise ValueError(f"{name} must be a finite 4x4 transform in metres")
    rotation = matrix[:3, :3]
    if (not np.allclose(matrix[3], [0, 0, 0, 1])
            or not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-4)
            or not np.isclose(np.linalg.det(rotation), 1., atol=1e-4)):
        raise ValueError(f"{name} must be an SE(3) transform")


@dataclass
class LeRobotOriginalConfig(LeRobotDualConfig):
    # Camera K is specified at each camera's image_size, before loader resizing.
    # pose = ^parent T_camera, translation in metres. Parent can be world or
    # left/right_tcp/flange. base_to_world maps the recorded arm bases to world.
    geometry: dict | None = None

    @classmethod
    def load(cls, path, geometry_config=None, **overrides):
        values = json.loads(Path(path).read_text())
        values.update({key: value for key, value in overrides.items() if value is not None})
        if geometry_config is not None:
            calibration = json.loads(Path(geometry_config).read_text())
            required = {"base_to_world", "geometry"}
            if (not required.issubset(calibration) or not isinstance(calibration["geometry"], dict)
                    or set(calibration) - (required | {"pose_to_tcp"})):
                raise ValueError("Geometry file requires base_to_world and geometry; optional pose_to_tcp")
            values.update(calibration)
        if values.get("geometry") is not None and "base_to_world" not in values:
            raise ValueError("Calibrated data must explicitly specify both base_to_world transforms")
        result = cls(**values)
        result.validate()
        return result

    def validate(self):
        super().validate()
        if self.geometry is None:
            return
        cameras = self.geometry.get("cameras", {})
        if set(cameras) != set(self.camera_keys):
            raise ValueError("geometry.cameras must match camera_keys exactly")
        refs = self.geometry.get("action_reference_cameras", [])
        if len(refs) != 2 or any(key not in cameras for key in refs):
            raise ValueError("Set action_reference_cameras to two camera keys, left then right")
        for key, camera in cameras.items():
            k = np.asarray(camera.get("K"), dtype=np.float64)
            if (k.shape != (3, 3) or not np.isfinite(k).all() or k[0, 0] <= 0 or k[1, 1] <= 0
                    or not np.allclose(k[2], [0, 0, 1]) or k[0, 1] != 0 or k[1, 0] != 0):
                raise ValueError(f"{key}.K must be a finite pinhole intrinsic matrix without skew")
            size = camera.get("image_size", [])
            if len(size) != 2 or any(not isinstance(x, int) or x <= 0 for x in size):
                raise ValueError(f"{key}.image_size must be [height, width] at K's resolution")
            if camera.get("parent") not in {"world", "left_tcp", "right_tcp", "left_flange", "right_flange"}:
                raise ValueError(f"Unknown parent frame for {key}")
            validate_transform(camera.get("pose"), f"{key}.pose")


class LeRobotOriginalDataset(LeRobotDualDataset):
    """Reuse numeric/video I/O, then supply the original geometric input fields."""

    def require_geometry(self):
        if self.config.geometry is None:
            raise ValueError(
                "Original VLA keeps cRoPE enabled: configure geometry (camera K/poses, "
                "action_reference_cameras) and explicit base_to_world in --data-config. "
                "The current dataset has no common-frame calibration. --check-data can "
                "inspect its numeric/video fields without calibration; training cannot "
                "silently treat identity placeholders as measured poses.")

    def __getitem__(self, index):
        sample = super().__getitem__(index)
        if self.config.geometry is None:
            # Only used by --check-data; the strict collator rejects this marker.
            sample._original_geometry_ready = False
            return sample
        return apply_geometry(sample, self.config)


def apply_geometry(sample, cfg):
    """Attach checkpoint camera geometry to TCP states already in the common world."""
    tcp = ProprioParser(sample.state[:, -1]).posemat
    poses, intrinsics = [], []
    for key in cfg.camera_keys:
        camera = cfg.geometry["cameras"][key]
        parent = camera["parent"]
        parent_pose = torch.eye(4)
        if parent != "world":
            arm = 0 if parent.startswith("left_") else 1
            parent_pose = tcp[arm]
            if parent.endswith("_flange"):
                parent_pose = parent_pose @ torch.linalg.inv(torch.tensor(cfg.pose_to_tcp[arm], dtype=torch.float32))
        poses.append((parent_pose @ torch.tensor(camera["pose"], dtype=torch.float32))[None])
        h0, w0 = camera["image_size"]
        h, w = cfg.image_size
        k = torch.tensor(camera["K"], dtype=torch.float32)
        # Match OpenCV's pixel-centre convention when resizing the video.
        k[0, 0] *= w / w0
        k[1, 1] *= h / h0
        k[0, 2] = (k[0, 2] + .5) * w / w0 - .5
        k[1, 2] = (k[1, 2] + .5) * h / h0 - .5
        intrinsics.append(k)
    sample.raw_vl.K = torch.stack(intrinsics)
    sample.raw_vl.pose = poses
    sample.action_ref_pose = torch.stack([
        poses[cfg.camera_keys.index(key)][0]
        for key in cfg.geometry["action_reference_cameras"]])
    sample._original_geometry_ready = True
    return sample

class LeRobotOriginalCollator:
    """Use the original tokenizer/collator; add no camera or arm ID features."""
    def __init__(self, processor):
        self.processor = processor

    def __call__(self, samples):
        tokenized = []
        for sample in samples:
            if not getattr(sample, "_original_geometry_ready", False):
                raise ValueError("Original VLA batch requires calibrated LeRobotOriginalDataset geometry")
            raw_vl = sample.raw_vl
            if raw_vl.prompt:
                raw_vl = replace(raw_vl, prompt="Your task is to: {" + raw_vl.prompt
                                 + "}. Locate the key object needed and then figure out how to execute the task.")
            tokenized.append(tokenize_raw_vla(replace(sample, raw_vl=raw_vl), self.processor))
        return collate_fn(tokenized, return_dict=True)
