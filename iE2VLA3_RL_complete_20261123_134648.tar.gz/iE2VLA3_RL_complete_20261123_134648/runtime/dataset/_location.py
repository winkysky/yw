import psutil
import socket
from enum import IntEnum, auto
from typing import List, Dict, Union
from data_utils.dataset_base import DatasetBase


def get_ipv4_address():
    ipv4_list: List[str] = []
    for interface, addrs in psutil.net_if_addrs().items():
        for addr in addrs:
            if addr.family == socket.AF_INET:  # 只取 IPv4
                ipv4_list.append(addr.address)
    
    for ip in ipv4_list:
        if ip.startswith("10."):
            return ip
    else:
        raise ValueError(f"No matched ip. Current ips are {ipv4_list}")


class DSET(IntEnum):
    LiberoSpatial = auto()
    LiberoObject = auto()
    LiberoGoal = auto()
    Libero10 = auto()
    Libero90 = auto()

    Maniskill = auto()
    MetaWorld = auto()
    Droid = auto()

    PickPlaceCan = auto()
    OpenDrawer = auto()
    OpenOven = auto()
    AgibotWorldAlpha = auto()
    InternM1Franka = auto()
    RoboTwin2 = auto()
    EgoDex = auto()

    AlohaPickPlace0905 = auto()
    AlohaTableStorage0905 = auto()
    AlohaPickPlace1031 = auto()
    AlohaPickPlace1111 = auto()
    AlohaFridge1108 = auto()
    AlohaMakeTea = auto()

    FrankaOpenMicrowave1120 = auto()
    FrankaOpenMicrowave1120Dagger = auto()
    TakeLabelOut = auto()


dataset_locations: Dict[str, Dict[int, str]] = {}
dataset_locations["10.15.194.98"] = {
    DSET.LiberoSpatial: "/nas_data_new/caz/projects/e2vla/data_converted/libero/libero_spatial_no_noops/**/*.h5",
    DSET.LiberoObject: "/nas_data_new/caz/projects/e2vla/data_converted/libero/libero_object_no_noops/**/*.h5",
    DSET.LiberoGoal: "/nas_data_new/caz/projects/e2vla/data_converted/libero/libero_goal_no_noops/**/*.h5",
    DSET.Libero90: "/nas_data_new/caz/projects/e2vla/data_converted/libero/libero_90_no_noops/**/*.h5",
    DSET.Libero10: "/nas_data_new/caz/projects/e2vla/data_converted/libero/libero_10_no_noops/**/*.h5",

    DSET.Maniskill: "/nas_data_new/caz/projects/e2vla/data_converted/maniskill/0.1.0/*.h5",
    DSET.MetaWorld: "/nas_data_new/caz/projects/e2vla/data_converted/metaworld/*/*.h5",
    DSET.Droid: "/nas_data_new/caz/projects/e2vla/data_converted/droid",

    DSET.PickPlaceCan: "/nas_data_new/caz/projects/e2vla/data_converted/pick-place-can/*.h5",
    DSET.OpenDrawer: "/nas_data_new/caz/projects/e2vla/data_converted/drawer/*.h5",
    DSET.OpenOven: "/nas_data_new/caz/projects/e2vla/data_converted/oven/*.h5",

    DSET.AgibotWorldAlpha: "/home/chenanzhe/data_ssd/AgiBotWorld-Alpha-compressed",
    DSET.InternM1Franka: None, 
    DSET.RoboTwin2: None, 
    DSET.EgoDex: "/nas_data_new/caz/data_ssd/EgoDex/test/**/**.hdf5", 

    DSET.AlohaPickPlace0905: "/home/chenanzhe/data_ssd/self_aloha/data_hdf5/pick_place_new/*.h5",
    DSET.AlohaTableStorage0905: "/home/chenanzhe/data_ssd/self_aloha/data_hdf5/table_storage/*.h5",
    DSET.AlohaPickPlace1031: "/home/chenanzhe/data_ssd/self_aloha/data_hdf5/pick_place_1031/*.h5",
    DSET.AlohaPickPlace1111: "/home/chenanzhe/data_ssd/self_aloha/data_hdf5/pick_place_clutter_1111/*.h5",
    DSET.AlohaFridge1108: "/home/chenanzhe/data_ssd/self_aloha/data_hdf5/fridge_1108/*.h5",
    DSET.AlohaMakeTea: "/home/chenanzhe/data_ssd/self_aloha/data_hdf5/make_tea/*.h5",

    DSET.FrankaOpenMicrowave1120: None,
    DSET.FrankaOpenMicrowave1120Dagger: None
}

dataset_locations["10.15.194.104"] = {
    DSET.LiberoSpatial: "/data_ssd2/chenanzhe/data_ssd/libero_processed/datasets_original/libero_spatial_no_noops/**/*.h5",
    DSET.LiberoObject: "/data_ssd2/chenanzhe/data_ssd/libero_processed/datasets_original/libero_object_no_noops/**/*.h5",
    DSET.LiberoGoal: "/data_ssd2/chenanzhe/data_ssd/libero_processed/datasets_original/libero_goal_no_noops/**/*.h5",
    DSET.Libero90: "/data_ssd2/chenanzhe/data_ssd/libero_processed/datasets_original/libero_90_no_noops/**/*.h5",
    DSET.Libero10: "/data_ssd2/chenanzhe/data_ssd/libero_processed/datasets_original/libero_10_no_noops/**/*.h5",

    DSET.Maniskill: None,
    DSET.MetaWorld: "/data_ssd2/chenanzhe/data_ssd/metaworld/*/*.h5",
    DSET.Droid: "/data_ssd2/chenanzhe/data_ssd/droid_1.0.1_h5",

    DSET.PickPlaceCan: "/data_ssd2/chenanzhe/data_ssd/self_isaac/pick-place-can/*.h5",
    DSET.OpenDrawer: "/data_ssd2/chenanzhe/data_ssd/self_isaac/drawer/*.h5",
    DSET.OpenOven: "/data_ssd2/chenanzhe/data_ssd/self_isaac/oven/*.h5",

    DSET.AgibotWorldAlpha: "/data_ssd2/chenanzhe/data_ssd/AgiBotWorld-Alpha-compressed",
    DSET.InternM1Franka: "/data_ssd2/chenanzhe/data_ssd/InternData-M1-Franka-converted", 
    DSET.RoboTwin2: "/data_ssd2/chenanzhe/data_ssd/RoboTwin2_compressed/RoboTwin2_compressed", 
    DSET.EgoDex: "/data_ssd1/chenanzhe/EgoDex/**/**.hdf5", 

    DSET.AlohaPickPlace0905: "/data_ssd2/chenanzhe/data_ssd/self_aloha/data_hdf5/pick_place_new/*.h5",
    DSET.AlohaTableStorage0905: "/data_ssd2/chenanzhe/data_ssd/self_aloha/data_hdf5/table_storage/*.h5",
    DSET.AlohaPickPlace1031: "/data_ssd2/chenanzhe/data_ssd/self_aloha/data_hdf5/pick_place_1031/*.h5",
    DSET.AlohaPickPlace1111: "/data_ssd2/chenanzhe/data_ssd/self_aloha/data_hdf5/pick_place_clutter_1111/*.h5",
    DSET.AlohaFridge1108: "/data_ssd2/chenanzhe/data_ssd/self_aloha/data_hdf5/fridge_1108/*.h5",
    DSET.AlohaMakeTea: "/data_ssd2/chenanzhe/data_ssd/self_aloha/data_hdf5/make_tea/*.h5",

    DSET.FrankaOpenMicrowave1120: "/data_ssd2/chenanzhe/data_ssd/self_isaac/open_microwave2_1120_correct/*.hdf5",
    DSET.FrankaOpenMicrowave1120Dagger: "/data_ssd2/chenanzhe/data_ssd/self_isaac/open_microwave2_1120_dagger_correct/*.hdf5",
}

dataset_locations["10.15.194.96"] = {
    DSET.TakeLabelOut: "/home/hq/code/vla_datasets/e2vla_transitions/take_label_out/2026-06-05_18-07-48_org/*.hdf5",
}



LOC = dataset_locations[get_ipv4_address()]



def get_loc(cls: Union[str, DatasetBase]):
    # get file location for dataset cls
    if isinstance(cls, str):
        cls_name = cls
    else:
        cls_name = cls.__name__

    path = LOC[getattr(DSET, cls_name)]
    # assert path is not None, "No path defined for the dataset `{}` in this machine".format(cls_name)
    return path

