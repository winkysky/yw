import os
import glob
import h5py
import json
import numpy as np
from typing import Optional

from data_utils.transforms import BaseTransform
from data_utils.registry import mark_offline_test
from data_utils.dataset_base import DatasetBase, DataConfig

from ._location import DSET, LOC
from .custom_hdf5.map_base import UniqueDataConfig, H5DatasetMapBase


def get_files():
    spatial_files = glob.glob(LOC[DSET.LiberoSpatial])
    spatial_files.sort()
    
    object_files = glob.glob(LOC[DSET.LiberoObject])
    object_files.sort()
    
    goal_files = glob.glob(LOC[DSET.LiberoGoal])
    goal_files.sort()
    
    long_files = glob.glob(LOC[DSET.Libero10])
    long_files.sort()
    
    files = {
        "spatial": spatial_files,
        "object": object_files,
        "goal": goal_files,
        "long": long_files
    }
    return files


def get_train_statistics():
    def count_samples(file_list):
        counts = []
        for file in file_list:
            with h5py.File(file, 'r') as h5:
                counts.append(h5["ee_pose"].len())
        return counts
    
    statistics = {}
    files = get_files()
    for key, file_list in files.items():
        statistics[key] = count_samples(file_list)

    return statistics


def save_statistics():
    here = os.path.dirname(__file__)
    statistics = get_train_statistics()
    with open(os.path.join(here, "libero_train_statistics.json"), "w") as f:
        json.dump(statistics, f, indent=4)


@mark_offline_test()
class LiberoTrainDataset(H5DatasetMapBase):
    
    unique_config = UniqueDataConfig(
        record_dt=None,
        sample_dt=1.0,
        ee_indices=(0,),
        camera_names=("agentview", "eye_in_hand"),
        ee_ref_cams={0: ("agentview", "eye_in_hand")}
    )
    
    def __init__(self, 
        common_config: DataConfig,
        transforms: Optional[BaseTransform]
    ):
        self.files = get_files()
        here = os.path.dirname(__file__)
        with open(os.path.join(here, "libero_train_statistics.json"), "r") as f:
            self.statistics = json.load(f)
        
        self.files_flat = []
        self.n_frames_flat = []
        for key, file_list in self.files.items():
            self.files_flat.extend(file_list)
            self.n_frames_flat.extend(self.statistics[key])
        
        self.cumulative_frames = [0] + list(np.cumsum(self.n_frames_flat))
        self._in_visualization_context = False  # ugly hack

        super().__init__(self.files_flat, common_config, transforms)
    
    @classmethod
    def inst(cls, common_config, transforms):
        obj = cls(common_config=common_config, transforms=transforms)
        print("[INFO] num samples of {}: {}".format(cls.__name__, len(obj)))
        return obj
    
    def find_file_index(self, global_index: int):
        file_index = np.searchsorted(self.cumulative_frames, global_index, side='right') - 1
        local_index = global_index - self.cumulative_frames[file_index]
        return file_index, local_index
    
    def __len__(self):
        # return self.cumulative_frames[-1]
        return len(self.h5_filelist) if self._in_visualization_context else \
               self.cumulative_frames[-1]
    
    def __getitem__(self, index: int):
        assert self._in_visualization_context == False, "LiberoTrainDataset does not support __getitem__ in visualization context"
        file_index, local_index = self.find_file_index(index)
        file_path = self.files_flat[file_index]
        with h5py.File(file_path, 'r') as h5:
            L = h5["ee_pose"].len()
            assert local_index < L, f"Local index {local_index} out of bounds for file with {L} frames."
            data = self.sample_episode(h5, L, local_index)
        return data


if __name__ == "__main__":
    save_statistics()

