import time
import torch
from torch import nn, Tensor
from functools import partial
from typing import List, Dict
from peft import LoraConfig, get_peft_model, PeftModel
from transformers.feature_extraction_utils import BatchFeature
from transformers import Qwen3VLForConditionalGeneration, Qwen3VLProcessor, Qwen2TokenizerFast


class ExtentedEmbedding(nn.Module):
    def __init__(
        self, 
        old_embedding: nn.Embedding, 
        old_vocab_size: int, 
        additional_vocab_size: int
    ):
        super().__init__()
        self.old_vocab_size = old_vocab_size
        self.old_embedding = old_embedding
        self.new_embedding = nn.Embedding(
            additional_vocab_size,
            self.old_embedding.embedding_dim,
            max_norm=self.old_embedding.max_norm,
            norm_type=self.old_embedding.norm_type,
            scale_grad_by_freq=self.old_embedding.scale_grad_by_freq,
            sparse=self.old_embedding.sparse,
        ).to(self.old_embedding.weight.device)
    
    def forward(self, input_ids: Tensor):
        clipped_input_ids = input_ids.clip(None, self.old_vocab_size-1)
        outputs = self.old_embedding(clipped_input_ids).contiguous()

        mask = input_ids >= self.old_vocab_size
        if mask.any():
            masked_outputs = self.new_embedding(input_ids[mask] - self.old_vocab_size)
            if masked_outputs.dtype != outputs.dtype:
                outputs = outputs.type_as(masked_outputs)
            outputs[mask] = masked_outputs
        return outputs


class QwenVL3Extractor(nn.Module):
    def __init__(self, add_action_id: bool, enable_lora: bool):
        super().__init__()
        
        lora_config = LoraConfig(
            r=16,  
            lora_alpha=16,  
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", 
                            "gate_proj", "up_proj", "down_proj"], 
            bias="none", 
            task_type="CAUSAL_LM",
        )

        kwargs = {} if enable_lora else {"dtype": torch.bfloat16}

        try:
            import flash_attn
            attn_impl = "flash_attention_2"
        except Exception as e:
            attn_impl = "sdpa"

        print("[INFO] attn_impl = {}".format(attn_impl))
        qwen = Qwen3VLForConditionalGeneration.from_pretrained(
            "Qwen/Qwen3-VL-2B-Instruct", 
            # attn_implementation="sdpa", 
            attn_implementation=attn_impl, 
            # dtype=torch.bfloat16, 
            **kwargs
        )
        # print(qwen.visual.config._attn_implementation)
        self.config = qwen.config
        
        self.processor = Qwen3VLProcessor.from_pretrained(
            "Qwen/Qwen3-VL-2B-Instruct"
        )
        
        # add special token: <action>
        self.add_action_id = add_action_id
        self.tokenizer: Qwen2TokenizerFast = self.processor.tokenizer

        if self.add_action_id:
            qwen.model.language_model.embed_tokens = ExtentedEmbedding(
                old_embedding=qwen.model.language_model.embed_tokens,
                old_vocab_size=max(self.tokenizer.get_vocab().values()) + 1,
                additional_vocab_size=1
            )
            self.tokenizer.add_special_tokens({"additional_special_tokens": ["<action>"]})

        # forward hook of each llm layer
        self.hidden_states_buffer = [None for _ in qwen.language_model.layers]
        def llm_per_layer_forward_hook(layer_idx, module, input, output):
            self.hidden_states_buffer[layer_idx] = output
        for layer_idx, module in enumerate(qwen.language_model.layers):
            module.register_forward_hook(partial(llm_per_layer_forward_hook, layer_idx))
        
        # forward hook of the whole llm model
        self.llm_inputs = None
        def llm_whole_forward_hook(module, args, kwargs, output):
            self.llm_inputs = kwargs
            # kwargs are:
            # 'input_ids',
            # 'position_ids',
            # 'attention_mask',
            # 'past_key_values',
            # 'inputs_embeds',
            # 'cache_position',
            # 'visual_pos_masks',
            # 'deepstack_visual_embeds'
        qwen.language_model.register_forward_hook(
            llm_whole_forward_hook, with_kwargs=True)

        # setup lora model
        for p in qwen.parameters():
            p.requires_grad_(False)

        self.enable_lora = enable_lora
        # Enabled only by the full-Qwen LeRobot training/model builder. Kept
        # on the extractor so the same feature path is used at inference.
        self.full_qwen_features = False
        if enable_lora:
            self.qwen_peft: PeftModel = get_peft_model(qwen, lora_config)
            print("[INFO] In Qwen3VL:")
            self.qwen_peft.print_trainable_parameters()
        else:
            self._qwen = qwen

    @property
    def qwen(self) -> Qwen3VLForConditionalGeneration:
        if self.enable_lora:
            return self.qwen_peft.get_base_model()
        else:
            return self._qwen
    
    @property
    def image_ds(self):
        config = self.config.vision_config
        return config.patch_size * config.spatial_merge_size
    
    @property
    def num_llm_layers(self) -> int:
        return self.config.text_config.num_hidden_layers
    
    @property
    def hidden_size(self) -> int:
        return self.config.text_config.hidden_size
    
    @torch.no_grad()
    def chat(
        self, 
        inputs: BatchFeature | Dict[str, Tensor], 
        generation_config: dict,
    ):
        with torch.autocast(inputs["input_ids"].device.type, torch.bfloat16):
            qwen = self.qwen_peft if self.enable_lora else self._qwen
            generated_ids = qwen.generate(**inputs, **generation_config)
        questions = [out_ids[:len(in_ids)] for in_ids, out_ids in zip(inputs["input_ids"], generated_ids)]
        responses = [out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs["input_ids"], generated_ids)]
        
        # questions = self.processor.batch_decode(questions, skip_special_tokens=True, clean_up_tokenization_spaces=False)
        # responses = self.processor.batch_decode(responses, skip_special_tokens=True, clean_up_tokenization_spaces=False)
        questions = self.processor.batch_decode(questions, skip_special_tokens=False, clean_up_tokenization_spaces=False)
        responses = self.processor.batch_decode(responses, skip_special_tokens=False, clean_up_tokenization_spaces=False)
        return questions, responses

    def hidden_layer_features(
        self, 
        inputs: BatchFeature | Dict[str, Tensor], 
        select_layer_indices: List[int]
    ) -> Dict[str, Tensor]:
        # use only the first `n = use_num_layers` llm layers to extract feature
        max_layer_num = (self.num_llm_layers if self.full_qwen_features
                         else max(select_layer_indices) + 1)
        qwen: Qwen3VLForConditionalGeneration = self.qwen
        assert max_layer_num <= len(qwen.language_model.layers)
        original_llm_layers = qwen.language_model.layers
        qwen.language_model.layers = original_llm_layers[:max_layer_num]
        
        try:
            with torch.autocast(inputs["input_ids"].device.type, torch.bfloat16):
                if self.enable_lora:
                    with self.qwen_peft._enable_peft_forward_hooks(**inputs):
                        kwargs = {k: v for k, v in inputs.items() if k not in self.qwen_peft.special_peft_forward_args}
                        output = qwen.model(**kwargs)
                else:
                    kwargs = dict(inputs)
                    if self.full_qwen_features:
                        kwargs["use_cache"] = False
                    output = qwen.model(**kwargs)
        finally:
            qwen.language_model.layers = original_llm_layers

        inputs_embeds = self.llm_inputs["inputs_embeds"]  # (B, L, C)
        hidden_states = [self.hidden_states_buffer[i] for i in select_layer_indices]
        # list len = n_layers, each contains a tensor with shape (B, L, C)
        position_ids = self.llm_inputs["position_ids"]  # (D, B, L)

        if self.full_qwen_features:
            # The actor uses highways 0..N-2. Highway N-1 is never consumed.
            # Feed the final normalized Qwen output into the last CONSUMED
            # highway, giving all language blocks and final norm a loss path.
            if len(hidden_states) > 1:
                hidden_states[-2] = output.last_hidden_state
            else:
                inputs_embeds = output.last_hidden_state

        return{
            "inputs_embeds": inputs_embeds, 
            "hidden_states": hidden_states,
            "position_ids": position_ids
        }


if __name__ == "__main__":
    import cv2
    import numpy as np
    from data_utils import transforms as TF
    from data_utils.dataset_base import DataConfig
    from data_utils.tokenize import DataRawVL, DataRawVLA, collate_fn
    from dataset.custom_hdf5.dataset import Droid, LiberoSpatial


    qwen = QwenVL3Extractor(add_action_id=False, enable_lora=False).cuda()
    gen_config = {"max_new_tokens": 256}

    data_config = DataConfig()
    data_transform = TF.Compose([
        TF.ToDevice("cuda:0"),
        TF.CenterCamera(),
        TF.MakeInstruction(),
        TF.SmartResize(patch_size=32),
        TF.Tokenize(preserve_raw_vl=True)
    ])
    dataset = LiberoSpatial.inst(data_config, data_transform)
    print(qwen.qwen.get_input_embeddings().weight.shape)
    qwen.qwen.resize_token_embeddings
    qwen.qwen.tie_weights

    for i in range(len(dataset)):
        print("-"*81)
        sample = dataset[i]
        batched_sample = collate_fn([sample])

        questions, responses = qwen.chat(batched_sample.tokenized_vl, gen_config)
        print(questions)
        print(responses)
        from IPython import embed; embed()
        _ = input("[INFO] Press Enter to continue: ")

        break

    hidden_states, position_ids = qwen.hidden_layer_features(batched_sample.tokenized_vl, [0, 10, 20])
    from IPython import embed; embed()



# if __name__ == "__main__":

#     import cv2
#     import numpy as np
#     from transformers import Qwen2VLImageProcessorFast

#     def read_image(path: str):
#         bgr = cv2.imread(path)
#         bgr = cv2.resize(bgr, (256, 256))
#         rgb = np.ascontiguousarray(bgr[:, :, [2, 1, 0]])
#         if rgb.dtype == np.uint8:
#             rgb = rgb.astype(np.float32) / 255.
#         return torch.from_numpy(rgb).permute(2, 0, 1).contiguous()  # (C, H, W)
    

#     # images = [[read_image("./images/demo0.png"), torch.zeros(3, 256, 256)],
#     #           [read_image("./images/droid0.png"), read_image("./images/droid1.png")]]
#     images = [[read_image("./images/pick_place_scene2.png"), torch.zeros(3, 256, 256)],
#               [read_image("./images/droid0.png"), read_image("./images/droid1.png")]]
#     images = torch.stack([torch.stack(r, dim=0) for r in images], dim=0).cuda()  # (B, N, C, H, W)
#     camera_masks = torch.tensor([[1, 0],
#                                  [1, 1]]).bool().cuda()
#     norm_xy = torch.randn(2, 2, 2, 256, 256).cuda()
#     image_masks = torch.ones(2, 2, 256, 256).bool().cuda()
#     image_masks[0, 0, -33:, -33:] = False
#     image_masks[~camera_masks] = False
#     # prompts = ["Describe this image in short.",
#     #            "Given the two images from the same timestep but different viewpoints, describe what is the robot doing?"]
    
#     prompts = ["Your task is to: <pick up the eggplant and place it on the plate>. Locate the key object needed and then figure out how to execute the task.",
#                "Your task is to: <clean up the kitchen>. Locate the key object needed and then figure out how to execute the task."]
    
#     print(images.shape, images.dtype)

#     qwen = QwenVL3Encoder(add_action_id=False, enable_lora=False).cuda()
#     gen_config = {"max_new_tokens": 256}
#     # gen_config = {"max_new_tokens": 256, "num_beams": 1, "do_sample": False}
#     questions, responses = qwen.chat(images, camera_masks, prompts, gen_config)

#     inputs, outputs = qwen(
#         rgb=images.unsqueeze(1),
#         mask=image_masks.unsqueeze(1),
#         norm_xy=norm_xy.unsqueeze(1),
#         text=prompts,
#         select_layer_indices=list(range(20))
#     )

#     for q, r in zip(questions, responses):
#         print("-"*61)
#         print(q)
#         print(r)
    
#     trainable_params = [p for p in qwen.named_parameters() if p[1].requires_grad]
#     size = sum([x[1].numel() for x in trainable_params])

#     from IPython import embed
#     embed()


