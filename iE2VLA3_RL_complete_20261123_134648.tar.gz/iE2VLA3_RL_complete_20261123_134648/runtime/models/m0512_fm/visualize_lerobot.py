"""LeRobot dual-arm data/prediction viewer, also available as datavis.py --lerobot."""
import argparse
from collections import OrderedDict
from dataclasses import replace
from datetime import datetime
import html
import json
import os
from pathlib import Path
import time
from zoneinfo import ZoneInfo

import cv2
import numpy as np
import torch

from action.parser import ProprioParser
from data_utils.visualize import draw_state_actions, concat_bgrs, resize_to_fit
from dataset.lerobot_original import LeRobotOriginalConfig, LeRobotOriginalCollator
from dataset.lerobot_reviewed import build_dataset
from .lerobot_distributed import FORMAT
from .lerobot_inference import load_checkpoint, load_inference_model, predict_sample
from .train_lerobot_dual import DEFAULT_CONFIG


GT_COLOR, PRED_COLOR = (40, 200, 60), (255, 110, 30)  # OpenCV BGR


def episode_groups(dataset):
    """Map navigation to valid windows; never step through excluded/raw frame gaps."""
    groups = OrderedDict()
    start = 0
    if hasattr(dataset, "segments"):
        for segment, end in zip(dataset.segments, dataset.ends):
            key = (segment["dataset_id"], int(segment["episode_index"]))
            if end > start:
                groups.setdefault(key, []).append(np.arange(start, end))
            start = end
    else:
        for episode, end in zip(dataset.episodes, dataset.ends):
            key = ("lerobot", int(episode["episode_index"]))
            groups[key] = [np.arange(start, end)]
            start = end
    return [(key, np.concatenate(parts)) for key, parts in groups.items()]


def choose_indices(dataset, count):
    """First cover source datasets, then select other episodes deterministically."""
    groups = episode_groups(dataset)
    selected, seen = [], set()
    for (source, _), indices in groups:
        if source not in seen:
            selected.append(int(indices[len(indices) // 2]))
            seen.add(source)
    for _, indices in groups:
        index = int(indices[len(indices) // 2])
        if index not in selected:
            selected.append(index)
        if len(selected) >= count:
            break
    return selected[:count]


def sample_metadata(dataset, index, sample):
    info = dict(getattr(sample, "_review_metadata", {}))
    if not info:
        episode = int(np.searchsorted(dataset.ends, index, side="right"))
        start = dataset.ends[episode - 1] if episode else 0
        info = dict(dataset_id="lerobot", episode_index=dataset.episodes[episode]["episode_index"],
                    frame=index - start)
    return dict(info, sample_index=index, prompt=sample.raw_vl.prompt,
                horizon=dataset.config.num_future_actions, fps=dataset.fps,
                frame_stride=dataset.config.frame_stride, action_offset=dataset.config.action_offset,
                coordinate_frame="left_recorded_arm_base", arm_order=["left", "right"])


def predict_remote(client, sample, seed):
    prediction = torch.from_numpy(client.inference_raw(sample, seed=seed)).float()
    if prediction.shape != sample.action.shape or not torch.isfinite(prediction).all():
        raise ValueError("Remote prediction has an invalid shape or nonfinite values")
    return prediction


def trajectory_metrics(sample, prediction):
    if prediction is None:
        return None
    gt, pred = ProprioParser(sample.action), ProprioParser(prediction)
    result = {}
    for arm, name in enumerate(["left", "right"]):
        mask = sample.action_mask[arm]
        valid_pos, valid_rot, valid_grip = mask[:, :3].all(-1), mask[:, 3:9].all(-1), mask[:, 9]
        distance = (pred.trans[arm] - gt.trans[arm]).norm(dim=-1) * 1000
        relative = pred.rotmat[arm].transpose(-1, -2) @ gt.rotmat[arm]
        cosine = ((relative.diagonal(dim1=-2, dim2=-1).sum(-1) - 1) / 2).clamp(-1, 1)
        angle = torch.rad2deg(torch.acos(cosine))
        grip = (prediction[arm, :, 9] - sample.action[arm, :, 9]).abs()
        result[name] = dict(valid_steps=int(valid_pos.sum()),
                           position_mean_mm=float(distance[valid_pos].mean()) if valid_pos.any() else None,
                           position_final_mm=float(distance[valid_pos][-1]) if valid_pos.any() else None,
                           rotation_mean_deg=float(angle[valid_rot].mean()) if valid_rot.any() else None,
                           gripper_mae=float(grip[valid_grip].mean()) if valid_grip.any() else None)
    return result


def render_projection(sample, prediction, metadata, camera_keys):
    rows = []
    for arm, name in enumerate(["LEFT", "RIGHT"]):
        actions = [sample.action[arm:arm + 1]]
        colors = [GT_COLOR]
        masks = [sample.action_mask[arm:arm + 1]]
        if prediction is not None:
            actions.append(prediction[arm:arm + 1])
            colors.append(PRED_COLOR)
            masks.append(masks[0])
        panels = draw_state_actions(sample.raw_vl, sample.state[arm:arm + 1],
                                   sample.state_mask[arm:arm + 1], actions, colors, masks)
        labeled = []
        for camera, panel in zip(camera_keys, panels):
            panel = cv2.resize(panel, None, fx=2, fy=2, interpolation=cv2.INTER_LINEAR)
            panel = cv2.copyMakeBorder(panel, 30, 0, 0, 0, cv2.BORDER_CONSTANT, value=(28, 32, 40))
            label = camera.removeprefix("observation.images.")
            cv2.putText(panel, f"{name} arm | {label}", (10, 21), cv2.FONT_HERSHEY_SIMPLEX,
                        .55, (240, 240, 240), 1, cv2.LINE_AA)
            labeled.append(panel)
        rows.append(concat_bgrs(labeled))
    result = concat_bgrs(rows, vert_concat=True)
    result = cv2.copyMakeBorder(result, 85, 0, 0, 0, cv2.BORDER_CONSTANT, value=(28, 32, 40))
    title = (f"Sample {metadata['sample_index']} | {metadata['dataset_id']} | "
             f"episode {metadata['episode_index']} frame {metadata['frame']} | {metadata['horizon']} actions")
    cv2.putText(result, title, (12, 25), cv2.FONT_HERSHEY_SIMPLEX, .6, (240, 240, 240), 1, cv2.LINE_AA)
    cv2.putText(result, "GT command trajectory", (12, 53), cv2.FONT_HERSHEY_SIMPLEX, .6, GT_COLOR, 2, cv2.LINE_AA)
    cv2.putText(result, "Prediction" if prediction is not None else "Data only", (310, 53),
                cv2.FONT_HERSHEY_SIMPLEX, .6, PRED_COLOR, 2, cv2.LINE_AA)
    cv2.putText(result, "RGB axes: current TCP | Off-camera points are omitted", (500, 53),
                cv2.FONT_HERSHEY_SIMPLEX, .55, (220, 220, 220), 1, cv2.LINE_AA)
    return result


def save_trajectory_plot(path, sample, prediction, metadata):
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/ie2vla3-matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(12, 9))
    fig.subplots_adjust(left=.08, right=.97, bottom=.08, top=.87, wspace=.27, hspace=.5)
    steps = np.arange(sample.action.shape[1])
    seconds = (metadata["action_offset"] + steps * metadata["frame_stride"]) / metadata["fps"]
    for arm, name in enumerate(["Left arm", "Right arm"]):
        ax = fig.add_subplot(2, 2, arm + 1, projection="3d")
        current = sample.state[arm, -1, :3].numpy()
        points = [current[None]]
        for value, label, color in [(sample.action, "GT command", "#28a745"),
                                    (prediction, "Prediction", "#2563eb")]:
            if value is None:
                continue
            valid = sample.action_mask[arm, :, :3].all(-1).numpy()
            xyz = value[arm, :, :3].numpy().copy()
            xyz[~valid] = np.nan
            ax.plot(*xyz.T, color=color, label=label, marker=".", markersize=3)
            points.append(xyz[valid])
        ax.scatter(*current, color="#e58b25", s=25, label="Current TCP")
        all_points = np.concatenate(points)
        center = (all_points.min(0) + all_points.max(0)) / 2
        radius = max(float(np.ptp(all_points, axis=0).max()) / 2, .01) * 1.1
        for setter, c in zip([ax.set_xlim, ax.set_ylim, ax.set_zlim], center):
            setter(c - radius, c + radius)
        ax.set_box_aspect((1, 1, 1))
        ax.set(xlabel="X (m)", ylabel="Y (m)", zlabel="Z (m)", title=name + " | left-base coordinates")
        ax.legend(fontsize=8)
        grip_ax = fig.add_subplot(2, 2, arm + 3)
        valid = sample.action_mask[arm, :, 9].numpy()
        for value, label, color in [(sample.action, "GT command", "#28a745"),
                                    (prediction, "Prediction", "#2563eb")]:
            if value is not None:
                y = value[arm, :, 9].numpy().copy()
                y[~valid] = np.nan
                grip_ax.plot(seconds, y, color=color, label=label)
        grip_values = [sample.action[arm, valid, 9].numpy()]
        if prediction is not None:
            grip_values.append(prediction[arm, valid, 9].numpy())
        all_grips = np.concatenate(grip_values)
        if len(all_grips):
            grip_ax.set_ylim(min(-.05, float(all_grips.min()) - .05), max(1.05, float(all_grips.max()) + .05))
        grip_ax.set(xlabel="Time from observation (s)", ylabel="Gripper openness\n(0=closed, 1=open)", title=name)
        grip_ax.grid(alpha=.25)
        grip_ax.legend(fontsize=8)
    fig.suptitle(f"Sample {metadata['sample_index']} | episode {metadata['episode_index']}, frame {metadata['frame']}\n"
                 f"{metadata['horizon']}-step open-loop prediction against recorded commands", fontsize=13)
    fig.savefig(path, dpi=150)
    plt.close(fig)


def export_sample(output, sample, prediction, metadata, camera_keys):
    stem = f"sample_{metadata['sample_index']:06d}"
    projection = render_projection(sample, prediction, metadata, camera_keys)
    if not cv2.imwrite(str(output / (stem + "_projection.png")), projection):
        raise OSError("Could not write projected trajectory image")
    save_trajectory_plot(output / (stem + "_trajectory.png"), sample, prediction, metadata)
    arrays = dict(state=sample.state.numpy(), state_mask=sample.state_mask.numpy(),
                  ground_truth=sample.action.numpy(), action_mask=sample.action_mask.numpy(),
                  camera_K=sample.raw_vl.K.numpy(),
                  camera_poses=np.stack([p[-1].numpy() for p in sample.raw_vl.pose]),
                  action_ref_pose=sample.action_ref_pose.numpy())
    if prediction is not None:
        arrays["prediction"] = prediction.numpy()
    np.savez_compressed(output / (stem + ".npz"), **arrays)
    record = dict(metadata, metrics=trajectory_metrics(sample, prediction),
                  projection=stem + "_projection.png", trajectory=stem + "_trajectory.png", arrays=stem + ".npz")
    (output / (stem + ".json")).write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    return record


def write_report(output, records, info):
    (output / "manifest.json").write_text(json.dumps(dict(info, samples=records), ensure_ascii=False, indent=2) + "\n")
    cards = []
    for record in records:
        metrics = record["metrics"]
        detail = "仅显示数据"
        if metrics:
            detail = " / ".join(f"{name}臂平均位置误差 {metrics[key]['position_mean_mm']:.2f} mm"
                                for key, name in [("left", "左"), ("right", "右")]
                                if metrics[key]["position_mean_mm"] is not None)
        cards.append(f'<section><h2>样本 {record["sample_index"]} · episode {record["episode_index"]} · frame {record["frame"]}</h2>'
                     f'<p>{html.escape(record["prompt"] or "")}</p><p>{detail}</p>'
                     f'<a href="{record["projection"]}"><img src="{record["projection"]}" alt="三相机轨迹投影"></a>'
                     f'<details><summary>三维轨迹与夹爪曲线</summary><img src="{record["trajectory"]}" alt="三维轨迹"></details>'
                     f'<p><a href="{record["arrays"]}">下载轨迹 NPZ</a></p></section>')
    page = ('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>LeRobot 双臂推理轨迹</title><style>body{font:16px/1.6 system-ui;margin:28px auto;padding:0 20px;max-width:1400px;background:#f4f6fa;color:#172033}'
            'section{background:white;padding:20px;margin:24px 0;border-radius:12px}img{max-width:100%;height:auto}summary{cursor:pointer}a{color:#2563eb}</style>'
            '<h1>LeRobot 双臂推理轨迹</h1><p>绿色：记录的真实指令轨迹；蓝色：模型预测。上排左臂，下排右臂。三列为头部、左腕、右腕相机。</p>'
            f'<p>Checkpoint：{html.escape(str(info["checkpoint"]))} · device：{html.escape(info["device"])}</p>'
            '<p>每张图是固定观察时刻的动作块（长度以样本标注为准）；使用当时的相机位姿投影。'
            '这些是数据集上的离线对比，不是闭环实机评估；相机视野外和背后的点不绘制。</p>'
            + ''.join(cards) + '</html>')
    (output / "index.html").write_text(page)


def interactive(dataset, model, collator, device, seed, index, predictor=None):
    groups = episode_groups(dataset)
    group_index = next(i for i, (_, values) in enumerate(groups) if index in values)
    frame = int(np.flatnonzero(groups[group_index][1] == index)[0])
    available = model is not None or predictor is not None
    stride, enabled = 1, available
    print("Keys: q quit | n/p next/previous episode | arrows or d/b next/previous valid window | a step 1/10 | i inference", flush=True)
    try:
        while True:
            indices = groups[group_index][1]
            index = int(indices[frame])
            sample = dataset[index]
            prediction = None
            if enabled:
                prediction = (predictor(sample, seed + index) if predictor is not None
                              else predict_sample(model, collator, sample, device, seed + index))
            metadata = sample_metadata(dataset, index, sample)
            print(json.dumps(metadata, ensure_ascii=False), flush=True)
            display = render_projection(sample, prediction, metadata, dataset.config.camera_keys)
            cv2.imshow("LeRobot dual-arm: GT green / prediction blue", resize_to_fit(display, 1500, 1000))
            key = cv2.waitKeyEx(0)
            if key in [ord('q'), 27]:
                break
            if key in [ord('n'), ord('p')]:
                group_index = (group_index + (1 if key == ord('n') else -1)) % len(groups)
                frame = 0
            elif key in [83, 65363, 2555904, ord('d')]:
                frame = (frame + stride) % len(indices)
            elif key in [81, 65361, 2424832, ord('b')]:
                frame = (frame - stride) % len(indices)
            elif key == ord('a'):
                stride = 10 if stride == 1 else 1
            elif key == ord('i'):
                enabled = available and not enabled
    finally:
        cv2.destroyAllWindows()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    inference = parser.add_mutually_exclusive_group()
    inference.add_argument("--checkpoint", type=Path, help="Complete full-Qwen checkpoint directory or model.pt")
    inference.add_argument("--uri", help="Pyro4 LeRobot service name; data config comes from the service")
    parser.add_argument("--ns-host", "--ns_host", default="127.0.0.1")
    parser.add_argument("--ns-port", "--ns_port", type=int, default=9090)
    parser.add_argument("--tcp", action="store_true", help="Force TCP instead of same-host shared memory")
    parser.add_argument("--data-config", type=Path, help="Data-only config; inference always uses checkpoint calibration/horizon")
    parser.add_argument("--data-root", help="Relocated data root, preserving checkpoint conventions")
    parser.add_argument("--device", default="cpu", help="cpu (default, leaves training GPUs free), or cuda:N")
    parser.add_argument("--indices", nargs="+", type=int, help="Explicit dataset sample indices")
    parser.add_argument("--num-samples", type=int, default=5)
    parser.add_argument("--output", type=Path, help="Export directory; defaults to a new timestamped directory under audits")
    parser.add_argument("--show", action="store_true", help="Open interactive OpenCV viewer after export (requires display)")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args(argv)
    if args.threads < 1 or args.num_samples < 1:
        parser.error("threads and num-samples must be positive")
    if (args.checkpoint or args.uri) and args.data_config:
        parser.error("Inference supplies its own data config; do not combine with --data-config")
    if args.show and os.name != "nt" and not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        parser.error("--show requires a graphical display; omit it to export PNG/HTML on this server")
    torch.set_num_threads(args.threads)
    cv2.setNumThreads(1)
    device = torch.device(args.device)
    if device.type not in {"cpu", "cuda"}:
        parser.error("device must be cpu or cuda:N")
    if device.type == "cuda" and not args.uri:
        torch.cuda.set_device(device)
    output = args.output or Path("audits") / datetime.now(ZoneInfo("Asia/Shanghai")).strftime("lerobot_datavis_%Y%m%d_%H%M%S")
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Output is nonempty; choose a new --output: {output}")
    client = dataset = None
    try:
        if args.uri:
            from client import Client
            client = Client(args.uri, ns_host=args.ns_host, ns_port=args.ns_port, force_tcp=args.tcp)
            saved = client.policy_info
            if saved.get("format") != FORMAT or saved.get("input_contract") != "lerobot_dual_v1":
                raise ValueError("--lerobot requires models.m0512_fm.service_lerobot")
            checkpoint = saved["checkpoint"]
        else:
            saved, checkpoint = load_checkpoint(args.checkpoint) if args.checkpoint else (None, None)
        config = (LeRobotOriginalConfig(**saved["data_config"]) if saved
                  else LeRobotOriginalConfig.load(args.data_config or DEFAULT_CONFIG))
        if args.data_root:
            config = replace(config, root=args.data_root)
        config.validate()
        print(json.dumps(dict(status="loading_data", root=config.root, horizon=config.num_future_actions)), flush=True)
        dataset = build_dataset(config)
        dataset.require_geometry()
        if saved and hasattr(dataset, "fingerprint") and dataset.fingerprint != saved["dataset_fingerprint"]:
            raise ValueError("Reviewed snapshot differs from the checkpoint's dataset")
        indices = args.indices or choose_indices(dataset, args.num_samples)
        if any(index < 0 or index >= len(dataset) for index in indices):
            raise IndexError(f"Sample indices must be in [0, {len(dataset) - 1}]")
        model = collator = predictor = None
        if client is not None:
            predictor = lambda sample, seed: predict_remote(client, sample, seed)
        elif saved:
            print(json.dumps(dict(status="loading_model", checkpoint=str(checkpoint), device=str(device))), flush=True)
            model = load_inference_model(saved, device)
            collator = LeRobotOriginalCollator(model.vlm.processor)
            predictor = lambda sample, seed: predict_sample(model, collator, sample, device, seed)
        info = dict(checkpoint=str(checkpoint) if checkpoint else None,
                    created_at=datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
                    checkpoint_step=saved["step"] if saved else None,
                    dataset_fingerprint=getattr(dataset, "fingerprint", None), data_config=config.to_dict(),
                    device=saved["device"] if client is not None else str(device), seed=args.seed,
                    service_uri=args.uri, transport="tcp" if args.tcp else "auto",
                    inference_timesteps=saved["model_config"]["inference_timesteps"] if saved else None)
        del saved
        output.mkdir(parents=True, exist_ok=True)
        records = []
        for index in indices:
            sample = dataset[index]
            started = time.monotonic()
            prediction = predictor(sample, args.seed + index) if predictor is not None else None
            metadata = dict(sample_metadata(dataset, index, sample), inference_seconds=time.monotonic() - started,
                            inference_seed=args.seed + index)
            record = export_sample(output, sample, prediction, metadata, config.camera_keys)
            records.append(record)
            write_report(output, records, info)
            print(json.dumps(dict(status="exported", **record), ensure_ascii=False), flush=True)
        print(json.dumps(dict(status="done", output=str(output.resolve()), report=str((output / "index.html").resolve()))), flush=True)
        if args.show:
            interactive(dataset, model, collator, device, args.seed, indices[0], predictor=predictor)
    finally:
        if dataset is not None:
            dataset.close()
        if client is not None:
            client.close()


if __name__ == "__main__":
    main()
