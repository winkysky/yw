import torch
from typing import Tuple
from diffusers import DDIMScheduler
from torch import nn, Tensor, distributions


def sub(x1: Tensor, x0: Tensor):
    """
    * For linear: x1 - x0
    * For SO/SE(n): Log( Inv(x0) @ x1 )
    """
    return x1 - x0


def add(x: Tensor, u: Tensor):
    """
    * For linear: x + u
    * For SO/SE(n): x @ Exp(u)
    """
    return x + u


def integrate(
    x0: Tensor,
    vf: nn.Module,
    ts: Tensor,
    method: str = "euler"
):
    """
    Args:
        x0: (B, ..., D)
        vf: vector field, a neural network
        ts: (T,) or (B, T)
        method: choose from [euler, midpoint, huen, rk4]
    """
    x = x0

    has_batch_dim = False
    if x0.ndim >= 2 and ts.ndim == 1:
        has_batch_dim = True
        ts = ts[None]
        n_expand = x0.ndim - ts.ndim

    for i in range(ts.shape[-1] - 1):
        t = ts[..., i]  # scalar or (B,)
        dt = ts[..., i+1] - t  # scalar or (B,)
        dt_expand = dt.view(*dt.shape, *((1,)*n_expand)) if has_batch_dim else dt

        if method == "euler":
            v = vf(x, t)  # (B, ..., VD,)
            x = add(x, v * dt_expand)
        
        elif method == "midpoint":
            v0 = vf(x, t)
            x_mid = add(x, 0.5 * v0 * dt_expand)
            v_mid = vf(x_mid, t + 0.5 * dt)
            x = add(x, v_mid * dt_expand)
        
        elif method == "huen":
            v0 = vf(x, t)
            x1 = add(x, v0 * dt_expand)
            v1 = vf(x1, t + dt)
            x = add(x, (v0 + v1) * 0.5 * dt_expand)
        
        elif method == "rk4":
            k1 = vf(x, t)
            k2 = vf(add(x, dt_expand * k1 / 3), t + dt / 3)
            k3 = vf(add(x, dt_expand * (k2 - k1 / 3)), t + dt * 2 / 3)
            k4 = vf(add(x, dt_expand * (k1 - k2 + k3)), t + dt)
            u = (k1 + 3 * (k2 + k3) + k4) * dt_expand * 0.125
            x = add(x, u)
        
        else:
            raise ValueError("Unsupported method: {}".format(method))
    
    return x


class BaseDenoiser(nn.Module):
    def sample_t(self, shape, device=None) -> Tensor:
        raise NotImplementedError
    
    def sample_xt(self, x0: Tensor, x1: Tensor, t: Tensor) -> Tuple[Tensor, Tensor]:
        raise NotImplementedError
    
    def train_forward(self, x1: Tensor, field_fn: nn.Module) -> Tuple[Tensor, Tensor]:
        raise NotImplementedError
    
    def generate(self, x0: Tensor, field_fn: nn.Module, n_steps: int) -> Tensor:
        raise NotImplementedError


class JiTDenoiser(BaseDenoiser):
    def __init__(self):
        super().__init__()

        self.P_mean = -0.8
        self.P_std = 0.8
        self.noise_scale = 1.0
        self.t_eps = 5e-2
        self.method = "euler"
    
    @classmethod
    def xf2vf(cls, xf: nn.Module, t_eps: float = 5e-2):
        def vf(xt: Tensor, t: Tensor) -> Tensor:
            n_expand = xt.ndim - t.ndim
            t_expand = t.view(*t.shape, *((1,)*n_expand))

            x1: Tensor = xf(xt, t)
            vt = (x1 - xt) / (1 - t_expand).clamp_min(t_eps)
            return vt
        return vf
    
    def sample_t(self, shape, device=None):
        z = torch.randn(shape, device=device) * self.P_std + self.P_mean
        return torch.sigmoid(z)
    
    def sample_xt(
        self, x0: Tensor, x1: Tensor, t: Tensor, t_eps: float = 5e-2
    ):
        """
        Args:
            x0: noise, (B, ...)
            x1: gt, (B, ...)
            t: timestep, (B,)
        """
        n_expand = x0.ndim - t.ndim
        t = t.view(*t.shape, *((1,)*n_expand))

        delta = sub(x1, x0)  # (x1 - x0)
        xt = add(x0, t * delta)
        # below is actually: vt = delta
        vt = sub(x1, xt) / (1 - t).clamp_min(t_eps)
        return xt, vt

    def train_forward(self, x1: Tensor, xf: nn.Module):
        vf = self.xf2vf(xf, self.t_eps)
        t = self.sample_t(x1.shape[0], x1.device)
        x0 = torch.randn_like(x1) * self.noise_scale
        xt, vt = self.sample_xt(x0, x1, t, self.t_eps)
        vt_pred = vf(xt, t)
        return vt_pred, vt
    
    def generate(self, x0: Tensor, xf: nn.Module, n_steps: int):
        vf = self.xf2vf(xf, self.t_eps)
        ts = torch.linspace(0.0, 1.0, n_steps+1, device=x0.device)
        x1_pred = integrate(x0, vf, ts, self.method)
        return x1_pred


class Pi0Denoiser(BaseDenoiser):
    """
    Pi0 defines x0 as sample and x1 as noise, 
    here we inverse the definition: x0 as noise, and x1 as sample
    """
    def __init__(self):
        super().__init__()

        # inverse the time definition of Pi0, 
        # so that t=0 corresponds to x0 (noise), and t=1 corresponds to x1 (gt)
        self.alpha = 1.0
        self.beta = 1.5
        
        self.t_eps = 0.001
        self.method = "euler"
    
    def sample_t(self, shape, device=None):
        alpha = torch.tensor(self.alpha, dtype=torch.float32, device=device)
        beta = torch.tensor(self.beta, dtype=torch.float32, device=device)
        dist = distributions.Beta(alpha, beta)
        if isinstance(shape, int):
            shape = torch.Size([shape,])
        time = dist.sample(shape)
        return time * (1 - self.t_eps)
    
    def sample_xt(self, x0: Tensor, x1: Tensor, t: Tensor):
        """
        Args:
            x0: noise, (B, ...)
            x1: gt, (B, ...)
            t: timestep, (B,)
        """
        n_expand = x0.ndim - t.ndim
        t = t.view(*t.shape, *((1,)*n_expand))

        delta = sub(x1, x0)  # (x1 - x0)
        xt = add(x0, t * delta)
        vt = delta
        return xt, vt
    
    def train_forward(self, x1: Tensor, vf: nn.Module):
        t = self.sample_t(x1.shape[0], x1.device)
        x0 = torch.randn_like(x1)
        xt, vt = self.sample_xt(x0, x1, t)
        vt_pred = vf(xt, t)
        return vt_pred, vt
    
    def generate(self, x0: Tensor, vf: nn.Module, n_steps: int):
        ts = torch.linspace(0.0, 1.0, n_steps+1, device=x0.device)
        x1_pred = integrate(x0, vf, ts, self.method)
        return x1_pred


class E2Denoiser(Pi0Denoiser):
    def __init__(self):
        super().__init__()
        self.alpha = 1.5
        self.beta = 1.0
        self.t_eps = 0.005


class UniformDenoiser(Pi0Denoiser):
    def __init__(self):
        super().__init__()
        self.alpha = 1.0
        self.beta = 1.0
        self.t_eps = 0.0
    
    def sample_t(self, shape, device=None):
        return torch.rand(shape, device=device)


class SD3Denoiser(BaseDenoiser):
    def __init__(self):
        super().__init__()
        self.mu = 0.0
        self.std = 1.2
        self.t_eps = 0.001
        self.method = "euler"
    
    def sample_t(self, shape, device=None):
        r = torch.randn(shape, device=device) * self.std + self.mu
        t = torch.sigmoid(r)
        return t.clip(0, 1 - self.t_eps)
    
    def sample_xt(self, x0: Tensor, x1: Tensor, t: Tensor):
        """
        Args:
            x0: noise, (B, ...)
            x1: gt, (B, ...)
            t: timestep, (B,)
        """
        n_expand = x0.ndim - t.ndim
        t = t.view(*t.shape, *((1,)*n_expand))

        delta = sub(x1, x0)  # (x1 - x0)
        xt = add(x0, t * delta)
        vt = delta
        return xt, vt
    
    def train_forward(self, x1: Tensor, vf: nn.Module):
        t = self.sample_t(x1.shape[0], x1.device)
        x0 = torch.randn_like(x1)
        xt, vt = self.sample_xt(x0, x1, t)
        vt_pred = vf(xt, t)
        return vt_pred, vt
    
    def generate(self, x0: Tensor, vf: nn.Module, n_steps: int):
        ts = torch.linspace(0.0, 1.0, n_steps+1, device=x0.device)
        x1_pred = integrate(x0, vf, ts, self.method)
        return x1_pred


class DDIMDenoiser(BaseDenoiser):
    def __init__(self, train_timesteps: int = 100):
        super().__init__()

        self.num_train_steps = train_timesteps
        self.ddim = DDIMScheduler(
            num_train_timesteps=train_timesteps,
            beta_schedule="squaredcos_cap_v2",
            prediction_type="epsilon",
            clip_sample=False
        )
    
    def sample_t(self, shape, device=None):
        return torch.randint(0, self.num_train_steps, size=shape, device=device)
    
    def sample_xt(self, x0: Tensor, x1: Tensor, t: Tensor):
        """
        Args:
            x0: noise, (B, ...)
            x1: gt, (B, ...)
            t: timestep, (B,)
        """
        xt = self.ddim.add_noise(x1, x0, t)
        
        pred_type: str = self.ddim.config.prediction_type
        if pred_type == "epsilon":
            gt = x0
        if pred_type == "sample":
            gt = x1
        if pred_type == "v_prediction":
            gt = self.ddim.get_velocity(x1, x0, t)
        
        return xt, gt
    
    def train_forward(self, x1: Tensor, vf: nn.Module):
        t = self.sample_t((x1.shape[0],), x1.device)
        x0 = torch.randn_like(x1)
        xt, gt = self.sample_xt(x0, x1, t)
        pred = vf(xt, t.float() / self.num_train_steps)
        return pred, gt
    
    def generate(self, x0: Tensor, vf: nn.Module, n_steps: int):
        self.ddim.set_timesteps(n_steps)

        xt = x0
        for t in self.ddim.timesteps:
            out = vf(xt, t.float() / self.num_train_steps)
            xt = self.ddim.step(out, t, xt).prev_sample
        return xt


def get_denoiser(name: str) -> BaseDenoiser:
    return {
        "jit": JiTDenoiser,
        "pi0": Pi0Denoiser,
        "sd3": SD3Denoiser, 
        "e2": E2Denoiser,
        "uni": UniformDenoiser, 
        "ddim": DDIMDenoiser, 
    }[name]()


if __name__ == "__main__":
    import numpy as np
    import matplotlib.pyplot as plt
    import torch.nn.functional as F
    
    def sample_noise(shape: tuple, dtype = torch.float32, device = "cpu"):
        return torch.randn(shape, dtype=dtype, device=device)
    
    x0 = sample_noise(1)
    x1 = sample_noise(1)
    t = torch.rand(1)

    jit = JiTDenoiser()
    # pi0 = Pi0Denoiser()
    pi0 = SD3Denoiser()
    # pi0 = E2Denoiser()
    # pi0 = UniformDenoiser()


    def vf(x, t):
        vt = x1 - x0
        return vt
    
    def xf(x, t):
        return x1


    x1_int1 = jit.generate(x0, xf, 20)
    x1_int2 = pi0.generate(x0, vf, 20)

    print("x0      :", x0)
    print("x1      :", x1)
    print("x1_recon:", x1_int1)
    print("x1_recon:", x1_int2)
    # print("xt:", xt)
    # print("vt:", vt)


    t_jit = jit.sample_t(100000).numpy()
    t_pi0 = pi0.sample_t(100000).numpy()

    plt.figure()
    plt.subplot(211)
    plt.hist(t_jit, bins=np.linspace(0, 1, 40, endpoint=True))
    plt.subplot(212)
    plt.hist(t_pi0, bins=np.linspace(0, 1, 40, endpoint=True))
    plt.show()

