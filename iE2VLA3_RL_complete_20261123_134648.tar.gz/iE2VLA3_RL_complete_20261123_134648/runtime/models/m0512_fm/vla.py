from torch import nn
from .vlm import QwenVL3Extractor
from .action_expert import ActionExpert
from data_utils.tokenize import BatchDataTokenizedVLA


class VLA(nn.Module):
    def __init__(
        self, 
        hdim: int, 
        num_heads: int, 
        vlm_layer_gaps: int, 
        inference_timesteps: int = 4, 
    ):
        super().__init__()
        self.vlm = QwenVL3Extractor(False, False)
        self.vlm_layer_indices = list(range(0, self.vlm.num_llm_layers, vlm_layer_gaps))

        self.actor = ActionExpert(
            idim=self.vlm.hidden_size, 
            hdim=hdim,
            num_heads=num_heads,
            num_diffusion_layers=len(self.vlm_layer_indices), 
            inference_timesteps=inference_timesteps,
        )
    
        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, (nn.Linear, nn.Conv2d, nn.Conv3d)):
                if m.bias is not None and m.bias.requires_grad:
                    # Do not modify the bias in fronzen backbones!!!
                    nn.init.zeros_(m.bias)
    
    def parameter_groups(self):
        decay = []
        no_decay = []

        for name, param in self.named_parameters():
            if not param.requires_grad:
                continue

            if (
                name.endswith(".bias") or 
                "norm" in name.lower() or 
                "embedding" in name.lower() or 
                (param.ndim == 1)
            ):
                no_decay.append(param)
            else:
                decay.append(param)
        
        return decay, no_decay
    
    def forward(
        self, 
        vla_inputs: BatchDataTokenizedVLA, 
        inference: bool, 
        fp16: bool,
        n_repeats: int = 1,
    ):
        """
        Args:
            vla_inputs (BatchDataTokenizedVLA):
                - raw_vl: List[Optional[DataRawVL]]  # len = B
                - tokenized_vl: BatchFeature
                    * input_ids: Tensor  # (B, L)
                    * attention_mask: Tensor  # (B, L)
                    * pixel_values: Optional[Tensor]  # (L_imgs, C)
                    * image_grid_thw: Optional[Tensor]  # (N_imgs, 3)
                    * pixel_values_videos: Optional[Tensor]  # (L_vids, C)
                    * video_grid_thw: Optional[Tensor]  # (N_vids, 3)

            inference: if True, returns the predicted trajectory, otherwise returns loss and metrics for logging
            fp16: if True, use bfloat16
        
        Returns
        -------
        (if inference is True)
            pred_future_ee_states (Tensor): (B, Nee, Ta, D)
        (else)
            loss (Tensor): scalar tensor
            metrics (Dict[str, Tensor]): metrics for logging
        """
        vl_outputs = self.vlm.hidden_layer_features(
            inputs=vla_inputs.tokenized_vl,
            select_layer_indices=self.vlm_layer_indices
        )

        return self.actor(
            vla_inputs=vla_inputs,
            vl_outputs=vl_outputs,  
            inference=inference,
            fp16=fp16,
            n_repeats=n_repeats
        )


def vla_base(
    inference_timesteps: int = 4, 
):
    return VLA(
        hdim=768,
        num_heads=12,
        vlm_layer_gaps=3, 
        inference_timesteps=inference_timesteps
    )


def vla_large(
    inference_timesteps: int = 4, 
):
    return VLA(
        hdim=1024,
        num_heads=16,
        vlm_layer_gaps=2, 
        inference_timesteps=inference_timesteps
    )


def vla_huge(
    inference_timesteps: int = 4, 
):
    return VLA(
        hdim=1280,
        num_heads=16,
        vlm_layer_gaps=1, 
        inference_timesteps=inference_timesteps
    )


def count_modules(model: nn.Module):

    from collections import defaultdict
    from .layers.norm import AdaRMSNorm
    from .layers.attn import FFN, MySimpleMHA

    counts = defaultdict(int)
    for m in model.modules():
        if isinstance(m, MySimpleMHA):
            counts["att"] += 1
        elif isinstance(m, FFN):
            counts["ffn"] += 1
        elif isinstance(m, AdaRMSNorm):
            counts["adaln"] += 1
    
    ret = counts["att"] + counts["ffn"] * 2/3 * 3 + counts["adaln"] * 2/3
    print(counts)
    print(ret)



def count_parameters():
    model = vla_base()
    # model = vla_large()
    # model = vla_huge()
    print(model)

    modules = [
        model
    ]

    num_total = 0
    num_trainable = 0
    for m in modules:
        for p in m.parameters():
            num_total += p.numel()
            if p.requires_grad:
                num_trainable += p.numel()

    print("[INFO] Total {:.3f}M parameters, {:.3f}M frozen, {:.3f}M trainable"
          .format(num_total / 1e6, (num_total - num_trainable) / 1e6, num_trainable / 1e6))
    count_modules(model)


if __name__ == "__main__":
    count_parameters()
