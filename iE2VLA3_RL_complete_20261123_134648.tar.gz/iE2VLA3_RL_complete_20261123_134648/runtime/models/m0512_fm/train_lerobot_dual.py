"""Four-GPU LeRobot training with full Qwen fine-tuning and no speed condition.

Run from the repository root: python -m models.m0512_fm.train_lerobot_dual --help
"""

import argparse
from contextlib import nullcontext
from dataclasses import asdict
from datetime import timedelta
import hashlib
import json
import math
import os
from pathlib import Path
import random
import subprocess
import sys
import time

import cv2
import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel
from torch.utils.data import DataLoader, Sampler

from .lerobot_runtime import configure_conv3d_layout

from data_utils.tokenize import BatchDataTokenizedVLA
from dataset.balanced_sampler import BalancedGroupBatchSampler
from dataset.lerobot_original import (
    LeRobotOriginalConfig as LeRobotDualConfig,
    LeRobotOriginalDataset as LeRobotDualDataset,
    LeRobotOriginalCollator as LeRobotDualCollator,
)


DEFAULT_CONFIG = Path(__file__).with_name("lerobot_huawei_close_box_original.json")


def build_model(model="base", inference_timesteps=4, train_qwen=True):
    """Unfreeze after construction so pretrained Qwen biases are preserved."""
    from . import vla
    constructors = {"base": vla.vla_base, "large": vla.vla_large, "huge": vla.vla_huge}
    result = constructors[model](inference_timesteps=inference_timesteps)
    result.vlm.requires_grad_(train_qwen)
    result.vlm.full_qwen_features = train_qwen
    return result


def emit(**values):
    if dist.is_initialized() and dist.get_rank() != 0:
        return
    print(json.dumps(values, ensure_ascii=False), flush=True)


def check_data(dataset, all_episodes=False):
    """Validate numeric fields, and decode start/middle/end of selected episodes."""
    if hasattr(dataset, "group_ranges"):
        for source in dataset.sources:
            emit(status="checking_group_source", **source)
            check_data(dataset.readers[source["name"]], all_episodes)
        emit(status="data_ok", episodes=len(dataset.episodes), samples=len(dataset), fps=dataset.fps,
             sampling=dataset.sampling_summary, dataset_fingerprint=dataset.fingerprint)
        dataset.close()
        return
    if hasattr(dataset, "raw_sources"):
        for block, source in enumerate(dataset.raw_sources):
            reader = dataset.readers[source["name"]]
            selected = (range(len(reader.episodes)) if all_episodes else
                        sorted({0, len(reader.episodes) // 2, len(reader.episodes) - 1}))
            checked = 0
            base = dataset.ends[block - 1] if block else 0
            for ep in selected:
                reader._episode(ep)
                start = reader.ends[ep - 1] if ep else 0
                length = reader.sample_lengths[ep]
                for frame in sorted({0, length // 2, length - 1}):
                    sample = dataset[base + start + frame]
                    assert sample.raw_vl.prompt == source["instruction"]
                    assert torch.isfinite(sample.state).all() and torch.isfinite(sample.action).all()
                    assert sample.state_mask[:, -1, :10].all() and sample.action_mask[:, 0, :10].all()
                checked += 1
            emit(source=source["name"], prompt=source["instruction"], episodes=len(reader.episodes),
                 samples=len(reader), numeric_and_video_episodes_checked=checked)
        emit(status="data_ok", selection="all_original_episodes", episodes=len(dataset.episodes),
             samples=len(dataset), fps=dataset.fps, dataset_fingerprint=dataset.fingerprint,
             geometry_ready=dataset.config.geometry is not None)
        dataset.close()
        return
    if hasattr(dataset, "segments"):
        if all_episodes:
            for reader in dataset.readers.values():
                for index in range(len(reader.episodes)):
                    reader._episode(index)
        for index in sorted({0, len(dataset) // 2, len(dataset) - 1}):
            sample = dataset[index]
            assert torch.isfinite(sample.state).all() and torch.isfinite(sample.action).all()
            assert sample.state_mask[..., :10].all() and sample.action_mask[..., :10].all()
            emit(index=index, **sample._review_metadata, prompt=sample.raw_vl.prompt,
                 state=list(sample.state.shape), action=list(sample.action.shape))
        emit(status="data_ok", episodes=len(dataset.episodes), segments=len(dataset.segments),
             samples=len(dataset), fps=dataset.fps, dataset_fingerprint=dataset.fingerprint,
             numeric_episodes_checked=len(dataset.episodes) if all_episodes else "sampled",
             geometry_ready=dataset.config.geometry is not None)
        dataset.close()
        return
    selected = sorted({0, len(dataset.episodes) // 2, len(dataset.episodes) - 1})
    checked = range(len(dataset.episodes)) if all_episodes else selected
    for index in checked:
        dataset._episode(index)
    for index in selected:
        start = dataset.ends[index - 1] if index else 0
        for offset in sorted({0, dataset.sample_lengths[index] // 2, dataset.sample_lengths[index] - 1}):
            sample = dataset[start + offset]
            assert torch.isfinite(sample.state).all() and torch.isfinite(sample.action).all()
            assert sample.action_mask.any() and sample.state_mask[:, -1].any()
            emit(episode=dataset.episodes[index]["episode_index"], frame=offset,
                 images=[list(x.shape) for x in sample.raw_vl.rgb],
                 state=list(sample.state.shape), action=list(sample.action.shape),
                 valid_action_steps=sample.action_mask[0].any(dim=-1).sum().item(),
                 gripper=sample.state[:, -1, 9].tolist())
    emit(status="data_ok", episodes=len(dataset.episodes), samples=len(dataset), fps=dataset.fps,
         numeric_episodes_checked=len(checked), camera_order=dataset.config.camera_keys,
         arm_order=["left", "right"], geometry_ready=dataset.config.geometry is not None)
    dataset.close()


class EpochBatchSampler(Sampler):
    """Shuffle deterministically, resume by consumed batches, independent of prefetch."""
    def __init__(self, size, batch_size, seed, epoch, start_batch=0, rank=0, world_size=1):
        if not 0 <= rank < world_size or min(size, batch_size, world_size) < 1:
            raise ValueError("Invalid distributed sampler shape/rank")
        self.size, self.batch_size = size, batch_size
        self.seed, self.epoch, self.start_batch = seed, epoch, start_batch
        self.rank, self.world_size = rank, world_size
        self.stopped = False

    def __iter__(self):
        indices = torch.randperm(self.size, generator=torch.Generator().manual_seed(self.seed + self.epoch))
        global_batch = self.batch_size * self.world_size
        for batch in range(self.start_batch, self.size // global_batch):
            if self.stopped:
                break
            start = batch * global_batch + self.rank * self.batch_size
            yield indices[start:start + self.batch_size].tolist()

    def __len__(self):
        return max(0, self.size // (self.batch_size * self.world_size) - self.start_batch)


def init_worker(worker_id):
    cv2.setNumThreads(1)
    torch.set_num_threads(1)
    seed = torch.initial_seed() % 2**32
    np.random.seed(seed)
    random.seed(seed)


class TrainingStream:
    def __init__(self, dataset, collator, batch_size, workers, seed, epoch=0, batch_in_epoch=0,
                 rank=0, world_size=1):
        if not hasattr(dataset, "group_ranges") and len(dataset) < batch_size * world_size:
            raise ValueError("Dataset must contain at least one full global batch")
        self.dataset, self.collator = dataset, collator
        self.batch_size, self.workers, self.seed = batch_size, workers, seed
        self.epoch, self.batch_in_epoch = epoch, batch_in_epoch
        self.rank, self.world_size = rank, world_size
        self.iterator = None
        self.batches_per_epoch = len(self._make_sampler(start_batch=0))
        if not 0 <= batch_in_epoch <= self.batches_per_epoch:
            raise ValueError("Resume batch is outside the training epoch")

    def _make_sampler(self, start_batch):
        sampler, indices = EpochBatchSampler, len(self.dataset)
        if hasattr(self.dataset, "group_ranges"):
            sampler, indices = BalancedGroupBatchSampler, self.dataset.group_ranges
        return sampler(indices, self.batch_size, self.seed, self.epoch, start_batch,
                       self.rank, self.world_size)

    def next(self):
        if self.batch_in_epoch == self.batches_per_epoch:
            self.epoch += 1
            self.batch_in_epoch = 0
            self.iterator = None
        if self.iterator is None:
            self.sampler = self._make_sampler(self.batch_in_epoch)
            kwargs = dict(
                dataset=self.dataset, collate_fn=self.collator, num_workers=self.workers,
                batch_sampler=self.sampler,
                pin_memory=True, worker_init_fn=init_worker,
                generator=torch.Generator().manual_seed(self.seed + self.epoch + self.rank),
            )
            if self.workers:
                kwargs.update(multiprocessing_context="spawn", prefetch_factor=2)
            self.iterator = iter(DataLoader(**kwargs))
        result = next(self.iterator)
        self.batch_in_epoch += 1
        return result

    def close(self):
        # Drain already-prefetched results before normal DataLoader shutdown.
        # Stopping with tensor transfers still queued can abort native worker
        # threads. The stopped sampler prevents scheduling any more batches.
        if self.iterator is not None:
            self.sampler.stopped = True
            for _ in self.iterator:
                pass
            self.iterator = None
        self.dataset.close()


def lr_multiplier(step, warmup, total):
    if step < warmup:
        return (step + 1) / max(1, warmup)
    progress = (step - warmup) / max(1, total - warmup)
    return 0.5 * (1 + math.cos(math.pi * min(progress, 1)))


def rng_state():
    return dict(python=random.getstate(), numpy=np.random.get_state(), torch=torch.get_rng_state(),
                cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None)


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if state["cuda"] is not None:
        torch.cuda.set_rng_state_all(state["cuda"])


def check_resume(checkpoint, data_config, model_config, train_config):
    if checkpoint.get("format") != "lerobot_original_v1":
        raise ValueError("--resume requires a lerobot_original_v1 checkpoint; previous customized checkpoints are incompatible with the original model")
    saved = dict(checkpoint["data_config"])
    current = asdict(data_config)
    # Moving identical data or changing cache sizes does not change target semantics.
    for key in ("root", "cache_episodes", "cache_videos"):
        saved.pop(key)
        current.pop(key)
    if saved != current:
        raise ValueError("Resume data conventions differ (camera/arm order, units, transforms, or horizon)")
    if checkpoint["model_config"] != model_config or checkpoint["train_config"] != train_config:
        raise ValueError("Resume model/training options differ; reuse the original options")


def save_checkpoint(path, model, optimizer, scheduler, step, stream, data_config, model_config, train_config):
    """Legacy actor-only format, retained for frozen-Qwen compatibility."""
    if hasattr(model, "vlm") and any(p.requires_grad for p in model.vlm.parameters()):
        raise ValueError("Trainable Qwen requires save_full_checkpoint; actor-only saving would lose weights")
    payload = dict(format="lerobot_original_v1", variant="original_vla_lerobot", actor=model.actor.state_dict(),
                   optimizer=optimizer.state_dict(), scheduler=scheduler.state_dict(), step=step,
                   epoch=stream.epoch, batch_in_epoch=stream.batch_in_epoch,
                   data_config=asdict(data_config), model_config=model_config,
                   train_config=train_config, rng=rng_state())
    temporary = path.with_suffix(".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)
    emit(checkpoint=str(path), step=step)


def parser(distributed_defaults=True):
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--data-config", type=Path, default=DEFAULT_CONFIG)
    result.add_argument("--data-root", help="Override only the root in the JSON config")
    result.add_argument("--geometry-config", type=Path,
                        help="Separate calibration JSON: base_to_world, geometry, optional pose_to_tcp")
    result.add_argument("--check-data", action="store_true", help="Read real data without loading Qwen")
    result.add_argument("--check-all-episodes", action="store_true", help="Check every Parquet's numeric fields")
    result.add_argument("--model", choices=["base", "large", "huge"], default="base")
    result.add_argument("--inference-timesteps", type=int, default=4)
    result.add_argument("--batch-size", type=int, default=8 if distributed_defaults else 32,
                        help="Samples per GPU; default full-Qwen global batch is 8 x 4 = 32")
    result.add_argument("--gradient-accumulation-steps", type=int, default=1)
    result.add_argument("--n-repeats", type=int, default=1)
    result.add_argument("--workers", type=int, default=4)
    result.add_argument("--threads", type=int, default=4)
    result.add_argument("--conv3d-memory-format", choices=["channels_last_3d", "contiguous"],
                        default="channels_last_3d",
                        help="Weight storage layout only; keeps the original Conv3d and model structure")
    result.add_argument("--max-steps", type=int, default=100000, help="Optimizer updates, not microbatches")
    result.add_argument("--lr", type=float, default=1e-4)
    result.add_argument("--weight-decay", type=float, default=1e-5)
    result.add_argument("--warmup-steps", type=int, default=2000)
    result.add_argument("--grad-clip", type=float, default=1.0)
    result.add_argument("--seed", type=int, default=42)
    result.add_argument("--device", default="cuda:0")
    result.add_argument("--save-every", type=int, default=10000 if distributed_defaults else 2000)
    result.add_argument("--log-every", type=int, default=10)
    result.add_argument("--output", type=Path, default=Path("checkpoints/lerobot_original_full_reviewed"
                        if distributed_defaults else "checkpoints/lerobot_original_close_box"))
    result.add_argument("--resume", type=Path)
    if distributed_defaults:
        result.add_argument("--nproc-per-node", type=int, default=4,
                            help="Automatically launch torchrun when invoked with python")
        result.add_argument("--train-qwen", action=argparse.BooleanOptionalAction, default=True)
        result.add_argument("--optimizer-sharding", choices=["zero1", "none"], default="zero1")
    return result


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    args = parser().parse_args(argv)
    positive = (args.batch_size, args.gradient_accumulation_steps, args.n_repeats, args.max_steps,
                args.threads, args.inference_timesteps, args.log_every, args.save_every, args.nproc_per_node)
    if min(positive) < 1 or args.workers < 0 or args.warmup_steps < 0 or args.lr <= 0 or args.grad_clip <= 0:
        raise ValueError("Invalid training counts or optimizer settings")
    if args.check_all_episodes and not args.check_data:
        raise ValueError("--check-all-episodes requires --check-data")
    if not args.check_data and "RANK" not in os.environ and args.nproc_per_node > 1:
        if torch.cuda.device_count() < args.nproc_per_node:
            raise RuntimeError(f"Need {args.nproc_per_node} visible CUDA GPUs; use --nproc-per-node to override")
        subprocess.run([sys.executable, "-m", "torch.distributed.run", "--standalone",
                        f"--nproc_per_node={args.nproc_per_node}", "--module",
                        "models.m0512_fm.train_lerobot_dual", *argv], check=True)
        return
    torch.set_num_threads(args.threads)
    cv2.setNumThreads(1)
    dataset, stream = None, None
    try:
        device = torch.device(args.device)
        if not args.check_data:
            if "LOCAL_RANK" in os.environ:
                device = torch.device("cuda", int(os.environ["LOCAL_RANK"]))
            if device.type != "cuda" or not torch.cuda.is_available():
                raise RuntimeError("Training requires CUDA; --check-data works on CPU")
            torch.cuda.set_device(device)
            if not torch.cuda.is_bf16_supported():
                raise RuntimeError("Training requires BF16 support")
            if int(os.environ.get("WORLD_SIZE", "1")) > 1:
                dist.init_process_group("nccl", timeout=timedelta(minutes=30), device_id=device)
        from .lerobot_distributed import (rank_world, make_optimizers, save_full_checkpoint,
            read_full_checkpoint, restore_full_checkpoint)
        from dataset.lerobot_reviewed import build_dataset
        rank, world = rank_world()
        config = LeRobotDualConfig.load(args.data_config, root=args.data_root, geometry_config=args.geometry_config)
        emit(status="loading_data", root=config.root, world_size=world)
        dataset = build_dataset(config)
        if hasattr(dataset, "group_ranges"):
            sampler = BalancedGroupBatchSampler(dataset.group_ranges, args.batch_size, args.seed, 0,
                                                world_size=args.nproc_per_node if args.check_data else world)
            emit(status="sampling_config", **dataset.sampling_summary,
                 batches_per_epoch=len(sampler), global_microbatch=sampler.global_batch)
        if args.check_data:
            check_data(dataset, args.check_all_episodes)
            return
        dataset.require_geometry()
        if args.output.exists() and any(args.output.iterdir()) and args.resume is None:
            raise FileExistsError("Output is nonempty; use --resume or a new --output directory")
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        from transformers import Qwen3VLProcessor
        model_config = dict(model=args.model, inference_timesteps=args.inference_timesteps,
                            train_qwen=args.train_qwen)
        train_keys = ("batch_size", "gradient_accumulation_steps", "n_repeats", "max_steps", "lr",
                      "weight_decay", "warmup_steps", "grad_clip", "seed", "optimizer_sharding")
        train_config = {key: getattr(args, key) for key in train_keys}
        train_config["world_size"] = world
        if hasattr(dataset, "sampling_mode"):
            train_config["sampling"] = dataset.sampling_mode
        fingerprint = getattr(dataset, "fingerprint", None)
        if fingerprint is None:
            fingerprint = hashlib.sha256(b"".join((Path(config.root) / "meta" / name).read_bytes()
                         for name in ("info.json", "episodes.jsonl", "tasks.jsonl"))).hexdigest()
        checkpoint = local = None
        if args.resume:
            checkpoint, local = read_full_checkpoint(args.resume, config, model_config, train_config, fingerprint)
            if checkpoint["step"] >= args.max_steps:
                emit(status="already_complete", step=checkpoint["step"])
                return
        processor = Qwen3VLProcessor.from_pretrained("Qwen/Qwen3-VL-2B-Instruct")
        collator = LeRobotDualCollator(processor)
        collator([dataset[0]])
        dataset.close()
        model = build_model(**model_config).to(device).train()
        runtime_config = configure_conv3d_layout(model, args.conv3d_memory_format)
        distributed_model = (DistributedDataParallel(model, device_ids=[device.index],
                             find_unused_parameters=True, gradient_as_bucket_view=True)
                             if world > 1 else model)
        optimizers = make_optimizers(model, args.lr, args.weight_decay, args.optimizer_sharding)
        schedulers = [torch.optim.lr_scheduler.LambdaLR(opt,
                      lambda step: lr_multiplier(step, args.warmup_steps, args.max_steps)) for opt in optimizers]
        start_step, epoch, batch_in_epoch = 0, 0, 0
        # Shared initialization, independent diffusion noise per rank thereafter.
        random.seed(args.seed + rank)
        np.random.seed(args.seed + rank)
        torch.manual_seed(args.seed + rank)
        if checkpoint:
            restore_full_checkpoint(checkpoint, local, model, optimizers, schedulers)
            start_step, epoch, batch_in_epoch = (checkpoint[k] for k in ("step", "epoch", "batch_in_epoch"))
            del checkpoint, local
        stream = TrainingStream(dataset, collator, args.batch_size, args.workers, args.seed,
                                epoch, batch_in_epoch, rank, world)
        if rank == 0:
            args.output.mkdir(parents=True, exist_ok=True)
            run_config = dict(data=asdict(config), model=model_config, train=train_config,
                              runtime=runtime_config, dataset_fingerprint=fingerprint)
            if hasattr(dataset, "sampling_summary"):
                run_config["sampling"] = dataset.sampling_summary
            (args.output / "config.json").write_text(json.dumps(run_config, ensure_ascii=False, indent=2))
        if world > 1:
            dist.barrier()
        emit(status="training", variant="original_vla_full_qwen", gpu=torch.cuda.get_device_name(device),
             **runtime_config, world_size=world, per_gpu_batch=args.batch_size,
             trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
             frozen_parameters=sum(p.numel() for p in model.parameters() if not p.requires_grad),
             effective_sample_batch=args.batch_size * args.gradient_accumulation_steps * world,
             qwen_trainable=args.train_qwen, lora=False,
             optimizer_sharding=args.optimizer_sharding if world > 1 else "none",
             noise_repeats=args.n_repeats, episodes=len(dataset.episodes), samples=len(dataset))
        trainable = [p for p in model.parameters() if p.requires_grad]
        torch.cuda.reset_peak_memory_stats(device)
        started = time.monotonic()
        interval_seconds, interval_wait, interval_steps = 0., 0., 0
        for step in range(start_step + 1, args.max_steps + 1):
            step_started, data_wait = time.monotonic(), 0.
            for optimizer in optimizers:
                optimizer.zero_grad(set_to_none=True)
            metrics_sum = {}
            for microbatch in range(args.gradient_accumulation_steps):
                waiting = time.monotonic()
                raw_batch = stream.next()
                data_wait += time.monotonic() - waiting
                batch = BatchDataTokenizedVLA(**raw_batch).to(device, non_blocking=True)
                sync = (distributed_model.no_sync() if world > 1 and
                        microbatch < args.gradient_accumulation_steps - 1 else nullcontext())
                with sync:
                    loss, metrics = distributed_model(batch, inference=False, fp16=True, n_repeats=args.n_repeats)
                    finite = torch.isfinite(loss.detach()).to(torch.int32)
                    if world > 1:
                        dist.all_reduce(finite, op=dist.ReduceOp.MIN)
                    if not finite.item():
                        raise FloatingPointError(f"Nonfinite loss at step {step}")
                    (loss / args.gradient_accumulation_steps).backward()
                for key, value in {"loss": loss, **metrics}.items():
                    value = float(value.detach()) if torch.is_tensor(value) else float(value)
                    metrics_sum[key] = metrics_sum.get(key, 0.) + value / args.gradient_accumulation_steps
                del raw_batch, batch, loss, metrics
            norm = torch.nn.utils.clip_grad_norm_(trainable, args.grad_clip, error_if_nonfinite=True)
            used_lr = optimizers[0].param_groups[0]["lr"]
            for optimizer, scheduler in zip(optimizers, schedulers):
                optimizer.step()
                scheduler.step()
            torch.cuda.synchronize(device)
            seconds = time.monotonic() - step_started
            interval_seconds += seconds
            interval_wait += data_wait
            interval_steps += 1
            if step == start_step + 1 or step % args.log_every == 0:
                keys = sorted(metrics_sum)
                values = torch.tensor([metrics_sum[k] for k in keys], device=device)
                if world > 1:
                    dist.all_reduce(values)
                    values /= world
                emit(step=step, epoch=stream.epoch, lr=used_lr, grad_norm=float(norm),
                     **dict(zip(keys, values.tolist())), elapsed_seconds=round(time.monotonic() - started, 2),
                     step_seconds=round(seconds, 3), data_wait_seconds=round(data_wait, 3),
                     average_step_seconds=round(interval_seconds / interval_steps, 3),
                     average_data_wait_seconds=round(interval_wait / interval_steps, 3),
                     peak_allocated_GiB=round(torch.cuda.max_memory_allocated(device) / 2**30, 3),
                     peak_reserved_GiB=round(torch.cuda.max_memory_reserved(device) / 2**30, 3))
                interval_seconds, interval_wait, interval_steps = 0., 0., 0
            if step % args.save_every == 0 or step == args.max_steps:
                path = args.output / f"step_{step:07d}"
                save_full_checkpoint(path, model, optimizers, schedulers, step, stream,
                                     config, model_config, train_config, fingerprint)
                emit(checkpoint=str(path), step=step, includes="Qwen + actor + optimizer shards + per-rank RNG")
    finally:
        if stream is not None:
            stream.close()
        elif dataset is not None:
            dataset.close()
        if dist.is_initialized():
            dist.destroy_process_group()


if __name__ == "__main__":
    main()
