import math
import torch
from torch import nn, Tensor
from einops import rearrange
from dataclasses import dataclass


class PositionalEmbedding(nn.Module):

    def generate(self, pos_low_dim: Tensor):
        raise NotImplementedError
    
    @classmethod
    def embed_q(cls, q: Tensor, pe: Tensor):
        raise NotImplementedError
    
    @classmethod
    def embed_k(cls, k: Tensor, pe: Tensor):
        raise NotImplementedError
    
    @classmethod
    def embed_v(cls, v: Tensor, pe: Tensor):
        raise NotImplementedError
    
    @classmethod
    def embed_o(cls, o: Tensor, pe: Tensor):
        raise NotImplementedError


class Noop(PositionalEmbedding):
    """Do nothing"""
    @classmethod
    def embed_q(cls, q: Tensor, pe: Tensor):
        return q
    
    @classmethod
    def embed_k(cls, k: Tensor, pe: Tensor):
        return k
    
    @classmethod
    def embed_v(cls, v: Tensor, pe: Tensor):
        return v
    
    @classmethod
    def embed_o(cls, o: Tensor, pe: Tensor):
        return o


class SinusoidalPosEmbed(PositionalEmbedding):
    """sin-cos positional encoding"""
    def __init__(self, dim, temperature=1e4):
        super().__init__()
        self.dim = dim
        self.temperature = temperature
    
    @torch.no_grad()
    def generate(self, x: Tensor):
        device = x.device
        half_dim = self.dim // 2
        emb = math.log(self.temperature) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=device) * -emb)
        emb = x[:, None] * emb[None, :]
        emb = torch.cat((emb.sin(), emb.cos()), dim=-1)
        return emb


class SinusoidalPosEmbedPi0(nn.Module):
    def __init__(self, dimension: int, min_period: float, max_period: float):
        super().__init__()
        self.dimension = dimension
        self.min_period = min_period
        self.max_period = max_period
    
    def generate(self, time: Tensor):
        """Computes sine-cosine positional embedding vectors for scalar positions."""
        if self.dimension % 2 != 0:
            raise ValueError(f"dimension ({self.dimension}) must be divisible by 2")

        if time.ndim != 1:
            raise ValueError("The time tensor is expected to be of shape `(batch_size, )`.")

        fraction = torch.linspace(0.0, 1.0, self.dimension // 2, device=time.device)
        period = self.min_period * (self.max_period / self.min_period) ** fraction

        # Compute the outer product
        scaling_factor = 1.0 / period * 2 * torch.pi
        sin_input = scaling_factor[None, :] * time[:, None]
        return torch.cat([torch.sin(sin_input), torch.cos(sin_input)], dim=1)


class mRoPE(PositionalEmbedding):
    """multimodal-RoPE"""
    def __init__(self, pos_dim, head_dim, temperature=1e4):
        super().__init__()
        self.pos_dim = pos_dim
        self.head_dim = head_dim
        self.temperature = temperature
    
    @torch.no_grad()
    def generate(self, x: Tensor):
        """
        Arguments:
        - x: (..., pos_dim)

        Returns:
        - pe: (..., head_dim, 2)
        """
        # B, L, PD = x.size()
        PD = x.shape[-1]
        assert PD == self.pos_dim

        HD = self.head_dim
        div_term = torch.exp(
            torch.arange(0, HD // PD, 2, dtype=torch.float, device=x.device)
            * (-math.log(self.temperature) / (HD // PD))
        )  # (hd//pd/2,)

        x = x.unsqueeze(-1)  # (..., pd, 1)
        sinx = torch.sin(x * div_term)  # (..., pd, hd//pd/2)
        cosx = torch.cos(x * div_term)  # (..., pd, hd//pd/2)

        sinx = sinx.repeat_interleave(2, dim=-1)  # (..., pd, hd//pd)
        cosx = cosx.repeat_interleave(2, dim=-1)  # (..., pd, hd//pd)

        sinx = sinx.flatten(-2)  # (..., pd, hd//pd) -> (..., hd)
        cosx = cosx.flatten(-2)  # (..., pd, hd//pd) -> (..., hd)
        position_code = torch.stack([cosx, sinx], dim=-1)  # (..., hd, 2)
        return position_code
    
    @classmethod
    def embed_rotary(cls, x: Tensor, pe: Tensor):
        """
        - x: (batch_size, num_heads, length, head_dim)
        - pe: (batch_size, length, head_dim, 2)
        """
        assert x.shape[-2:] == pe.shape[-3:-1]
        if x.dim() == 4: pe = pe.unsqueeze(1)  # (batch_size, 1, length, head_dim, 2)
        
        original_dtype = x.dtype
        x = x.type_as(pe)
        
        cos, sin = pe.unbind(-1)
        x2 = torch.stack([-x[..., 1::2], x[..., ::2]], dim=-1).reshape_as(x)
        x = x * cos + x2 * sin
        
        return x.to(original_dtype)
    
    @classmethod
    def embed_q(cls, q, pe):
        return cls.embed_rotary(q, pe)

    @classmethod
    def embed_k(cls, k, pe):
        return cls.embed_rotary(k, pe)
    
    @classmethod
    def embed_v(cls, v, pe):
        return v  # identity
    
    @classmethod
    def embed_o(cls, o, pe):
        return o  # identity


class cRoPE(PositionalEmbedding):
    """camera extrinsic as relative positional encoding"""
    def generate(self, wcT: Tensor):
        """
        Args:
            wcT (Tensor): ^{world} _{camera} T, camera pose under world
        """
        # 求逆后暂存一下
        cwT = torch.inverse(wcT)
        return torch.stack([cwT, wcT], dim=0)  # (2, ..., 4, 4)
    
    @classmethod
    def embed_q(cls, q: Tensor, pe: Tensor):
        """
        Args:
            q: (B, NH, Lq, HD)
            pe: [cwT, wcT], (2, B, Lq, 4, 4)
                * cwT: (B, Lq, 4, 4), Gi, world to camera
                * wcT: (B, Lq, 4, 4), Gj^{-1}, camera to world
        """
        cwT, wcT = pe
        # gi^T @ qi -> Q @ gi
        q = rearrange(q, "b h l (d f) -> b h l d f", f=4)
        q = q @ cwT.unsqueeze(1)  # (B, H, Lq, D//4, 4)
        q = rearrange(q, "b h l d f -> b h l (d f)")
        return q
    
    @classmethod
    def embed_k(cls, k: Tensor, pe: Tensor):
        """
        Args:
            k: (B, NH, Lk, HD)
            pe: [cwT, wcT], (2, B, Lk, 4, 4)
                * cwT: (B, Lk, 4, 4), Gi, world to camera
                * wcT: (B, Lk, 4, 4), Gj^{-1}, camera to world
        """
        cwT, wcT = pe
        # gj^{-1} @ kj -> K @ gj^{-1}^T
        k = rearrange(k, "b h l (d f) -> b h l d f", f=4)
        k = k @ wcT.unsqueeze(1).transpose(-1, -2)  # (B, H, Lk, D//4, 4)
        k = rearrange(k, "b h l d f -> b h l (d f)")
        return k
    
    @classmethod
    def embed_v(cls, v: Tensor, pe: Tensor):
        """
        Args:
            v: (B, NH, Lk, HD)
            pe: [cwT, wcT], (2, B, Lk, 4, 4)
                * cwT: (B, Lk, 4, 4), Gi, world to camera
                * wcT: (B, Lk, 4, 4), Gj^{-1}, camera to world
        """
        return cls.embed_k(v, pe)
    
    @classmethod
    def embed_o(cls, o: Tensor, pe: Tensor):
        """
        Args:
            o: (B, NH, Lo, HD)
            pe: [cwT, wcT], (2, B, Lq, 4, 4)
                * cwT: (B, Lq, 4, 4), Gi, world to camera
                * wcT: (B, Lq, 4, 4), Gj^{-1}, camera to world
        """
        cwT, wcT = pe
        # gi @ oi -> O @ gi^T
        o = rearrange(o, "b h l (d f) -> b h l d f", f=4)
        o = o @ cwT.unsqueeze(1).transpose(-1, -2)
        o = rearrange(o, "b h l d f -> b h l (d f)")
        return o


@dataclass
class PEData(object):
    impl: PositionalEmbedding
    pe: Tensor  # 由generate()函数生成的位置编码
    d: int      # 位置编码所占用的feature dimension维数


class HybridPE(PositionalEmbedding):

    @classmethod
    def _embed_x(cls, x: Tensor, method: str, *pe: PEData):
        """
        Args:
            x (Tensor): (B, H, L, HD)
            method (str): "embed_q" | "embed_k" | "embed_v" | "embed_o"
            pe (PEData): variable length positional encodings
        
        Returns:
            x (Tensor): (B, H, L, HD)
        """
        head_dim = x.shape[-1]
        if len(pe) == 0:
            return x  # no pe
        
        # 如果仅有一种位置编码且占用所有的feature dimension，则直接调用
        if len(pe) == 1 and pe[0].d == head_dim:
            return getattr(pe[0].impl, method)(x, pe[0].pe)
        
        split_size = [_pe.d for _pe in pe]
        occupied_d = sum(split_size)
        if occupied_d < head_dim:
            # 如不足，则补全，补全部分的feature不会被编码位置，相当于identity mapping
            split_size.append(head_dim - occupied_d)
        
        x_chunks = list(torch.split(x, split_size, dim=-1))
        for i in range(len(pe)):
            x_chunks[i] = getattr(pe[i].impl, method)(x_chunks[i], pe[i].pe)
        return torch.cat(x_chunks, dim=-1)

    @classmethod
    def embed_q(cls, q: Tensor, *pe: PEData):
        return cls._embed_x(q, "embed_q", *pe)
    
    @classmethod
    def embed_k(cls, k: Tensor, *pe: PEData):
        return cls._embed_x(k, "embed_k", *pe)
    
    @classmethod
    def embed_v(cls, v: Tensor, *pe: PEData):
        return cls._embed_x(v, "embed_v", *pe)
    
    @classmethod
    def embed_o(cls, o: Tensor, *pe: PEData):
        return cls._embed_x(o, "embed_o", *pe)
