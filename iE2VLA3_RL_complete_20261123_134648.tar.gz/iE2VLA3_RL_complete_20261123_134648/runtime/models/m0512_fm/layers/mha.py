import math
import torch
import torch.nn.functional as F

from einops import rearrange
from torch import nn, Tensor
from enum import IntFlag, auto
from dataclasses import dataclass
from typing import Optional, Union, Iterable


from .norm import RMSNorm
from .pe import PEData, HybridPE


@dataclass
class KVCache(object):
    k: Optional[Tensor] = None  # shape (B, H, Lc, HD)
    v: Optional[Tensor] = None  # shape (B, H, Lc, HD)


class ProjOpt(IntFlag):
    QK = auto()  # use 1 linear layer, to_qk, note v is not projected
    QKV = auto()  # use 1 linear layer: to_qkv
    Q_KV = auto()  # use 2 linear layers: to_q, to_kv
    Q_K_V = auto()  # use 3 linear layers: to_q, to_k, to_v
    DEFAULT = Q_K_V


class MySimpleMHA(nn.Module):
    def __init__(
        self, 
        embed_dim, 
        num_heads, 
        dropout=0., 
        kdim=None, 
        vdim=None, 
        proj_opt=ProjOpt.DEFAULT, 
        flash=True,
        bias=False,
        qk_norm=False,
        gate=False,
    ):
        super().__init__()
        assert embed_dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.kdim = embed_dim if kdim is None else kdim
        self.vdim = embed_dim if vdim is None else vdim
        self.dropout = dropout
        self.flash = flash
        self.qk_norm = qk_norm
        self.gate = gate

        extra = 1 if self.gate else 0
        self.proj_opt = proj_opt
        if proj_opt == ProjOpt.QKV:
            self.to_qkv = nn.Linear(embed_dim, (3+extra)*embed_dim, bias=bias)
        elif proj_opt == ProjOpt.Q_KV:
            self.to_q = nn.Linear(embed_dim, (1+extra)*embed_dim, bias=bias)
            self.to_kv = nn.Linear(self.kdim, 2*embed_dim, bias=bias)
        elif proj_opt == ProjOpt.Q_K_V:
            self.to_q = nn.Linear(embed_dim, (1+extra)*embed_dim, bias=bias)
            self.to_k = nn.Linear(self.kdim, embed_dim, bias=bias)
            self.to_v = nn.Linear(self.vdim, embed_dim, bias=bias)
        elif proj_opt == ProjOpt.QK:
            self.to_qk = nn.Linear(embed_dim, (2+extra)*embed_dim, bias=bias)
        
        if self.qk_norm:
            self.q_norm = RMSNorm(self.head_dim)
            self.k_norm = RMSNorm(self.head_dim)

        self.to_out = nn.Linear(embed_dim, embed_dim, bias=bias)

    @classmethod
    def check_expand_attn_mask(cls, attn_mask: Tensor, B_H_Lx_Lc):
        """
        Arguments:
        - attn_mask: (B, Lc) or (B, Lx, Lc) or (B, H, Lx, Lc)
        - B_H_Lx_Lc: tuple of ints, (B, H, Lx, Lc)

        Returns:
        - attn_mask: (B, H, Lx, Lc)
        """
        if attn_mask is not None:
            B, H, Lx, Lc = B_H_Lx_Lc
            attn_dim = attn_mask.dim()
            assert attn_dim in (2, 3, 4)
            if attn_dim == 2:
                assert attn_mask.shape == (B, Lc), \
                    "attn_mask shape = {}, (B, Lc) = ({}, {})".format(attn_mask.shape, B, Lc)
                attn_mask = attn_mask[:, None, None, :].expand(B, H, Lx, Lc)
            elif attn_dim == 3:
                assert attn_mask.shape == (B, Lx, Lc), \
                    "attn_mask shape = {}, (B, Lx, Lc) = ({}, {}, {})".format(attn_mask.shape, B, Lx, Lc)
                attn_mask = attn_mask[:, None, :, :].expand(B, H, Lx, Lc)
            elif attn_dim == 4:
                assert attn_mask.shape == (B, H, Lx, Lc), \
                    "attn_mask shape = {}, (B, H, Lx, Lc) = ({}, {}, {})".format(attn_mask.shape, B, H, Lx, Lc)
        return attn_mask

    def _project_qwkv(self, x: Tensor, c: Tensor):
        if self.proj_opt == ProjOpt.QKV:
            assert x is c, "id(x) = {:x}, id(c) = {:x}".format(id(x), id(c))
            qwkv = rearrange(self.to_qkv(x), "b l (n h c) -> b h n l c", n=4, h=self.num_heads)
            q, w, k, v = torch.unbind(qwkv, dim=2)
        elif self.proj_opt == ProjOpt.Q_KV:
            qw = rearrange(self.to_q(x), "b l (n h c) -> b h n l c", n=2, h=self.num_heads)
            kv = rearrange(self.to_kv(c), "b l (n h c) -> b h n l c", n=2, h=self.num_heads)
            q, w = torch.unbind(qw, dim=2)
            k, v = torch.unbind(kv, dim=2)
        elif self.proj_opt == ProjOpt.Q_K_V:
            qw = rearrange(self.to_q(x), "b l (n h c) -> b h n l c", n=2, h=self.num_heads)
            k = rearrange(self.to_k(c), "b l (h c) -> b h l c", h=self.num_heads)
            v = rearrange(self.to_v(c), "b l (h c) -> b h l c", h=self.num_heads)
            q, w = torch.unbind(qw, dim=2)
        elif self.proj_opt == ProjOpt.QK:
            qwk = rearrange(self.to_qk(x), "b l (n h c) -> b h n l c", n=3, h=self.num_heads)
            q, w, k = torch.unbind(qwk, dim=2)
            v = rearrange(c, "b l (h c) -> b h l c", h=self.num_heads)
        else:
            raise ValueError("Unknown projection option: {}".format(self.proj_opt))
        
        if self.qk_norm:
            q = self.q_norm(q)
            k = self.k_norm(k)
        
        return q, w, k, v
    
    def _project_qkv(self, x: Tensor, c: Tensor):
        if self.proj_opt == ProjOpt.QKV:
            assert x is c, "id(x) = {:x}, id(c) = {:x}".format(id(x), id(c))
            qkv = rearrange(self.to_qkv(x), "b l (n h c) -> b h n l c", n=3, h=self.num_heads)
            q, k, v = torch.unbind(qkv, dim=2)
        elif self.proj_opt == ProjOpt.Q_KV:
            q = rearrange(self.to_q(x), "b l (h c) -> b h l c", h=self.num_heads)
            kv = rearrange(self.to_kv(c), "b l (n h c) -> b h n l c", n=2, h=self.num_heads)
            k, v = torch.unbind(kv, dim=2)
        elif self.proj_opt == ProjOpt.Q_K_V:
            q = rearrange(self.to_q(x), "b l (h c) -> b h l c", h=self.num_heads)
            k = rearrange(self.to_k(c), "b l (h c) -> b h l c", h=self.num_heads)
            v = rearrange(self.to_v(c), "b l (h c) -> b h l c", h=self.num_heads)
        elif self.proj_opt == ProjOpt.QK:
            qk = rearrange(self.to_qk(x), "b l (n h c) -> b h n l c", n=2, h=self.num_heads)
            q, k = torch.unbind(qk, dim=2)
            v = rearrange(c, "b l (h c) -> b h l c", h=self.num_heads)
        else:
            raise ValueError("Unknown projection option: {}".format(self.proj_opt))
        
        if self.qk_norm:
            q = self.q_norm(q)
            k = self.k_norm(k)
        
        return q, None, k, v
    
    def project_qkv(self, x: Tensor, c: Tensor):
        if self.gate:
            return self._project_qwkv(x, c)
        else:
            return self._project_qkv(x, c)

    def forward(
        self, 
        x: Tensor, 
        c: Tensor, 
        x_pe: Optional[Union[PEData, Iterable[PEData]]] = None, 
        c_pe: Optional[Union[PEData, Iterable[PEData]]] = None, 
        attn_mask: Optional[Tensor] = None,
        return_attn_weights = False,
        average_attn_weights = True,
        kv_cache: Optional[KVCache] = None,
        update_cache: bool = True,
    ):
        """
        Arguments:
        - x: (B, Lx, C)
        - c: (B, Lc, C), context
        - x_pe (PEData): pos embedding of q
        - c_pe (PEData): pos embedding of kv
        - attn_mask: (B, Lc) or (B, Lx, Lc) or (B, NH, Lx, Lc)
            * if boolean: then attn_bias at attn_mask will be -inf
            * if float/double: then attn_bias will be attn_mask
        - return_attn_weights: bool
        - average_attn_weights: bool
        - kv_cache (KVCache): 
        - update_cache (bool): 

        Returns:
        - out: (B, Lx, C)
        - attn_weight: (B, Lx, Lc) if average_attn_weights 
                  else (B, H, Lx, Lc)
        - attn_mask: (B, NH, Lx, Lc)
        """
        use_sdpa = self.flash and (not return_attn_weights)
        attn_impl = self._attn_impl_sdpa if use_sdpa else self._attn_impl_eager

        q, w, k, v = self.project_qkv(x, c)
        q, k, v = self.embed_qkv(q, k, v, x_pe, c_pe)
        
        if kv_cache is not None:
            if kv_cache.k is not None and kv_cache.v is not None:
                k = torch.cat([kv_cache.k, k], dim=2)
                v = torch.cat([kv_cache.v, v], dim=2)
            if update_cache:
                kv_cache.k = k
                kv_cache.v = v
        
        out, attn_weight, attn_mask = attn_impl(
            q, k, v,
            training=self.training,
            attn_mask=attn_mask,
            drop_attn=self.dropout,
            return_attn_weights=return_attn_weights, 
            average_attn_weights=average_attn_weights
        )

        out = self.embed_o(out, x_pe)
        if self.gate:
            out = out * w.sigmoid()  # qwen's gated attention, NIPS 2025's best paper
        out = rearrange(out, "b h l c -> b l (h c)", h=self.num_heads)
        out = self.to_out(out)

        return out, attn_weight, attn_mask
    
    @classmethod
    def _attn_impl_eager(
        cls,
        q: Tensor, 
        k: Tensor, 
        v: Tensor, 
        training: bool, 
        attn_mask: Tensor = None, 
        drop_attn: float = 0.0, 
        return_attn_weights = False,
        average_attn_weights = True,
    ):
        B, H, Lq, D = q.shape
        B, H, Lk, _ = k.shape
        
        attn_mask = cls.check_expand_attn_mask(attn_mask, (B, H, Lq, Lk))
        corr: Tensor = (q @ k.transpose(-1, -2)) / (D ** 0.5)  # (B, H, Lx, Lc)
        if attn_mask is not None:
            if attn_mask.dtype == torch.bool:
                corr = corr.masked_fill(attn_mask.logical_not(), float("-inf"))
            else:
                corr = corr + attn_mask
        corr = corr - corr.amax(dim=-1, keepdim=True).detach()  # (B, H, Lx, Lc)
        attn_weight = torch.softmax(corr, dim=-1)
        attn_weight = attn_weight.masked_fill(attn_weight.isnan(), 0.)  # nan occurs if one row is fully masked out
        attn_weight = torch.dropout(attn_weight, drop_attn, training)
        out = attn_weight @ v  # (B, H, Lx, HD)

        if return_attn_weights and average_attn_weights:
            if H == 1:
                attn_weight = attn_weight.squeeze(1)
            else:
                attn_weight = attn_weight.mean(1)  # (B, Lx, Lc)
        else:
            attn_weight = None
        
        return out, attn_weight, attn_mask
    
    @classmethod
    def _attn_impl_sdpa(
        cls,
        q: Tensor, 
        k: Tensor, 
        v: Tensor, 
        training: bool, 
        attn_mask: Tensor = None, 
        drop_attn: float = 0.0, 
        **kwargs,  # compatibility with interface of _attn_impl_eager
    ):
        B, H, Lq, D = q.shape
        B, H, Lk, _ = k.shape
        
        attn_mask = cls.check_expand_attn_mask(attn_mask, (B, H, Lq, Lk))
        out = F.scaled_dot_product_attention(
            q, k, v,
            attn_mask = attn_mask,
            dropout_p = drop_attn if training else 0., 
            is_causal = False
        )
        out = out.masked_fill(out.isnan(), 0.)  # nan occurs if one row is fully masked out
        attn_weight = None
        return out, attn_weight, attn_mask
    
    def embed_qkv(
        self, 
        q: Tensor, k: Tensor, v: Tensor, 
        x_pe: Optional[Union[PEData, Iterable[PEData]]] = None, 
        c_pe: Optional[Union[PEData, Iterable[PEData]]] = None, 
    ):
        if x_pe is not None:
            if isinstance(x_pe, PEData):
                x_pe = (x_pe,)
            q = HybridPE.embed_q(q, *x_pe)
        
        if c_pe is not None:
            if isinstance(c_pe, PEData):
                c_pe = (c_pe,)
            k = HybridPE.embed_k(k, *c_pe)
            v = HybridPE.embed_v(v, *c_pe)
        
        return q, k, v
    
    def embed_o(
        self, 
        o: Tensor, 
        x_pe: Optional[Union[PEData, Iterable[PEData]]] = None, 
    ):
        if x_pe is not None:
            if isinstance(x_pe, PEData):
                x_pe = (x_pe,)
            o = HybridPE.embed_o(o, *x_pe)
        
        return o



def test_rope():
    import pypose as pp
    from .pe import mRoPE, cRoPE

    torch.set_default_device("cuda:0")
    torch.set_default_dtype(torch.float64)
    torch.manual_seed(0)

    B, L, C = 32, 1024, 256
    H = 4  # num of heads

    x = torch.randn(B, L, C)
    pos3d = torch.rand((B, L, 3)) * L       # (B, L, 3)
    poses = pp.randn_SE3((B, L)).matrix()   # (B, L, 4, 4)

    pos3d_disturb = torch.rand((B, 1, 3)) * L + pos3d
    poses_disturb = pp.randn_SE3((B, 1)).matrix() @ poses

    mha = MySimpleMHA(C, H)
    mrope = mRoPE(3, 24)
    crope = cRoPE()

    pe_data = [
        PEData(
            impl=mRoPE,
            pe=mrope.generate(pos3d),
            d=24
        ),
        PEData(
            impl=cRoPE,
            pe=crope.generate(poses),
            d=32
        )
    ]

    pe_data_disturb = [
        PEData(
            impl=mRoPE,
            pe=mrope.generate(pos3d_disturb),
            d=24
        ),
        PEData(
            impl=cRoPE,
            pe=crope.generate(poses_disturb),
            d=32
        )
    ]

    out, _, _ = mha(
        x, x, 
        pe_data, pe_data
    )

    out_disturb, _, _ = mha(
        x, x, 
        pe_data_disturb, pe_data_disturb
    )

    delta = out_disturb - out
    print(delta.abs().max())
    print(delta.abs().mean())
    print(torch.allclose(out, out_disturb))

    from IPython import embed; embed()


if __name__ == "__main__":
    test_rope()


