"""DDP optimizer state sharding and complete, atomic training checkpoints."""
from dataclasses import asdict
import json
from pathlib import Path
import random
import uuid

import numpy as np
import torch
import torch.distributed as dist

FORMAT = "lerobot_original_full_v2"


def rank_world():
    return (dist.get_rank(), dist.get_world_size()) if dist.is_initialized() else (0, 1)


def make_optimizers(model, lr, weight_decay, sharding="zero1"):
    decay, no_decay = model.parameter_groups()
    groups = [dict(params=decay, weight_decay=weight_decay), dict(params=no_decay, weight_decay=0.)]
    if sharding == "zero1" and rank_world()[1] > 1:
        from torch.distributed.optim import ZeroRedundancyOptimizer
        # PyTorch ZeRO requires homogeneous dtype per optimizer. Qwen is BF16,
        # whereas the original actor keeps FP32 parameters.
        result = []
        for dtype in sorted({p.dtype for p in decay + no_decay}, key=str):
            typed = [dict(group, params=[p for p in group["params"] if p.dtype == dtype]) for group in groups]
            typed = [group for group in typed if group["params"]]
            result.append(ZeroRedundancyOptimizer(typed, optimizer_class=torch.optim.AdamW,
                                                 lr=lr, foreach=False))
        return result
    return [torch.optim.AdamW(groups, lr=lr, foreach=False)]


def local_rng_state():
    return dict(python=random.getstate(), numpy=np.random.get_state(), torch=torch.get_rng_state(),
                cuda=torch.cuda.get_rng_state() if torch.cuda.is_available() else None)


def restore_local_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if state["cuda"] is not None:
        torch.cuda.set_rng_state(state["cuda"])


def optimizer_state(optimizer):
    sharded = hasattr(optimizer, "optim")
    local = optimizer.optim if sharded else optimizer
    return dict(sharded=sharded, local=local.state_dict(),
                groups=[{k: v for k, v in group.items() if k != "params"} for group in optimizer.param_groups])


def restore_optimizer(optimizer, saved):
    sharded = hasattr(optimizer, "optim")
    if sharded != saved["sharded"] or len(optimizer.param_groups) != len(saved["groups"]):
        raise ValueError("Optimizer sharding/group layout differs from checkpoint")
    local = optimizer.optim if sharded else optimizer
    local.load_state_dict(saved["local"])
    for group, options in zip(optimizer.param_groups, saved["groups"]):
        group.update(options)


def save_full_checkpoint(path, model, optimizers, schedulers, step, stream,
                         data_config, model_config, train_config, dataset_fingerprint):
    """Every rank participates; model is saved once, optimizer/RNG once per rank.

    Local optimizer shards avoid gathering multiple GB of Adam states onto one
    GPU. The final directory appears only after every shard has been written.
    """
    path = Path(path)
    rank, world = rank_world()
    temporary = [str(path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")) if rank == 0 else None]
    if world > 1:
        dist.broadcast_object_list(temporary, src=0)
    temporary = Path(temporary[0])
    if rank == 0:
        if path.exists():
            raise FileExistsError(f"Checkpoint already exists: {path}")
        temporary.mkdir(parents=True)
    if world > 1:
        dist.barrier()
    torch.save(dict(optimizers=[optimizer_state(opt) for opt in optimizers],
                    schedulers=[sched.state_dict() for sched in schedulers], rng=local_rng_state(),
                    rank=rank, world_size=world, step=step, epoch=stream.epoch, batch_in_epoch=stream.batch_in_epoch),
               temporary / f"rank_{rank:05d}.pt")
    if rank == 0:
        module = model.module if hasattr(model, "module") else model
        torch.save(dict(format=FORMAT, model=module.state_dict(), step=step,
                        epoch=stream.epoch, batch_in_epoch=stream.batch_in_epoch, world_size=world,
                        data_config=asdict(data_config), model_config=model_config, train_config=train_config,
                        dataset_fingerprint=dataset_fingerprint), temporary / "model.pt")
    if world > 1:
        dist.barrier()
    if rank == 0:
        (temporary / "complete.json").write_text(json.dumps(dict(format=FORMAT, world_size=world, step=step)))
        temporary.rename(path)
    if world > 1:
        dist.barrier()


def read_full_checkpoint(path, data_config, model_config, train_config, dataset_fingerprint):
    path = Path(path)
    rank, world = rank_world()
    if not (path / "complete.json").is_file():
        raise ValueError("Resume requires a complete lerobot_original_full_v2 checkpoint directory")
    marker = json.loads((path / "complete.json").read_text())
    if marker.get("format") != FORMAT or marker.get("world_size") != world:
        raise ValueError("Resume checkpoint format/world_size differs")
    if not all((path / f"rank_{r:05d}.pt").is_file() for r in range(world)):
        raise ValueError("Checkpoint is missing optimizer/RNG shards")
    saved = torch.load(path / "model.pt", map_location="cpu", weights_only=False)
    if saved.get("format") != FORMAT or saved["world_size"] != world or saved["step"] != marker["step"]:
        raise ValueError("Checkpoint metadata differs from completion marker")
    old_data, current_data = dict(saved["data_config"]), asdict(data_config)
    for key in ("root", "cache_episodes", "cache_videos"):
        old_data.pop(key, None)
        current_data.pop(key, None)
    if old_data != current_data or saved["dataset_fingerprint"] != dataset_fingerprint:
        raise ValueError("Resume data conventions or reviewed snapshot differ")
    if saved["model_config"] != model_config or saved["train_config"] != train_config:
        raise ValueError("Resume model/training options differ; reuse the original options")
    local = torch.load(path / f"rank_{rank:05d}.pt", map_location="cpu", weights_only=False)
    if (local["rank"] != rank or local["world_size"] != world
            or any(local[key] != saved[key] for key in ("step", "epoch", "batch_in_epoch"))):
        raise ValueError("Optimizer shard does not match the model checkpoint")
    return saved, local


def restore_full_checkpoint(saved, local, model, optimizers, schedulers):
    model.load_state_dict(saved["model"], strict=True)
    if len(optimizers) != len(local["optimizers"]) or len(schedulers) != len(local["schedulers"]):
        raise ValueError("Optimizer count differs from checkpoint")
    for optimizer, state in zip(optimizers, local["optimizers"]):
        restore_optimizer(optimizer, state)
    for scheduler, state in zip(schedulers, local["schedulers"]):
        scheduler.load_state_dict(state)
    # DataLoader workers use an independent seeded generator; model randomness
    # continues from the saved state on this rank.
    restore_local_rng(local["rng"])
