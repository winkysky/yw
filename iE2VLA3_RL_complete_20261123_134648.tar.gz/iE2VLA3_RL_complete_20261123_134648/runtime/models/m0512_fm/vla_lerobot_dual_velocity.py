"""iE2VLA3 four-factor conditioning through the original additive FiLM path.

This is the speed branch only. The no-speed VLA, action expert and services are
unchanged. Physical m/s and legacy categorical-speed checkpoints are rejected.
"""
from dataclasses import replace
import math
import torch
from torch import nn
from action.define import START_END_INDICES
from data_utils.transforms import DecenterCamera
from .action_expert import (ActionExpert, DiffusionHead, compute_loss, compute_loss_simple,
                           pad_or_trunc_inputs, repeat_batch_vla, repeat_vl_outputs)
from .action_transform import ActionTransform
from models.speed_factor import SpeedFactorEmbedding, factor_tensor, FACTORS
from .vla import VLA
from .vlm import QwenVL3Extractor

MODEL_SIZES = {"base": (768, 12, 3), "large": (1024, 16, 2), "huge": (1280, 16, 1)}


class VelocityDiffusionHead(DiffusionHead):
    def __init__(self, hdim, num_heads, num_layers):
        super().__init__(hdim, num_heads, num_layers)
        self.velocity_enc = SpeedFactorEmbedding(hdim)

    def _conditioned_forward(self, denoise_timestep, trajectory, history, context_outputs,
                             speed_feature, fp16, kv_caches=None, export_feat_layers=None):
        b, arms, ts, _ = history.shape
        ta = trajectory.shape[2]
        time = self.proj_timestep(self.denoise_time_embed.generate(denoise_timestep)) + speed_feature
        history_time = self.proj_timestep(
            self.denoise_time_embed.generate(torch.ones_like(denoise_timestep))) + speed_feature
        features = torch.cat([self.state_enc(history, context_outputs["s_mask"]),
                              self.action_enc(trajectory, context_outputs["a_mask"])], dim=2)
        film = torch.cat([history_time[:, None, None].expand(b, arms, ts, -1),
                          time[:, None, None].expand(b, arms, ta, -1)], dim=2)
        features = features.reshape(b, arms * (ts + ta), -1)
        film = film.reshape(b, arms * (ts + ta), -1)
        with torch.autocast(time.device.type, dtype=torch.bfloat16, enabled=fp16):
            if kv_caches is None:
                vla = self.traj_context_attn.forward_vla(
                    vla=torch.cat([context_outputs["vl0"], features], dim=1), film_cond=film,
                    context_outputs=context_outputs,
                    export_feat_layers={} if export_feat_layers is None else export_feat_layers)
                _, features = vla.split(context_outputs["vla_split_size"], dim=1)
            else:
                features = self.traj_context_attn.forward_a(
                    a=features, film_cond=film, context_outputs=context_outputs, kv_caches=kv_caches)
        features = features.reshape(b, arms, ts + ta, -1)[:, :, ts:]
        return self.act_head(self.final_norm(features, time[:, None, None]))

    def forward_vla(self, denoise_timestep, trajectory, history, latest_s, action_ref_pose,
                    context_outputs, fp16, speed_feature, export_feat_layers=None):
        return self._conditioned_forward(denoise_timestep, trajectory, history, context_outputs,
                                         speed_feature, fp16, export_feat_layers=export_feat_layers)

    def forward_a(self, denoise_timestep, trajectory, history, latest_s, action_ref_pose,
                  context_outputs, kv_caches, fp16, speed_feature):
        return self._conditioned_forward(denoise_timestep, trajectory, history, context_outputs,
                                         speed_feature, fp16, kv_caches=kv_caches)


class DualVelocityActionExpert(ActionExpert):
    def __init__(self, idim, hdim, num_heads, num_diffusion_layers,
                 inference_timesteps=4, velocity_dropout=.1, action_horizon=32):
        super().__init__(idim, hdim, num_heads, num_diffusion_layers, inference_timesteps)
        if not math.isfinite(velocity_dropout) or not 0 <= velocity_dropout < 1 or action_horizon != 32:
            raise ValueError("Expected dropout in [0,1) and 32 targets")
        self.action_horizon = action_horizon
        self.velocity_dropout = velocity_dropout
        self.speed_factors = FACTORS
        self.dp_head = VelocityDiffusionHead(hdim, num_heads, num_diffusion_layers)
        self.decenter = DecenterCamera()

    def forward(self, vla_inputs, vl_outputs, inference, fp16, n_repeats=1,
                speed_factor=None, initial_noise=None, return_speed_info=False):
        if not isinstance(n_repeats, int) or n_repeats < 1 or (inference and n_repeats != 1):
            raise ValueError("Use positive repeats and n_repeats=1 for inference")
        if not inference and (speed_factor is not None or initial_noise is not None):
            raise ValueError("Training uses dataset factor labels; overrides are inference-only")
        b, device = vla_inputs.state.shape[0], vla_inputs.state.device
        if vla_inputs.action.shape[2] != 32:
            raise ValueError("Expected 32 future targets/placeholders")
        selected = factor_tensor(speed_factor if inference else vla_inputs._aux_data.get('speed_factor'), b, device)
        data = pad_or_trunc_inputs(replace(vla_inputs, _aux_data=dict(vla_inputs._aux_data)))
        data = repeat_batch_vla(data, n_repeats)
        features = repeat_vl_outputs(vl_outputs, n_repeats)
        context = self.context_encoder(data, features)
        lo, _ = START_END_INDICES['rot6d']
        context['a_mask'][..., lo+3:lo+6] = False
        speed_feature = self.dp_head.velocity_enc(selected.repeat(n_repeats))
        if not inference and self.training and self.velocity_dropout:
            keep = torch.rand(len(speed_feature), device=device) >= self.velocity_dropout
            speed_feature = speed_feature * keep[:, None]
        latest = data.state[:, :, -1]
        history = ActionTransform.weT_to_ceT(cur_wcT=data.action_ref_pose, a=data.state)
        fixed = dict(history=history, latest_s=latest, action_ref_pose=data.action_ref_pose,
                     context_outputs=context, fp16=fp16, speed_feature=speed_feature)
        if inference:
            if initial_noise is not None:
                if initial_noise.shape != data.action.shape or not torch.isfinite(initial_noise).all():
                    raise ValueError(f"initial_noise must be finite with shape {tuple(data.action.shape)}")
                initial_noise = initial_noise.to(device=device, dtype=data.action.dtype)
            caches = self.dp_head.forward_vl(context, fp16)
            predicted = self.iterative_denoise(data.action.shape, fixed, initial_noise, caches)
            actions, mask = ActionTransform.ccT_to_weT(
                cur_wcT=data.action_ref_pose, s=latest, a=predicted, a_mask=data.action_mask)
            if data._avg_pose is not None:
                actions = self.decenter(avg_pose=data._avg_pose, raw=actions)
            actions = actions * mask.float()
            return (actions, dict(speed_factor=selected)) if return_speed_info else actions
        target_actions, target_mask = ActionTransform.weT_to_ccT(
            cur_wcT=data.action_ref_pose, s=latest, a=data.action, a_mask=data.action_mask)
        def field(trajectory, timestep):
            return self.dp_head.forward_vla(timestep, trajectory, **fixed)
        prediction, target = self.denoiser.train_forward(target_actions, field)
        loss = compute_loss_simple(prediction, target, target_mask)
        _, metrics = compute_loss(prediction, target, target_mask)
        metrics.update(action_loss=loss.detach(), speed_factor_mean=selected.mean().detach())
        for factor in FACTORS:
            metrics[f'factor_{factor}_fraction'] = torch.isclose(selected, selected.new_tensor(factor)).float().mean()
        return loss, metrics


class LeRobotDualVelocityVLA(VLA):
    def __init__(self, model='base', inference_timesteps=4, velocity_dropout=.1,
                 action_horizon=32, train_qwen=True, full_qwen_features=True):
        nn.Module.__init__(self)
        hdim, heads, gap = MODEL_SIZES[model]
        self.vlm = QwenVL3Extractor(False, False)
        self.vlm_layer_indices = list(range(0, self.vlm.num_llm_layers, gap))
        self.actor = DualVelocityActionExpert(self.vlm.hidden_size, hdim, heads,
            len(self.vlm_layer_indices), inference_timesteps, velocity_dropout, action_horizon)
        # Initialize before unfreezing so pretrained Qwen biases are preserved.
        self.reset_parameters()
        self.vlm.requires_grad_(train_qwen)
        self.vlm.full_qwen_features = full_qwen_features

    def forward(self, vla_inputs, inference, fp16=True, n_repeats=1, **factor_options):
        features = self.vlm.hidden_layer_features(vla_inputs.tokenized_vl, self.vlm_layer_indices)
        return self.actor(vla_inputs, features, inference, fp16, n_repeats, **factor_options)
