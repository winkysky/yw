"""Shared discrete speed policy for dual-arm velocity v2, independent of force."""

import math

import torch
from torch import nn
from torch.distributions import Categorical

from data_utils.tokenize import ModalityType


class SpeedBins(nn.Module):
    def __init__(self, spec):
        super().__init__()
        edges = torch.tensor(spec["boundaries_mps"], dtype=torch.float32)
        centers = torch.tensor(spec["centers_mps"], dtype=torch.float32)
        self.num_bins = int(spec["num_bins"])
        low, high = float(spec["speed_min_mps"]), float(spec["speed_max_mps"])
        if (self.num_bins < 2 or edges.shape != (self.num_bins - 1,) or centers.shape != (self.num_bins,)
                or not torch.isfinite(edges).all() or not torch.isfinite(centers).all()
                or not math.isfinite(low + high) or not 0 <= low < high
                or not (edges[1:] > edges[:-1]).all() or not low < edges[0] or not edges[-1] < high):
            raise ValueError("Invalid calibrated speed bins")
        full_edges = torch.cat([torch.tensor([low]), edges, torch.tensor([high])])
        if ((centers < full_edges[:-1]).any() or (centers > full_edges[1:]).any()
                or not torch.equal(torch.bucketize(centers, edges), torch.arange(self.num_bins))):
            raise ValueError("Each speed center must belong to its own bin")
        # Persistent: a saved actor carries the physical meaning of its bins.
        self.register_buffer("boundaries_mps", edges)
        self.register_buffer("centers_mps", centers)

    def speed_to_bin(self, speed, batch_size, device):
        value = torch.as_tensor(speed, dtype=torch.float32, device=device)
        if value.ndim == 0:
            value = value.expand(batch_size)
        if value.shape != (batch_size,) or not torch.isfinite(value).all() or (value < 0).any():
            raise ValueError("speed_mps must be a nonnegative finite scalar or (B,) tensor, in m/s")
        return torch.bucketize(value.contiguous(), self.boundaries_mps)

    def validate_bin(self, index, batch_size, device):
        value = torch.as_tensor(index, device=device)
        if value.ndim == 0:
            value = value.expand(batch_size)
        if (value.shape != (batch_size,) or value.dtype == torch.bool
                or not torch.isfinite(value).all() or not torch.equal(value, value.long())
                or (value < 0).any() or (value >= self.num_bins).any()):
            raise ValueError(f"speed_bin must contain integers in [0, {self.num_bins - 1}]")
        return value.long()


class VelocityPolicy(nn.Module):
    """Dedicated learned query attends only to current frozen VLM features.

    No action targets, speed labels or force enter this prediction branch.
    The categorical distribution retains gradients for future PPO/REINFORCE.
    """
    def __init__(self, idim, num_bins, policy_dim=256, num_heads=4):
        super().__init__()
        if policy_dim < 1 or policy_dim % num_heads:
            raise ValueError("policy_dim must be divisible by policy num_heads")
        self.context_proj = nn.Sequential(nn.LayerNorm(idim), nn.Linear(idim, policy_dim))
        self.query = nn.Parameter(torch.zeros(1, 1, policy_dim))
        self.attention = nn.MultiheadAttention(policy_dim, num_heads, batch_first=True, dropout=0.)
        self.head = nn.Sequential(nn.LayerNorm(policy_dim), nn.Linear(policy_dim, policy_dim),
                                  nn.GELU(), nn.Linear(policy_dim, num_bins))
        nn.init.normal_(self.query, std=.02)
        nn.init.zeros_(self.head[-1].weight)
        nn.init.zeros_(self.head[-1].bias)

    def forward(self, modality, vl_outputs):
        hidden = vl_outputs["hidden_states"][-1].detach().float()
        padding = modality.eq(ModalityType.PAD)
        if hidden.shape[:2] != padding.shape or padding.all(-1).any():
            raise ValueError("VelocityPolicy needs at least one valid observation token per sample")
        context = self.context_proj(hidden)
        query = self.query.expand(hidden.shape[0], -1, -1)
        feature, _ = self.attention(query, context, context, key_padding_mask=padding, need_weights=False)
        return self.head((feature + query)[:, 0])

    def distribution(self, modality, vl_outputs, temperature=1.):
        if not math.isfinite(temperature) or temperature <= 0:
            raise ValueError("temperature must be positive and finite")
        return Categorical(logits=self(modality, vl_outputs) / temperature)
