"""Shared full-checkpoint inference and calibrated observation preparation."""
import copy
from contextlib import nullcontext
import json
from pathlib import Path

import cv2
import numpy as np
import torch

from action.define import ACTION_SPACE_SIZE
from data_utils.data_raw import DataRawVL, DataRawVLA
from data_utils.tokenize import BatchDataTokenizedVLA
from dataset.lerobot_dual import decode_tcp, decode_gripper, pack_states
from dataset.lerobot_original import apply_geometry
from .lerobot_distributed import FORMAT
from .lerobot_runtime import configure_conv3d_layout
from .train_lerobot_dual import build_model


def load_checkpoint(path):
    path = Path(path).expanduser().resolve()
    model_path = path / "model.pt" if path.is_dir() else path
    marker_path = model_path.parent / "complete.json"
    if not marker_path.is_file():
        raise ValueError("A complete full-Qwen checkpoint directory (or its model.pt) is required")
    marker = json.loads(marker_path.read_text())
    if marker.get("format") != FORMAT:
        raise ValueError(f"Expected {FORMAT}; actor-only/speed checkpoints are incompatible")
    saved = torch.load(model_path, map_location="cpu", weights_only=False, mmap=True)
    if (saved.get("format") != FORMAT or saved.get("step") != marker.get("step")
            or saved.get("world_size") != marker.get("world_size")):
        raise ValueError("Checkpoint model and completion marker disagree")
    return saved, model_path


def load_inference_model(saved, device):
    model = build_model(**saved["model_config"])
    model.load_state_dict(saved["model"], strict=True)
    model = model.to(device).eval().requires_grad_(False)
    configure_conv3d_layout(model)
    return model


@torch.inference_mode()
def infer_batch(model, data, device, seed=None):
    if seed is not None and (type(seed) is not int or not 0 <= seed < 2**63):
        raise ValueError("seed must be an integer in [0, 2**63)")
    batch = data.deepcopy().to(device)
    shape = batch.action.shape
    batch.action.zero_()
    devices = [device.index if device.index is not None else torch.cuda.current_device()] if device.type == "cuda" else []
    with torch.random.fork_rng(devices=devices) if seed is not None else nullcontext():
        if seed is not None:
            torch.manual_seed(seed)
        prediction = model(batch, inference=True, fp16=True).float().cpu()
    if prediction.shape[:3] != shape[:3] or prediction.shape[-1] < shape[-1] or not torch.isfinite(prediction).all():
        raise ValueError("Prediction has an invalid shape or nonfinite values")
    return prediction[..., :shape[-1]].clone()


def predict_sample(model, collator, sample, device, seed):
    batch = BatchDataTokenizedVLA(**collator([copy.deepcopy(sample)]))
    return infer_batch(model, batch, device, seed)[0]


def validate_state_action(data, config, batched=False):
    prefix = (data.state.shape[0],) if batched and data.state.ndim == 4 else ()
    if batched and (not prefix or prefix[0] < 1):
        raise ValueError("Expected a nonempty batch")
    state_shape = (*prefix, 2, config.num_history_states, ACTION_SPACE_SIZE)
    action_shape = (*prefix, 2, config.num_future_actions, ACTION_SPACE_SIZE)
    if tuple(data.state.shape) != state_shape or tuple(data.action.shape) != action_shape:
        raise ValueError(f"Expected state {state_shape} and action {action_shape}, left arm then right arm")
    if data._avg_pose is not None:
        raise ValueError("Input must use the checkpoint world frame; do not apply CenterCamera")
    if not data.state.is_floating_point() or not torch.isfinite(data.state).all():
        raise ValueError("State must contain finite floating point TCPs/openness")
    for mask, values in [(data.state_mask, data.state), (data.action_mask, data.action)]:
        if mask.dtype != torch.bool or mask.shape != values.shape or mask[..., 10:].any():
            raise ValueError("Expected boolean dual-arm masks with only the first 10 channels enabled")
    if not data.state_mask[..., -1, :10].all() or not data.action_mask[..., :10].any():
        raise ValueError("Current TCPs/grippers and future action channels must be valid")


def prepare_raw(data, config):
    """DataRawVLA: TCP state is ALREADY in left base, metres/rot6d/openness."""
    if not isinstance(data, DataRawVLA) or data.raw_vl is None:
        raise TypeError("inference_raw expects DataRawVLA with camera images and an instruction")
    validate_state_action(data, config)
    sample = copy.deepcopy(data).to("cpu").decompress_()
    if not isinstance(sample.raw_vl.prompt, str) or not sample.raw_vl.prompt.strip():
        raise ValueError("A nonempty instruction is required")
    if len(sample.raw_vl.rgb) != len(config.camera_keys):
        raise ValueError("Images must follow the checkpoint camera_keys order")
    height, width = config.image_size
    images = []
    for rgb in sample.raw_vl.rgb:
        if not isinstance(rgb, torch.Tensor) or rgb.dtype != torch.uint8 or rgb.ndim != 4 or tuple(rgb.shape[:2]) != (1, 3):
            raise ValueError("Each camera must have one RGB uint8 image of shape [1, 3, H, W]")
        if tuple(rgb.shape[-2:]) != (height, width):
            array = rgb[0].permute(1, 2, 0).contiguous().numpy()
            # Calibrated streams must have the same uncropped aspect ratio.
            if array.shape[0] * width != array.shape[1] * height:
                raise ValueError("Camera image aspect ratio differs from checkpoint calibration")
            array = cv2.resize(array, (width, height), interpolation=cv2.INTER_AREA)
            rgb = torch.from_numpy(np.ascontiguousarray(array.transpose(2, 0, 1)))[None]
        images.append(rgb)
    sample.raw_vl.rgb = images
    sample.action = torch.zeros_like(sample.action)
    # Intrinsics, wrist extrinsics and action references come from the checkpoint.
    # Only the observation API below converts per-arm bases; never do it twice.
    return apply_geometry(sample, config)


def _observation_to_sample(observation, config, poses, grippers):
    """Pack decoded common-frame TCPs; calibration is always checkpoint-owned."""
    if len(poses) != config.num_history_states or len(grippers) != config.num_history_states:
        raise ValueError(f"Expected {config.num_history_states} aligned state history rows")
    state, state_mask = pack_states(poses, grippers, np.ones(len(poses), dtype=bool))
    images = observation["images"]
    if not isinstance(images, dict) or set(images) != set(config.camera_keys):
        raise ValueError("images must contain exactly the checkpoint camera_keys")
    rgb = []
    for key in config.camera_keys:
        value = images[key]
        if isinstance(value, dict):
            # Portable robot-side wire format; no NumPy pickle module paths.
            shape, payload = value.get("shape"), value.get("rgb_bytes")
            if (not isinstance(shape, (list, tuple)) or len(shape) != 3 or shape[-1] != 3
                    or any(type(x) is not int or x < 1 for x in shape)
                    or not isinstance(payload, bytes) or len(payload) != shape[0] * shape[1] * 3):
                raise ValueError(f"{key}: invalid RGB byte buffer/shape")
            array = np.frombuffer(payload, dtype=np.uint8).reshape(shape)
        else:
            array = np.asarray(value)
        if array.dtype != np.uint8 or array.ndim != 3 or array.shape[-1] != 3 or min(array.shape[:2]) < 1:
            raise ValueError(f"{key} must be an RGB uint8 [H, W, 3] image")
        rgb.append(torch.from_numpy(np.ascontiguousarray(array.transpose(2, 0, 1)))[None])
    action = torch.zeros(2, config.num_future_actions, ACTION_SPACE_SIZE)
    action_mask = state_mask[:, -1:].expand_as(action).clone()
    sample = DataRawVLA(DataRawVL(K=torch.eye(3).repeat(len(rgb), 1, 1), rgb=rgb,
                                 pose=[torch.eye(4)[None] for _ in rgb], fps=30., prompt=observation["instruction"]),
                        state=state, state_mask=state_mask, action=action, action_mask=action_mask,
                        action_ref_pose=torch.eye(4).repeat(2, 1, 1))
    return prepare_raw(sample, config)


def _require_observation_fields(observation, keys):
    if not isinstance(observation, dict):
        raise TypeError("Observation must be a dictionary")
    for key in [*keys, "images", "instruction"]:
        if key not in observation:
            raise ValueError(f"Missing observation field: {key}")


def observation_to_sample(observation, config):
    """LeRobot numeric fields in recorded arm bases + named RGB images, no actions."""
    _require_observation_fields(observation, [config.state_pose_key, config.state_gripper_key])
    poses = decode_tcp(observation[config.state_pose_key], config)
    grippers = decode_gripper(observation[config.state_gripper_key], config)
    return _observation_to_sample(observation, config, poses, grippers)


def world_observation_to_sample(observation, config):
    """ROS TF TCPs already in the checkpoint world: no base/tool transform."""
    _require_observation_fields(observation, ["world_tcp", "gripper", "frame"])
    world = config.geometry.get("world_frame", "left_recorded_arm_base")
    if observation["frame"] != world:
        raise ValueError(f"world_tcp must be in {world}")
    poses = np.asarray(observation["world_tcp"], dtype=np.float32)
    grippers = np.asarray(observation["gripper"], dtype=np.float32)
    if poses.shape != (config.num_history_states, 2, 4, 4) or not np.isfinite(poses).all():
        raise ValueError("world_tcp must be finite [history, 2, 4, 4] TCP transforms in metres")
    rotation = poses[..., :3, :3]
    if (not np.allclose(poses[..., 3, :], [0, 0, 0, 1], atol=1e-5)
            or not np.allclose(rotation.swapaxes(-1, -2) @ rotation, np.eye(3), atol=2e-3)
            or not np.allclose(np.linalg.det(rotation), 1., atol=2e-3)):
        raise ValueError("world_tcp must contain rigid transforms")
    if (grippers.shape != (config.num_history_states, 2) or not np.isfinite(grippers).all()
            or np.any((grippers < 0) | (grippers > 1))):
        raise ValueError("gripper must be [history, 2] openness in [0, 1]")
    return _observation_to_sample(observation, config, poses, grippers)
