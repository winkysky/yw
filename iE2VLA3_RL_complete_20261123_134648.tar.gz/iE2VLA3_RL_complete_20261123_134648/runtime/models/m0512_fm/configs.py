import os
import json
import importlib
from typing import List, Dict
from dataclasses import dataclass, field, asdict

from dataset.egodex import EgoDex
from dataset.libero_train import LiberoTrainDataset
from dataset.custom_hdf5 import dataset as custom_dataset
from data_utils.dataset_base import DatasetBase, DataConfig


@dataclass
class TrainConfig(object):

    model: str = "base"  # choices are ["tiny", "small", "base"]
    pretrained_ckpt: str | None = None  # ckpt path of pretrained model
    stage: int = 2  # deepspeed ZeRO stage

    bs_micro: int = 32  # batch size per gpu and per fwd
    workers: int = 8  # num_workers
    fp16: bool = True  # enable mixed precision training (fp32 and bfloat16)
    n_repeats: int = 1  # number of repeats of diffusion batch

    grad_clip: float = 1.0  # <= 0 disables the grad clip
    max_lr: float = 1e-4  # maximum learning rate
    wd: float = 1e-2  # weight decay
    num_warmup: int = int(10e3)  # warm up steps
    gradient_accumulation_steps: int = 1
    lr_scaling: bool = True  # scale lr with num gpus and batch size

    data_config: DataConfig = field(default_factory=DataConfig)
    dataset_classes: List[type[DatasetBase] | str] = field(default_factory=list)
    dataset_weights: List[float] | None = None  # len = len(datasets)
    sample_multiplex: int = 1   # set this to a large number (e.g. 1000) if the total number of samples are small

    log_interval: int = 100
    save_interval: int = int(100e3)  # ckpt are named as ckpt_{iter}.pt, set <0 to disable this
    save_latest_interval: int = 2000  # ckpt are named as ckpt_latest.pt
    max_iterations: int = int(600e3)

    def __post_init__(self):
        for i, D in enumerate(self.dataset_classes):
            if isinstance(D, str):
                module_name, qualname = D.split(":")
                assert module_name != "__main__", "Class defined in __main__ cannot be re-imported"
                cls = importlib.import_module(module_name)
                for attr in qualname.split("."):
                    cls = getattr(cls, attr)
                self.dataset_classes[i] = cls
            else:
                assert issubclass(D, DatasetBase)
    
    def dump(self, path: str):
        items = asdict(self)
        # items["data_config"] = asdict(items["data_config"]) # automatically converted to dict
        dataset_classes = items["dataset_classes"]
        for i, D in enumerate(dataset_classes):
            if issubclass(D, DatasetBase):
                dataset_classes[i] = D.__module__ + ":" + D.__qualname__
            else:
                assert isinstance(D, str)
        
        save_folder = os.path.dirname(path)
        os.makedirs(save_folder, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fp:
            json.dump(items, fp, ensure_ascii=False, indent=4)
    
    @classmethod
    def load(cls, path: str):
        with open(path, "r", encoding="utf-8") as fp:
            items = json.load(fp)
        items["data_config"] = DataConfig(**items["data_config"])
        return cls(**items)


CONFIGS: Dict[str, TrainConfig] = {}
CONFIGS["debug"] = TrainConfig()
CONFIGS["statistics"] = TrainConfig(
    data_config=DataConfig(load_vl=False), 
    dataset_classes=[
        custom_dataset.Droid,
        custom_dataset.AgibotWorldAlpha,
        custom_dataset.InternM1Franka, 
        custom_dataset.RoboTwin2, 
        custom_dataset.OpenDrawer,
        custom_dataset.OpenOven,
        EgoDex,
    ],
    dataset_weights=[10, 10, 10, 5, 1, 1, 10]
)
CONFIGS["pretrain_subset"] = TrainConfig(
    dataset_classes=[
        custom_dataset.Droid,
        custom_dataset.AgibotWorldAlpha,
        custom_dataset.MetaWorld,
        custom_dataset.PickPlaceCan,
        custom_dataset.OpenDrawer,
        custom_dataset.OpenOven,
    ],
    dataset_weights=[10, 10, 1, 1, 1, 1]
)
CONFIGS["pretrain"] = TrainConfig(
    dataset_classes=[
        custom_dataset.Droid,
        custom_dataset.AgibotWorldAlpha,
        custom_dataset.InternM1Franka, 
        custom_dataset.MetaWorld,
        # custom_dataset.PickPlaceCan,
        # custom_dataset.OpenDrawer,
        # custom_dataset.OpenOven,
        EgoDex,
    ],
    dataset_weights=[10, 10, 10, 1, # 1, 1, #1,
                     10]
)
CONFIGS["pretrain_droid"] = TrainConfig(
    dataset_classes=[
        custom_dataset.Droid,
    ],
    dataset_weights=[1.0]
)
CONFIGS["pretrain_droid_egodex"] = TrainConfig(
    dataset_classes=[
        custom_dataset.Droid,
        EgoDex,
    ],
    dataset_weights=[1.0, 1.0]
)
CONFIGS["finetune_libero_all"] = TrainConfig(
    pretrained_ckpt="checkpoints/E2VLA/m0219_fm_nocet_pretrain/ckpt_0300000", 
    stage=0, 
    dataset_classes=[
        LiberoTrainDataset
    ],
    max_lr=5e-5,
    dataset_weights=None,
    sample_multiplex=1,
    num_warmup=int(1e3),
    save_interval=int(10e3),
    max_iterations=int(70e3),
)
CONFIGS["scratch_libero_all"] = TrainConfig(
    stage=0, 
    dataset_classes=[
        LiberoTrainDataset
    ],
    max_lr=1e-4,
    bs_micro=64, 
    dataset_weights=None,
    sample_multiplex=1,
    num_warmup=int(1e3),
    save_interval=int(50e3),
    max_iterations=int(200e3),
)
CONFIGS["finetune_libero_all2"] = TrainConfig(
    pretrained_ckpt="checkpoints/E2VLA/m0219_fm_nocet_pretrain/ckpt_0300000", 
    stage=0, 
    dataset_classes=[
        LiberoTrainDataset
    ],
    max_lr=5e-4,
    bs_micro=64, 
    lr_scaling=False, 
    dataset_weights=None,
    data_config=DataConfig(num_future_actions=20), 
    sample_multiplex=1,
    num_warmup=int(2e3),
    save_interval=int(10e3),
    max_iterations=int(40e3),
)


CONFIGS["scratch_libero_all2"] = TrainConfig(
    stage=1, 
    dataset_classes=[
        LiberoTrainDataset
    ],
    max_lr=2e-4,
    bs_micro=48, 
    lr_scaling=False, 
    dataset_weights=None,
    data_config=DataConfig(num_future_actions=20), 
    sample_multiplex=1,
    num_warmup=int(2e3),
    save_interval=int(50e3),
    max_iterations=int(100e3),
)

CONFIGS["scratch_libero_all3"] = TrainConfig(
    stage=2, 
    dataset_classes=[
        LiberoTrainDataset
    ],
    wd=1e-5, 
    max_lr=1e-4,
    bs_micro=24, 
    n_repeats=4, 
    lr_scaling=False, 
    dataset_weights=None,
    data_config=DataConfig(num_future_actions=20), 
    sample_multiplex=1,
    num_warmup=int(2e3),
    save_interval=int(40e3),
    max_iterations=int(200e3),
)


if __name__ == "__main__":
    # CONFIGS["pretrain_subset"].dump("./config.json")
    config = TrainConfig.load("./config.json")
    print(config)
    from IPython import embed; embed()

