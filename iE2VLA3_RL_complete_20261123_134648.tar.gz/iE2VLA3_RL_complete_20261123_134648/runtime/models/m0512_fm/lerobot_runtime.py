"""Runtime layout for the unchanged Qwen Conv3d used by LeRobot training.

PyTorch 2.9.1 disables contiguous half/BF16 3D cuDNN convolutions with
non-unit kernels on cuDNN 9.8--9.14 (Convolution.cpp::use_cudnn).
The public channels_last_3d weight conversion retains the original Conv3d,
parameter objects, values, shape, dtype, and checkpoint keys. Different CUDA
kernels may have different floating-point rounding.
"""

import torch
from torch import nn


def configure_conv3d_layout(model, memory_format="channels_last_3d"):
    """Call after moving the model to its device, before creating the optimizer.

    Applies only to Qwen's image patch projection, with no layer replacements,
    forward overrides, weight casts, or global backend flags. ``contiguous``
    restores the original storage layout for reference measurements.
    """
    formats = {"channels_last_3d": torch.channels_last_3d,
               "contiguous": torch.contiguous_format}
    if memory_format not in formats:
        raise ValueError(f"Unknown Conv3d memory format: {memory_format}")
    projection = model.vlm.qwen.visual.patch_embed.proj
    if type(projection) is not nn.Conv3d:
        raise TypeError("Expected the original Qwen nn.Conv3d patch projection")
    if projection.weight.device.type == "meta":
        raise ValueError("Configure Conv3d layout after loading real model weights")
    before = projection.weight.stride()
    target = formats[memory_format]
    if not projection.weight.is_contiguous(memory_format=target):
        nn.utils.convert_conv3d_weight_memory_format(projection, target)
    return dict(conv3d_memory_format=memory_format,
                conv3d_weight_stride=list(projection.weight.stride()),
                conv3d_layout_changed=before != projection.weight.stride())
