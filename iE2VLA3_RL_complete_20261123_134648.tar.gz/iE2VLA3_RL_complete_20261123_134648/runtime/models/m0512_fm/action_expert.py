import torch
import warnings
import torch.nn.functional as F

from einops import rearrange
from torch import nn, Tensor
from typing import Optional, Tuple, Dict, List

from .fm import get_denoiser
from .layers.attn import FFN
from .layers.norm import RMSNorm, AdaRMSNorm
from .layers.pe import SinusoidalPosEmbedPi0
from .layers.pe import mRoPE, cRoPE, Noop, PEData
from .layers.mha import MySimpleMHA, ProjOpt, KVCache
from .action_transform import ActionTransform

from action.parser import ProprioParser
from data_utils.transforms import DecenterCamera
from data_utils.tokenize import BatchDataTokenizedVLA, ModalityType
from action.define import ACTION_SPACE_SIZE, ORDERED_ACTION_SPACE, START_END_INDICES


PAD_ACTION_SPACE_SIZE = 80

if PAD_ACTION_SPACE_SIZE < ACTION_SPACE_SIZE:
    warnings.warn("Trunc action space from {} to {}".format(ACTION_SPACE_SIZE, PAD_ACTION_SPACE_SIZE))
elif PAD_ACTION_SPACE_SIZE > ACTION_SPACE_SIZE:
    warnings.warn("Pad action space from {} to {}".format(ACTION_SPACE_SIZE, PAD_ACTION_SPACE_SIZE))


def simple_mlp(neurons: List[int], ln: bool = False):
    assert len(neurons) >= 2
    modules = [nn.Linear(neurons[0], neurons[1])]
    for i in range(1, len(neurons)-1):
        if ln:
            modules.append(nn.RMSNorm(neurons[i]))
        modules.append(nn.GELU())
        modules.append(nn.Linear(neurons[i], neurons[i+1]))
    return nn.Sequential(*modules)


def prepare_attention_mask(
    vl_modality: Tensor, 
    a_mask: Tensor
):
    """
    Args:
        vl_modality (Tensor): (B, len_vl)
        a_mask (Tensor): (B, len_a), len_a = Nee * (Ts + Ta)
    
    Returns:
    -------
        causal_mask (Tensor): (B, len_vl + len_a * 2, len_vl + len_a * 2)
        causal_mask_dilated (Tensor): (B, len_vl + len_a * 2, len_vl + len_a * 2)
    """

    a_modality = vl_modality.new_full(a_mask.shape, ModalityType.PAD)
    a_modality[a_mask] = ModalityType.ACTION
    vla_modality = torch.cat([vl_modality, a_modality], dim=1)  # (B, len_vl + len_a)

    causal_mask = vla_modality.unsqueeze(-1) >= vla_modality.unsqueeze(-2)  # (B, len_vl + len_a, len_vl + len_a)
    # causal mask removing attention to pad tokens
    row_mask = (vla_modality != ModalityType.PAD)
    col_mask = (vla_modality == ModalityType.PAD)
    causal_mask[row_mask.unsqueeze(-1) & col_mask.unsqueeze(-2)] = False


    causal_mask_dilated = vla_modality.unsqueeze(-1) == vla_modality.unsqueeze(-2)
    # make a dependent on v
    row_mask = (vla_modality == ModalityType.ACTION)
    col_mask = (vla_modality == ModalityType.VISION)
    causal_mask_dilated[row_mask.unsqueeze(-1) & col_mask.unsqueeze(-2)] = True

    return causal_mask, causal_mask_dilated


def make_vla_pos_1d(is_vision_mask: Tensor, len_a: int):
    L = is_vision_mask.shape[1]
    offset = torch.cumsum(is_vision_mask.int(), dim=-1)  # (B, L)
    pos_id_1d = torch.arange(L).to(offset) - (offset - 1).clamp_min(0)
    #         modality: P P P V V V V L L L L (P for <pad>, V for <vision>, L for <language>)
    #           arange: 0 1 2 3 4 5 6 7 8 9 10
    # max(offset-1, 0): 0 0 0 0 1 2 3 3 3 3 3
    #        pos_id_1d: 0 1 2 3 3 3 3 4 5 6 7
    
    offset = pos_id_1d[:, -1:] + 1  # (B, 1)
    act_pos_1d = torch.arange(len_a).to(offset) + offset  # (B, len_a)
    return torch.cat([pos_id_1d, act_pos_1d], dim=1)  # (B, L+len_a)


class ContextEncoder(nn.Module):
    def __init__(self, idim, hdim: int, num_heads: int, num_layers: int):
        super().__init__()
        self.idim = idim
        self.hdim = hdim
        self.num_heads = num_heads
        self.proj_input = nn.Linear(idim, hdim)
        self.proj_vl = nn.ModuleList([nn.Sequential(nn.RMSNorm(idim), nn.Linear(idim, hdim)) 
                                      for _ in range(num_layers)])
        self.proj_pe = nn.Linear(2, hdim)  # for normalized coordinates

        HD = hdim//num_heads
        self.crope_dim = HD // 2
        self.mrope_dim = HD // 2
        self.crope = cRoPE()
        self.mrope = mRoPE(1, self.mrope_dim)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.zeros_(self.proj_pe.weight)
        nn.init.zeros_(self.proj_pe.bias)

    def forward(
        self, 
        vla_inputs: BatchDataTokenizedVLA,
        vl_outputs: Dict[str, Tensor]
    ):
        """
        Args:
            vla_inputs (BatchDataTokenizedVLA):
                - raw_vl: List[Optional[DataRawVL]]  # len = B
                - tokenized_vl: BatchFeature
                    * input_ids: Tensor  # (B, L)
                    * attention_mask: Tensor  # (B, L)
                    * pixel_values: Optional[Tensor]  # (L_imgs, C)
                    * image_grid_thw: Optional[Tensor]  # (N_imgs, 3)
                    * pixel_values_videos: Optional[Tensor]  # (L_vids, C)
                    * video_grid_thw: Optional[Tensor]  # (N_vids, 3)
                - modality: Tensor  # (B, L)

                - patch_pose: Tensor  # (L_imgs+L_vids, 4, 4)
                - patch_norm_xy: Tensor  # (L_imgs+L_vids, 2)

                - state: Tensor  # (B, Nee, Ts, state_dim), state_dim = 3 (trans) + 6 (rot6d) + 1 (gripper) + 20 (MANO hands) + ...
                - state_mask: Tensor  # shape compatible with state

                - action: Tensor  # (B, Nee, Ta, action_dim), action_dim = 3 (trans) + 6 (rot6d) + 1 (gripper) + 20 (MANO hands) + ...
                - action_mask: Tensor  # shape compatible with action
                - action_ref_pose: Tensor  # (B, Nee, 4, 4)
            
            vl_outputs (Dict[str, Tensor]):
                - inputs_embeds (Tensor): shape = (B, L, C), L = Lpad + Ncam*Lv + Llang
                - hidden_states (List[Tensor]): len = n_layers, shape = (B, L, C), L = Lpad + Ncam*Lv + Llang
                - position_ids: (Tensor): shape = (D, B, L), D = 3, [t, h, w]
        
        Returns
        -------
            context_outputs (Dict[str, Tensor]):
        """
        ################## process VLM ##################
        # B, Ncam, Lv, _ = vl_outputs["norm_xy_ds"].shape
        is_vision_mask = vla_inputs.modality == ModalityType.VISION  # (B, L)
        

        # initial vl pose as eye(4)
        B, len_vl, _ = vl_outputs["hidden_states"][0].shape
        vl_extr = torch.eye(4).to(is_vision_mask.device)[None, None].repeat(B, len_vl, 1, 1)  # (B, len_vl, 4, 4)

        # camera pose as positional encoding
        vl_extr[is_vision_mask] = vla_inputs.patch_pose

        # project initial and hidden vl features
        vl0: Tensor = self.proj_input(vl_outputs["inputs_embeds"].float())
        vl_highways: List[Tensor] = [proj(vl_outputs["hidden_states"][i].float()) 
                                    for i, proj in enumerate(self.proj_vl)]

        # add norm xy embed
        vl0 = vl0.clone()
        norm_xy_embed: Tensor = self.proj_pe(vla_inputs.patch_norm_xy)  # (L', hdim)
        vl0[is_vision_mask] = vl0[is_vision_mask] + norm_xy_embed


        ################## process Action Expert ##################
        B, Nee, Ts, D = vla_inputs.state_mask.shape
        B, Nee, Ta, D = vla_inputs.action_mask.shape
        La = Ts + Ta
        action_extr = vla_inputs.action_ref_pose[:, :, None].expand(B, Nee, La, 4, 4).reshape(B, Nee*La, 4, 4)

        ################## Merge together ##################
        state_action_mask_full = torch.cat([vla_inputs.state_mask, vla_inputs.action_mask], dim=2)  # (B, Nee, Ts+Ta, D)
        state_action_mask_noD = state_action_mask_full.any(dim=-1)  # (B, Nee, Ts+Ta)
        vla_mask_seelang, vla_mask_dilated = prepare_attention_mask(
            vl_modality=vla_inputs.modality,
            a_mask=state_action_mask_noD.view(B, Nee*La)
        )
        vla_split_size = (len_vl, Nee*La)

        vla_extr = torch.cat([vl_extr, action_extr], dim=1)  # (B, L+La, 4, 4)
        # vla_pos = torch.cat([vl_pos_nd, action_pos], dim=1)  # (B, L+La, pos_dim)
        vla_pos = make_vla_pos_1d(is_vision_mask, Nee*La).unsqueeze(-1)  # (B, L+La, 1)
        # from IPython import embed; embed()

        vla_mrope: Tensor = self.mrope.generate(vla_pos)    # (B, L+La, D, 2)
        vla_crope: Tensor = self.crope.generate(vla_extr)   # (2, B, L+La, 4, 4)

        ### training, forward only once, no kv cache required
        vla_pe_pure = (
            PEData(impl=Noop, pe=None, d=self.crope_dim),
            PEData(impl=mRoPE, pe=vla_mrope, d=self.mrope_dim)
        )  # rope only, half dimension

        vla_pe_hybrid = (
            PEData(impl=cRoPE, pe=vla_crope, d=self.crope_dim),
            PEData(impl=mRoPE, pe=vla_mrope, d=self.mrope_dim)
        )  # GTA + RoPE

        outputs = {
            "vl0": vl0,                             # (B, L, C)
            "vl_highways": vl_highways,             # List of (B, L, C) Tensor
            "vla_split_size": vla_split_size, 
            "s_mask": vla_inputs.state_mask.clone(),    # (B, Nee, Ts, D)
            "a_mask": vla_inputs.action_mask.clone(),   # (B, Nee, Ta, D)
            "is_vision_mask": is_vision_mask,       # (B, L) 

            "vla_pe_pure": vla_pe_pure,
            "vla_pe_hybrid": vla_pe_hybrid,
            "vla_mask_seelang": vla_mask_seelang,
            "vla_mask_dilated": vla_mask_dilated,
        }
        
        ### inference, forward VL once, cache kv, and forward A multiple times
        vl_mrope, a_mrope = torch.split(vla_mrope, vla_split_size, dim=1)  # (B, L, D, 2)
        vl_crope, a_crope = torch.split(vla_crope, vla_split_size, dim=2)  # (2, B, L, 4, 4)
        vl_mask_seelang = vla_mask_seelang[:, :len_vl, :len_vl].contiguous()  # (B, L, L)
        vl_mask_dilated = vla_mask_dilated[:, :len_vl, :len_vl].contiguous()  # (B, L, L)
        a_mask_seelang = vla_mask_seelang[:, len_vl:].contiguous()  # (B, La, L+La)
        a_mask_dilated = vla_mask_dilated[:, len_vl:].contiguous()  # (B, La, L+La)

        vl_pe_pure = (
            PEData(impl=Noop, pe=None, d=self.crope_dim),
            PEData(impl=mRoPE, pe=vl_mrope, d=self.mrope_dim)
        )  # rope only, half dimension

        vl_pe_hybrid = (
            PEData(impl=cRoPE, pe=vl_crope, d=self.crope_dim),
            PEData(impl=mRoPE, pe=vl_mrope, d=self.mrope_dim)
        )  # GTA + RoPE

        a_pe_pure = (
            PEData(impl=Noop, pe=None, d=self.crope_dim),
            PEData(impl=mRoPE, pe=a_mrope, d=self.mrope_dim)
        )  # rope only, half dimension

        a_pe_hybrid = (
            PEData(impl=cRoPE, pe=a_crope, d=self.crope_dim),
            PEData(impl=mRoPE, pe=a_mrope, d=self.mrope_dim)
        )  # GTA + RoPE

        outputs.update({
            "vl_pe_pure": vl_pe_pure,
            "vl_pe_hybrid": vl_pe_hybrid,
            "vl_mask_seelang": vl_mask_seelang,
            "vl_mask_dilated": vl_mask_dilated,

            "a_pe_pure": a_pe_pure,
            "a_pe_hybrid": a_pe_hybrid,
            "a_mask_seelang": a_mask_seelang,
            "a_mask_dilated": a_mask_dilated,
        })

        # mark dynamic axes for dynamo
        torch._dynamo.mark_dynamic(a_mrope, 1)
        torch._dynamo.mark_dynamic(a_crope, 2)
        torch._dynamo.mark_dynamic(a_mask_seelang, (1, 2))
        torch._dynamo.mark_dynamic(a_mask_dilated, (1, 2))

        return outputs


def mask2img(mask: Tensor, out_path: str):
    import cv2
    import numpy as np

    assert mask.ndim == 2

    mask = mask.float().cpu().numpy() * 255
    mask = mask.astype(np.uint8)
    cv2.imwrite(out_path, mask)


class SplitNorm(nn.Module):
    def __init__(self, embed_dim: int):
        super().__init__()
        self.norm_vl = RMSNorm(embed_dim)
        self.norm_a = AdaRMSNorm(embed_dim)
    
    def forward(self, x: Tensor, t: Tensor, split: Tuple[int, int]):
        vl, a = x.split(split, dim=1)  # (B, L_vl, C), (B, La, C)
        vl = self.norm_vl(vl)
        a = self.norm_a(a, t)  # modulated by diffusion timestep
        return torch.cat([vl, a], dim=1)


class AttentionBlock(nn.Module):
    def __init__(self, embed_dim: int, num_heads: int):
        super().__init__()
        self.norm1 = SplitNorm(embed_dim)
        self.attn = MySimpleMHA(
            embed_dim, num_heads, proj_opt=ProjOpt.QKV,
            bias=True, qk_norm=True, gate=False
        )

        self.norm2 = SplitNorm(embed_dim)
        self.ffn = FFN(embed_dim, embed_dim * 2)
    
    def forward_vla(self, vla: Tensor, vla_pe: PEData, vla_mask: Tensor, film: Tensor, split: Tuple[int, int]):
        """In training stage, forward only once"""
        # SA
        residual = vla
        vla = self.norm1(vla, film, split)
        vla, _, vla_mask = self.attn(x=vla, c=vla, x_pe=vla_pe, c_pe=vla_pe, attn_mask=vla_mask)
        vla = vla + residual
        # FFN
        vla = vla + self.ffn(self.norm2(vla, film, split))
        return vla, vla_mask

    def forward_vl(self, vl: Tensor, vl_pe: PEData, vl_mask: Tensor, vl_cache: Optional[KVCache]):
        """In inference stage, forward only once"""
        # SA
        residual = vl
        vl = self.norm1.norm_vl(vl)
        vl, _, vl_mask = self.attn(x=vl, c=vl, x_pe=vl_pe, c_pe=vl_pe, attn_mask=vl_mask, kv_cache=vl_cache, update_cache=True)
        vl = vl + residual
        # FFN
        vl = vl + self.ffn(self.norm2.norm_vl(vl))
        return vl, vl_mask
    
    def forward_a(self, a: Tensor, a_pe: PEData, a_mask: Tensor, film: Tensor, vl_cache: KVCache):
        """In training stage, forward mutiple times"""
        # SA
        residual = a
        a = self.norm1.norm_a(a, film)
        a, _, a_mask = self.attn(x=a, c=a, x_pe=a_pe, c_pe=a_pe, attn_mask=a_mask, kv_cache=vl_cache, update_cache=False)
        a = a + residual
        # FFN
        a = a + self.ffn(self.norm2.norm_a(a, film))
        return a, a_mask


class HybridAttentionLayers(nn.Module):
    def __init__(self, embed_dim: int, num_heads: int, num_layers: int):
        super().__init__()
        self.num_layers = num_layers
        self.layers = nn.ModuleList([AttentionBlock(embed_dim, num_heads) for _ in range(num_layers)])

    def forward_vla(
        self, 
        vla: Tensor, 
        film_cond: Tensor, 
        context_outputs: Dict[str, Tensor], 
        export_feat_layers: Dict[int, Tensor | None] = {}
    ):
        for i, layer in enumerate(self.layers):
            layer: AttentionBlock
            
            if i % 2 == 0:
                vla, context_outputs["vla_mask_seelang"] = layer.forward_vla(
                    vla=vla,
                    vla_pe=context_outputs["vla_pe_pure"],
                    vla_mask=context_outputs["vla_mask_seelang"],
                    film=film_cond,
                    split=context_outputs["vla_split_size"],
                )
            else:
                vla, context_outputs["vla_mask_dilated"] = layer.forward_vla(
                    vla=vla,
                    vla_pe=context_outputs["vla_pe_hybrid"],
                    vla_mask=context_outputs["vla_mask_dilated"],
                    film=film_cond,
                    split=context_outputs["vla_split_size"],
                )

            if i < self.num_layers - 1:
                vl, a = vla.split(context_outputs["vla_split_size"], dim=1)
                if i in export_feat_layers:
                    export_feat_layers[i] = vl[context_outputs["is_vision_mask"]]

                vl = vl + context_outputs["vl_highways"][i]
                vla = torch.cat([vl, a], dim=1)
        
        return vla

    def forward_vl(
        self, 
        vl: Tensor, 
        context_outputs: Dict[str, Tensor],
    ):
        kv_caches = [KVCache() for _ in range(len(self.layers))]
        for i, layer in enumerate(self.layers):
            layer: AttentionBlock

            if i % 2 == 0:
                vl, context_outputs["vl_mask_seelang"] = layer.forward_vl(
                # vl, _ = layer.forward_vl(
                    vl=vl,
                    vl_pe=context_outputs["vl_pe_pure"],
                    vl_mask=context_outputs["vl_mask_seelang"],
                    vl_cache=kv_caches[i],
                )
            else:
                vl, context_outputs["vl_mask_dilated"] = layer.forward_vl(
                # vl, _ = layer.forward_vl(
                    vl=vl,
                    vl_pe=context_outputs["vl_pe_hybrid"],
                    vl_mask=context_outputs["vl_mask_dilated"],
                    vl_cache=kv_caches[i],
                )
            
            if i < self.num_layers - 1:
                vl = vl + context_outputs["vl_highways"][i]
        
        return vl, kv_caches
    
    def forward_a(
        self, 
        a: Tensor, 
        film_cond: Tensor, 
        context_outputs: Dict[str, Tensor], 
        kv_caches: List[KVCache]
    ):
        for i, layer in enumerate(self.layers):
            layer: AttentionBlock

            if i % 2 == 0:
                # a, context_outputs["a_mask_seelang"] = layer.forward_a(
                a, _ = layer.forward_a(
                    a=a,
                    a_pe=context_outputs["a_pe_pure"],
                    a_mask=context_outputs["a_mask_seelang"],
                    film=film_cond,
                    vl_cache=kv_caches[i],
                )
            else:
                # a, context_outputs["a_mask_dilated"] = layer.forward_a(
                a, _ = layer.forward_a(
                    a=a,
                    a_pe=context_outputs["a_pe_hybrid"],
                    a_mask=context_outputs["a_mask_dilated"],
                    film=film_cond,
                    vl_cache=kv_caches[i],
                )
        
        return a


class MaskedMLP(nn.Module):
    def __init__(self, neurons: List[int], ln: bool = False):
        super().__init__()
        self.enc_x = simple_mlp(neurons, ln=ln)
        self.enc_mask = simple_mlp(neurons, ln=ln)
    
    def forward(self, x: Tensor, mask: Tensor):
        mask = mask.float()
        x = self.enc_x(x * mask) * self.enc_mask(mask).sigmoid()
        return x


class DiffusionHead(nn.Module):
    """
    - Input: image observations and noisy action at `t`
    - Output: noisy action at `t-1`
    """

    def __init__(self, hdim: int, num_heads: int, num_layers: int):
        super().__init__()
        self.hdim = hdim
        self.num_layers = num_layers
        self.state_enc = MaskedMLP([self.pad_act_dim, hdim, hdim], ln=True)
        self.action_enc = MaskedMLP([self.pad_act_dim, hdim, hdim], ln=True)

        self.denoise_time_embed = SinusoidalPosEmbedPi0(hdim, min_period=4e-3, max_period=4.0)
        self.proj_timestep = nn.Sequential(
            nn.Linear(hdim, hdim), nn.SiLU(),
            nn.Linear(hdim, hdim), nn.SiLU(),
        )

        ### traj self attn + traj-context cross attn
        self.traj_context_attn = HybridAttentionLayers(
            hdim, num_heads, num_layers
        )

        ### final mlp
        self.final_norm = AdaRMSNorm(hdim)
        self.act_head = nn.Linear(hdim, self.pad_act_dim)
        self.reset_parameters()
    
    @property
    def pad_act_dim(self):
        return PAD_ACTION_SPACE_SIZE

    def reset_parameters(self):
        nn.init.zeros_(self.act_head.weight)

    def forward_vla(
        self, 
        denoise_timestep: Tensor, 
        trajectory: Tensor, 
        history: Tensor,
        latest_s: Tensor, 
        action_ref_pose: Tensor, 
        context_outputs: Dict[str, Tensor], 
        fp16: bool, 
        export_feat_layers: Dict[int, Tensor | None] = {}, 
    ):
        """
        Args:
            denoise_timestep: (B,), denoising time step
            trajectory: (B, Nee, Ta, act_dim)
            history: (B, Nee, Ts, act_dim)
            latest_s: (B, Nee, D)
            action_ref_pose: (B, Nee, 4, 4)
            context_outputs (Dict[str, Tensor]):
                * vl0: (B, L, C)
                * vl_highways (List[Tensor]): each of shape (B, L, C)
                * vla_split_size (Tuple[int, int]): 
                * s_mask (Tensor): (B, Nee, Ts, D)
                * a_mask (Tensor): (B, Nee, Ta, D)
                * vla_pe_pure (Tuple[PEData]):
                * vla_pe_hybrid (Tuple[PEData]):
                * vla_mask_seelang: (B, L+La, L+La)
                * vla_mask_dilated: (B, L+La, L+La)
            fp16 (bool): use bfloat16
            export_feat_layers (Dict[int, Tensor | None]): 

        Returns:
            action_epsilon: (B, Nee, Ta, act_dim)
        """
        denoise_time_embed = self.denoise_time_embed.generate(denoise_timestep)  # (B, hdim)
        denoise_time_embed: Tensor = self.proj_timestep(denoise_time_embed)      # (B, hdim)

        # 历史动作已知，相当于解噪时间步为t=1时刻的样本（这里定义t=0为noise, t=1为样本）
        prev_denoise_time_embed = self.denoise_time_embed.generate(torch.ones_like(denoise_timestep))  # (B, hdim)
        prev_denoise_time_embed: Tensor = self.proj_timestep(prev_denoise_time_embed)                  # (B, hdim)

        # noisy trajectory add temporal positional embeddings
        B, Nee, Ts, _ = history.shape
        B, Nee, Ta, _ = trajectory.shape
        
        hist_feats = self.state_enc(history, context_outputs["s_mask"])  # (B, Nee, Ts, hdim)
        traj_feats = self.action_enc(trajectory, context_outputs["a_mask"])  # (B, Nee, Ta, hdim)
        full_traj_feats = torch.cat([hist_feats, traj_feats], dim=-2)  # (B, Nee, Ts+Ta, hdim)

        full_denoise_time_embed = torch.cat([
            prev_denoise_time_embed[:, None, None].expand(B, Nee, Ts, -1),
            denoise_time_embed[:, None, None].expand(B, Nee, Ta, -1),
        ], dim=2)  # (B, Nee, Ts+Ta, hdim)

        # rearrange shape
        full_traj_feats = rearrange(full_traj_feats, "b n l c -> b (n l) c")    # (B, Nee*(Ts+Ta), C)
        full_denoise_time_embed = rearrange(full_denoise_time_embed, "b n l c -> b (n l) c")  # (B, Nee*(Ts+Ta), C)

        vla = torch.cat([context_outputs["vl0"], full_traj_feats], dim=1)

        with torch.autocast(
            denoise_time_embed.device.type, 
            torch.bfloat16 if fp16 else torch.float32
        ):
            vla = self.traj_context_attn.forward_vla(
                vla=vla,
                film_cond=full_denoise_time_embed,
                context_outputs=context_outputs,
                export_feat_layers=export_feat_layers
            )

        _, full_traj_feats = torch.split(vla, context_outputs["vla_split_size"], dim=1)  # (B, Nee*(Ts+Ta), C)
        full_traj_feats = rearrange(full_traj_feats, "b (n l) c -> b n l c", n=Nee, l=Ts+Ta)
        _, traj_feats = torch.split(full_traj_feats, [Ts, Ta], dim=2)  # (B, Nee, Ta, hdim)
        traj_feats = self.final_norm(traj_feats, denoise_time_embed[:, None, None])
        action = self.act_head(traj_feats)
        return action
    
    def forward_vl(
        self,
        context_outputs: Dict[str, Tensor], 
        fp16: bool
    ):
        """
        Args:
            context_outputs (Dict[str, Tensor]):
                * vl0: (B, L, C)
                * vl_highways (List[Tensor]): each of shape (B, L, C)
                * vl_pe_pure (Tuple[PEData]):
                * vl_pe_hybrid (Tuple[PEData]):
                * vl_mask_seelang: (B, L, L)
                * vl_mask_dilated: (B, L, L)
            fp16 (bool):
        
        Returns:
            kv_caches (List[KVCache]):
        """
        vl = context_outputs["vl0"]
        with torch.autocast(
            vl.device.type,
            torch.bfloat16 if fp16 else torch.float32
        ):
            vl, kv_caches = self.traj_context_attn.forward_vl(
                vl=vl,
                context_outputs=context_outputs
            )
        return kv_caches

    def forward_a(
        self,
        denoise_timestep: Tensor, 
        trajectory: Tensor, 
        history: Tensor,
        latest_s: Tensor, 
        action_ref_pose: Tensor, 
        context_outputs: Dict[str, Tensor], 
        kv_caches: List[KVCache], 
        fp16: bool
    ):
        """
        Args:
            denoise_timestep: (B,), denoising time step
            trajectory: (B, Nee, Ta, act_dim)
            history: (B, Nee, Ts, act_dim)
            latest_s: (B, Nee, D)
            action_ref_pose: (B, Nee, 4, 4)
            context_outputs (Dict[str, Tensor]):
                * a_pe_pure (Tuple[PEData]):
                * a_pe_hybrid (Tuple[PEData]):
                * a_mask_seelang: (B, L+La, L+La)
                * a_mask_dilated: (B, L+La, L+La)
            kv_caches (List[KVCache]): 
            fp16 (bool): use bfloat16

        Returns:
            action_epsilon: (B, Nee, Ta, act_dim)
        """
        denoise_time_embed = self.denoise_time_embed.generate(denoise_timestep)  # (B, hdim)
        denoise_time_embed: Tensor = self.proj_timestep(denoise_time_embed)      # (B, hdim)

        # 历史动作已知，相当于解噪时间步为t=1时刻的样本（这里定义t=0为noise, t=1为样本）
        prev_denoise_time_embed = self.denoise_time_embed.generate(torch.ones_like(denoise_timestep))  # (B, hdim)
        prev_denoise_time_embed: Tensor = self.proj_timestep(prev_denoise_time_embed)                  # (B, hdim)

        # noisy trajectory add temporal positional embeddings
        B, Nee, Ts, _ = history.shape
        B, Nee, Ta, _ = trajectory.shape

        hist_feats = self.state_enc(history, context_outputs["s_mask"])  # (B, Nee, Ts, hdim)
        traj_feats = self.action_enc(trajectory, context_outputs["a_mask"])  # (B, Nee, Ta, hdim)
        full_traj_feats = torch.cat([hist_feats, traj_feats], dim=-2)  # (B, Nee, Ts+Ta, hdim)

        full_denoise_time_embed = torch.cat([
            prev_denoise_time_embed[:, None, None].expand(B, Nee, Ts, -1),
            denoise_time_embed[:, None, None].expand(B, Nee, Ta, -1),
        ], dim=2)  # (B, Nee, Ts+Ta, hdim)

        # rearrange shape
        full_traj_feats = rearrange(full_traj_feats, "b n l c -> b (n l) c")    # (B, Nee*(Ts+Ta), C)
        full_denoise_time_embed = rearrange(full_denoise_time_embed, "b n l c -> b (n l) c")  # (B, Nee*(Ts+Ta), C)

        # mark dynamic axes for dynamo
        torch._dynamo.mark_dynamic(full_traj_feats, 1)
        torch._dynamo.mark_dynamic(full_denoise_time_embed, 1)
        for kv in kv_caches:
            torch._dynamo.mark_dynamic(kv.k, 2)
            torch._dynamo.mark_dynamic(kv.v, 2)

        with torch.autocast(
            denoise_time_embed.device.type, 
            torch.bfloat16 if fp16 else torch.float32
        ):
            full_traj_feats = self.traj_context_attn.forward_a(
                a=full_traj_feats,
                film_cond=full_denoise_time_embed,
                context_outputs=context_outputs,
                kv_caches=kv_caches
            )  # (B, Nee*(Ts+Ta), C)

        full_traj_feats = rearrange(full_traj_feats, "b (n l) c -> b n l c", n=Nee, l=Ts+Ta)
        _, traj_feats = torch.split(full_traj_feats, [Ts, Ta], dim=2)  # (B, Nee, Ta, hdim)
        traj_feats = self.final_norm(traj_feats, denoise_time_embed[:, None, None])
        action = self.act_head(traj_feats)
        return action


def pad_or_trunc(x: Tensor):
    D = x.shape[-1]
    assert D == ACTION_SPACE_SIZE

    if D == PAD_ACTION_SPACE_SIZE:
        pass
    elif D < PAD_ACTION_SPACE_SIZE:
        x = F.pad(x, (0, PAD_ACTION_SPACE_SIZE - D), value=0)
    else:
        x = x[..., :PAD_ACTION_SPACE_SIZE]
    
    return x


def pad_or_trunc_inputs(data: BatchDataTokenizedVLA):
    data.state = pad_or_trunc(data.state)
    data.state_mask = pad_or_trunc(data.state_mask)
    data.action = pad_or_trunc(data.action)
    data.action_mask = pad_or_trunc(data.action_mask)
    return data


def repeat_batch_vla(data: BatchDataTokenizedVLA, n: int = 1):
    if n == 1:
        return data
    
    repeat_raw_vl = data.raw_vl * n
    # skip repeat tokenized_vl as it is not called in action_expert
    repeat_modality = data.modality.repeat(n, 1)
    repeat_patch_pose = data.patch_pose.repeat(n, 1, 1)
    repeat_patch_norm_xy = data.patch_norm_xy.repeat(n, 1)
    
    repeat_state = data.state.repeat(n, 1, 1, 1)
    repeat_state_mask = data.state_mask.repeat(n, 1, 1, 1)
    repeat_action = data.action.repeat(n, 1, 1, 1)
    repeat_action_mask = data.action_mask.repeat(n, 1, 1, 1)
    repeat_action_ref_pose = data.action_ref_pose.repeat(n, 1, 1, 1)
    
    repeat_avg_pose = None
    if data._avg_pose is not None:
        repeat_avg_pose = data._avg_pose.repeat(n, 1, 1)
    
    return BatchDataTokenizedVLA(
        raw_vl=repeat_raw_vl,
        tokenized_vl=data.tokenized_vl,
        modality=repeat_modality,
        patch_pose=repeat_patch_pose,
        patch_norm_xy=repeat_patch_norm_xy,
        state=repeat_state,
        state_mask=repeat_state_mask,
        action=repeat_action,
        action_mask=repeat_action_mask,
        action_ref_pose=repeat_action_ref_pose,
        _avg_pose=repeat_avg_pose,
        _aux_data=data._aux_data,
    )


def repeat_vl_outputs(vl_outputs: Dict[str, Tensor], n: int = 1):
    if n == 1:
        return vl_outputs
    
    repeat_inputs_embeds = vl_outputs["inputs_embeds"].repeat(n, 1, 1)
    repeat_hidden_states = [h.repeat(n, 1, 1) for h in vl_outputs["hidden_states"]]
    repeat_position_ids = vl_outputs["position_ids"].repeat(1, n, 1)

    return {
        "inputs_embeds": repeat_inputs_embeds,
        "hidden_states": repeat_hidden_states,
        "position_ids": repeat_position_ids,
    }


class ActionExpert(nn.Module):
    def __init__(
        self, 
        idim: int, 
        hdim: int, 
        num_heads: int, 
        num_diffusion_layers: int, 
        inference_timesteps: int = 20, 
    ):
        super().__init__()
        self.context_encoder = ContextEncoder(idim, hdim, num_heads, num_diffusion_layers)
        self.dp_head = DiffusionHead(hdim, num_heads, num_diffusion_layers)
        self.inference_timesteps = inference_timesteps
        self.denoiser = get_denoiser("pi0")
        self.decenter = DecenterCamera()

    @property
    def pad_act_dim(self):
        """dimension of action defined in camera frame"""
        return self.dp_head.pad_act_dim

    def iterative_denoise(
        self, 
        traj_shape: Tuple[int, int, int, int],
        fixed_inputs: Dict[str, Tensor],
        initial_noise: Optional[Tensor] = None,
        kv_caches: Optional[List[KVCache]] = None
    ):
        """
        Args:
            trajectory_shape: (B, Nee, Ta, act_dim)
            fixed_inputs: inputs for diffusion head
            initial_noise: (B, Nee, Ta, act_dim) or None

        Returns:
            trajectory: (B, Nee, Ta, act_dim)
        """
        if initial_noise is None:
            device = next(self.parameters()).device
            initial_noise = torch.randn(traj_shape, device=device)

        def field_func(xt: Tensor, t: Tensor):
            """
            Args:
                xt: (B, ..., D)
                t: (1,) or (B,)
            """
            if kv_caches is not None:
                return self.dp_head.forward_a(
                    denoise_timestep=t * xt.new_ones(xt.shape[0]), 
                    trajectory=xt, 
                    kv_caches=kv_caches,
                    **fixed_inputs
                )
            else:
                return self.dp_head.forward_vla(
                    denoise_timestep=t * xt.new_ones(xt.shape[0]), 
                    trajectory=xt, 
                    **fixed_inputs
                )

        trajectory = self.denoiser.generate(
            initial_noise, field_func, n_steps=self.inference_timesteps
        )
        return trajectory

    def forward(
        self, 
        vla_inputs: BatchDataTokenizedVLA,
        vl_outputs: Dict[str, Tensor], 
        inference: bool, 
        fp16: bool,
        n_repeats: int = 1, 
    ):
        """
        Args:
            vla_inputs (BatchDataTokenizedVLA):
                - raw_vl: List[Optional[DataRawVL]]  # len = B
                - tokenized_vl: BatchFeature
                    * input_ids: Tensor  # (B, L)
                    * attention_mask: Tensor  # (B, L)
                    * pixel_values: Optional[Tensor]  # (L_imgs, C)
                    * image_grid_thw: Optional[Tensor]  # (N_imgs, 3)
                    * pixel_values_videos: Optional[Tensor]  # (L_vids, C)
                    * video_grid_thw: Optional[Tensor]  # (N_vids, 3)
                - modality: Tensor  # (B, L)

                - patch_pose: Tensor  # (L_imgs+L_vids, 4, 4)
                - patch_norm_xy: Tensor  # (L_imgs+L_vids, 2)

                - state: Tensor  # (B, Nee, Ts, state_dim), state_dim = 3 (trans) + 6 (rot6d) + 1 (gripper) + 20 (MANO hands) + ...
                - state_mask: Tensor  # shape compatible with state

                - action: Tensor  # (B, Nee, Ta, action_dim), action_dim = 3 (trans) + 6 (rot6d) + 1 (gripper) + 20 (MANO hands) + ...
                - action_mask: Tensor  # shape compatible with action
                - action_ref_pose: Tensor  # (B, Nee, 4, 4)
            
            vl_outputs (Dict[str, Tensor]):
                - inputs_embeds (Tensor): shape = (B, L, C), L = Lpad + Ncam*Lv + Llang
                - hidden_states (List[Tensor]): len = n_layers, shape = (B, L, C), L = Lpad + Ncam*Lv + Llang
                - position_ids: (Tensor): shape = (D, B, L), D = 3, [t, h, w]
        
            inference: if True, returns the predicted trajectory, otherwise returns loss and metrics for logging
            fp16: if True, use bfloat16
            n_repeats: number of repeats for batch
        
        Returns
        -------
        (if inference is True)
            pred_future_ee_states (Tensor): (B, Nee, Ta, act_dim)
        (else)
            loss (Tensor): scalar tensor
            metrics (Dict[str, Tensor]): metrics for logging
        """
        vla_inputs = pad_or_trunc_inputs(vla_inputs)
        
        vla_inputs = repeat_batch_vla(vla_inputs, n_repeats)
        vl_outputs = repeat_vl_outputs(vl_outputs, n_repeats)

        context_outputs: Dict[str, Tensor] = self.context_encoder(
            vla_inputs=vla_inputs, 
            vl_outputs=vl_outputs, 
        )
        
        # rotation action will be transformed from rot6d to rotvec, 
        # we need to modify the action mask (state keeps rot6d representation)
        lo, hi = START_END_INDICES["rot6d"]
        context_outputs["a_mask"][..., lo+3:lo+6] = False


        latest_s = vla_inputs.state[:, :, -1]  # (B, Nee, D)
        history_action = ActionTransform.weT_to_ceT(
            cur_wcT=vla_inputs.action_ref_pose,
            a=vla_inputs.state,  # (B, Nee, Ts, D)
        )

        if not inference:
            gt_future_action, gt_future_action_mask = ActionTransform.weT_to_ccT(
                cur_wcT=vla_inputs.action_ref_pose, 
                s=latest_s, 
                a=vla_inputs.action,
                a_mask=vla_inputs.action_mask
            )  # (B, Nee, Ta, D)
            vla_inputs.action_mask = gt_future_action_mask

        fixed_inputs = dict(
            history=history_action,
            latest_s=latest_s,
            action_ref_pose=vla_inputs.action_ref_pose,
            context_outputs=context_outputs, 
            fp16=fp16
        )

        ###################### Inference ######################
        if inference:
            kv_caches = self.dp_head.forward_vl(
                context_outputs=context_outputs,
                fp16=fp16
            )

            pred_actions = self.iterative_denoise(
                traj_shape=vla_inputs.action.shape,
                fixed_inputs=fixed_inputs,
                kv_caches=kv_caches, 
            )  # (B, Nee, Ta, act_dim)

            pred_future_ee_states, pred_future_action_mask = ActionTransform.ccT_to_weT(
                cur_wcT=vla_inputs.action_ref_pose,     # (B, Nee, 4, 4)
                s=latest_s,                             # (B, Nee, D)
                a=pred_actions,                         # (B, Nee, Ta, act_dim)
                a_mask=vla_inputs.action_mask
            )  # (B, Nee, Ta, act_dim)

            # revert avg pose subtraction
            if vla_inputs._avg_pose is not None:
                # _avg_pose: (B, 4, 4)
                pred_future_ee_states = self.decenter(
                    avg_pose=vla_inputs._avg_pose,
                    raw=pred_future_ee_states
                )

            return pred_future_ee_states * pred_future_action_mask.float()  # (B, Nee, Ta, D)

        ###################### Training ######################
        def field_fn(xt: Tensor, t: Tensor):
            """
            Args:
                xt: (B, ..., D)
                t: (B,)
            """
            return self.dp_head.forward_vla(
                denoise_timestep=t, 
                trajectory=xt, 
                **fixed_inputs
            )
        
        pred, target = self.denoiser.train_forward(gt_future_action, field_fn)
        _, metrics = compute_loss(pred, target, gt_future_action_mask)
        l2_loss = compute_loss_simple(pred, target, gt_future_action_mask)
        metrics["l2_total"] = l2_loss.item()
        return l2_loss, metrics


def compute_loss_simple(pred: Tensor, gt: Tensor, mask: Tensor):
    return F.mse_loss(pred[mask], gt[mask], reduction="mean")


def compute_loss(pred: Tensor, gt: Tensor, mask: Tensor):
    ACTION_LOSS_WEIGHT = {
        "trans": 1.0,
        "rot6d": 1.0,
        "gripper": 1.0,
        "dexhand": 0.02,
    }

    chunk_sizes = list(v[0] for v in ORDERED_ACTION_SPACE.values())
    if PAD_ACTION_SPACE_SIZE > ACTION_SPACE_SIZE:
        chunk_sizes.append(PAD_ACTION_SPACE_SIZE - ACTION_SPACE_SIZE)
    elif PAD_ACTION_SPACE_SIZE < ACTION_SPACE_SIZE:
        chunk_sizes[-1] -= ACTION_SPACE_SIZE - PAD_ACTION_SPACE_SIZE

    mask_sec = torch.split(mask, chunk_sizes, dim=-1)
    pred_sec = torch.split(pred, chunk_sizes, dim=-1)
    gt_sec = torch.split(gt, chunk_sizes, dim=-1)

    total_loss = torch.tensor(0.0).to(pred)
    metrics: Dict[str, float] = {}
    for i, name in enumerate(ORDERED_ACTION_SPACE.keys()):
        if mask_sec[i].any():
            loss = F.l1_loss(
                pred_sec[i][mask_sec[i]], 
                gt_sec[i][mask_sec[i]], 
                reduction="mean"
            )
            total_loss = total_loss + ACTION_LOSS_WEIGHT[name] * loss
            metrics[name] = loss.item()
    metrics["l1_total"] = total_loss.item()
    return total_loss, metrics

