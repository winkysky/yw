# 原版 iE2VLA3：LeRobot 全量 Qwen 四卡训练

无速度版入口为 `models.m0512_fm.train_lerobot_dual`。从 2026-11-16 起，默认使用人工复核数据、Qwen 全量训练及四卡 DDP。

2026-11-22 新增两组等频训练配置：A 组为 239 + 68 条复核轨迹，B 组为 `close_box_1118` 的 694 条，每个全局 batch 各占 50%。执行 `bash /home/hq/code/iE2VLA3/scripts/train_lerobot_balanced.sh`，详见 [分组采样和启动说明](../../configs/lerobot_balanced_20261122/README.md)。下文的旧默认配置继续保留。

## 默认参数

| 项目 | 默认值 |
| --- | --- |
| 数据配置 | `lerobot_huawei_close_box_original.json` |
| 数据入口 | `/home/hq/code/huawei_261112/reviewed_training_20261115/filtered_data` |
| 模型 | 原版 `VLA base`，无速度条件，cRoPE 保留 |
| Qwen | `Qwen3-VL-2B-Instruct`，所有参数 `requires_grad=True`，LoRA 关闭 |
| 分布式 | 单机四卡 NCCL DDP，AdamW ZeRO-1 优化器状态分片 |
| batch | 每卡 8，梯度累积 1，全局 32 |
| 训练步数 | 100000 次优化器更新 |
| 保存间隔 | 每 10000 步；最后一步也保存 |
| 学习率 | `1e-4`，2000 步线性 warmup 后余弦衰减 |
| weight decay / 梯度裁剪 | `1e-5` / `1.0`；bias、norm 等参数不衰减 |
| workers / CPU threads | 每进程各 4 |
| 随机种子 / 日志间隔 | 42 / 10 步 |
| 图像 | 头、左腕、右腕，三路 192×256（H×W） |
| 时序 | 1 帧状态、32 步动作；stride=1，action_offset=0；30 Hz 下约 1.07 秒 |
| 推理采样步数 / 噪声重复 | 4 / 1 |
| 输出目录 | `checkpoints/lerobot_original_full_reviewed` |

Qwen 保留加载时的 BF16 权重，Actor 保留 FP32 权重；前向使用 BF16 autocast。AdamW 的 Qwen moment 状态也是 BF16，没有额外 FP32 master 权重。两个 dtype 各使用一个 ZeRO-1 optimizer，学习率调度一致；`foreach=False` 控制更新阶段的临时显存。

Qwen 在模型初始化完成后解冻，避免原版 Actor 初始化逻辑修改预训练 Qwen 的 bias。全量模式计算完整语言网络，并将最终归一化输出接入 Actor 最后一个实际使用的特征连接，使视觉编码器、全部语言 block 和最终 RMSNorm 都能获得动作损失梯度。模块形状及 Actor 层数保持原样。特征模式由 checkpoint 的 `model_config.train_qwen` 恢复，推理必须使用相同 builder。

## 数据读取合同

`filtered_data` 只有数值修正副本，不含独立的 LeRobot 元数据和视频。`dataset/lerobot_reviewed.py` 调用同级交付包的 `read_training.py`，校验快照、人工 keep 决定、原始文件和修正副本，再构造训练窗口。DDP 下只在 rank 0 执行一次完整校验，并将已验证的紧凑索引传给其他 rank。

- 唯一枚举来源是已验证的 `task_segments.jsonl`；当前共 239 条保留轨迹、288 个片段。
- 使用清单加载器返回的修正 Parquet；没有修正副本的片段按清单读取已核验的原始 Parquet。
- prompt 使用人工确认的 `segment.instruction`，包括子任务 prompt。
- 历史和动作所有访问行都检查边界与排除区间。丢弃不完整窗口，不跨坏帧或子任务拼接、不做隐式 padding。
- 视频按原始 episode/frame 编号从对应 `source_root` 读取。
- 当前默认 1+32 配置得到 **64241 个训练窗口**，不加入 253 条 pending 或 1 条 exclude 轨迹。
- 每个 epoch 使用同一全局 shuffle，再按 rank 划分互不重叠的 batch；不足一个全局 batch 的尾部丢弃。

仍支持通过 `--data-root` 指向普通 LeRobot v2 根目录。默认复核快照保持其 `pilot` 状态；不修改数据交付包或绕过其校验。训练恢复会比对快照指纹，防止混用不同版本的复核结果。

## 双臂与相机坐标

模型 world 为左臂记录 base。使用固定版本的 [yw 标定](https://github.com/winkysky/yw/blob/aa219ea6779a2b30101f2de80b2dfc499185ee3f/lerobot_hdf5_tools/camera_params.json)：左 base 映射为单位矩阵；右 base 到左 base 约为 `Rx(180°)`，平移 `[0.000221830, -0.000030121, -0.230034851]` 米，实际使用 JSON 的完整精度矩阵。

```text
left_base_T_right_TCP = left_base_T_right_base @ right_base_T_flange @ flange_T_TCP
left_base_T_right_camera = left_base_T_right_base @ right_base_T_flange @ flange_T_camera
```

`observation.tcp_pose` / `action.tcp_pose_cmd` 按源仓库解释为法兰 xyz 毫米、外旋 XYZ 欧拉角度。读取时转换为米并附加工具变换；历史与动作执行同一基座映射。头相机已在左 base，腕相机附着于当前法兰；内参由 640×480 按像素中心约定缩放。夹爪 1886=关、0=开，内部开度为 0=关、1=开。

源仓库的基座关系来自 URDF/记录位姿拟合；头相机未重新标定，右 TCP 工具偏移仍为左臂的暂定副本。已统一坐标的输入需配置单位 base 映射，避免重复转换。

## 启动与恢复

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

# 校验所有复核轨迹并抽查真实图像，不加载 Qwen，不启动 GPU 训练
python -m models.m0512_fm.train_lerobot_dual --check-data --check-all-episodes

# 自动通过 torchrun 启动四个进程，每卡 8，总 batch 32
CUDA_VISIBLE_DEVICES=0,1,2,3 python -m models.m0512_fm.train_lerobot_dual

# 也可以显式使用 torchrun；入口识别 RANK，不会再启动一层进程
CUDA_VISIBLE_DEVICES=0,1,2,3 torchrun --standalone --nproc_per_node=4 \
  -m models.m0512_fm.train_lerobot_dual

# 从第 1 万步恢复；保持原来的数据、模型、world size 和训练超参数
CUDA_VISIBLE_DEVICES=0,1,2,3 python -m models.m0512_fm.train_lerobot_dual \
  --resume checkpoints/lerobot_original_full_reviewed/step_0010000
```

单卡调试可显式使用 `--nproc-per-node 1 --batch-size 1`。`--no-train-qwen` 选择冻结 Qwen 的原始特征路径；`--optimizer-sharding none` 关闭 optimizer 状态分片。普通 `python ... --help` 显示所有可覆盖参数。`--batch-size` 始终表示每卡样本数。

本机四张 24 GiB RTX 4090 的实际训练使用 `--batch-size 4 --gradient-accumulation-steps 2`，全局 batch 仍为 32，并设置 `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True`。此前每卡 batch 8 的全量训练出现显存不足。更改动作长度后应从头训练并指定新的 `--output`；32 步动作长度由数据配置 `num_future_actions` 控制，`--inference-timesteps 4` 是 Flow Matching 的生成迭代次数。

## Checkpoint

完整格式为 `lerobot_original_full_v2`。每个 `step_XXXXXXX/` 目录包含：

- `model.pt`：完整 Qwen + Actor 权重、模型/数据/训练配置、快照指纹、训练步数及采样位置。
- `rank_00000.pt` 到 `rank_00003.pt`：各 rank 的 optimizer 状态分片、scheduler、独立随机数状态和采样位置。
- `complete.json`：全部文件写完后生成；整个临时目录原子重命名为最终目录。

保存时不在单张 GPU 上聚合全部 Adam 状态。恢复需要相同 world size、每卡 batch、梯度累积和训练选项，以恢复相同的分片及下一次更新。旧 `lerobot_original_v1` 只保存 Actor，不能恢复当前全量训练；坐标修复之前的旧 checkpoint 也不能直接续训。

推理加载完整权重：

```python
import torch
from models.m0512_fm.train_lerobot_dual import build_model
from models.m0512_fm.lerobot_runtime import configure_conv3d_layout

saved = torch.load("checkpoints/lerobot_original_full_reviewed/step_0010000/model.pt",
                   map_location="cpu", weights_only=False)
model = build_model(**saved["model_config"])
model.load_state_dict(saved["model"], strict=True)
model = model.cuda().eval().requires_grad_(False)
configure_conv3d_layout(model)
```

## 验证与速度版

### LeRobot 双臂数据与推理轨迹可视化

`datavis.py --lerobot` 使用当前数据读取器和训练 collator，支持完整 `lerobot_original_full_v2` checkpoint。推理从 checkpoint 恢复 Qwen、Actor、全量特征模式、数据标定及动作长度，未来动作输入清零，仅保留形状和 mask。输出仍在左臂 base 下，按当前观察时刻的三路相机位姿投影。

```bash
# 数据与模型推理：默认 CPU，适合 GPU 正在训练时使用。
python datavis.py --lerobot \
  --checkpoint checkpoints/lerobot_original_full_reviewed_h32_20261116_021607/step_0020000 \
  --device cpu --num-samples 5 --output audits/lerobot_step20000_visualization

# 按数据集样本索引选取观察窗口。
python datavis.py --lerobot --checkpoint /path/to/step_0020000 \
  --indices 0 100 1000 --output audits/lerobot_selected_windows

# 仅可视化数据，不加载模型。
python datavis.py --lerobot --indices 0 --output audits/lerobot_data_only

# 有图形桌面且 GPU 空闲时，可使用 CUDA 并打开原来的交互浏览方式。
python datavis.py --lerobot --checkpoint /path/to/step_0020000 \
  --device cuda:0 --num-samples 1 --show
```

导出目录包含 `index.html` 图册、每个样本的三相机投影 PNG、三维轨迹与夹爪曲线 PNG、NPZ 原始轨迹和 JSON 元数据/误差。默认选样先覆盖各数据来源，再补充其他轨迹；绿色为记录的指令轨迹、蓝色为预测，上排左臂、下排右臂。视野外、相机背后及无效动作行不绘制。NPZ 的 `prediction` 和 `ground_truth` 均为 `[2, horizon, 73]`，前三维为左臂 base 下的 TCP 米制位置，旋转为 rot6d，第 9 维为归一化夹爪开度。

`--show` 快捷键：`n/p` 切换轨迹，左右箭头或 `d/b` 切换有效观察窗口，`a` 切换步长 1/10，`i` 切换推理，`q` 退出。复核数据只导航有效窗口，跳过排除帧及不能组成完整动作块的边界。原来的 HDF5 `datavis.py` 用法保留。

JSON 的位置误差是同一步预测与记录指令之间的欧氏距离（mm），旋转误差是 SO(3) 夹角（度）；夹爪 MAE 使用归一化开度。数据来自训练集时，这些离线误差不代表未见轨迹泛化或闭环实机成功率。

### Pyro4 双臂推理

机器人端继续使用原 e2vla 客户端，通过 [e2vla 兼容服务端](../../e2vla_compat/README.md) 调用当前模型。服务入口为 `e2vla_compat.remote_service`，保留 `reset/set_prompt/add_obs_frames/get_action` 等旧接口。默认输入为 `recorded/raw`，由服务端处理单位、工具和左右基座转换；也支持已在公共坐标系中的 `tcp_world/openness` 模式。配置必须与客户端实际上传内容一致，ROS TF 客户端需在服务端显式选择 `tcp_world/openness`。

下文的 `models.m0512_fm.service_lerobot` 和启动脚本 `scripts/serve_lerobot_pyro.sh` 保留给直接观测接口及数据可视化使用，也是兼容服务端复用的模型后端。它读取完整 Qwen + Actor checkpoint，复用训练时的坐标变换、三相机标定、prompt/tokenizer 和全量 Qwen 特征模式。旧 `models.m0512_fm.service` 使用另一种 checkpoint 格式，不能直接读取当前完整模型文件。

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

# 终端一：自动创建本地名称服务，或使用已有名称服务。
# CPU 默认 4 个线程，适合四张 GPU 正在训练时使用。
bash scripts/serve_lerobot_pyro.sh \
  --checkpoint checkpoints/lerobot_original_full_reviewed_h32_20261116_021607/step_0020000 \
  --uri ie2vla3_lerobot_h32 --device cpu --ns-port 19090 --port 19091

# 终端二：通过 Pyro4 推理并导出三相机投影/三维轨迹。
python datavis.py --lerobot --uri ie2vla3_lerobot_h32 \
  --ns-port 19090 --num-samples 5

# 强制 TCP；有图形桌面时添加 --show 可交互浏览。
python datavis.py --lerobot --uri ie2vla3_lerobot_h32 \
  --ns-port 19090 --tcp --indices 214 --show
```

`--checkpoint` 和 `--uri` 二选一。远程可视化客户端从服务获取数据配置、标定、32 步长度和快照指纹，只需访问数据及视频，不加载 Qwen 或 checkpoint。模型所在设备由服务端 `--device` 决定；有空闲 GPU 时可改为 `cuda:0`。脚本可通过 `IE2VLA_PYTHON=/path/to/python` 覆盖默认解释器。同名服务已注册时会报错，避免覆盖正在使用的服务；正常退出会注销名称。

同机默认使用共享内存，`--tcp` 强制走 TCP；跨机器自动使用 TCP。跨机器部署时，服务端同时设置 `--ns-host <服务器内网IP> --host <服务器内网IP>`，客户端设置同一个 `--ns-host`，端口保持一致。现有传输使用 pickle，只用于可信内网。独立名称服务可用 `python -m Pyro4.naming -n <IP> -p 19090` 启动；直接运行 Python 服务模块时，不带 `--start-ns` 表示名称服务必须已存在。

实时观测接口不需要未来动作或速度，示例中的数组应由同一观察时刻的机器人和相机数据填充：

```python
import numpy as np
from client import Client

client = Client("ie2vla3_lerobot_h32", ns_host="127.0.0.1", ns_port=19090)
try:
    print(client.policy_info)  # step、output_shape、data_config、output_frame
    observation = {
        # shape [1, 12]，左臂六维 + 右臂六维；使用记录时各自的 base。
        # 与训练字段一致：法兰 xyz 毫米、外旋 XYZ 欧拉角度。
        "observation.tcp_pose": np.asarray(tcp_pose_rows, dtype=np.float32),
        # shape [1, 14]；第 6、13 维为左右夹爪，1886=关、0=开。
        "observation.state": np.asarray(joint_state_rows, dtype=np.float32),
        "instruction": "close the box",
        "images": {
            "observation.images.head_image": head_rgb,
            "observation.images.left_wrist_image": left_wrist_rgb,
            "observation.images.right_wrist_image": right_wrist_rgb,
        },
    }
    actions = client.inference_observation(observation, seed=42)
    # numpy float32 [2, 32, 73]：左臂、右臂。
    xyz = actions[..., :3]       # 左臂 base 下的 TCP 位置，米。
    rot6d = actions[..., 3:9]    # 旋转矩阵的前两行展开。
    openness = actions[..., 9]  # 归一化开度，0=关、1=开。
finally:
    client.close()
```

三路图像必须为 RGB `uint8 [H,W,3]`，OpenCV BGR 图像需先转 RGB；支持未裁剪的 640×480 或等比例图像，服务端缩放到训练使用的 256×192。历史长度、字段名、夹爪端点和图像顺序以 `client.data_config` 为准。服务端将记录位姿转换为 TCP，并将右臂统一到左臂 base，再根据当前法兰姿态计算腕相机外参；输出第 10–72 维未训练，不用于控制。输出是左臂 base 下的 TCP 轨迹，机器人若接受各自 base 下的法兰指令，执行前仍需做逆坐标/工具变换及控制器适配。

另外保留两个接口：`client.inference_raw(sample, seed=42)` 接收数据读取器返回的 `DataRawVLA`，其中双臂状态必须**已经**是左臂 base 下的 TCP、米/rot6d/归一化开度，服务端只重建相机标定，不重复转换 base；`client.inference_batch(batch, seed=42)` 接收由相同配置和 `LeRobotOriginalCollator` 生成的 batch，返回 CPU Tensor `[B,2,32,73]`。三种接口都会清零未来动作值，保留形状与 mask；固定 seed 用于复现，不提供 seed 时自然随机采样。

真实 checkpoint/socket 回归（需先启动服务）：

```bash
PYTHONPATH=. python tests/pyro_lerobot_probe.py \
  --uri ie2vla3_lerobot_h32 --ns-port 19090 \
  --output audits/lerobot_pyro_check/validation.json
```

它比较本地推理与 TCP/共享内存的 raw、batch、原始观测接口，并检查固定 seed 复现、修改未来 GT 不影响预测、错误动作长度被拒绝。

```bash
python -m pytest tests -q

# 小型真实 Qwen/VLA 的四卡 NCCL 回归，无需下载预训练权重
# 输出目录须为空或不存在；测试会写完整模型及 optimizer 分片。
torchrun --standalone --nproc_per_node=4 tests/distributed_full_training_probe.py \
  --output /tmp/ie2vla3-full-ddp-test --cuda
```

验证覆盖全量 Qwen 梯度、四 rank 样本划分、混合 dtype 优化器分片、梯度累积、参数同步，以及保存恢复后下一次 loss、全部权重与 optimizer 状态一致。小模型验证不代表完整 2B 模型的长程收敛或实机效果。

速度版入口 `train_lerobot_dual_velocity` 保留原有独立配方：冻结 Qwen、单卡每批 32、32 步重采样及速度条件，见 [速度版说明](README_lerobot_dual_velocity.md)。本次修改针对无速度版默认训练。
