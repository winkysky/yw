"""Pyro4 service for the no-speed full-Qwen LeRobot dual-arm checkpoint."""
import argparse
import copy
import json
from pathlib import Path
import signal
import threading

import cv2
import Pyro4
import Pyro4.naming
import torch

from data_utils.tokenize import BatchDataTokenizedVLA
from dataset.lerobot_original import LeRobotOriginalConfig, LeRobotOriginalCollator
from shm_transport import expose, run_simple_server
from .lerobot_inference import (load_checkpoint, load_inference_model, infer_batch,
                                prepare_raw, observation_to_sample, world_observation_to_sample, validate_state_action)


class Service:
    def __init__(self, checkpoint, device="cpu"):
        self.device = torch.device(device)
        if self.device.type not in {"cpu", "cuda"}:
            raise ValueError("device must be cpu or cuda:N")
        if self.device.type == "cuda":
            torch.cuda.set_device(self.device)
        saved, model_path = load_checkpoint(checkpoint)
        self.data_config = LeRobotOriginalConfig(**saved["data_config"])
        self.data_config.validate()
        if self.data_config.geometry is None:
            raise ValueError("A calibrated checkpoint is required")
        self.model = load_inference_model(saved, self.device)
        self.collator = LeRobotOriginalCollator(self.model.vlm.processor)
        self.model_lock = threading.Lock()
        self.policy_info = {key: saved[key] for key in ["format", "step", "model_config", "data_config", "dataset_fingerprint"]}
        self.policy_info.update(checkpoint=str(model_path), device=str(self.device),
                                input_contract="lerobot_dual_v1", arm_order=["left", "right"],
                                output_frame="left_recorded_arm_base", output_shape=[2, self.data_config.num_future_actions, 73],
                                output_units="xyz metres, rotation first two matrix rows, gripper openness 0=closed/1=open")
        # Current HW LeRobot training streams are 30 Hz (README/data validation).
        # Preserve action_offset=0; the first target is at observation time.
        cfg = self.data_config
        self.policy_info.update(world_observation_contract="lerobot_world_tcp_v1",
                                world_observation_wire="builtin_arrays_v1", fps=30.,
                                state_dt=cfg.frame_stride / 30.,
                                action_time_offsets=[(cfg.action_offset + i * cfg.frame_stride) / 30.
                                                     for i in range(cfg.num_future_actions)])

    @expose(en_ret_sh_cuda=False)
    def get_policy_info(self):
        return copy.deepcopy(self.policy_info)

    @expose(en_ret_sh_cuda=False)
    def get_data_config(self):
        return self.data_config.to_dict()

    @expose(en_ret_sh_cuda=False)
    def inference_raw(self, data, seed=None):
        with self.model_lock:
            sample = prepare_raw(data, self.data_config)
            batch = BatchDataTokenizedVLA(**self.collator([sample]))
            return infer_batch(self.model, batch, self.device, seed)[0].numpy()

    @expose(en_ret_sh_cuda=False)
    def inference_observation(self, observation, seed=None):
        with self.model_lock:
            sample = observation_to_sample(observation, self.data_config)
            batch = BatchDataTokenizedVLA(**self.collator([sample]))
            return infer_batch(self.model, batch, self.device, seed)[0].numpy()

    @expose(en_ret_sh_cuda=False)
    def inference_world_observation(self, observation, seed=None, return_numpy=True):
        if type(return_numpy) is not bool:
            raise ValueError("return_numpy must be boolean")
        with self.model_lock:
            sample = world_observation_to_sample(observation, self.data_config)
            batch = BatchDataTokenizedVLA(**self.collator([sample]))
            prediction = infer_batch(self.model, batch, self.device, seed)[0].numpy()
            return prediction if return_numpy else prediction.tolist()

    @expose(en_ret_sh_cuda=False)
    def inference_batch(self, data, seed=None):
        if isinstance(data, dict):
            data = BatchDataTokenizedVLA(**data)
        if not isinstance(data, BatchDataTokenizedVLA):
            raise TypeError("Expected BatchDataTokenizedVLA from LeRobotOriginalCollator")
        with self.model_lock:
            validate_state_action(data, self.data_config, batched=True)
            return infer_batch(self.model, data, self.device, seed)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", "--ckpt", type=Path, required=True)
    parser.add_argument("--uri", default="ie2vla3_lerobot")
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--ns-host", "--ns_host", default="127.0.0.1")
    parser.add_argument("--ns-port", "--ns_port", type=int, default=9090)
    parser.add_argument("--host", default="127.0.0.1", help="Address advertised to clients; use this machine's LAN IP for remote clients")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--start-ns", action="store_true", help="Create a local name server if none is reachable at ns-host/ns-port")
    args = parser.parse_args(argv)
    if args.threads < 1:
        parser.error("threads must be positive")
    torch.set_num_threads(args.threads)
    cv2.setNumThreads(1)
    ns_daemon = None
    stopped = threading.Event()
    old_handler = signal.signal(signal.SIGTERM, lambda *_: stopped.set())
    try:
        try:
            ns = Pyro4.locateNS(host=args.ns_host, port=args.ns_port)
        except Pyro4.errors.NamingError:
            if not args.start_ns:
                raise
            _, ns_daemon, _ = Pyro4.naming.startNS(host=args.ns_host, port=args.ns_port, enableBroadcast=False)
            threading.Thread(target=ns_daemon.requestLoop, daemon=True).start()
            ns = Pyro4.locateNS(host=args.ns_host, port=args.ns_port)
        try:
            ns.lookup(args.uri)
        except Pyro4.errors.NamingError:
            pass
        else:
            raise ValueError(f"Service name already registered: {args.uri}; choose a different --uri")
        finally:
            ns._pyroRelease()
        print(json.dumps(dict(status="loading", checkpoint=str(args.checkpoint), device=args.device)), flush=True)
        service = Service(args.checkpoint, args.device)
        print(json.dumps(dict(status="model_loaded", **service.get_policy_info()), ensure_ascii=False), flush=True)
        run_simple_server(service, uri_name=args.uri, ns_host=args.ns_host, ns_port=args.ns_port,
                          daemon_host=args.host, daemon_port=args.port, replace_existing=False,
                          loop_cond=lambda: not stopped.is_set())
    finally:
        signal.signal(signal.SIGTERM, old_handler)
        if ns_daemon is not None:
            ns_daemon.shutdown()
            ns_daemon.close()


if __name__ == "__main__":
    main()
