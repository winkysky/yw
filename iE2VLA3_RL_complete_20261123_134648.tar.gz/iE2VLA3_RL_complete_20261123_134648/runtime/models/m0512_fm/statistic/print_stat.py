import os
from .nd_tdigest import ndTDigest


here = os.path.dirname(__file__)
digest = ndTDigest.load(os.path.join(here, "statistics.pkl"))
print("01:", digest.percentile(1))
print("50:", digest.percentile(50))
print("99:", digest.percentile(99))


from IPython import embed
embed()


