import torch
from torch import Tensor
from action.parser import ProprioParser
from action.transform import full_invariant, rot_invariant


class ActionTransform(object):

    # inv_impl = full_invariant
    inv_impl = rot_invariant

    @classmethod
    def _normalize(cls, p: ProprioParser):
        p.gripper = p.gripper * 2 - 1

    @classmethod
    def _denormalize(cls, p: ProprioParser):
        p.gripper = (p.gripper + 1) / 2.0

    @classmethod
    def weT_to_ccT(cls, cur_wcT: Tensor, s: Tensor, a: Tensor):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            s (Tensor): (..., D)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        S = ProprioParser(s)
        A = ProprioParser(a.clone())
        
        # transform wrist pose
        ccT = cls.inv_impl.weT_to_ccT(cur_wcT, S.posemat, A.posemat)
        A.posemat = ccT

        # transform finger position
        delta_dexhand = A.dexhand - S.dexhand.unsqueeze(-2)  # (B, T, D)
        B = delta_dexhand.shape[:-2]
        T, Dex = delta_dexhand.shape[-2:]

        delta_pos = delta_dexhand.view(*B, T, -1, 3)  # (B, T, N, 3)
        cur_cwT = torch.inverse(cur_wcT)  # (B, 4, 4)
        delta_pos = delta_pos @ cur_cwT[..., None, :3, :3].transpose(-1, -2)
        A.dexhand = delta_pos.reshape(*B, T, Dex)  # ^c t _{e*} - ^c t _e

        # normalize
        cls._normalize(A)
        return A.raw
    
    @classmethod
    def ccT_to_weT(cls, cur_wcT: Tensor, s: Tensor, a: Tensor):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            s (Tensor): (..., D)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        S = ProprioParser(s)
        A = ProprioParser(a.clone())

        # denormalize
        cls._denormalize(A)

        # transform wrist pose
        weT = cls.inv_impl.ccT_to_weT(cur_wcT, S.posemat, A.posemat)
        A.posemat = weT

        # transform finger position
        A_dex_shapes = A.dexhand.shape
        B = A_dex_shapes[:-2]
        T, Dex = A_dex_shapes[-2:]

        delta_pos = A.dexhand.view(*B, T, -1, 3)  # (B, T, N, 3)
        delta_pos = delta_pos @ cur_wcT[..., None, :3, :3].transpose(-1, -2)
        dexhand = delta_pos.reshape(*B, T, Dex)
        dexhand = dexhand + S.dexhand.unsqueeze(-2)
        A.dexhand = dexhand

        return A.raw
    
    @classmethod
    def ccT_to_ceT(cls, cur_wcT: Tensor, s: Tensor, a: Tensor):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            s (Tensor): (..., D)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        S = ProprioParser(s)
        A = ProprioParser(a.clone())

        # denormalize
        cls._denormalize(A)
        
        # transform wrist
        ceT = cls.inv_impl.ccT_to_ceT(cur_wcT, S.posemat, A.posemat)
        A.posemat = ceT

        # transform finger position
        A_dex_shapes = A.dexhand.shape
        B = A_dex_shapes[:-2]
        T, Dex = A_dex_shapes[-2:]
        
        cur_cwT = torch.inverse(cur_wcT)  # (B, 4, 4)
        wet = S.dexhand.view(*B, 1, -1, 3)  # (B, 1, N, 3)
        cet = wet @ cur_cwT[..., None, :3, :3].transpose(-1, -2) + cur_cwT[..., None, None, :3, 3]
        A.dexhand = A.dexhand + cet.reshape(*B, 1, Dex)

        return A.raw
    
    @classmethod
    def ceT_to_weT(cls, cur_wcT: Tensor, a: Tensor):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        A = ProprioParser(a.clone())

        # transform wrist
        A.posemat = cur_wcT.unsqueeze(-3) @ A.posemat

        # transform finger position
        A_dex_shapes = A.dexhand.shape
        B = A_dex_shapes[:-2]
        T, Dex = A_dex_shapes[-2:]

        cet = A.dexhand.view(*B, T, -1, 3)
        wet = cet @ cur_wcT[..., None, :3, :3].transpose(-1, -2) + cur_wcT[..., None, None, :3, 3]
        A.dexhand = wet.reshape(*B, T, Dex)

        return A.raw

