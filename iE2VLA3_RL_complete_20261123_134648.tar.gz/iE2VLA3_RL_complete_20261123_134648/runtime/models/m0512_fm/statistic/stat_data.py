import os
import deepspeed
import numpy as np
import torch.distributed as dist

from tqdm import tqdm
from functools import partial
from torch.utils.data import DataLoader

from data_utils.data_raw import BatchDataA, collate_action_fn
from data_utils.dataset_base import generate_sample_weights, concat_datasets
from data_utils.distributed_sampler import DistributedWeightedSampler, DistributedMultiplexSampler

from ..configs import CONFIGS, TrainConfig
from .action_transform import ActionTransform
from .nd_tdigest import ndTDigest


def get_ds_config(cfg: TrainConfig):
    ds_config = {
        "train_micro_batch_size_per_gpu": cfg.bs_micro,
        "gradient_accumulation_steps": cfg.gradient_accumulation_steps,
        "zero_optimization": 0,
        "data_types": {
            "grad_accum_dtype": "fp32"
        },
    }
    
    if cfg.grad_clip > 0:
        ds_config["gradient_clipping"] = cfg.grad_clip
    
    return ds_config


def get_dataloader_sampler_for_cfg(cfg: TrainConfig):
    if cfg.sample_multiplex > 1:
        assert cfg.dataset_weights is not None, \
            "sample_multiplex should be used together with dataset_weights"
    
    data_transform = None
    datasets = [D.inst(cfg.data_config, data_transform) for D in cfg.dataset_classes]
    datasets_concat = concat_datasets(datasets)
    
    if cfg.dataset_weights is None:
        sampler = DistributedMultiplexSampler(
            dataset=datasets_concat,
            shuffle=True,
            multiplex=cfg.sample_multiplex,
        )
    
    else:
        sample_weights = generate_sample_weights(datasets, cfg.dataset_weights)
        assert len(sample_weights) == len(datasets_concat)
        sampler = DistributedWeightedSampler(
            weights=sample_weights,
            num_samples=len(sample_weights) * cfg.sample_multiplex,
            replacement=True,
        )  # always shuffled since using sampling

    # total_batch_size = cfg.bs_micro * cfg.gradient_accumulation_steps * num_processes
    dataloader = DataLoader(
        dataset=datasets_concat,
        batch_size=cfg.bs_micro,
        sampler=sampler,
        num_workers=cfg.workers,
        prefetch_factor=(max(cfg.workers, 2) * 2) if cfg.workers > 0 else None,
        collate_fn=partial(collate_action_fn, return_dict=True),
        persistent_workers=True
    )
    return dataloader, sampler


def train():
    rank = dist.get_rank()
    is_main_process = rank == 0
    
    # get configurations
    cfg = CONFIGS["statistics"]
    if is_main_process:
        print("[INFO] Train config:")
        print(cfg)
    
    # learning rate scaling
    world_size = dist.get_world_size()
    total_batch_size = cfg.bs_micro * cfg.gradient_accumulation_steps * world_size
    learning_rate_scale = total_batch_size / 32
    if cfg.lr_scaling:
        if is_main_process:
            print(f"[INFO] scale learning rate from {cfg.max_lr:.3e} to {cfg.max_lr * learning_rate_scale:.3e}")
        cfg.max_lr = cfg.max_lr * learning_rate_scale


    # dataloader
    train_loader, sampler = get_dataloader_sampler_for_cfg(cfg)
    device = "cuda:{}".format(rank)

    # wrap dataloader
    def preprocess_fn(data):
        # return BatchDataA(**data).to(device, non_blocking=True)
        return BatchDataA(**data)


    digest = ndTDigest(6)

    # sync
    dist.barrier()

    # train
    for data in tqdm(train_loader):
        data = preprocess_fn(data)
        
        dist.barrier()
        if is_main_process:
            print("-"*61)

        va_inputs: BatchDataA = data
        latest_s = va_inputs.state[:, :, -1]  # (B, Nee, D)
        gt_future_action = ActionTransform.weT_to_ccT(
            cur_wcT=va_inputs.action_ref_pose, 
            s=latest_s, 
            a=va_inputs.action,
        )  # (B, Nee, Ta, D)

        valid_mask = va_inputs.action_mask  # (B, Nee, Ta, D)
        valid_mask_noTD = valid_mask.any(dim=(-1, -2))
        valid_action = gt_future_action[valid_mask_noTD]  # (N, Ta, D)

        # small_action_mask = valid_action[..., :3].norm(dim=-1).max(dim=-1).values < 1e-2
        # valid_action = valid_action[~small_action_mask]  # (N', Ta, D)
        # print(valid_action.shape, small_action_mask.float().mean())

        # N, T, D = valid_action.shape
        # valid_action = valid_action.detach().cpu().numpy()  # (N', T, D)
        # for n in range(N):
        #     for t in range(T):
        #         digest.update(valid_action[n, t])
        
        small_trans_mask = valid_action[..., 0:3].norm(dim=-1) < 0.01  # (N, Ta)
        small_rot_mask = valid_action[..., 3:6].norm(dim=-1) < 0.1  # (N, Ta)
        small_action_mask = small_trans_mask & small_rot_mask  # (N, Ta)
        
        valid_action = valid_action[~small_action_mask]  # (M, D)
        print(valid_action.shape, small_action_mask.float().mean())
        
        valid_action = valid_action.detach().cpu().numpy()  # (M, D)
        for m in range(valid_action.shape[0]):
            digest.update(valid_action[m])
    
    if is_main_process:
        here = os.path.dirname(__file__)
        digest.save(os.path.join(here, "statistics.pkl"))
        print("01:", digest.percentile(1))
        print("50:", digest.percentile(50))
        print("99:", digest.percentile(99))



if __name__ == "__main__":
    deepspeed.init_distributed()
    train()
    dist.destroy_process_group()


# CUDA_VISIBLE_DEVICES=3 torchrun --nproc_per_node 1 --master_port 29233 -m models.m0210_baseline.statistic.stat_data


