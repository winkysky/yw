import os
import pickle
import numpy as np
from tdigest import TDigest


class ndTDigest(object):
    def __init__(self, d: int):
        self.d = d
        self.digests = [TDigest() for _ in range(d)]
    
    def update(self, x: np.ndarray):
        for i in range(self.d):
            self.digests[i].update(x[i])
    
    def percentile(self, p: int):
        values = []
        for i in range(self.d):
            values.append(self.digests[i].percentile(p))
        return np.array(values)
    
    def cdf(self, x: np.ndarray):
        values = []
        for i in range(self.d):
            values.append(self.digests[i].cdf(x[i]))
        return np.array(values)
    
    def save(self, output_path: str):
        output_dir = os.path.dirname(output_path)
        os.makedirs(output_dir, exist_ok=True)

        outputs = [digest.to_dict() for digest in self.digests]
        with open(output_path, "wb") as fp:
            pickle.dump(outputs, fp)
    
    @classmethod
    def load(cls, file_path: str):
        with open(file_path, "rb") as fp:
            data = pickle.load(fp)
        
        d = len(data)
        obj = cls(d)
        for i in range(d):
            obj.digests[i].update_from_dict(data[i])
        return obj

