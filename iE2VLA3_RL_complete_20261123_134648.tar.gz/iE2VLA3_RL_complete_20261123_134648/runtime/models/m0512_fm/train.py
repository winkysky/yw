import os
import sys
import tyro
import copy
import torch
import argparse
import deepspeed
import torch.distributed as dist

from datetime import datetime
from functools import partial
from torch import Tensor, optim
from collections import defaultdict
from torch.utils.data import DataLoader
from diffusers.optimization import get_scheduler
from torch.utils.tensorboard import SummaryWriter

from . import vla
from .configs import CONFIGS, TrainConfig
from data_utils import transforms as TF
from data_utils.tokenize import BatchDataTokenizedVLA, collate_fn
from data_utils.dataset_base import generate_sample_weights, concat_datasets
from data_utils.distributed_sampler import DistributedWeightedSampler, DistributedMultiplexSampler
from .simple_prefetcher import PrefetchDataLoader


def init_train_config():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("-s", dest="save", type=str, default="", help="exp name to save")     # save
    parser.add_argument("-c", dest="conti", type=str, default="", help="exp name to resume")  # continue

    if "-h" in sys.argv or "--help" in sys.argv:
        print("=== argparse help ===")
        parser.print_help()
        print("\n=== tyro help ===")
        tyro.extras.get_parser(TrainConfig).print_help()
        sys.exit(0)

    args, remaining_argv = parser.parse_known_args()
    save: str = args.save
    conti: str = args.conti

    cfg = CONFIGS[args.config]
    cfg = tyro.cli(cfg.__class__, default=cfg, args=remaining_argv)
    return cfg, save, conti


def get_ds_config(cfg: TrainConfig):
    if cfg.stage == 0:
        zero_config = {
            "stage": 0
        }
    elif cfg.stage == 1:
        zero_config = {
            "stage": 1,
            "contiguous_gradients": True,
        }
    elif cfg.stage == 2:
        zero_config = {
            "stage": 2,
            # "overlap_comm": True,
            "overlap_comm": False,
            "contiguous_gradients": True,
            "reduce_scatter": True,
            "reduce_bucket_size": 1e8,
            "allgather_partitions": True,
            "allgather_bucket_size": 1e8,
        }
    else:
        raise ValueError("Currently only supports stage-[0,1,2], got {}".format(cfg.stage))

    ds_config = {
        "train_micro_batch_size_per_gpu": cfg.bs_micro,
        "gradient_accumulation_steps": cfg.gradient_accumulation_steps,
        "zero_optimization": zero_config,
        "data_types": {
            "grad_accum_dtype": "fp32"
        },
    }
    
    if cfg.grad_clip > 0:
        ds_config["gradient_clipping"] = cfg.grad_clip
    
    return ds_config


def count_parameters(m: torch.nn.Module):
    num_total = 0
    num_trainable = 0
    for p in m.parameters():
        num_total += p.numel()
        if p.requires_grad:
            num_trainable += p.numel()

    print("[INFO] Total {:.3f}M parameters, {:.3f}M frozen, {:.3f}M trainable"
          .format(num_total / 1e6, (num_total - num_trainable) / 1e6, num_trainable / 1e6))
    return num_total, num_trainable


def noop_collate(batch):
    # print("[INFO] dist-{} noop collate called".format(dist.get_rank()))
    return batch


def get_dataloader_sampler_for_cfg(cfg: TrainConfig):
    if cfg.sample_multiplex > 1:
        assert cfg.dataset_weights is not None, \
            "sample_multiplex should be used together with dataset_weights"
    
    data_transform = TF.Compose([
        # TF.CenterCamera(), 
        TF.MakeInstruction(), 
        TF.SmartResize(patch_size=32), 
        TF.Tokenize(), 
    ])
    datasets = [D.inst(cfg.data_config, data_transform) for D in cfg.dataset_classes]
    datasets_concat = concat_datasets(datasets)
    
    if cfg.dataset_weights is None:
        sampler = DistributedMultiplexSampler(
            dataset=datasets_concat,
            shuffle=True,
            multiplex=cfg.sample_multiplex,
        )
    
    else:
        sample_weights = generate_sample_weights(datasets, cfg.dataset_weights)
        assert len(sample_weights) == len(datasets_concat)
        sampler = DistributedWeightedSampler(
            weights=sample_weights,
            num_samples=len(sample_weights) * cfg.sample_multiplex,
            replacement=True,
        )  # always shuffled since using sampling

    # total_batch_size = cfg.bs_micro * cfg.gradient_accumulation_steps * num_processes
    dataloader = DataLoader(
        dataset=datasets_concat,
        batch_size=cfg.bs_micro,
        sampler=sampler,
        num_workers=cfg.workers,
        prefetch_factor=(max(cfg.workers, 2) * 2) if cfg.workers > 0 else None,
        collate_fn=partial(collate_fn, return_dict=True),
        persistent_workers=True
    )
    return dataloader, sampler


def train_fwd_pass(model: vla.VLA, data: BatchDataTokenizedVLA, cfg: TrainConfig):
    total_loss, metrics = model(
        vla_inputs=data, 
        inference=False, 
        fp16=cfg.fp16,
    )
    
    return total_loss, metrics


class DictAverageMeter(object):
    def __init__(self):
        self.sums = defaultdict(float)
        self.counts = defaultdict(int)
    
    def reset(self):
        self.sums.clear()
        self.counts.clear()
        return self
    
    def append(self, metric: dict):
        for k, v in metric.items():
            self.sums[k] += v
            self.counts[k] += 1
        return self
    
    def avg(self):
        return {k: self.sums[k] / self.counts[k] for k in self.sums}


def gather_reduce_metrics(metric: dict, group=None):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    
    metrics_all_ranks = [None for _ in range(world_size)] if rank == 0 else None
    dist.gather_object(metric, metrics_all_ranks, dst=0, group=group)  # must be called on all ranks
    
    if rank != 0:
        return None
    
    averager = DictAverageMeter()
    for metric in metrics_all_ranks:
        averager.append(metric)
    return averager.avg()


def train():
    LOG_DIR = "./logs/E2VLA"
    CKPT_DIR = "./checkpoints/E2VLA"
    
    is_main_process = dist.get_rank() == 0
    
    # new gloo group for cpu communication
    if dist.get_backend() != "gloo":
        gloo_group = dist.new_group(backend="gloo")
    else:
        gloo_group = None  # will be dist.group.WORLD
    
    # get configurations
    launch_time_str = datetime.now().strftime("%Y%m%d%H%M")
    cfg, save, conti = init_train_config()
    if is_main_process:
        print("[INFO] Train config:")
        print(cfg)
    
    # learning rate scaling
    world_size = dist.get_world_size()
    total_batch_size = cfg.bs_micro * cfg.gradient_accumulation_steps * world_size
    learning_rate_scale = total_batch_size / 32
    if cfg.lr_scaling:
        if is_main_process:
            print(f"[INFO] scale learning rate from {cfg.max_lr:.3e} to {cfg.max_lr * learning_rate_scale:.3e}")
        cfg.max_lr = cfg.max_lr * learning_rate_scale
    
    # model
    torch.manual_seed(42)
    model: vla.VLA = getattr(vla, "vla_" + cfg.model.strip())()
    model.train()
    if is_main_process:
        count_parameters(model)
    
    # optimizer
    decay, no_decay = model.parameter_groups()
    optimizer = optim.AdamW([
        {"params": decay, "lr": cfg.max_lr, "weight_decay": cfg.wd},
        {"params": no_decay, "lr": cfg.max_lr, "weight_decay": 0.0}
    ])
    
    # scheduler
    scheduler = get_scheduler(
        name="constant_with_warmup",
        optimizer=optimizer,
        num_warmup_steps=cfg.num_warmup * cfg.gradient_accumulation_steps,
    )
    
    # engine
    engine: deepspeed.DeepSpeedEngine = deepspeed.initialize(
        model=model,
        optimizer=optimizer,
        lr_scheduler=scheduler,
        config=get_ds_config(cfg)
    )[0]


    # loading from ckpt
    iterations = 0
    last_epoch = -1
    
    if cfg.pretrained_ckpt and (not conti):
        pretrained_dir, tag_name = os.path.split(cfg.pretrained_ckpt)
        load_path, _ = engine.load_checkpoint(
            pretrained_dir,
            tag=tag_name,
            load_module_strict=False, 
            load_optimizer_states=False,
            load_lr_scheduler_states=False,  # only warmup model
        )
        assert load_path is not None, "Failed to load checkpoint"
    
    if conti:
        load_path, client_state = engine.load_checkpoint(
            os.path.join(CKPT_DIR, conti),
            tag="ckpt_latest",
            load_module_strict=False
        )
        assert load_path is not None, "Failed to load checkpoint"
        iterations = client_state["iterations"]
        last_epoch = client_state["last_epoch"]
        
    if conti and not save:  # if resume is set but save is not set
        save = conti

    # dataloader
    train_loader, sampler = get_dataloader_sampler_for_cfg(cfg)

    # wrap dataloader
    def preprocess_fn(data):
        return BatchDataTokenizedVLA(**data).to(engine.device, non_blocking=True)
    
    train_loader = PrefetchDataLoader(
        dataloader=train_loader,
        prep_model=preprocess_fn,
        max_queue_size=2
    )

    # logger
    writer = None
    if save and is_main_process:
        log_dir = os.path.join(LOG_DIR, save)
        os.makedirs(log_dir, exist_ok=True)
        writer = SummaryWriter(log_dir)
    
    # sync
    dist.barrier()

    # train
    _is_first_save = True
    average_meter = DictAverageMeter()
    for epoch in range(last_epoch+1, 100000000):  # never reaches
        if is_main_process:
            print("[INFO] Starting epoch {}...".format(epoch))
        
        sampler.set_epoch(epoch)  # sync random seed
        
        if iterations > cfg.max_iterations:
            break
        
        for data in train_loader:
            # data = BatchDataTokenizedVLA(**data).to(engine.device)  # move to preprocess fn
            total_loss, metric = train_fwd_pass(engine, data, cfg)
            average_meter.append(metric)
            engine.backward(total_loss)
            engine.step()

            if engine.is_gradient_accumulation_boundary():
                iterations += 1
                
                # preproces average metric
                avg_metric_per_rank = average_meter.avg()
                avg_metric_per_rank.update({"lr": engine.lr_scheduler.get_last_lr()[0]})  # add learning rate
                
                # printing
                if is_main_process:
                    metric_str = " | ".join([f"{k} = {v:.3e}" for k, v in avg_metric_per_rank.items()])
                    print(f"[INFO] {iterations}/{cfg.max_iterations} | {metric_str}")
                
                # logging
                if save and iterations % cfg.log_interval == 0:
                    log = gather_reduce_metrics(avg_metric_per_rank, gloo_group)
                    if is_main_process and writer is not None:
                        for key, val in log.items():
                            if key != "lr":
                                key = "train/" + key
                            writer.add_scalar(key, val, iterations)
                    average_meter.reset()
                
                # checkpointing
                if save and iterations % cfg.save_interval == 0:
                    if is_main_process:
                        print("[INFO] saving checkpoints...")
                    engine.save_checkpoint(
                        save_dir=os.path.join(CKPT_DIR, save),
                        tag=f"ckpt_{iterations:0>7d}",
                        client_state={"iterations": iterations,
                                      "last_epoch": epoch},
                        exclude_frozen_parameters=True
                    )  # must be called on all ranks
                
                if save and iterations % cfg.save_latest_interval == 0:
                    if is_main_process:
                        print("[INFO] saving checkpoints...")
                        if _is_first_save:
                            # save launch command
                            cfg_save_path = os.path.join(CKPT_DIR, save, f"{launch_time_str}.json")
                            cfg.dump(cfg_save_path)
                            _is_first_save = False
                    
                    engine.save_checkpoint(
                        save_dir=os.path.join(CKPT_DIR, save),
                        tag=f"ckpt_latest",
                        client_state={"iterations": iterations,
                                      "last_epoch": epoch},
                        exclude_frozen_parameters=True
                    )  # must be called on all ranks
                
                if iterations > cfg.max_iterations:
                    break


if __name__ == "__main__":
    deepspeed.init_distributed()
    train()
    dist.destroy_process_group()


# CUDA_VISIBLE_DEVICES=0,1 torchrun --nproc_per_node 2 --master_port 29323 -m models.m0214_adv_rep.train --config pretrain_subset -s m0214_adv_rep_pretrain
# CUDA_VISIBLE_DEVICES=0,1 torchrun --nproc_per_node 2 --master_port 29323 -m models.m0219_fm.train --config pretrain_subset -s m0219_fm_pretrain
# CUDA_VISIBLE_DEVICES=2,3 torchrun --nproc_per_node 2 --master_port 29328 -m models.m0215_adv_rep.train --config pretrain_subset -s m0215_adv_rep_pretrain

# CUDA_VISIBLE_DEVICES=3 torchrun --nproc_per_node 1 --master_port 29110 -m models.m0219_fm.train --config finetune_libero_all -s m0219_fm_300k_ft_libero_all
# CUDA_VISIBLE_DEVICES=3 torchrun --nproc_per_node 1 --master_port 29110 -m models.m0504_fm.train --config scratch_libero_all -s m0504_fm_300k_scratch_libero_all


