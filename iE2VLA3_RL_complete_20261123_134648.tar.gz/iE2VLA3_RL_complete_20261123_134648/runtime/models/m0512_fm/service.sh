
CUDA_VISIBLE_DEVICES=3 python -m models.m0504_fm.service --ckpt checkpoints/E2VLA/m0504_fm_scratch_libero_all2/ckpt_0100000/mp_rank_00_model_states.pt --uri m0504_fm_scratch_libero_all2_100k
