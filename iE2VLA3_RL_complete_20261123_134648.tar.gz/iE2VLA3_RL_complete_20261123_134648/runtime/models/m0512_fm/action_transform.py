import torch
from torch import Tensor
from typing import Optional
from action.parser import ProprioParser
from action.define import START_END_INDICES
from action.transform import full_invariant, rot_invariant
from action.rotations_torch import rotation_6d_to_matrix, matrix_to_axis_angle
from action.rotations_torch import matrix_to_rotation_6d, axis_angle_to_matrix


def make_slice(all_dims: int, select_dim: int, select_idx: int):
    all_slices = [slice(None) for _ in range(all_dims)]
    all_slices[select_dim] = select_idx
    return tuple(all_slices)


def unwrap_so3(
    so3_seq: Tensor, 
    seq_dim: int = 0, 
    so3_init: Optional[Tensor] = None,
):
    """
    so3_seq (Tensor): (..., T, ..., 3)
    seq_dim (int): dimension of the time sequence
    so3_init (Tensor): (..., ..., 3)
    """

    if so3_init is None:
        s0 = make_slice(so3_seq.ndim, seq_dim, 0)
        so3_init = so3_seq[s0]
    
    unwrapped = so3_seq.clone()
    for i in range(so3_seq.shape[seq_dim]):
        si = make_slice(so3_seq.ndim, seq_dim, i)
        si_1 = make_slice(so3_seq.ndim, seq_dim, i-1)
        
        rotv = so3_seq[si]
        rotv_prev = unwrapped[si_1] if i > 0 else so3_init

        axis = torch.nn.functional.normalize(rotv, dim=-1)
        proj = torch.linalg.vecdot(rotv_prev - rotv, axis, dim=-1)
        m = torch.round(proj / (2.0 * torch.pi)).unsqueeze(-1)
        unwrapped[si] = rotv + (2.0 * torch.pi * m) * axis
        
    return unwrapped


def rotation_6d_to_rotvec(rot6d: Tensor):
    rotmat = rotation_6d_to_matrix(rot6d)  # (..., 3, 3)
    rotvec = matrix_to_axis_angle(rotmat)  # (..., 3)
    rotvec = unwrap_so3(rotvec, seq_dim=-2)  # unwrap along time dimension
    return rotvec


def rotvec_to_rotation_6d(rotvec: Tensor):
    rotmat = axis_angle_to_matrix(rotvec)  # (..., 3, 3)
    rot6d = matrix_to_rotation_6d(rotmat)  # (..., 6)
    return rot6d


def norm_pos(x: Tensor):
    return x * 5.0


def denorm_pos(x: Tensor):
    return x / 5.0


def norm_rot(x: Tensor):
    return x * 2.0


def denorm_rot(x: Tensor):
    return x / 2.0


class ActionTransform(object):

    # inv_impl = full_invariant
    inv_impl = rot_invariant

    @classmethod
    def _normalize(cls, p: ProprioParser):
        p.gripper = p.gripper * 2 - 1
        p.trans = norm_pos(p.trans)
        p.rot6d = norm_rot(p.rot6d)
        p.dexhand = norm_pos(p.dexhand)
    
    @classmethod
    def _denormalize(cls, p: ProprioParser):
        p.gripper = (p.gripper + 1) / 2.0
        p.trans = denorm_pos(p.trans)
        p.rot6d = denorm_rot(p.rot6d)
        p.dexhand = denorm_pos(p.dexhand)
    
    @classmethod
    def weT_to_ccT(cls, cur_wcT: Tensor, s: Tensor, a: Tensor, a_mask: Optional[Tensor] = None):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            s (Tensor): (..., D)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        S = ProprioParser(s)
        A = ProprioParser(a.clone())
        
        # transform wrist pose
        ccT = cls.inv_impl.weT_to_ccT(cur_wcT, S.posemat, A.posemat)
        A.posemat = ccT

        # transform finger position
        delta_dexhand = A.dexhand - S.dexhand.unsqueeze(-2)  # (B, T, D)
        B = delta_dexhand.shape[:-2]
        T, Dex = delta_dexhand.shape[-2:]

        delta_pos = delta_dexhand.view(*B, T, -1, 3)  # (B, T, N, 3)
        cur_cwT = torch.inverse(cur_wcT)  # (B, 4, 4)
        delta_pos = delta_pos @ cur_cwT[..., None, :3, :3].transpose(-1, -2)
        A.dexhand = delta_pos.reshape(*B, T, Dex)  # ^c t _{e*} - ^c t _e
        
        # action rotation to rotvec
        rotvec = rotation_6d_to_rotvec(A.rot6d)  # (..., T, 3)
        zero3 = torch.zeros_like(rotvec)
        A.rot6d = torch.cat([rotvec, zero3], dim=-1)
        if a_mask is not None:
            a_mask = a_mask.clone()
            lo, hi = START_END_INDICES["rot6d"]
            a_mask[..., lo+3:lo+6] = False
        
        # normalize
        cls._normalize(A)
        return A.raw, a_mask
    
    @classmethod
    def ccT_to_weT(cls, cur_wcT: Tensor, s: Tensor, a: Tensor, a_mask: Optional[Tensor] = None):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            s (Tensor): (..., D)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        S = ProprioParser(s)
        A = ProprioParser(a.clone())

        # denormalize
        cls._denormalize(A)
        
        # action rotvec to rot6d
        lo, hi = START_END_INDICES["rot6d"]
        rotvec = A.raw[..., lo:lo+3]  # (..., T, 3)
        rot6d = rotvec_to_rotation_6d(rotvec)  # (..., T, 6)
        A.rot6d = rot6d
        if a_mask is not None:
            a_mask = a_mask.clone()
            a_mask[..., lo:lo+6] = True

        # transform wrist pose
        weT = cls.inv_impl.ccT_to_weT(cur_wcT, S.posemat, A.posemat)
        A.posemat = weT

        # transform finger position
        A_dex_shapes = A.dexhand.shape
        B = A_dex_shapes[:-2]
        T, Dex = A_dex_shapes[-2:]

        delta_pos = A.dexhand.view(*B, T, -1, 3)  # (B, T, N, 3)
        delta_pos = delta_pos @ cur_wcT[..., None, :3, :3].transpose(-1, -2)
        dexhand = delta_pos.reshape(*B, T, Dex)
        dexhand = dexhand + S.dexhand.unsqueeze(-2)
        A.dexhand = dexhand

        return A.raw, a_mask
    
    @classmethod
    def ccT_to_ceT(cls, cur_wcT: Tensor, s: Tensor, a: Tensor):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            s (Tensor): (..., D)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        S = ProprioParser(s)
        A = ProprioParser(a.clone())

        # denormalize
        cls._denormalize(A)
        
        # transform wrist
        ceT = cls.inv_impl.ccT_to_ceT(cur_wcT, S.posemat, A.posemat)
        A.posemat = ceT

        # transform finger position
        A_dex_shapes = A.dexhand.shape
        B = A_dex_shapes[:-2]
        T, Dex = A_dex_shapes[-2:]
        
        cur_cwT = torch.inverse(cur_wcT)  # (B, 4, 4)
        wet = S.dexhand.view(*B, 1, -1, 3)  # (B, 1, N, 3)
        cet = wet @ cur_cwT[..., None, :3, :3].transpose(-1, -2) + cur_cwT[..., None, None, :3, 3]
        A.dexhand = A.dexhand + cet.reshape(*B, 1, Dex)

        return A.raw
    
    @classmethod
    def ceT_to_weT(cls, cur_wcT: Tensor, a: Tensor):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        A = ProprioParser(a.clone())

        # transform wrist
        A.posemat = cur_wcT.unsqueeze(-3) @ A.posemat

        # transform finger position
        A_dex_shapes = A.dexhand.shape
        B = A_dex_shapes[:-2]
        T, Dex = A_dex_shapes[-2:]

        cet = A.dexhand.view(*B, T, -1, 3)
        wet = cet @ cur_wcT[..., None, :3, :3].transpose(-1, -2) + cur_wcT[..., None, None, :3, 3]
        A.dexhand = wet.reshape(*B, T, Dex)

        return A.raw
    
    @classmethod
    def weT_to_ceT(cls, cur_wcT: Tensor, a: Tensor):
        """
        Args:
            cur_wcT (Tensor): (..., 4, 4)
            a (Tensor): (..., T, D)
        
        Returns:
            a_new (Tensor): (..., T, D)
        """
        cur_cwT = torch.inverse(cur_wcT)  # (..., 4, 4)
        return cls.ceT_to_weT(cur_cwT, a)

