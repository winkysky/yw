# Train libero from scratch
```bash
CUDA_VISIBLE_DEVICES=0,1 torchrun --nproc_per_node 2 --master_port 29110 -m models.m0512_fm.sft --config scratch_libero_all3 -s m0512_fm_scratch_libero_all3
```

# Evaluation
## Launch model server
```bash
CUDA_VISIBLE_DEVICES=3 python -m models.m0512_fm.service --ckpt checkpoints/E2VLA/m0512_fm_scratch_libero_all3/ckpt_0160000/mp_rank_00_model_states.pt --uri m0512_fm_scratch_libero_all3_160k --compile
```
在4090上一次推理约80~85ms

## Run evaluation
```bash
python -m examples.libero.eval --uri m0512_fm_scratch_libero_all3_160k --horizon 20 --task_suite libero_10 --substep 8 --eih --save --video
```

# 已有结果
1. ckpt: checkpoints/E2VLA/m0512_fm_scratch_libero_all3
2. eval results: eval_results/libero_*/m0512_fm_scratch_libero_all3_160k_eih.csv
