# iE2VLA3 四倍率版本：0.8 / 1 / 1.5 / 2

本版直接更新已有速度分支。条件标签为无量纲 `speed_factor`，不再计算 TCP 平移 m/s 标签。
实现日期：2026-11-23。无速度模型、无速度训练入口、已有 checkpoint、所有已有推理服务及客户端均未修改。

## 数据与条件

- 倍率固定为 `[0.8, 1.0, 1.5, 2.0]`。监督目标固定 32 个点、30 Hz、`action_offset=0`，首尾间隔 `31/30` 秒。
- 第 k 个目标从原始时间 `t0 + speed_factor * k / 30` 获取。位置线性插值、旋转 SLERP、夹爪事件保持；双臂采用同一倍率。
- 条件为 `log(speed_factor) → MLP → 加到去噪时间嵌入 → 原速度分支 FiLM`，覆盖历史/动作 token 的调制和最终归一化。
- 不从未来动作计算物理速度，也不训练“从同一观测猜指定倍率”的分类头。倍率由外部调用方或新增离散 SAC 决定。
- 图像、当前 state、相机几何、历史观测均来自原始观测时钟。未来动作变速；历史状态和历史力不做倍速增强。
- 四个倍率使用同一组有效起点。每个起点必须容纳 2x 的完整未来区间；不跨 episode、任务/文本切换或人工排除区间，不外推、填充尾部。
- 因此每档候选数相同；一个随机 minibatch 内不强制四档各占 1/4。纯旋转、纯夹爪、静止区间保留四档。
- 默认数据根目录是现有 `configs/lerobot_balanced_20261122`：A=239+68 条复核数据，B=694 条 close_box_1118；两组全局采样各 50%。原分组配置文件不变，速度适配器另外建立重采样索引。
- 原有单位换算、工具偏移、左右基座统一和三路 RGB 内外参继续使用现有 LeRobot 读取器。

## 训练

以下命令供之后启动；本次实现没有启动新 GPU 训练。

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

# 只检查数据，不加载 Qwen、不使用 GPU
CUDA_VISIBLE_DEVICES='' python -m models.m0512_fm.train_lerobot_dual_velocity --check-data

# 需要四张空闲卡。不要与现有训练同时争用这四张卡。
CUDA_VISIBLE_DEVICES=0,1,2,3 TOKENIZERS_PARALLELISM=false \
python -m models.m0512_fm.train_lerobot_dual_velocity \
  --output /nas_data_new/hq/98qwenvla/ie2vla3_factor_sft_20261123
```

默认自动启动 4 进程 DDP；每卡 batch=4、累积=2，有效 batch=32；训练 100k 更新、每 10k 保存。
Qwen3-VL-2B-Instruct 全量训练，LoRA 关闭，AdamW + ZeRO-1，BF16；动作网络从头初始化。
这里的 from scratch 指不加载旧机器人任务 checkpoint；Qwen 仍加载预训练视觉语言权重。
`full_qwen_features=True` 明确保留当前训练版的特征接入语义，和是否解冻是两个独立设置。

覆盖数据根目录使用 `--data-root /absolute/path`，支持原始单数据集、`raw_sources.json`、复核 filtered_data、`dataset_groups.json`。
单卡须显式传 `--nproc-per-node 1`；此时有效 batch 随卡数变化。

断点续训：原训练命令追加 `--resume /.../step_0010000`，其余模型、优化器、数据配置保持一致。
新格式为 `lerobot_factor_full_v3`，每个目录仍包含：

```text
step_0010000/
  model.pt           # 完整 Qwen + 动作专家 + 倍率编码器
  rank_00000.pt      # 本 rank 的优化器、scheduler、RNG、数据游标
  rank_00001.pt
  rank_00002.pt
  rank_00003.pt
  complete.json     # 所有分片落盘后才发布完整目录
```

采用新的格式标识，避免误把物理速度版或无速度版 checkpoint 当作倍率版恢复。旧 checkpoint 未转换或覆盖。

## Python 推理调用

```python
from rl_factor_sac.foundation import FrozenFoundation

foundation = FrozenFoundation.load('/absolute/factor_checkpoint_dir', device='cuda:0')
# batch 来自原 LeRobot tokenizer，动作占位为 (B,2,32,73)。
context = foundation.encode(batch, with_token=False)
trajectory = foundation.predict(context, speed_factor=1.5, fp16=True)
# trajectory: (B,32,2,17)，左臂基座中的 TCP 4x4 展平 + 夹爪 openness。
```

直接调用模型时使用 `model(batch, inference=True, speed_factor=...)`，输出为原内部 `(B,2,32,80)`。
倍率可为标量或 `(B,)`，只接受四档；同噪声比较可传 `initial_noise` `(B,2,32,80)`。
不再接受旧 `speed_mps`、`speed_bin`、`speed_spec`、旧速度 policy。

此 Python 桥接器独立于所有现有 Pyro4 服务。新倍率权重不会自动被旧服务接受，也没有把旧 `speed_mps` 字段偷偷改成倍率。
RL token 和双 SAC 的训练、执行记录 API 见 [rl_factor_sac/README.md](../../rl_factor_sac/README.md)。

## 验证

```bash
CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 OMP_NUM_THREADS=2 PYTHONDONTWRITEBYTECODE=1 \
python -m pytest -q tests/test_retime32.py tests/test_lerobot_dual_velocity.py tests/test_rl_factor_sac.py
```

测试使用临时 LeRobot Parquet/视频、真实的小型 Qwen/动作网络和模拟执行反馈，验证梯度与数值行为。
倍率数据是运动学时间重采样；真实机器人上的倍率跟踪、接触行为和成功率需新模型训练后再测量。
