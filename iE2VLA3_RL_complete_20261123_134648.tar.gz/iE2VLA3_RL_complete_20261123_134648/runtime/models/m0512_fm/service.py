import envars  # activate custom environment variables

import os
import tyro
import glob
import time
import torch
import threading
from typing import Optional
from torch import Tensor, nn
from dataclasses import dataclass, asdict

import data_utils.transforms as TF
from data_utils.data_raw import DataRawVLA
from data_utils.tokenize import BatchDataTokenizedVLA, collate_fn

from . import vla
from .configs import TrainConfig
from .action_expert import HybridAttentionLayers
from shm_transport import expose, run_simple_server


def parse_config(ckpt_dir: str):
    config_files = glob.glob(os.path.join(ckpt_dir, "*.json"))
    config_files.sort()
    
    assert len(config_files), "No config files found in {}".format(ckpt_dir)
    config_file = config_files[-1]
    print("[INFO] Use config file {}".format(config_file))
    
    cfg = TrainConfig.load(config_file)
    return cfg


def load_model(path, device):
    cfg = parse_config(os.path.dirname(os.path.dirname(path)))
    
    ckpt = torch.load(path, map_location=device, weights_only=False)
    model: vla.VLA = getattr(vla, "vla_{}".format(cfg.model))().to(device)
    incompatiable = model.load_state_dict(ckpt["module"], strict=False)
    assert not incompatiable.unexpected_keys
    print("[INFO] Load weights from iter: {}".format(ckpt["iterations"]))
    return model, cfg


def attach_timing_hooks(model: nn.Module, timing_data: dict, sync: bool = False):
    handles = []
    for name, module in model.named_modules():
        module_name = name + " / " + module.__class__.__qualname__
        
        def make_hook(module_name):
            def hook(m, input, output):
                if sync and torch.cuda.is_available():
                    torch.cuda.synchronize()
                end_time = time.time()
                duration = end_time - timing_data[module_name]['start_time']
                timing_data[module_name]['duration'] = duration
            return hook

        # Pre-hook to record start time
        def make_pre_hook(module_name):
            def pre_hook(m, input):
                if sync and torch.cuda.is_available():
                    torch.cuda.synchronize()
                timing_data[module_name] = {'start_time': time.time(), 'duration': 0}
            return pre_hook
        
        handles.append(module.register_forward_pre_hook(make_pre_hook(module_name)))
        handles.append(module.register_forward_hook(make_hook(module_name)))
            
    return handles


class Service(object):
    def __init__(
        self, 
        ckpt_path: str, 
        device: str = "cuda:0", 
        use_bf16: bool = True,
        compile: bool = False,
    ):
        self.device = device
        self.use_bf16 = use_bf16
        self.model, self.cfg = load_model(ckpt_path, device)
        self.model.eval()

        if compile:
            for m in self.model.modules():
                if isinstance(m, HybridAttentionLayers):
                    # m.forward_a = torch.compile(m.forward_a, dynamic=True)
                    m.forward_a = torch.compile(m.forward_a)

        self.model_lock = threading.Lock()
        self.data_config = self.cfg.data_config
        self.data_transform_timings = {}
        self.data_transforms = TF.Compose([
            TF.ToDevice("cuda:0"),
            TF.CenterCamera(), 
            TF.MakeInstruction(), 
            TF.SmartResize(patch_size=32), 
            TF.Tokenize(preserve_raw_vl=True), 
        ]).eval()

    @expose()
    def insert_resize_transform(self, h: int, w: int):
        new_resize = TF.Resize((h, w)).eval()
        for i, m in enumerate(self.data_transforms.transforms):
            if isinstance(m, (TF.Resize, TF.SmartResize)):
                self.data_transforms.transforms[i] = new_resize
                break
        else:
            self.data_transforms.transforms.insert(0, new_resize)

    @expose()
    def get_data_config(self):
        return asdict(self.data_config)
    
    @expose()
    def inference_raw(self, data: DataRawVLA):
        print("-"*61)
        t0 = time.perf_counter()
        if self.data_transforms is not None:
            data = self.data_transforms(data)
        t1 = time.perf_counter()
        print("[INFO] transform time: {:.2f} ms".format((t1 - t0) * 1000))

        # for name, tt in self.data_transform_timings.items():
        #     print(f"[INFO] Layer {name} duration: {tt['duration']*1000:.3f} ms")
        
        t0 = time.perf_counter()
        batch_data = collate_fn([data])
        t1 = time.perf_counter()
        print("[INFO] collate time: {:.2f} ms".format((t1 - t0) * 1000))

        action = self.inference_batch(batch_data)
        return action[0].numpy()  # (Nee, Ta, D)
    
    @expose()
    def inference_batch(self, data: BatchDataTokenizedVLA):
        with self.model_lock:
            t0 = time.perf_counter()
            with torch.no_grad():
                action: Tensor = self.model(
                    vla_inputs=data.to(self.device),
                    inference=True,
                    fp16=self.use_bf16
                )  # (B, Nee, Ta, D)
            t1 = time.perf_counter()
            print("[INFO] network inference time: {:.2f} ms".format((t1 - t0) * 1000))

        return action.detach().cpu()


########################################


@dataclass
class LaunchArgs(object):
    ckpt: str   # checkpoint path of model
    uri: str    # alias name of the launched service
    ns_host: str = "localhost"  # host of naming server
    ns_port: int = 9090         # port of naming server
    host: str = "localhost"     # host of launched daemon
    port: int = 0               # port of launched daemon
    nathost: Optional[str] = None
    natport: Optional[int] = None
    multiplex: bool = True      # if False, use threading
    compile: bool = False       # if True, compile the method: HybridAttentionLayers.forward_a


def launch_service(args: tyro.conf.OmitArgPrefixes[LaunchArgs]):
    service = Service(args.ckpt, compile=args.compile)
    run_simple_server(
        obj=service,
        uri_name=args.uri,
        multiplex=args.multiplex, 
        ns_host=args.ns_host,
        ns_port=args.ns_port,
        daemon_host=args.host,
        daemon_port=args.port,
        nathost=args.nathost,
        natport=args.natport, 
    )


if __name__ == "__main__":
    tyro.cli(launch_service)


# CUDA_VISIBLE_DEVICES=3 python -m models.m0512_fm.service --ckpt checkpoints/E2VLA/m0512_fm_scratch_libero_all3/ckpt_0160000/mp_rank_00_model_states.pt --uri m0512_fm_scratch_libero_all3_160k
