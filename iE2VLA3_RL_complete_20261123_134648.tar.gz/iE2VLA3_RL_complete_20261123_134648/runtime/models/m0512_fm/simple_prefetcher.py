
import torch
import queue
import threading
from typing import Callable
from torch.utils.data import DataLoader


class PrefetchDataLoader(object):
    def __init__(
        self, 
        dataloader: DataLoader, 
        prep_model: Callable, 
        max_queue_size: int = 8,
    ):
        self.dataloader = dataloader
        self.prep_model = prep_model
        self.max_queue_size = max_queue_size
        self.queue = queue.Queue(maxsize=max_queue_size)
        self.stop_event = threading.Event()
        self.worker_thread = None

    def _worker(self):
        """后台线程：负责从原始 dataloader 读数据并用 prep_model 处理"""
        try:
            for batch in self.dataloader:
                if self.stop_event.is_set():
                    break

                with torch.no_grad():
                    processed_data = self.prep_model(batch)

                # 将处理好的数据放入队列（如果队列满了会阻塞在这里，起到背压作用）
                self.queue.put(processed_data)
                # print("[INFO] current qsize = {}".format(self.queue.qsize()))
            
            # 放入哨兵值，标记结束
            self.queue.put(None)
            
        except Exception as e:
            self.queue.put(e) # 传递异常给主线程
            self.queue.put(None)

    def __iter__(self):
        self.stop_event.clear()
        # 清空队列（防止重用时残留）
        while not self.queue.empty():
            self.queue.get()
            
        self.worker_thread = threading.Thread(target=self._worker, daemon=True)
        self.worker_thread.start()
        return self

    def __next__(self):
        # 从队列获取结果
        res = self.queue.get()
        
        if res is None: # 收到哨兵值
            self.worker_thread.join()
            raise StopIteration
        
        if isinstance(res, Exception): # 传递后台异常
            raise res
        
        return res

    def __len__(self):
        return len(self.dataloader)
