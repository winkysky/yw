"""Dimensionless, explicitly supported tempo conditions; never physical m/s."""
import torch
from torch import nn

FACTORS = (0.8, 1.0, 1.5, 2.0)


def factor_tensor(value, batch_size, device):
    if value is None:
        raise ValueError("An explicit speed_factor is required (0.8, 1, 1.5, 2)")
    value = torch.as_tensor(value, dtype=torch.float32, device=device)
    if value.ndim == 0:
        value = value.expand(batch_size)
    choices = value.new_tensor(FACTORS)
    if (value.shape != (batch_size,) or not torch.isfinite(value).all()
            or not torch.isclose(value[:, None], choices, atol=1e-6, rtol=0).any(-1).all()):
        raise ValueError("speed_factor must be scalar or (B,), with values 0.8, 1, 1.5, 2")
    return value


class SpeedFactorEmbedding(nn.Module):
    def __init__(self, hidden_dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(1, hidden_dim), nn.SiLU(), nn.Linear(hidden_dim, hidden_dim))

    def forward(self, factor):
        # Same scalar -> MLP -> additive FiLM path as the former speed branch.
        return self.net(torch.log(factor.float()).unsqueeze(-1))
