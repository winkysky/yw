import copy
import math
import time
import torch
import numpy as np
import torch.nn.functional as F

from torch import Tensor
from enum import IntEnum
from typing import List, Optional, Tuple, Dict, Union, Any
from dataclasses import dataclass, is_dataclass, field, fields, asdict
from transformers.feature_extraction_utils import BatchFeature
from transformers import Qwen3VLProcessor, Qwen2TokenizerFast, Qwen3VLVideoProcessor
from .data_raw import DataRawVL, DataRawVLA


class ModalityType(IntEnum):
    PAD = 0
    VISION = 1
    LANGUAGE = 2
    ACTION = 3


def recursive_to_dtype_device(obj, *args, **kwargs):
    if isinstance(obj, (Tensor, BatchFeature)):
        return obj.to(*args, **kwargs)
    elif isinstance(obj, list):
        return [recursive_to_dtype_device(o, *args, **kwargs) for o in obj]
    elif isinstance(obj, tuple):
        return tuple([recursive_to_dtype_device(o, *args, **kwargs) for o in obj])
    elif isinstance(obj, dict):
        return {k: recursive_to_dtype_device(v, *args, **kwargs) for k, v in obj.items()}
    elif is_dataclass(obj):
        data_dict = {f.name: recursive_to_dtype_device(getattr(obj, f.name), *args, **kwargs) for f in fields(obj)}
        return type(obj)(**data_dict)
    else:
        return obj


def recursive_to_torch(obj):
    if isinstance(obj, np.ndarray):
        return torch.from_numpy(obj)
    elif isinstance(obj, list):
        return [recursive_to_torch(o) for o in obj]
    elif isinstance(obj, tuple):
        return tuple([recursive_to_torch(o) for o in obj])
    elif isinstance(obj, dict):
        return {k: recursive_to_torch(v) for k, v in obj.items()}
    elif is_dataclass(obj):
        data_dict = {f.name: recursive_to_torch(getattr(obj, f.name)) for f in fields(obj)}
        return type(obj)(**data_dict)
    else:
        return obj


def recursive_deepcopy(obj):
    if isinstance(obj, Tensor):
        return obj.clone()
    elif isinstance(obj, np.ndarray):
        return obj.copy()
    elif isinstance(obj, BatchFeature):
        data_dict = {k: recursive_deepcopy(v) for k, v in obj.items()}
        return BatchFeature(data_dict)
    elif isinstance(obj, list):
        return [recursive_deepcopy(o) for o in obj]
    elif isinstance(obj, tuple):
        return tuple([recursive_deepcopy(o) for o in obj])
    elif isinstance(obj, dict):
        return {k: recursive_deepcopy(v) for k, v in obj.items()}
    elif is_dataclass(obj):
        data_dict = {f.name: recursive_deepcopy(getattr(obj, f.name)) for f in fields(obj)}
        return type(obj)(**data_dict)
    else:
        return copy.deepcopy(obj)


def recursive_iterate_tensors(obj):
    if isinstance(obj, Tensor):
        yield obj
    elif isinstance(obj, (list, tuple)):
        for item in obj:
            yield from recursive_iterate_tensors(item)
    elif isinstance(obj, (dict, BatchFeature)):
        for value in obj.values():
            yield from recursive_iterate_tensors(value)
    elif is_dataclass(obj):
        for field in fields(obj):
            yield from recursive_iterate_tensors(getattr(obj, field.name))


def ceil_by_factor(number: int, factor: int) -> int:
    """Returns the smallest integer greater than or equal to 'number' that is divisible by 'factor'."""
    return math.ceil(number / factor) * factor


@dataclass
class DataTokenizedVLA(object):
    raw_vl: Optional[DataRawVL]  # for debug or analysis purpose only
    tokenized_vl: Union[BatchFeature, Dict[str, Tensor]]
    # input_ids: Tensor  # (B[=1], L)
    # attention_mask: Tensor  # (B[=1], L)
    # pixel_values: Optional[Tensor]  # (L_imgs, C)
    # image_grid_thw: Optional[Tensor]  # (N_imgs, 3)
    # pixel_values_videos: Optional[Tensor]  # (L_vids, C)
    # video_grid_thw: Optional[Tensor]  # (N_vids, 3)
    modality: Tensor  # (B[=1], L)

    patch_pose: Tensor  # (L_imgs+L_vids, 4, 4)
    patch_norm_xy: Tensor  # (L_imgs+L_vids, 2)
    
    state: Tensor  # (Nee, Ts, state_dim)
    state_mask: Tensor  # shape compatible with state

    action: Tensor  # (Nee, Ta, action_dim)
    action_mask: Tensor  # shape compatible with action
    action_ref_pose: Tensor  # (Nee, 4, 4)

    _avg_pose: Optional[Tensor] = None  # preserved as buffer for CenterCameras transforms, shape (4, 4)
    _aux_data: Dict[str, Tensor] = field(default_factory=dict)

    def __post_init__(self):
        assert self.modality.ndim == 2 and self.modality.shape[0] == 1, "modality should have shape (B[=1], L)"
        assert self.patch_pose.ndim == 3 and self.patch_pose.shape[1:] == (4, 4), "patch_pose should have shape (L_imgs+L_vids, 4, 4)"
        assert self.patch_norm_xy.ndim == 2 and self.patch_norm_xy.shape[1] == 2, "patch_norm_xy should have shape (L_imgs+L_vids, 2)"
        assert self.state.ndim == 3, "state should have shape (Nee, Ts, state_dim)"
        assert self.action.ndim == 3, "action should have shape (Nee, Ta, action_dim)"
        assert self.action_ref_pose.ndim == 3, "action_ref_pose should have shape (Nee, 4, 4)"

    def to(self, *args, **kwargs) -> "DataTokenizedVLA":
        return recursive_to_dtype_device(self, *args, **kwargs)


@dataclass
class BatchDataTokenizedVLA(object):
    raw_vl: List[Optional[DataRawVL]]  # len = B
    tokenized_vl: Union[BatchFeature, Dict[str, Tensor]]
    # input_ids: Tensor  # (B, L)
    # attention_mask: Tensor  # (B, L)
    # pixel_values: Optional[Tensor]  # (L_imgs, C)
    # image_grid_thw: Optional[Tensor]  # (N_imgs, 3)
    # pixel_values_videos: Optional[Tensor]  # (L_vids, C)
    # video_grid_thw: Optional[Tensor]  # (N_vids, 3)
    modality: Tensor  # (B, L)

    patch_pose: Tensor  # (L_imgs+L_vids, 4, 4)
    patch_norm_xy: Tensor  # (L_imgs+L_vids, 2)
    
    state: Tensor  # (B, Nee, Ts, state_dim)
    state_mask: Tensor  # shape compatible with state

    action: Tensor  # (B, Nee, Ta, action_dim)
    action_mask: Tensor  # shape compatible with action
    action_ref_pose: Tensor  # (B, Nee, 4, 4)

    _avg_pose: Optional[Tensor] = None  # preserved as buffer for CenterCameras transforms, shape (B, 4, 4)
    _aux_data: Dict[str, Tensor] = field(default_factory=dict)

    def __post_init__(self):
        assert self.modality.ndim == 2, "modality should have shape (B, L)"
        assert self.patch_pose.ndim == 3 and self.patch_pose.shape[1:] == (4, 4), "patch_pose should have shape (L_imgs+L_vids, 4, 4)"
        assert self.patch_norm_xy.ndim == 2 and self.patch_norm_xy.shape[1] == 2, "patch_norm_xy should have shape (L_imgs+L_vids, 2)"
        assert self.state.ndim == 4, "state should have shape (B, Nee, Ts, state_dim)"
        assert self.action.ndim == 4, "action should have shape (B, Nee, Ta, action_dim)"
        assert self.action_ref_pose.ndim == 4, "action_ref_pose should have shape (B, Nee, 4, 4)"

    def to(self, *args, **kwargs) -> "BatchDataTokenizedVLA":
        return recursive_to_dtype_device(self, *args, **kwargs)
    
    def deepcopy(self) -> "BatchDataTokenizedVLA":
        return recursive_deepcopy(self)


# @torch.compile
def collate_fn(batch: List[DataTokenizedVLA], return_dict=False) -> Union[BatchDataTokenizedVLA, Dict[str, Tensor]]:
    # process tokenized_vl
    Ls = [b.tokenized_vl["input_ids"].shape[1] for b in batch]
    max_L = max(Ls)

    # left padding for tokenized_vl and modality
    modality = []
    vl_input_ids = []
    vl_attention_mask = []

    vl_pixel_values = []
    vl_image_grid_thw = []
    vl_pixel_values_videos = []
    vl_video_grid_thw = []

    patch_pose = []
    patch_norm_xy = []
    _aux_data = {}

    PAD_TOKEN_ID = 151643  # <|endoftext|>
    for i, b in enumerate(batch):
        pad_len = max_L - Ls[i]
        # left padding
        vl_input_ids.append(F.pad(b.tokenized_vl.input_ids, (pad_len, 0), value=PAD_TOKEN_ID))
        vl_attention_mask.append(F.pad(b.tokenized_vl.attention_mask, (pad_len, 0), value=0))
        modality.append(F.pad(b.modality, (pad_len, 0), value=ModalityType.PAD))

        if "pixel_values" in b.tokenized_vl:
            vl_pixel_values.append(b.tokenized_vl.pixel_values)
            vl_image_grid_thw.append(b.tokenized_vl.image_grid_thw)
        if "pixel_values_videos" in b.tokenized_vl:
            vl_pixel_values_videos.append(b.tokenized_vl.pixel_values_videos)
            vl_video_grid_thw.append(b.tokenized_vl.video_grid_thw)
        
        patch_pose.append(b.patch_pose)
        patch_norm_xy.append(b.patch_norm_xy)
        
        # aggregate aux_data, will concat the first dim later
        for key, value in b._aux_data.items():
            if key not in _aux_data:
                _aux_data[key] = []
            _aux_data[key].append(value)
    
    for key, value in _aux_data.items():
        _aux_data[key] = torch.cat(value, dim=0)
    
    batch_feature_dict = {
        "input_ids": torch.cat(vl_input_ids, dim=0),            # (B, L_vision + L_lang)
        "attention_mask": torch.cat(vl_attention_mask, dim=0),  # (B, L_vision + L_lang)
    }
    if len(vl_pixel_values) > 0:
        batch_feature_dict["pixel_values"] = torch.cat(vl_pixel_values, dim=0)      # (sum(L_imgs), C)
        batch_feature_dict["image_grid_thw"] = torch.cat(vl_image_grid_thw, dim=0)  # (sum(N_imgs), 3)
    if len(vl_pixel_values_videos) > 0:
        batch_feature_dict["pixel_values_videos"] = torch.cat(vl_pixel_values_videos, dim=0)    # (sum(L_vids), C)
        batch_feature_dict["video_grid_thw"] = torch.cat(vl_video_grid_thw, dim=0)              # (sum(N_vids), 3)

    # process state and action
    Nees = [b.state.shape[0] for b in batch]
    max_Nee = max(Nees)

    # right padding at Nee dimension for state and action
    states = []
    state_masks = []
    actions = []
    action_masks = []
    action_ref_poses = []
    _avg_poses = []

    def pad_fn(x: Tensor, pad: int, zero: bool):
        if pad == 0:
            return x
        
        s = x[-1:]
        if zero:
            s = torch.zeros_like(s)
        return torch.cat([x, s.expand(pad, *x.shape[1:])], dim=0)

    for i, b in enumerate(batch):
        pad_nee = max_Nee - Nees[i]
        states.append(pad_fn(b.state, pad_nee, zero=False))
        state_masks.append(pad_fn(b.state_mask, pad_nee, zero=True))
        actions.append(pad_fn(b.action, pad_nee, zero=False))
        action_masks.append(pad_fn(b.action_mask, pad_nee, zero=True))
        action_ref_poses.append(pad_fn(b.action_ref_pose, pad_nee, zero=False))
        _avg_poses.append(b._avg_pose)
    
    valid_avg_mask = [p is not None for p in _avg_poses]
    if any(valid_avg_mask):
        for i in range(len(valid_avg_mask)):
            if not valid_avg_mask[i]:
                _avg_poses[i] = torch.eye(4).to(b.patch_pose)
        _avg_poses = torch.stack(_avg_poses, dim=0)
    else:
        _avg_poses = None

    batch_data = BatchDataTokenizedVLA(
        raw_vl=[b.raw_vl for b in batch], 
        tokenized_vl=batch_feature_dict if return_dict else BatchFeature(batch_feature_dict),
        modality=torch.cat(modality, dim=0),                    # (B, max_L)
        patch_pose=torch.cat(patch_pose, dim=0),                # (sum(L_imgs+L_vids), 4, 4)
        patch_norm_xy=torch.cat(patch_norm_xy, dim=0),          # (sum(L_imgs+L_vids), 2)
        state=torch.stack(states, dim=0),                       # (B, max_Nee, Ts, state_dim)
        state_mask=torch.stack(state_masks, dim=0),             # (B, max_Nee, Ts, state_dim)
        action=torch.stack(actions, dim=0),                     # (B, max_Nee, Ta, action_dim)
        action_mask=torch.stack(action_masks, dim=0),           # (B, max_Nee, Ta, action_dim)
        action_ref_pose=torch.stack(action_ref_poses, dim=0),   # (B, max_Nee, 4, 4)
        _avg_pose=_avg_poses,
        _aux_data=_aux_data,
    )

    if return_dict:
        return asdict(batch_data)
    else:
        return batch_data


def patch_K(K_old: Tensor, patch_size: int):
    fx = K_old[..., 0, 0]
    fy = K_old[..., 1, 1]
    cx = K_old[..., 0, 2]
    cy = K_old[..., 1, 2]

    K_new = K_old.clone()
    K_new[..., 0, 0] = fx / patch_size
    K_new[..., 1, 1] = fy / patch_size
    K_new[..., 0, 2] = (cx - (patch_size - 1) * 0.5) / patch_size
    K_new[..., 1, 2] = (cy - (patch_size - 1) * 0.5) / patch_size
    return K_new


def generate_patched_norm_xy(K: Tensor, img_shape: Tuple[int, int], patch_size: int):
    """
    Args:
        K (Tensor): shape (..., 3, 3)
        image_shape (Tuple[int, int]): (H, W)
        patch_size (int): true patch size, for QwenVL, it is patch_size * spatial_merge_size
    
    Returns:
        grid (Tensor): (..., L, 2), L = H//patch_size * W//patch_size
    """
    h, w = img_shape
    h_ds, w_ds = h // patch_size, w // patch_size
    
    x = torch.arange(w_ds, device=K.device)
    y = torch.arange(h_ds, device=K.device)
    XX, YY = torch.meshgrid(x, y, indexing="xy")

    K_patched = patch_K(K, patch_size=patch_size)  # (..., 3, 3)
    fx = K_patched[..., 0, 0].unsqueeze(-1)  # (..., 1)
    fy = K_patched[..., 1, 1].unsqueeze(-1)  # (..., 1)
    cx = K_patched[..., 0, 2].unsqueeze(-1)  # (..., 1)
    cy = K_patched[..., 1, 2].unsqueeze(-1)  # (..., 1)

    xx = (XX.ravel() - cx) / fx  # (..., L)
    yy = (YY.ravel() - cy) / fy  # (..., L)
    grid = torch.stack([xx, yy], dim=-1)  # (..., L, 2)
    return grid


def tokenize_raw_vl(data: DataRawVL, processor: Qwen3VLProcessor):
    video_processor: Qwen3VLVideoProcessor = processor.video_processor
    PATCH_SIZE = video_processor.patch_size
    TPS = video_processor.temporal_patch_size
    SPATIAL_MERGE_SIZE = video_processor.merge_size
    FRAME_FACTOR = TPS

    content = []
    flat_patch_pose, flat_patch_norm_xy = [], []
    image_inputs, video_inputs, video_metadatas = [], [], []
    # image_inputs: List[(3, H, W) Tensor], len = Ncam
    # video_inputs: List[(To, 3, H, W) Tensor], len = Ncam

    vision_grid_thw = []

    data.decompress_()  # decompress in tokenze stage for efficiency
    for i, frames in enumerate(data.rgb):
        To = len(frames)
        shape = frames[0].shape[-2:]  # (H, W)
        norm_xy = generate_patched_norm_xy(data.K[i], shape, patch_size=PATCH_SIZE*SPATIAL_MERGE_SIZE)

        if To == 1:
            # only one frame for this camera, input as image
            content.append({"type": "image", "image": frames[0]})
            image_inputs.append(frames[0])  # (3, H, W)

            flat_patch_norm_xy.append(norm_xy)
            flat_patch_pose.append(data.pose[i].expand(norm_xy.shape[0], 4, 4))
            vision_grid_thw.append([1, shape[0] // (PATCH_SIZE*SPATIAL_MERGE_SIZE), shape[1] // (PATCH_SIZE*SPATIAL_MERGE_SIZE)])
        
        else:
            # multiple frames for this camera, input as video
            nframes = ceil_by_factor(To, FRAME_FACTOR)
            if nframes > To:
                # pad by repeating the last frame, consistent with `qwen_vl_utils` implementation
                frames = torch.cat([frames, frames[-1:].expand(nframes - To, -1, -1, -1)], dim=0)

            content.append({"type": "video", "video": frames, "sample_fps": float(data.fps[i])})
            video_inputs.append(frames)  # (To, 3, H, W)
            video_metadatas.append({
                "fps": float(data.fps[i]), 
                "frames_indices": list(range(To)),
                "total_num_frames": To,
            })

            flat_patch_norm_xy.extend([norm_xy] * (nframes // TPS))
            if nframes > To:
                poses = torch.cat([data.pose[i], data.pose[i][-1:].expand(nframes - To, 4, 4)], dim=0)
            else:
                poses = data.pose[i]
            poses_temporal_pooled = poses[TPS-1::TPS]  # (T, 4, 4) 取一个temporal patch中最新时间刻的pose
            flat_patch_pose.append(poses_temporal_pooled[:, None].expand(-1, norm_xy.shape[0], 4, 4).reshape(-1, 4, 4))
            vision_grid_thw.append([nframes // TPS, shape[0] // (PATCH_SIZE*SPATIAL_MERGE_SIZE), shape[1] // (PATCH_SIZE*SPATIAL_MERGE_SIZE)])

    flat_patch_pose = torch.cat(flat_patch_pose, dim=0)
    flat_patch_norm_xy = torch.cat(flat_patch_norm_xy, dim=0)
    vision_grid_thw = torch.tensor(vision_grid_thw).long()

    if data.prompt is not None:
        content.append({"type": "text", "text": data.prompt})
    message = [{"role": "user", "content": content}]
    video_kwargs = {"do_sample_frames": False} if len(video_inputs) else {}

    text = processor.apply_chat_template([message], 
                                         tokenize=False, 
                                         add_generation_prompt=True,
                                         padding=True,
                                         padding_side="left")  # List[str], list len = 1
    
    # from IPython import embed; embed()

    inputs: BatchFeature = processor(text=text, 
                                     images=image_inputs if len(image_inputs) else None, 
                                     videos=video_inputs if len(video_inputs) else None, 
                                     video_metadata=video_metadatas, 
                                     **video_kwargs, 
                                     do_resize=False, 
                                     return_tensors="pt",
                                     padding=True,
                                     padding_side="left")
    inputs.data["vision_grid_thw"] = vision_grid_thw
    inputs = inputs.to(device=data.K.device)
    # input_ids: (B, L)
    # attention_mask: (B, L)
    # pixel_values: (L_imgs, C)
    # image_grid_thw: (N_imgs, 3)
    # pixel_values_videos: (L_vids, C)
    # video_grid_thw: (N_vids, 3)

    tokenizer: Qwen2TokenizerFast = processor.tokenizer
    modality = torch.full_like(inputs.input_ids, ModalityType.LANGUAGE)
    # vocab = tokenizer.get_vocab()  # this time consuming
    # vision_mask: Tensor = (inputs.input_ids == vocab["<|image_pad|>"]) | (inputs.input_ids == vocab["<|video_pad|>"])
    image_pad, video_pad = tokenizer.convert_tokens_to_ids(["<|image_pad|>", "<|video_pad|>"])
    vision_mask: Tensor = (inputs.input_ids == image_pad) | (inputs.input_ids == video_pad)
    modality[vision_mask] = ModalityType.VISION

    assert vision_mask.sum().item() == flat_patch_pose.shape[0], "Number of vision patches does not match!"
    return inputs, modality, flat_patch_pose, flat_patch_norm_xy


def prepare_for_depthanything(data: DataRawVL, qwen_processor: Qwen3VLProcessor):
    video_processor: Qwen3VLVideoProcessor = qwen_processor.video_processor
    TPS = video_processor.temporal_patch_size
    FRAME_FACTOR = TPS

    vision_pixels = []
    vision_extrs = []
    vision_intrs = []

    for i, frames in enumerate(data.rgb):
        To = len(frames)
        shape = frames[0].shape[-2:]  # (H, W)

        if To == 1:
            # only one frame for this camera, input as image
            vision_pixels.append(frames)  # (1, 3, H, W)
            vision_extrs.append(data.pose[i])  # (1, 4, 4)
            vision_intrs.append(data.K[i].unsqueeze(0))  # (1, 3, 3)
        
        else:
            # multiple frames for this camera, input as video
            nframes = ceil_by_factor(To, FRAME_FACTOR)

            sample_indices = torch.arange(To)
            if nframes > To:
                # pad by repeating the last frame, consistent with `qwen_vl_utils` implementation
                sample_indices = torch.cat([sample_indices, torch.full(nframes - To, -1).to(sample_indices)])
            sample_indices = sample_indices[TPS-1::TPS]

            vision_pixels.append(frames[sample_indices])  # (To, 3, H, W)
            vision_extrs.append(data.pose[i][sample_indices])  # (To, 4, 4)
            vision_intrs.append(data.K[i].unsqueeze(0).repeat(nframes, 3, 3))  # (To, 3, 3)
    
    vision_pixels = torch.cat(vision_pixels, dim=0) # (N, 3, H, W)
    vision_extrs = torch.cat(vision_extrs, dim=0)   # (N, 4, 4)
    vision_intrs = torch.cat(vision_intrs, dim=0)   # (N, 3, 3)
    return vision_pixels, vision_extrs, vision_intrs


def tokenize_raw_vla(data: DataRawVLA, processor: Qwen3VLProcessor, preserve_raw_vl: bool = False) -> DataTokenizedVLA:
    inputs, modality, flat_patch_pose, flat_patch_norm_xy = tokenize_raw_vl(data.raw_vl, processor)
    return DataTokenizedVLA(
        raw_vl=data.raw_vl if preserve_raw_vl else None,
        tokenized_vl=inputs,
        modality=modality,
        patch_pose=flat_patch_pose,
        patch_norm_xy=flat_patch_norm_xy,
        state=data.state,
        state_mask=data.state_mask,
        action=data.action,
        action_mask=data.action_mask,
        action_ref_pose=data.action_ref_pose,
        _avg_pose=data._avg_pose, 
    )


if __name__ == "__main__":
    import pypose as pp
    from IPython import embed

    K = torch.tensor([[334, 0, 224],
                      [0, 334, 224],
                      [0, 0, 1]]).float()[None].expand(2, 3, 3)
    rgb = [
        torch.rand(1, 3, 448, 448),
        torch.rand(5, 3, 448, 448),
    ]
    camera_pose = [
        pp.randn_SE3(1).matrix(),
        pp.randn_SE3(5).matrix(),
    ]
    video_fps = (1, 5)
    state = torch.randn(2, 50, 27)
    state_mask = torch.ones(27).bool()
    action = torch.randn(2, 50, 27)
    action_mask = torch.ones(27).bool()
    action_ref_pose = pp.randn_SE3(2).matrix()

    data_sample_raw = DataRawVLA(
        raw_vl=DataRawVL(
            K=K,
            rgb=rgb,
            pose=camera_pose,
            fps=video_fps,
            prompt="Pick up the red cube.",
        ),
        state=state,
        state_mask=state_mask,
        action=action,
        action_mask=action_mask,
        action_ref_pose=action_ref_pose,
    )

    processor = Qwen3VLProcessor.from_pretrained(
        "Qwen/Qwen3-VL-2B-Instruct"
    )
    inputs = tokenize_raw_vla(data_sample_raw, processor)
    embed()


