import os
import sys
import time
import torch
import dacite
import torch.nn.functional as F
import torch.distributed as dist

from torch import nn, Tensor
from einops import rearrange
from torchvision.transforms import v2
from qwen_vl_utils import smart_resize
from transformers import Qwen3VLProcessor
from torch.utils.data import get_worker_info
from typing import Optional, Tuple, List, Union
from dataclasses import fields, is_dataclass, asdict

from action.parser import ProprioParser
from action.rotations_torch import quaternion_to_matrix
from .tokenize import DataRawVLA, DataTokenizedVLA, tokenize_raw_vla


def scale_K(K_old: Tensor, shape_old: Tuple[int, int], shape_new: Tuple[int, int]):
    h_old, w_old = shape_old
    h_new, w_new = shape_new
    sx = w_new / w_old
    sy = h_new / h_old
    K_new = K_old.clone()
    K_new[0] *= sx
    K_new[1] *= sy
    return K_new


class BaseTransform(nn.Module):
    def forward(self, *args, **kwds):
        raise NotImplementedError
    
    def asdict(self):
        raise NotImplementedError
    
    @classmethod
    def fromdict(cls, d: dict):
        return cls(**d)


class Tokenize(BaseTransform):
    def __init__(
        self, 
        path: str = "Qwen/Qwen3-VL-2B-Instruct", 
        preserve_raw_vl: bool = False
    ):
        super().__init__()
        self.path = path
        self.preserve_raw_vl = preserve_raw_vl
        self.processor = Qwen3VLProcessor.from_pretrained(path)
    
    def forward(self, data: DataRawVLA):
        return tokenize_raw_vla(data, self.processor, self.preserve_raw_vl)
    
    def asdict(self):
        return {"path": self.path, "preserve_raw_vl": self.preserve_raw_vl}


class ToDevice(BaseTransform):
    def __init__(self, device: Union[torch.device, str]):
        super().__init__()
        self._device = device
        self._device_parsed = None
    
    @classmethod
    def parse_auto_device(cls, device: str):
        if isinstance(device, str):
            if "auto" in device.lower():
                if torch.cuda.is_available():
                    if torch.distributed.is_initialized():
                        rank = torch.distributed.get_rank()
                        return f"cuda:{rank}"
                    else:
                        info = get_worker_info()
                        index = 0 if info is None else info.id

                        visible_devices = os.environ.get("CUDA_VISIBLE_DEVICES", None)
                        if visible_devices is not None:
                            num_gpus = len(visible_devices.split(","))
                        else:
                            num_gpus = torch.cuda.device_count()
                        return f"cuda:{index%num_gpus}"
                else:
                    return "cpu"
        return device
    
    def forward(self, data: Union[DataRawVLA, DataTokenizedVLA]):
        if self._device_parsed is None:
            # lazy initialize
            self._device_parsed = self.parse_auto_device(self._device)
        return data.to(self._device_parsed)
    
    def asdict(self):
        return {"device": str(self._device)}


class ToDict(BaseTransform):
    def forward(self, data: Union[DataRawVLA, DataTokenizedVLA]):
        assert is_dataclass(data)
        data_dict = asdict(data)
        T = data.__class__
        data_dict["__dataclass_type__"] = T.__module__ + ":" + T.__qualname__
        return data_dict

    def asdict(self):
        return {}


class FromDict(BaseTransform):
    def forward(self, data: dict):
        T = data.pop("__dataclass_type__")
        module, qualname = T.split(":")
        cls = getattr(__import__(module, fromlist=[qualname]), qualname)
        return dacite.from_dict(data_class=cls, data=data)
    
    def asdict(self):
        return {}


class Resize(BaseTransform):
    def __init__(self, image_size: Tuple[int, int]):
        super().__init__()
        self.image_size = image_size
        self.transform = v2.Resize(image_size, interpolation=v2.InterpolationMode.BILINEAR)

    def forward(self, data: DataRawVLA):
        if data.raw_vl is None:
            return data

        data.decompress_()
        Ncam = data.raw_vl.K.shape[0]

        if isinstance(data.raw_vl.rgb, Tensor):
            h_old, w_old = data.raw_vl.rgb.shape[-2:]
            data.raw_vl.rgb = self.transform(data.raw_vl.rgb)
            for i in range(Ncam):
                data.raw_vl.K[i] = scale_K(data.raw_vl.K[i], (h_old, w_old), self.image_size)
            return data
        
        else:
            for i in range(Ncam):
                h_old, w_old = data.raw_vl.rgb[i].shape[-2:]
                data.raw_vl.rgb[i] = self.transform(data.raw_vl.rgb[i])
                data.raw_vl.K[i] = scale_K(data.raw_vl.K[i], (h_old, w_old), self.image_size)
            return data
    
    def asdict(self):
        return {"image_size": self.image_size}


class SmartResize(BaseTransform):
    def __init__(self, patch_size: int, min_pixels: Optional[int] = None, max_pixels: Optional[int] = None):
        super().__init__()
        self.patch_size = patch_size
        self.min_pixels = min_pixels
        self.max_pixels = max_pixels
    
    def forward(self, data: DataRawVLA):
        if data.raw_vl is None:
            return data
        
        data.decompress_()
        Ncam = data.raw_vl.K.shape[0]

        if isinstance(data.raw_vl.rgb, Tensor):
            h_old, w_old = data.raw_vl.rgb.shape[-2:]
            h_new, w_new = smart_resize(h_old, w_old, self.patch_size, self.min_pixels, self.max_pixels)
            resize_transform = v2.Resize((h_new, w_new), interpolation=v2.InterpolationMode.BILINEAR)
            data.raw_vl.rgb = resize_transform(data.raw_vl.rgb)
            for i in range(Ncam):
                data.raw_vl.K[i] = scale_K(data.raw_vl.K[i], (h_old, w_old), (h_new, w_new))
            return data
        
        else:
            for i in range(Ncam):
                h_old, w_old = data.raw_vl.rgb[i].shape[-2:]
                h_new, w_new = smart_resize(h_old, w_old, self.patch_size, self.min_pixels, self.max_pixels)
                resize_transform = v2.Resize((h_new, w_new), interpolation=v2.InterpolationMode.BILINEAR)
                data.raw_vl.rgb[i] = resize_transform(data.raw_vl.rgb[i])
                data.raw_vl.K[i] = scale_K(data.raw_vl.K[i], (h_old, w_old), (h_new, w_new))
            return data
    
    def asdict(self):
        return {
            "patch_size": self.patch_size, 
            "min_pixels": self.min_pixels, 
            "max_pixels": self.max_pixels
        }


class Compose(BaseTransform):
    def __init__(self, transforms):
        super().__init__()
        self.transforms = nn.ModuleList([t for t in transforms if t])

    def forward(self, data: Union[DataRawVLA, DataTokenizedVLA]):
        for t in self.transforms:
            data = t(data)
        return data
    
    def asdict(self):
        return {"transforms": [(t.__class__.__name__, t.asdict()) for t in self.transforms]}
    
    @classmethod
    def fromdict(cls, d: dict):
        transforms: List[BaseTransform] = []
        for name, params in d["transforms"]:
            child_cls = getattr(sys.modules[__name__], name)
            transforms.append(child_cls.fromdict(params))
        return cls(transforms)


class ForwardTcpOrigin(BaseTransform):
    def __init__(self, axis: Union[int, str], distance: float):
        super().__init__()
        if isinstance(axis, str):
            axis = {"x": 0, "y": 1, "z": 2}[axis]
        self.axis = axis
        self.distance = distance
    
    def transform(self, raw: Tensor):
        p = ProprioParser(raw.clone())
        vec = p.rotmat[..., :3, self.axis] * self.distance
        p.trans = p.trans + vec
        dexhand = rearrange(p.dexhand, "... (n d) -> ... n d", d=3) + vec.unsqueeze(-2)
        p.dexhand = rearrange(dexhand, "... n d -> ... (n d)")
        return p.raw
    
    def forward(self, data: Union[DataRawVLA, DataTokenizedVLA]):
        data.state = self.transform(data.state)
        data.action = self.transform(data.action)
        return data
    
    def asdict(self):
        return {"axis": self.axis, "distance": self.distance}


class CenterCamera(BaseTransform):
    def __init__(self, inplace: bool = False):
        super().__init__()
        self.inplace = inplace

    @classmethod
    def transform(self, avg_pose_inv: Tensor, raw: Tensor):
        """
        Args:
            avg_pose_inv (Tensor): (..., Nee, T, 4, 4)
            raw (Tensor): (..., Nee, T, D)
        """
        p = ProprioParser(raw.clone())

        # wrist pose
        p.posemat = avg_pose_inv @ p.posemat

        # finger position
        fingers = p.dexhand.view(*raw.shape[:-1], -1, 3)  # (B, Nee, T, 20, 3)
        rotmat = avg_pose_inv[..., :3, :3]      # (B, Nee, T, 3, 3)
        trans = avg_pose_inv[..., None, :3, 3]  # (B, Nee, T, 1, 3)
        fingers = fingers @ rotmat.transpose(-1, -2) + trans
        p.dexhand = fingers.reshape(*raw.shape[:-1], -1)

        return p.raw

    def forward(self, data: DataRawVLA):
        assert isinstance(data, DataRawVLA)
        assert data._avg_pose is None, "_avg_pose already be computed"

        if not self.inplace:
            data: DataRawVLA = data.shallow_copy()

        trans = []
        for cam_poses in data.raw_vl.pose:
            trans.append(cam_poses[-1, :3, 3])  # (3,)
        trans = torch.stack(trans, dim=0)  # (Ncam, 3)
        avg_trans = trans.mean(dim=0)  # (3,)

        avg_pose = torch.eye(4).to(avg_trans)
        avg_pose[:3, 3] = avg_trans

        if self.training:
            q = torch.randn(4).to(avg_trans)  # (4,)
            q = F.normalize(q, dim=-1)        # (4,)
            avg_pose[:3, :3] = quaternion_to_matrix(q)
        avg_pos_inv = torch.inverse(avg_pose)  # (4, 4)

        # apply pose subtraction on state and action
        data.state = self.transform(avg_pos_inv[None, None], data.state)
        data.action = self.transform(avg_pos_inv[None, None], data.action)
        # DONOT forget the transformation of ref pose!!!
        # fixed @ 2026.02.04, ckpts before this are all wrong !!!  :(
        data.action_ref_pose = avg_pos_inv @ data.action_ref_pose

        # apply pose subtraction on camera extrinsics
        tf_cam_pose = []
        for cam_poses in data.raw_vl.pose:
            tf_cam_pose.append(avg_pos_inv[None] @ cam_poses)
        if isinstance(data.raw_vl.pose, Tensor):
            tf_cam_pose = torch.stack(tf_cam_pose, dim=0)
        data.raw_vl.pose = tf_cam_pose

        # mark the avg pose
        data._avg_pose = avg_pose
        return data

    def asdict(self):
        return {"inplace": self.inplace}


class DecenterCamera(BaseTransform):
    def forward(self, avg_pose: Tensor, raw: Tensor):
        """
        Args:
            avg_pose (Tensor): (B, 4, 4)
            raw (Tensor): (B, Nee, T, D)
        """
        B, Nee, T, _ = raw.shape
        parser = ProprioParser(raw.clone())

        # wrist pose
        parser.posemat = avg_pose[:, None, None] @ parser.posemat

        # finger position
        fingers = parser.dexhand.view(B, Nee, T, -1, 3)
        rotmat = avg_pose[:, None, None, :3, :3]  # (B, 1, 1, 3, 3)
        trans = avg_pose[:, None, None, None, :3, 3]  # (B, 1, 1, 1, 3)
        fingers = fingers @ rotmat.transpose(-1, -2) + trans
        parser.dexhand = fingers.reshape(B, Nee, T, -1)
        return parser.raw


class MakeInstruction(BaseTransform):
    def forward(self, data: DataRawVLA):
        assert isinstance(data, DataRawVLA)
        if data.raw_vl.prompt:
            data.raw_vl.prompt = "Your task is to: {{{}}}. Locate the key object needed and then figure out how to execute the task.".format(data.raw_vl.prompt)
        return data
    
    def asdict(self):
        return {}


class PreprocessQwenDA(BaseTransform):
    def __init__(self, uri_base_name: str):
        super().__init__()
        self.uri_base_name = uri_base_name
        self.proxy = None
    
    def asdict(self):
        return {"uri_base_name": self.uri_base_name}
    
    def _lazy_init(self):
        import torch.distributed as dist
        from shm_transport import get_shm_proxy
        
        if dist.is_initialized():
            rank = dist.get_rank()
        else:
            rank = 0
        
        worker_info = get_worker_info()
        if worker_info is None:
            worker_id = 0
        else:
            worker_id = worker_info.id % 2
        
        self.proxy = get_shm_proxy(
            uri_name=self.uri_base_name + ".rank{}.id{}".format(rank, worker_id),
        )
    
    def forward(self, data: DataRawVLA):
        if self.proxy is None:
            self._lazy_init()
        
        # rank = dist.get_rank()
        # worker_info = get_worker_info()
        # print("[INFO] rank = {}, worker id = {}".format(rank, worker_info.id))
        
        data_tokenized = self.proxy.process_single(data, need_da=True)
        return data_tokenized


# class DebugPrint(BaseTransform):
#     def forward(self, data):
#         worker_info = get_worker_info()
#         rank = dist.get_rank()
#         print("[INFO] rank = {}, worker id = {}".format(rank, worker_info.id))
#         return data

