"""Four tempo labels at 30 Hz, without computing physical-speed labels.

Only future commands are retimed. Historical measurements are always observed.
The old physical-speed retimer is left intact for historical code/tests.
"""
import numpy as np
from .trajectory_retime32 import sample_poses, sample_grippers
from models.speed_factor import FACTORS

HORIZON = 32


def retime_sample(columns, frame, factor, num_history=1, target_fps=30.):
    if factor not in FACTORS or target_fps != 30. or num_history < 1:
        raise ValueError("Expected a supported factor, positive history and 30 Hz")
    times = np.asarray(columns['timestamp'], dtype=np.float64)
    origin = times[frame]
    target = np.arange(HORIZON, dtype=np.float64) / target_fps
    source = origin + factor * target
    history = origin + np.arange(1 - num_history, 1) / target_fps
    return dict(history_pose=sample_poses(times, columns['state_pose'], history),
                history_gripper=sample_grippers(times, columns['state_gripper'], history),
                action_pose=sample_poses(times, columns['action_pose'], source),
                action_gripper=sample_grippers(times, columns['action_gripper'], source),
                speed_factor=np.float32(factor), source_times=source,
                target_times=target, history_times=history)


def valid_anchors(columns, allowed_frames, num_history=1, target_fps=30.):
    """Paired anchors: all four factors must fit the same reviewed/task interval.

    Check every source row touched by interpolation, including intervening rows.
    This prevents exclusions/task changes being jumped over by 2x sampling.
    """
    times = np.asarray(columns['timestamp'], dtype=np.float64)
    frames = np.asarray(allowed_frames, dtype=np.int64)
    if not len(frames):
        return frames.astype(np.int32)
    if not np.isfinite(times).all() or np.any(np.diff(times) <= 0):
        raise ValueError("Source timestamps must be finite and strictly increasing")
    allowed = np.zeros(len(times), dtype=bool)
    allowed[frames] = True
    lo_time = times[frames] - (num_history - 1) / target_fps
    hi_time = times[frames] + max(FACTORS) * (HORIZON - 1) / target_fps
    lo = (np.searchsorted(times, lo_time + 2e-6, side='right') - 1).clip(0, len(times)-1)
    hi = np.searchsorted(times, hi_time - 2e-6, side='left').clip(0, len(times)-1)
    invalid = np.r_[0, np.cumsum(~allowed)]
    changes = np.r_[0, np.cumsum(np.diff(columns['task_index']) != 0)]
    valid = ((lo_time >= times[0]-2e-6) & (hi_time <= times[-1]+2e-6)
             & (invalid[hi+1] == invalid[lo]) & (changes[hi] == changes[lo]))
    # Per-frame prompts are also task boundaries, even when task_index is stale.
    if columns.get('prompt') is not None:
        prompt = np.asarray(columns['prompt'], dtype=str)
        changes = np.r_[0, np.cumsum(prompt[1:] != prompt[:-1])]
        valid &= changes[hi] == changes[lo]
    return frames[valid].astype(np.int32)
