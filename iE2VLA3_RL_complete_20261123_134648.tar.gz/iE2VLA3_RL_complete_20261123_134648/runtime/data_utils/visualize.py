import cv2
import numpy as np
from torch import Tensor
from typing import List, Tuple, Optional

from .data_raw import DataRawVL
from action.parser import ProprioParser


def proj(K: np.ndarray, cwT: np.ndarray, pos: np.ndarray):
    """
    Args:
        K (np.ndarray): (3, 3)
        cwT (np.ndarray): (4, 4)
        pos (np.ndarray): (..., 3)
    
    Returns:
        uv (np.ndarray): (..., 2)
    """
    pos_in_cam = pos @ cwT[:3, :3].T + cwT[:3, 3]
    xy = pos_in_cam[..., :2] / pos_in_cam[..., -1:]

    fx = K[0, 0]; fy = K[1, 1]; cx = K[0, 2]; cy = K[1, 2]
    fxy = np.array([fx, fy]); cxy = np.array([cx, cy])
    uv = xy * fxy + cxy
    return uv


def draw_ee_axis(bgr: np.ndarray, K: np.ndarray, cwT: np.ndarray, weT: np.ndarray):
    alen = 0.05  # 5cm
    pos = weT[:3, 3]
    points = np.stack([pos, *(pos + weT[:3, i] * alen for i in range(3))])
    uv, valid = project_for_drawing(K, cwT, points)

    A = np.sqrt(np.prod(bgr.shape[:2]))
    thickness = max(1, int(round(2 * A / 256.0)))
    for i, color in enumerate([(0, 0, 255), (0, 255, 0), (255, 0, 0)], start=1):
        if valid[0] and valid[i]:
            origin, endpoint = tuple(np.rint(uv[0]).astype(int)), tuple(np.rint(uv[i]).astype(int))
            visible, start, end = cv2.clipLine((0, 0, bgr.shape[1], bgr.shape[0]), origin, endpoint)
            if visible:
                cv2.line(bgr, start, end, color, thickness=thickness, lineType=cv2.LINE_AA)
    return bgr


def project_for_drawing(K, cwT, points):
    """Keep points behind/on the camera or nonfinite projections out of OpenCV."""
    points = np.asarray(points)
    depth = (points @ cwT[:3, :3].T + cwT[:3, 3])[..., 2]
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        uv = proj(K, cwT, points)
    valid = (depth > 1e-6) & np.isfinite(uv).all(axis=-1) & (np.abs(uv) < 1e8).all(axis=-1)
    return uv, valid


def draw_ee_dots(bgr: np.ndarray, K: np.ndarray, cwT: np.ndarray, wet: np.ndarray, color: Tuple[int, int, int]):
    uvs, valid = project_for_drawing(K, cwT, np.atleast_2d(wet))
    valid &= (uvs[:, 0] >= 0) & (uvs[:, 0] < bgr.shape[1])
    valid &= (uvs[:, 1] >= 0) & (uvs[:, 1] < bgr.shape[0])
    uvs = np.rint(uvs[valid]).astype(int).tolist()

    A = np.sqrt(np.prod(bgr.shape[:2]))
    radius = max(1, int(round(2 * A / 256.0)))

    for uv in uvs:
        cv2.circle(bgr, tuple(uv), radius=radius, color=color, thickness=-1, lineType=cv2.LINE_AA)
    return bgr


def draw_fingers(bgr: np.ndarray, K: np.ndarray, cwT: np.ndarray, fingers: np.ndarray, color: Tuple[int, int, int]):
    pos = fingers.reshape(21, 3)
    uvs = proj(K, cwT, pos)

    uvs = uvs.astype(int).tolist()  # (N, 2)

    A = np.sqrt(np.prod(bgr.shape[:2]))
    radius = max(1, int(round(1 * A / 256.0)))

    connections = [(0, 1), (1, 2), (2, 3), (3, 4),
                   (0, 5), (5, 6), (6, 7), (7, 8),
                   (0, 9), (9, 10), (10, 11), (11, 12),
                   (0, 13), (13, 14), (14, 15), (15, 16),
                   (0, 17), (17, 18), (18, 19), (19, 20)]
    
    for uv in uvs:
        cv2.circle(bgr, tuple(uv), radius=radius, color=color, thickness=-1, lineType=cv2.LINE_AA)
    
    for start, end in connections:
        cv2.line(bgr, tuple(uvs[start]), tuple(uvs[end]), color=color, thickness=radius, lineType=cv2.LINE_AA)
    
    return bgr


def draw_state_actions(
    raw_vl: DataRawVL,
    state: Optional[Tensor] = None, 
    state_mask: Optional[Tensor] = None, 
    actions: Optional[List[Tensor]] = None, 
    colors: Optional[List[Tuple[int, int, int]]] = None,
    action_masks: Optional[List[Tensor]] = None,
):
    """
    Args:
        raw_vl (DataRawVL):
        state (Tensor): (Nee, Ts, state_dim)
        actions (List[Tensor]): [(Nee, Ta, state_dim)], you can visualize multiple actions
        colors (List[Tuple[int, int, int]]): colors for multiple actions
    
    Returns:
        bgrs (List[np.ndarray]): images to show
    """

    if state is not None:
        parser = ProprioParser(
            raw=state[..., -1, :], 
            mask=None if state_mask is None else state_mask[..., -1, :]
        )
        current_weT = parser.posemat.cpu().numpy()  # (Nee, 4, 4)
        current_fingers = parser.dexhand.cpu().numpy()  # (Nee, 21*3)
        current_fingers_mask = parser.dexhand_mask.cpu().numpy()  # (Nee, 21*3)
    else:
        current_weT = None
        current_fingers = None
        current_fingers_mask = None
    
    if actions is not None:
        future_weTs = [ProprioParser(a).posemat.cpu().numpy() for a in actions]  # each of (Nee, Ta, 4, 4)
    else:
        future_weTs = None

    bgrs: List[np.ndarray] = []
    for cam_id, rgb in enumerate(raw_vl.rgb):
        K = raw_vl.K[cam_id].cpu().numpy()  # (3, 3)
        bgr = rgb[-1].flip(0).permute(1, 2, 0).contiguous().cpu().numpy()  # (H, W, 3)
        wcT = raw_vl.pose[cam_id][-1].cpu().numpy()  # (4, 4)
        cwT = np.linalg.inv(wcT)

        if current_weT is not None:
            for ee_id, weT in enumerate(current_weT):
                bgr = draw_ee_axis(bgr, K, cwT, weT)

                if current_fingers is not None and np.any(current_fingers_mask[ee_id]):
                    bgr = draw_fingers(bgr, K, cwT, current_fingers[ee_id], color=(187, 134, 192))

        if future_weTs is not None:
            for traj_id, traj_weTs in enumerate(future_weTs):
                for ee_id, weT in enumerate(traj_weTs):
                    color = colors[traj_id] if colors is not None else (0, 0, 255)
                    positions = weT[..., :3, 3]
                    if action_masks is not None:
                        valid = action_masks[traj_id][ee_id, ..., :3].all(dim=-1).cpu().numpy()
                        positions = positions[valid]
                    bgr = draw_ee_dots(bgr, K, cwT, positions, color)
        bgrs.append(bgr)
    return bgrs


def concat_bgrs(bgrs: List[np.ndarray], vert_concat: bool = False) -> np.ndarray:
    """
    Args:
        bgrs (List[np.ndarray]): a series of bgr images with different shape
        vert_concat (bool): if True, concat images vertically, otherwise horizontally
    
    Returns:
        bgr (np.ndarray): (H, W, 3)
    """
    Hs, Ws = [], []
    for bgr in bgrs:
        H, W = bgr.shape[:2]
        Hs.append(H); Ws.append(W)
    
    H_cumsum = np.cumsum([0] + Hs)
    W_cumsum = np.cumsum([0] + Ws)

    if vert_concat:
        H_total = sum(Hs)
        W_total = max(Ws)
        image = np.zeros((H_total, W_total, 3), dtype=bgrs[0].dtype)

        for i, bgr in enumerate(bgrs):
            image[H_cumsum[i]:H_cumsum[i+1], :Ws[i]] = bgr
    
    else:
        H_total = max(Hs)
        W_total = sum(Ws)
        image = np.zeros((H_total, W_total, 3), dtype=bgrs[0].dtype)

        for i, bgr in enumerate(bgrs):
            image[:Hs[i], W_cumsum[i]:W_cumsum[i+1]] = bgr
    
    return image


def resize_to_fit(bgr: np.ndarray, maxW: int, maxH: int) -> np.ndarray:
    if bgr is None:
        raise ValueError("Input image is None")

    h, w = bgr.shape[:2]

    # 如果已经 fit，直接返回
    if w <= maxW and h <= maxH:
        return bgr

    scale_w = maxW / w
    scale_h = maxH / h
    scale = min(scale_w, scale_h)

    new_w = int(round(w * scale))
    new_h = int(round(h * scale))

    resized = cv2.resize(bgr, (new_w, new_h))

    return resized
