import torch
from torch.utils.data.sampler import Sampler
from torch.utils.data.dataset import Dataset


class MultiplexSampler(Sampler):
    def __init__(
        self,
        dataset: Dataset,
        shuffle: bool = True,
        seed: int = 0,
        multiplex: int = 1,
    ) -> None:

        self.dataset = dataset
        self.epoch = 0
        self.num_samples = len(self.dataset)
        self.shuffle = shuffle
        self.seed = seed
        self.multiplex = multiplex
    
    def __iter__(self):
        if self.shuffle:
            # deterministically shuffle based on epoch and seed
            g = torch.Generator()
            g.manual_seed(self.seed + self.epoch)
            indices = torch.randperm(len(self.dataset), generator=g).tolist()  # type: ignore[arg-type]
        else:
            indices = list(range(len(self.dataset)))  # type: ignore[arg-type]

        assert len(indices) == self.num_samples
        indices = indices * self.multiplex  # multiplexing
        return iter(indices)

    def __len__(self) -> int:
        return self.num_samples

    def set_epoch(self, epoch: int) -> None:
        r"""
        Set the epoch for this sampler.

        When :attr:`shuffle=True`, this ensures all replicas
        use a different random ordering for each epoch. Otherwise, the next iteration of this
        sampler will yield the same ordering.

        Args:
            epoch (int): Epoch number.
        """
        self.epoch = epoch
