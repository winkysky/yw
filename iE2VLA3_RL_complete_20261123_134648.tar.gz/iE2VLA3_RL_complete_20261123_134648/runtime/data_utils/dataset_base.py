import torch
import random
import numpy as np
from dataclasses import dataclass
from torch.utils.data import Dataset, ConcatDataset
from typing import Tuple, Any, Optional, List, Union

from . import transforms as TF
from .tokenize import DataRawVL, DataRawVLA, DataTokenizedVLA


@dataclass
class DataConfig(object):
    num_history_states: int = 1
    num_future_actions: int = 32
    load_vl: bool = True


class DatasetBase(Dataset):
    @classmethod
    def inst(
        cls, 
        data_config: DataConfig, 
        transforms: Optional[TF.BaseTransform]
    ) -> "DatasetBase":
        raise NotImplementedError

    def get_handler(self, episode_id: int) -> Tuple[Any, int]:
        """
        Args:
            episode_id (int): The ID of the episode to get the handler for.
        
        Returns
        -------
            handler (Any): the handler object for the episode.
            episode_len (int): the length of the episode.
        """
        raise NotImplementedError
    
    def close_handler(self, handler: Any):
        raise NotImplementedError

    def sample_episode(
        self, 
        handler: Any, 
        episode_len: int, 
        frame_index: int,
    ) -> Union[DataRawVLA, DataTokenizedVLA]:
        """
        Args:
            handler: the handler object for the episode.
            episode_len (int): the length of the episode.
            frame_index (int): the index of current frame.
        
        Returns:
            data (DataRawVLA | DataTokenizedVLA): the sampled data from the episode.
        """
        raise NotImplementedError

    def __len__(self) -> int:
        raise NotImplementedError

    def __getitem__(self, i: int):
        handler, episode_len = self.get_handler(i)
        try:
            frame_index = random.choice(range(episode_len))
            data = self.sample_episode(handler, episode_len, frame_index)
        except Exception as e:
            self.close_handler(handler)
            raise e
        else:
            self.close_handler(handler)
        
        return data


def generate_sample_weights(
    datasets: List[DatasetBase],
    dataset_weights: List[float]
):
    sample_weights = []
    for i, dataset in enumerate(datasets):
        sample_weights.append(
            np.array([dataset_weights[i] / len(dataset)] * len(dataset))
        )
    sample_weights = np.concatenate(sample_weights)
    sample_weights = sample_weights / sample_weights.sum()
    return sample_weights.tolist()


def concat_datasets(datasets: List[DatasetBase]):
    return ConcatDataset(datasets)


class DemoRandomDataset(DatasetBase):
    def __init__(self, n: int):
        super().__init__()
        self.n = n
        self.data_config = DataConfig()
        self.transforms = TF.Compose([
            TF.ToDevice("auto"),
            TF.SmartResize(patch_size=32),
            TF.Tokenize(preserve_raw_vl=True), 
        ])

    def __len__(self):
        return self.n

    def get_handler(self, episode_id: int):
        episode_len = random.randint(100, 1000)
        return None, episode_len
    
    def close_handler(self, handler):
        return  # do nothing

    def sample_episode(
        self, 
        handler: Any, 
        episode_len: int, 
        frame_index: int,
    ) -> DataTokenizedVLA:
        
        import pypose as pp

        Nee = random.randint(1, 4)
        Ncam = random.randint(1, 3)
        Ts = self.data_config.num_history_states
        Ta = self.data_config.num_future_actions
        
        K = []
        rgb = []
        video_fps = []
        camera_pose = []
        for n in range(Ncam):
            n_frames = random.randint(1, 5)
            h = random.randint(256, 512)
            w = random.randint(256, 512)
            # print(f"[INFO] n_frames = {n_frames}, h = {h}, w = {w}")
            rgb.append(torch.rand(n_frames, 3, h, w))
            f = random.uniform(200, 600)
            K.append(torch.tensor([[f, 0, w//2],
                                   [0, f, h//2],
                                   [0, 0, 1]]).float())
            camera_pose.append(pp.randn_SE3(n_frames).matrix())
            video_fps.append(random.randint(1, 30))
        K = torch.stack(K, dim=0)

        state = torch.randn(Nee, Ts, 27)
        state_mask = torch.ones(27).bool()
        action = torch.randn(Nee, Ta, 27)
        action_mask = torch.ones(27).bool()
        action_ref_pose = pp.randn_SE3(Nee).matrix()

        data_sample_raw = DataRawVLA(
            raw_vl=DataRawVL(
                K=K,
                rgb=rgb,
                pose=camera_pose,
                fps=video_fps,
                prompt="Pick up the red cube.",
            ),
            state=state,
            state_mask=state_mask,
            action=action,
            action_mask=action_mask,
            action_ref_pose=action_ref_pose,
        )

        data_sample_tokenized = self.transforms(data_sample_raw)
        return data_sample_tokenized


if __name__ == "__main__":
    from IPython import embed
    from torch.utils.data import DataLoader
    from .tokenize import collate_fn


    dataset = DemoRandomDataset(1000)
    dataloader = DataLoader(
        dataset=dataset,
        batch_size=16,
        num_workers=4,
        collate_fn=collate_fn
    )

    for i, data in enumerate(dataloader):
        print("-"*81)
        embed()
        input("[INFO] Press Enter to continue: ")
