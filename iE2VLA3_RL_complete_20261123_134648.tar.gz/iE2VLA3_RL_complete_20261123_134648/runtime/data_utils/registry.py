import inspect
import pkgutil
import importlib
from typing import List, Type


def mark_offline_test(tag: str | None = None):
    """
    用于标记类的 decorator
    """
    def decorator(cls):
        cls.__marked__ = True
        cls.__mark_tag__ = tag
        return cls
    
    return decorator


def find_marked_classes(package_name: str) -> List[Type]:
    """
    递归查找指定包及其子包下所有被 mark_offline_test 标记的类。
    
    :param package_name: 包的名称 (例如 'my_project.modules')
    :return: 被标记的类列表
    """
    found_classes = set() # 使用 set 防止重复 (应对同一个类被多次 import 的情况)
    
    # 1. 导入顶层包
    try:
        package = importlib.import_module(package_name)
    except ImportError as e:
        print(f"无法导入包 {package_name}: {e}")
        return []

    # 准备路径用于 walk_packages
    # 注意：如果传入的是普通模块而非包（没有__path__），则当作单文件处理
    if not hasattr(package, "__path__"):
        path = None
    else:
        path = package.__path__

    # 2. 遍历包下的所有模块
    # pkgutil.walk_packages 可以递归遍历子文件夹
    prefix = package.__name__ + "."
    
    # 如果是包，遍历子模块；如果是单文件，构建一个包含自身的列表
    iterator = pkgutil.walk_packages(path, prefix) if path else []
    
    # 先检查顶层包本身
    _scan_module(package, found_classes)

    for _, name, _ in iterator:
        try:
            # 动态导入模块
            module = importlib.import_module(name)
            _scan_module(module, found_classes)
        except Exception as e:
            # 某些模块可能因为依赖问题导入失败，这里可以选择跳过或报错
            print(f"跳过模块 {name}: {e}")

    return list(found_classes)


def _scan_module(module, found_classes_set):
    """辅助函数：扫描单个模块中的类"""
    # 获取模块中所有的成员
    for name, obj in inspect.getmembers(module):
        # 1. 必须是类
        if inspect.isclass(obj):
            # 2. 检查是否有我们的标记
            if getattr(obj, "__marked__", False):
                # 3. (可选但推荐) 确保类是定义在该模块中的
                # 如果不加这行，如果 module A 引用了 module B 的类，会被重复扫描
                if obj.__module__ == module.__name__:
                    found_classes_set.add(obj)

