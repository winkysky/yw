import cv2
import time
import copy
import torch
import numpy as np
from torch import Tensor
from typing import List, Optional, Union
from dataclasses import dataclass, is_dataclass, fields, asdict


def recursive_to_dtype_device(obj, *args, **kwargs):
    if isinstance(obj, Tensor):
        return obj.to(*args, **kwargs)
    elif isinstance(obj, list):
        return [recursive_to_dtype_device(o, *args, **kwargs) for o in obj]
    elif isinstance(obj, tuple):
        return tuple([recursive_to_dtype_device(o, *args, **kwargs) for o in obj])
    elif isinstance(obj, dict):
        return {k: recursive_to_dtype_device(v, *args, **kwargs) for k, v in obj.items()}
    elif is_dataclass(obj):
        data_dict = {f.name: recursive_to_dtype_device(getattr(obj, f.name), *args, **kwargs) for f in fields(obj)}
        return type(obj)(**data_dict)
    else:
        return obj


def recursive_shallow_copy(obj):
    if isinstance(obj, (Tensor, np.ndarray)):
        return obj
    elif isinstance(obj, list):
        return [recursive_shallow_copy(o) for o in obj]
    elif isinstance(obj, tuple):
        return tuple([recursive_shallow_copy(o) for o in obj])
    elif isinstance(obj, dict):
        return {k: recursive_shallow_copy(v) for k, v in obj.items()}
    elif is_dataclass(obj):
        data_dict = {f.name: recursive_shallow_copy(getattr(obj, f.name)) for f in fields(obj)}
        return type(obj)(**data_dict)
    else:
        return copy.copy(obj)


def recursive_deepcopy(obj):
    if isinstance(obj, Tensor):
        return obj.clone()
    elif isinstance(obj, np.ndarray):
        return obj.copy()
    elif isinstance(obj, list):
        return [recursive_deepcopy(o) for o in obj]
    elif isinstance(obj, tuple):
        return tuple([recursive_deepcopy(o) for o in obj])
    elif isinstance(obj, dict):
        return {k: recursive_deepcopy(v) for k, v in obj.items()}
    elif is_dataclass(obj):
        data_dict = {f.name: recursive_deepcopy(getattr(obj, f.name)) for f in fields(obj)}
        return type(obj)(**data_dict)
    else:
        return copy.deepcopy(obj)


@dataclass
class CompressedImage(object):
    data: Union[np.ndarray, Tensor]
    encoding: str  # e.g., "bgr", "rgb", "bgr_compressed", "rgb_compressed"
    
    def decode(self, device = "cpu") -> Tensor:
        # decompress
        if "compressed" in self.encoding:
            data = self.data if isinstance(self.data, np.ndarray) else self.data.cpu().numpy()
            assert data.dtype == np.uint8, "compressed image data should be of type uint8"
            img_array = cv2.imdecode(data, cv2.IMREAD_COLOR)
        else:
            img_array = self.data
        
        # convert to tensor
        if isinstance(img_array, np.ndarray):
            img_tensor = torch.from_numpy(img_array).to(device)
        else:
            img_tensor = img_array
        
        # convert to (3, H, W)
        if img_tensor.shape[-1] == 3:  # (H, W, 3)
            img_tensor = img_tensor.permute(2, 0, 1)  # (H, W, 3) -> (3, H, W)
        
        # convert to RGB
        if self.encoding.startswith("bgr"):
            img_tensor = img_tensor.flip(0)  # BGR -> RGB
        
        # convert to uint8
        if torch.is_floating_point(img_tensor):
            img_tensor = (img_tensor * 255.0).to(torch.uint8)
        
        return img_tensor.contiguous()


@dataclass
class DataRawVL(object):
    K: Tensor  # (Ncam, 3, 3)
    rgb: Union[Tensor, List[Tensor], List[List[CompressedImage]]]  # len = Ncam, each element is (To, 3, H, W)
    pose: Union[Tensor, List[Tensor]]  # len = Ncam, each element is (To, 4, 4)
    fps: Union[tuple, float]  # (Ncam,)
    prompt: Optional[str]  # natural language instruction
    
    _decompressed: bool = False  # whether the rgb images have been decompressed

    def __post_init__(self):
        if isinstance(self.fps, float):
            self.fps = tuple([self.fps] * len(self.K))

        assert self.K.ndim == 3, "K should have shape (Ncam, 3, 3)"

        # shape checks for rgb
        if isinstance(self.rgb, Tensor):
            assert self.rgb.ndim == 5, "rgb should have shape (Ncam, To, 3, H, W)"
            assert self.rgb.shape[-3] == 3, "the third dimension of rgb should be 3"
            # convert to uint8
            if torch.is_floating_point(self.rgb):
                self.rgb = (self.rgb * 255.0).to(torch.uint8)
            self._decompressed = True
        else:
            for i, frames in enumerate(self.rgb):
                if isinstance(frames, Tensor):
                    assert frames.ndim == 4, "each frames in rgb should have shape (To, 3, H, W)"
                    assert frames.shape[-3] == 3, "the second dimension of rgb should be 3"
                    # convert to uint8
                    if torch.is_floating_point(frames):
                        self.rgb[i] = (frames * 255.0).to(torch.uint8)
                    self._decompressed = True
                else:
                    for img in frames:
                        assert isinstance(img, CompressedImage), "each element in rgb should be CompressedImage"    
                    self._decompressed = False

        # shape checks for pose
        if isinstance(self.pose, Tensor):
            assert self.pose.ndim == 4, "pose should have shape (Ncam, To, 4, 4)"
        else:
            for pose in self.pose:
                assert pose.ndim == 3, "each pose should have shape (To, 4, 4)"
    
    def to(self, *args, **kwargs) -> "DataRawVL":
        return recursive_to_dtype_device(self, *args, **kwargs)
    
    def decompress_(self):
        if self._decompressed:
            return self
        
        # t0 = time.perf_counter()
        for i, frames in enumerate(self.rgb):
            if isinstance(frames, Tensor):
                continue
            decompressed_frames = []
            for img in frames:
                img_tensor = img.decode(device=self.K.device)  # (3, H, W)
                decompressed_frames.append(img_tensor)
            self.rgb[i] = torch.stack(decompressed_frames, dim=0)  # (To, 3, H, W)
        self._decompressed = True
        # t1 = time.perf_counter()
        # print("[INFO] decompress time: {:.2f} ms".format((t1 - t0) * 1000))
        return self


@dataclass
class DataRawVLA(object):
    raw_vl: Optional[DataRawVL]
    
    state: Tensor  # (Nee, Ts, state_dim)
    state_mask: Tensor  # shape compatible with state
    
    action: Tensor  # (Nee, Ta, action_dim)
    action_mask: Tensor  # shape compatible with action
    action_ref_pose: Tensor  # (Nee, 4, 4)

    _avg_pose: Optional[Tensor] = None  # preserved as buffer for CenterCameras transforms, shape (4, 4)
    
    def __post_init__(self):
        assert self.state.ndim == 3, "state should have shape (Nee, Ts, state_dim)"
        assert self.action.ndim == 3, "action should have shape (Nee, Ta, action_dim)"
        assert self.action_ref_pose.ndim == 3, "action_ref_pose should have shape (Nee, 4, 4)"

        if self._avg_pose is not None:
            assert self._avg_pose.ndim == 2, "_avg_pose should have shape (4, 4)"
        
        self.state_mask = self.state_mask.expand_as(self.state)
        self.action_mask = self.action_mask.expand_as(self.action)
    
    def to(self, *args, **kwargs) -> "DataRawVLA":
        return recursive_to_dtype_device(self, *args, **kwargs)
    
    def decompress_(self):
        if self.raw_vl is not None:
            self.raw_vl.decompress_()
        return self
    
    def shallow_copy(self) -> "DataRawVLA":
        return recursive_shallow_copy(self)
    
    def deepcopy(self) -> "DataRawVLA":
        return recursive_deepcopy(self)


@dataclass
class BatchDataA(object):
    state: Tensor  # (B, Nee, Ts, state_dim)
    state_mask: Tensor  # shape compatible with state
    
    action: Tensor  # (B, Nee, Ta, action_dim)
    action_mask: Tensor  # shape compatible with action
    action_ref_pose: Tensor  # (B, Nee, 4, 4)

    _avg_pose: Optional[Tensor] = None  # preserved as buffer for CenterCameras transforms, shape (4, 4)

    def __post_init__(self):
        assert self.state.ndim == 4, "state should have shape (B, Nee, Ts, state_dim)"
        assert self.action.ndim == 4, "action should have shape (B, Nee, Ta, action_dim)"
        assert self.action_ref_pose.ndim == 4, "action_ref_pose should have shape (B, Nee, 4, 4)"

        if self._avg_pose is not None:
            assert self._avg_pose.ndim == 3, "_avg_pose should have shape (B, 4, 4)"
        
        self.state_mask = self.state_mask.expand_as(self.state)
        self.action_mask = self.action_mask.expand_as(self.action)
    
    def to(self, *args, **kwargs) -> "BatchDataA":
        return recursive_to_dtype_device(self, *args, **kwargs)
    
    def shallow_copy(self) -> "BatchDataA":
        return recursive_shallow_copy(self)
    
    def deepcopy(self) -> "BatchDataA":
        return recursive_deepcopy(self)


def collate_action_fn(batch: List[DataRawVLA], return_dict: bool = False):
    # process state and action
    Nees = [b.state.shape[0] for b in batch]
    max_Nee = max(Nees)

    # right padding at Nee dimension for state and action
    states = []
    state_masks = []
    actions = []
    action_masks = []
    action_ref_poses = []
    _avg_poses = []

    def pad_fn(x: Tensor, pad: int, zero: bool):
        if pad == 0:
            return x
        
        s = x[-1:]
        if zero:
            s = torch.zeros_like(s)
        return torch.cat([x, s.expand(pad, *x.shape[1:])], dim=0)

    for i, b in enumerate(batch):
        pad_nee = max_Nee - Nees[i]
        states.append(pad_fn(b.state, pad_nee, zero=False))
        state_masks.append(pad_fn(b.state_mask, pad_nee, zero=True))
        actions.append(pad_fn(b.action, pad_nee, zero=False))
        action_masks.append(pad_fn(b.action_mask, pad_nee, zero=True))
        action_ref_poses.append(pad_fn(b.action_ref_pose, pad_nee, zero=False))
        _avg_poses.append(b._avg_pose)
    
    valid_avg_mask = [p is not None for p in _avg_poses]
    if any(valid_avg_mask):
        for i in range(len(valid_avg_mask)):
            if not valid_avg_mask[i]:
                _avg_poses[i] = torch.eye(4).to(b.state)
        _avg_poses = torch.stack(_avg_poses, dim=0)
    else:
        _avg_poses = None
    
    batch_data = BatchDataA(
        state=torch.stack(states, dim=0),                       # (B, max_Nee, Ts, state_dim)
        state_mask=torch.stack(state_masks, dim=0),             # (B, max_Nee, Ts, state_dim)
        action=torch.stack(actions, dim=0),                     # (B, max_Nee, Ta, action_dim)
        action_mask=torch.stack(action_masks, dim=0),           # (B, max_Nee, Ta, action_dim)
        action_ref_pose=torch.stack(action_ref_poses, dim=0),   # (B, max_Nee, 4, 4)
        _avg_pose=_avg_poses,
    )

    if return_dict:
        return asdict(batch_data)
    else:
        return batch_data

