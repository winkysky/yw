"""Real checkpoint + localhost Pyro + independent replay client; no hardware."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

import cv2
import numpy as np
import pyarrow.parquet as pq
import Pyro4.naming
import torch

from dataset.lerobot_reviewed import build_dataset
from e2vla_compat.config import PlannerConfig
from e2vla_compat.policy import Policy
from shm_transport import run_simple_server
from shm_transport.shm_mng import register_cleanup_this_process
from .remote_service import Service


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint',required=True)
    parser.add_argument('--device',default='cuda:0')
    parser.add_argument('--index',type=int,default=214)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--duration',type=float,default=5.)
    parser.add_argument('--gpu-memory-fraction',type=float,default=.24)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(4);cv2.setNumThreads(1)
    if args.device.startswith('cuda'):
        torch.cuda.set_device(torch.device(args.device))
        torch.cuda.set_per_process_memory_fraction(args.gpu_memory_fraction,torch.device(args.device))
    ns=service=dataset=server_thread=None
    stop=threading.Event();failures=[];intervals=[]
    try:
        _,ns,_=Pyro4.naming.startNS(host='127.0.0.1',port=0,enableBroadcast=False)
        ns_thread=threading.Thread(target=ns.requestLoop,daemon=True);ns_thread.start()
        port=ns.sock.getsockname()[1]
        print('Loading existing checkpoint and validated observations',flush=True)
        cfg=PlannerConfig(checkpoint=args.checkpoint,task='close_box',device=args.device,seed=42)
        policy=Policy(cfg)
        dataset=build_dataset(policy.config)
        sample=dataset[args.index]
        cfg.prompt=sample.raw_vl.prompt
        metadata=sample._review_metadata
        reader=dataset.readers[metadata['dataset_id']]
        c=policy.config
        columns=pq.read_table(reader._path('data_path',metadata['episode_index']),
            columns=[c.state_pose_key,c.state_gripper_key]).to_pydict()
        arrays=dict(recorded_pose=np.asarray(columns[c.state_pose_key])[metadata['frame']],
                    recorded_gripper=np.asarray(columns[c.state_gripper_key])[metadata['frame'],c.gripper_indices])
        for i,key in enumerate(c.camera_keys):
            cap=cv2.VideoCapture(str(reader._path('video_path',metadata['episode_index'],key)),
                cv2.CAP_FFMPEG,[cv2.CAP_PROP_N_THREADS,1])
            try:
                cap.set(cv2.CAP_PROP_POS_FRAMES,metadata['frame']);ok,bgr=cap.read()
                if not ok:raise RuntimeError('Could not read test observation')
                arrays[f'rgb_{i}']=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
                arrays[f'K_{i}']=np.asarray(c.geometry['cameras'][key]['K'])
            finally:cap.release()
        observation=args.output/'observation.npz'
        np.savez_compressed(observation,**arrays)
        observation.with_suffix('.json').write_text(json.dumps(dict(camera_keys=c.camera_keys,prompt=cfg.prompt)))
        expected=policy.predict_samples([sample],42).numpy()
        original_predict=policy.predict_samples
        def measured(*a,**kw):
            begin=time.time()
            prediction=original_predict(*a,**kw)
            end=time.time()
            diff=float(np.max(np.abs(prediction.numpy()-expected)))
            intervals.append(dict(start=begin,end=end,max_abs_diff=diff))
            np.testing.assert_array_equal(prediction.numpy(),expected)
            return prediction
        policy.predict_samples=measured
        service=Service(policy=policy,config=cfg)
        register_cleanup_this_process()
        name='ie2vla3_async_probe'
        def serve():
            try:
                run_simple_server(service,uri_name=name,ns_host='127.0.0.1',ns_port=port,
                    daemon_host='127.0.0.1',daemon_port=0,multiplex=False,replace_existing=False,
                    loop_cond=lambda:not stop.is_set())
            except BaseException as exc:failures.append(exc)
        server_thread=threading.Thread(target=serve,daemon=True);server_thread.start()
        deadline=time.monotonic()+10
        while name not in ns.nameserver.list():
            if failures:raise failures[0]
            if time.monotonic()>deadline:raise TimeoutError('Service did not register')
            time.sleep(.02)
        print('Running independent TCP replay client and local simulated control loop',flush=True)
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
        completed=subprocess.run([sys.executable,'-m','e2vla_async.replay_client',
            '--observation',str(observation),'--output',str(args.output/'client.json'),
            '--uri',name,'--ns-port',str(port),'--duration',str(args.duration)],
            cwd=Path(__file__).resolve().parents[1],env=env,capture_output=True,text=True,timeout=90)
        (args.output/'client.log').write_text(completed.stdout+completed.stderr)
        if completed.returncode:raise RuntimeError(completed.stdout+completed.stderr)
        report=json.loads((args.output/'client.json').read_text())
        targets=[e for e in report['events'] if e['kind']=='target']
        overlaps=[e for e in targets if any(i['start']<=e['wall_time']<=i['end'] for i in intervals)]
        assert len(targets)>10 and len(overlaps)>5
        assert len({e['sequence'] for e in targets})>=2
        assert all(a['timestamp']<b['timestamp'] for a,b in zip(targets,targets[1:]))
        assert all(0<=e['timestamp']-e['observation_timestamp']<=31/30 for e in targets)
        assert all(i['max_abs_diff']==0 for i in intervals)
        assert report['stats']['uploaded']>len(intervals)
        if failures:raise failures[0]
        result=dict(checkpoint=str(args.checkpoint),checkpoint_step=policy.native_info['step'],device=args.device,
            hardware_connected=False,artificial_inference_delay_s=0.,
            repeated_static_observation=True,independent_client_process=True,transport='TCP',
            native_prediction_max_abs_diff=max(i['max_abs_diff'] for i in intervals),
            inference_calls=len(intervals),uploaded_observations=report['stats']['uploaded'],
            control_targets=len(targets),control_targets_during_inference=len(overlaps),
            executed_result_sequences=sorted({e['sequence'] for e in targets}),
            monotonic_control_timestamps=True,no_expired_targets=True,
            inference_intervals=intervals)
        (args.output/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({k:v for k,v in result.items() if k!='inference_intervals'}),flush=True)
    finally:
        stop.set()
        if server_thread is not None:server_thread.join(5.)
        if service is not None:service.close()
        if dataset is not None:dataset.close()
        if ns is not None:ns.shutdown();ns.close()


if __name__=='__main__':
    main()
