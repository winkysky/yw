"""Two RPC workers plus a local, nonblocking trajectory/control buffer."""
import copy
import math
import threading
import time

import numpy as np
from scipy.spatial.transform import Rotation, Slerp


class TrajectoryBuffer:
    def __init__(self):
        self.lock = threading.Lock()
        self.session = None
        self.sequence = 0
        self.chunks = []

    def clear(self):
        with self.lock:
            self.session, self.sequence, self.chunks = None, 0, []

    def accept(self, envelope):
        with self.lock:
            session = envelope['stream_id'], envelope['generation']
            if session != self.session:
                self.session, self.sequence, self.chunks = session, 0, []
            if envelope['error']:
                self.chunks = []
                raise RuntimeError(envelope['error'])
            if not envelope['enabled']:
                self.chunks = []
                return False
            result = envelope['result']
            if result is None or result['sequence'] <= self.sequence:
                return False
            if (result['stream_id'], result['generation']) != self.session:
                raise ValueError('Result generation differs from its envelope')
            poses, grips, times = (np.asarray(result[k]).copy() for k in ['poses','grippers','times'])
            if (times.ndim != 1 or len(times) < 2 or poses.shape != (len(times),2,4,4)
                    or grips.shape != (len(times),2) or np.any(np.diff(times) <= 0)
                    or not all(np.isfinite(x).all() for x in [poses,grips,times])):
                raise ValueError('Invalid trajectory shape, values or times')
            rotations = poses[...,:3,:3]
            if (not np.allclose(poses[...,3,:], [0,0,0,1], atol=1e-5)
                    or not np.allclose(rotations.swapaxes(-1,-2)@rotations,np.eye(3),atol=2e-3)
                    or not np.allclose(np.linalg.det(rotations),1.,atol=2e-3)):
                raise ValueError('Invalid trajectory rotations')
            if self.chunks and times[0] <= self.chunks[-1]['times'][0]:
                raise ValueError('New trajectory did not advance the observation time')
            self.sequence = result['sequence']
            self.chunks.append(dict(result, poses=poses, grippers=grips, times=times))
            self.chunks = self.chunks[-2:]
            return True

    def target(self, now, lead_time_s=0.):
        """Interpolate at the execution clock; never shift or extrapolate old chunks."""
        if not math.isfinite(now) or not math.isfinite(lead_time_s) or lead_time_s < 0:
            raise ValueError('Execution time must be finite and lead_time_s nonnegative')
        when = now + lead_time_s
        with self.lock:
            self.chunks = [c for c in self.chunks if c['times'][-1] >= when]
            chunk = next((c for c in reversed(self.chunks) if c['times'][0] <= when),None)
            if chunk is None:
                return None
            times = chunk['times']
            upper = min(int(np.searchsorted(times,when,side='right')),len(times)-1)
            lower = max(upper-1,0)
            weight = (when-times[lower])/(times[upper]-times[lower])
            pose = np.tile(np.eye(4),(2,1,1))
            pose[:,:3,3] = (1-weight)*chunk['poses'][lower,:,:3,3]+weight*chunk['poses'][upper,:,:3,3]
            for arm in range(2):
                rotations = Rotation.from_matrix(chunk['poses'][[lower,upper],arm,:3,:3])
                pose[arm,:3,:3] = Slerp([0.,1.],rotations)([weight]).as_matrix()[0]
            grip = (1-weight)*chunk['grippers'][lower]+weight*chunk['grippers'][upper]
            return dict(poses=pose,grippers=grip,timestamp=when,sequence=chunk['sequence'],
                        observation_timestamp=chunk['observation_timestamp'])


def connect(uri, ns_host, ns_port, timeout_s):
    import Pyro4
    from shm_transport import get_shm_proxy
    # Set before opening a connection, including the initial name-server lookup.
    Pyro4.config.COMMTIMEOUT = timeout_s
    return get_shm_proxy(uri,ns_host=ns_host,ns_port=ns_port,force_use_socket=True,
                         en_arg_sh_cuda=False,copy_ret_sh_cuda=False)


def release(proxy):
    if proxy is None:
        return
    try:
        if proxy._shm_name_prefix is not None:
            from shm_transport.shm_mng import get_client_shm_managers
            get_client_shm_managers().del_proxy_mng(proxy._shm_name_prefix)
            proxy._shm_name_prefix = None
    finally:
        proxy._pyro_proxy._pyroRelease()


class PipelinedClient:
    def __init__(self, uri='e2vla_async', ns_host='127.0.0.1', ns_port=9090,
                 timeout_s=3., poll_interval_s=.01, *, proxy_factory=None):
        if not all(math.isfinite(x) and x > 0 for x in [timeout_s,poll_interval_s]):
            raise ValueError('Timeout and poll interval must be positive')
        self.factory = proxy_factory or (lambda: connect(uri,ns_host,ns_port,timeout_s))
        self.release = release if proxy_factory is None else lambda proxy: None
        self.timeout_s, self.poll_interval = timeout_s, poll_interval_s
        self.buffer = TrajectoryBuffer()
        self.lock = threading.Lock()
        self.observation_ready = threading.Event()
        self.stop_event = threading.Event()
        self.pending = None
        self.last_submitted = -math.inf
        self.error = None
        self.threads = []
        self.running = False
        self.stats = dict(submitted=0, uploaded=0, coalesced=0, received=0, targets=0)

    def start(self, prompt):
        if self.running:
            raise RuntimeError('Client already started')
        if self.threads:
            raise RuntimeError('Create a new PipelinedClient after close')
        from shm_transport.shm_mng import register_cleanup_this_process
        register_cleanup_this_process()  # main thread; worker proxies are thread-owned
        proxy = self.factory()
        try:
            self.info = proxy.get_info()
            if self.info.get('async_protocol') != 'ie2vla3_latest_observation_v1':
                raise ValueError('Connect to e2vla_async.remote_service')
            proxy.reset()
            proxy.set_prompt(prompt)
            proxy.start_async()
        finally:
            self.release(proxy)
        self.running = True
        for name, fn in [('observation-upload',self._upload),('action-receive',self._receive)]:
            thread = threading.Thread(target=self._worker,args=(fn,),name=name,daemon=True)
            self.threads.append(thread)
            thread.start()
        return self.info

    def _fail(self, exc):
        with self.lock:
            if self.error is None:
                self.error = exc
        self.buffer.clear()
        self.stop_event.set()
        self.observation_ready.set()

    def check_error(self):
        with self.lock:
            error = self.error
        if error is not None:
            raise RuntimeError(f'Asynchronous client failed: {error}') from error

    def submit_observation(self, frame):
        self.check_error()
        if not self.running or self.stop_event.is_set():
            raise RuntimeError('Client is not running')
        stamp = float(frame['timestamp'])
        if not math.isfinite(stamp) or stamp < 0:
            raise ValueError('Invalid observation timestamp')
        with self.lock:
            if stamp <= self.last_submitted:
                return False  # camera callback may expose the same frame repeatedly
            self.last_submitted = stamp
            self.stats['submitted'] += 1
            self.stats['coalesced'] += self.pending is not None
            self.pending = copy.deepcopy(frame)
            self.observation_ready.set()
        return True

    def _worker(self, fn):
        proxy = None
        try:
            proxy = self.factory()
            fn(proxy)
        except Exception as exc:
            if not self.stop_event.is_set():
                self._fail(exc)
        finally:
            try:
                self.release(proxy)
            except Exception:
                pass

    def _upload(self, proxy):
        while not self.stop_event.is_set():
            self.observation_ready.wait(.1)
            with self.lock:
                frame, self.pending = self.pending, None
                self.observation_ready.clear()
            if frame is not None and not self.stop_event.is_set():
                proxy.add_obs_frame(frame)
                with self.lock:
                    self.stats['uploaded'] += 1

    def _receive(self, proxy):
        after = 0
        session = None
        while not self.stop_event.is_set():
            envelope = proxy.get_latest_action(after)
            new_session = envelope['stream_id'], envelope['generation']
            if new_session != session:
                after, session = 0, new_session
            if self.buffer.accept(envelope):
                after = envelope['result']['sequence']
                with self.lock:
                    self.stats['received'] += 1
            self.stop_event.wait(self.poll_interval)

    def next_target(self, now, lead_time_s=0.):
        self.check_error()
        if not self.running or self.stop_event.is_set():
            return None
        target = self.buffer.target(now,lead_time_s)
        if target is not None:
            with self.lock:
                self.stats['targets'] += 1
        return target

    def run(self, capture_latest, send_target, on_wait, *, control_hz=50., capture_hz=30.,
            clock=time.time, stop_event=None, duration_s=None, lead_time_s=0.):
        """capture in its own thread; send_target consumes one local servo target."""
        if not self.running:
            raise RuntimeError('Call start(prompt) first')
        if not all(math.isfinite(x) and x > 0 for x in [control_hz,capture_hz]):
            raise ValueError('Capture/control frequencies must be positive')
        if duration_s is not None and (not math.isfinite(duration_s) or duration_s <= 0):
            raise ValueError('duration_s must be positive')
        done = threading.Event()
        def capture():
            try:
                while not done.is_set() and not self.stop_event.is_set():
                    start = time.monotonic()
                    frame = capture_latest()
                    if frame is not None and not done.is_set() and not self.stop_event.is_set():
                        self.submit_observation(frame)
                    done.wait(max(0.,1/capture_hz-(time.monotonic()-start)))
            except Exception as exc:
                self._fail(exc)
        thread = threading.Thread(target=capture,name='observation-capture',daemon=True)
        thread.start()
        started, waiting = time.monotonic(), False
        try:
            while not self.stop_event.is_set() and not (stop_event and stop_event.is_set()):
                if duration_s is not None and time.monotonic()-started >= duration_s:
                    break
                tick = time.monotonic()
                target = self.next_target(clock(),lead_time_s)
                if target is None:
                    if not waiting:
                        on_wait()
                    waiting = True
                else:
                    send_target(target)
                    waiting = False
                self.stop_event.wait(max(0.,1/control_hz-(time.monotonic()-tick)))
            self.check_error()
        finally:
            done.set()
            try:
                on_wait()
            finally:
                thread.join(self.timeout_s+1.)
            if thread.is_alive():
                raise TimeoutError('capture_latest must return within a bounded time')

    def close(self):
        self.running = False
        self.stop_event.set()
        self.observation_ready.set()
        self.buffer.clear()
        for thread in self.threads:
            thread.join(self.timeout_s+1.)
        alive = [t.name for t in self.threads if t.is_alive()]
        proxy = None
        try:
            if self.threads:
                proxy = self.factory()
                proxy.pause_async()
        except Exception as exc:
            self.shutdown_error = str(exc)
        finally:
            try:
                self.release(proxy)
            except Exception as exc:
                self.shutdown_error = str(exc)
        if alive:
            raise TimeoutError(f'RPC worker did not stop: {alive}')
