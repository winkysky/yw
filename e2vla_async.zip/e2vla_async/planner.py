"""Latest-observation background inference; no model or coordinate changes."""
import copy
import math
import threading
import time
import uuid

import numpy as np

from e2vla_compat.planner import Planner, draw_prediction
from e2vla_compat.observations import HistoryNotReady


class AsyncPlanner(Planner):
    def __init__(self, config=None, *, policy=None, max_inference_hz=0.):
        if not math.isfinite(max_inference_hz) or max_inference_hz < 0:
            raise ValueError('max_inference_hz must be finite and nonnegative; 0 means no extra cap')
        super().__init__(config=config, policy=policy)
        self.condition = threading.Condition(self.lock)
        self.compute_lock = threading.Lock()
        self.stream_id = uuid.uuid4().hex
        self.generation = 0
        self.observation_sequence = 0
        self.result_sequence = 0
        self.latest_result = None
        self.enabled = False
        self.closed = False
        self.in_flight = False
        self.error = None
        self.consumed = None
        self.last_start = -math.inf
        self.min_interval = 0. if max_inference_hz == 0 else 1./max_inference_hz
        self.counts = dict(started=0, completed=0, discarded=0)
        self.worker = threading.Thread(target=self._work, name='ie2vla3-inference', daemon=True)
        self.worker.start()

    def get_info(self):
        return dict(super().get_info(), async_protocol='ie2vla3_latest_observation_v1',
                    async_endpoint='get_latest_action', stream_id=self.stream_id)

    def get_status(self):
        with self.lock:
            return dict(super().get_status(), stream_id=self.stream_id, generation=self.generation,
                        enabled=self.enabled, in_flight=self.in_flight, error=self.error,
                        observation_sequence=self.observation_sequence,
                        result_sequence=self.result_sequence, counts=self.counts.copy(),
                        max_inference_hz=0. if self.min_interval == 0 else 1./self.min_interval)

    def _invalidate(self):
        self.generation += 1
        self.latest_result = None
        self.error = None
        self.consumed = None
        self.condition.notify_all()

    def reset(self):
        with self.condition:
            super().reset()
            self.enabled = False
            self._invalidate()

    def set_config(self, values):
        with self.condition:
            previous = self.settings
            super().set_config(values)
            if self.settings != previous:
                self._invalidate()

    def start_async(self):
        with self.condition:
            if self.closed:
                raise RuntimeError('Planner is closed')
            if not self.settings.prompt:
                raise ValueError('Set a prompt before start_async')
            if not self.enabled:
                self.enabled = True
                self.error = None
                self.consumed = None
            self.condition.notify_all()
            return self.get_status()

    def pause_async(self):
        with self.condition:
            self.enabled = False
            self._invalidate()
            return self.get_status()

    def add_obs_frame(self, obs_frame):
        return self.add_obs_frames([obs_frame])

    def add_obs_frames(self, obs_frames):
        with self.condition:
            super().add_obs_frames(obs_frames)
            self.observation_sequence += len(obs_frames)
            self.condition.notify_all()

    def _snapshot(self):
        # Incoming arrays are copied by ObservationBuffer and never edited.
        # Copy the small deque, then resize/tokenize outside the observation lock.
        sampler = copy.copy(self.sampler)
        sampler.states = self.sampler.states.copy()
        return (sampler, self.settings, self.generation, self.observation_sequence)

    def _predict(self, snapshot, seed=None, speed_mps=None, draw_traj=False, compress=False):
        sampler, settings, generation, sequence = snapshot
        sample = sampler.sample(settings.prompt)
        started = time.monotonic()
        actions = self.policy.predict_samples([sample], settings.seed if seed is None else seed,
            settings.speed_mps if speed_mps is None else speed_mps, settings.guidance_scale)[0].numpy()
        poses, grippers = actions[...,:16].reshape(-1,2,4,4), actions[...,16]
        stamp = sampler.latest['timestamp']
        times = stamp + (self.config.action_offset + np.arange(len(actions))*self.config.frame_stride)/self.policy.fps
        image = draw_prediction(sample, poses, compress) if draw_traj else None
        result = dict(stream_id=self.stream_id, generation=generation,
            observation_sequence=sequence, observation_timestamp=stamp,
            inference_seconds=time.monotonic()-started,
            poses=poses.copy(), grippers=grippers.copy(), times=times, image=image)
        return result, sample

    def get_action(self, draw_traj=False, compress_traj_img=False, seed=None, speed_mps=None):
        """Preserve the old blocking endpoint, but allow concurrent observation uploads."""
        with self.compute_lock:
            with self.lock:
                if not self.sampler.states:
                    return None
                snapshot = self._snapshot()
            try:
                result, sample = self._predict(snapshot, seed, speed_mps, draw_traj, compress_traj_img)
            except HistoryNotReady as exc:
                with self.lock:
                    self.last_status = str(exc)
                return None
            with self.lock:
                if snapshot[2] != self.generation or self.closed:
                    raise RuntimeError('Planner changed during inference; result discarded')
                self.last_obs_data, self.last_status = sample, 'ready'
            return result['poses'], result['grippers'], result['times'], result['image']

    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        with self.compute_lock:
            with self.lock:
                settings, generation = self.settings, self.generation
            result = self.policy.run_inference(obs_data, settings.seed if seed is None else seed,
                contract_sha256, settings.speed_mps if speed_mps is None else speed_mps,
                settings.guidance_scale if guidance_scale is None else guidance_scale)
            with self.lock:
                if generation != self.generation or self.closed:
                    raise RuntimeError('Planner changed during inference; result discarded')
            return result

    def get_latest_action(self, after_sequence=0):
        """Always returns control state; returns a new result only when available."""
        if type(after_sequence) is not int or after_sequence < 0:
            raise ValueError('after_sequence must be a nonnegative integer')
        with self.lock:
            result = self.latest_result
            if result is None or result['sequence'] <= after_sequence:
                result = None
            return dict(stream_id=self.stream_id, generation=self.generation,
                        enabled=self.enabled, error=self.error, result=copy.deepcopy(result))

    def _ready(self):
        return (self.enabled and self.sampler.latest is not None
                and self.consumed != (self.generation, self.observation_sequence))

    def _work(self):
        while True:
            with self.condition:
                while not self.closed:
                    delay = self.min_interval-(time.monotonic()-self.last_start)
                    if self._ready() and delay <= 0:
                        break
                    self.condition.wait(timeout=max(delay,.001) if self._ready() else None)
                if self.closed:
                    return
            with self.compute_lock:
                with self.condition:
                    if self.closed:
                        return
                    if not self._ready():
                        continue
                    snapshot = self._snapshot()
                    self.consumed = snapshot[2:]
                    self.in_flight = True
                    self.last_start = time.monotonic()
                    self.counts['started'] += 1
                result = sample = error = None
                try:
                    result, sample = self._predict(snapshot)
                except Exception as exc:
                    error = exc
                with self.condition:
                    self.in_flight = False
                    if self.closed or snapshot[2] != self.generation:
                        self.counts['discarded'] += 1
                    elif isinstance(error, HistoryNotReady):
                        self.last_status = str(error)
                    elif error is not None:
                        self.error = f'{type(error).__name__}: {error}'
                        self.enabled = False
                        self.latest_result = None
                        self.last_status = 'inference_failed'
                    else:
                        # New observations do NOT invalidate a running result:
                        # publish it, then immediately snapshot the latest frame.
                        self.result_sequence += 1
                        result['sequence'] = self.result_sequence
                        self.latest_result = result
                        self.last_obs_data, self.last_status = sample, 'ready'
                        self.counts['completed'] += 1
                    self.condition.notify_all()

    def close(self, timeout=30.):
        with self.condition:
            self.closed = True
            self.enabled = False
            self._invalidate()
        self.worker.join(timeout)
        if self.worker.is_alive():
            raise TimeoutError('Inference is still finishing; worker cannot be interrupted inside CUDA')
