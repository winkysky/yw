"""Run the asynchronous loop with an existing robot's observation/control adapter."""
import argparse
import importlib
import json
from pathlib import Path
import time

from .client import PipelinedClient


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--adapter',required=True,help='Python module:factory; factory(config_dict) returns an adapter')
    parser.add_argument('--adapter-config',type=Path)
    parser.add_argument('--prompt',required=True)
    parser.add_argument('--uri',default='e2vla_async')
    parser.add_argument('--ns-host',default='127.0.0.1')
    parser.add_argument('--ns-port',type=int,default=9090)
    parser.add_argument('--control-hz',type=float,default=50.)
    parser.add_argument('--capture-hz',type=float,default=30.)
    parser.add_argument('--poll-interval',type=float,default=.01)
    parser.add_argument('--timeout',type=float,default=3.)
    parser.add_argument('--lead-time',type=float,default=0.)
    parser.add_argument('--duration',type=float)
    args=parser.parse_args()
    module,separator,name=args.adapter.partition(':')
    if not separator:parser.error('--adapter requires module:factory')
    factory=getattr(importlib.import_module(module),name)
    config=json.loads(args.adapter_config.read_text()) if args.adapter_config else {}
    adapter=factory(config)
    client=PipelinedClient(args.uri,args.ns_host,args.ns_port,args.timeout,args.poll_interval)
    try:
        for name in ['capture_latest','send_target','on_wait']:
            if not callable(getattr(adapter,name,None)):
                raise TypeError(f'Adapter must provide {name}()')
        info=client.start(args.prompt)
        # Adapter may check backend coordinates/rates before any control call.
        if hasattr(adapter,'configure'):
            adapter.configure(info)
        client.run(adapter.capture_latest,adapter.send_target,adapter.on_wait,
            control_hz=args.control_hz,capture_hz=args.capture_hz,
            lead_time_s=args.lead_time,duration_s=args.duration,
            clock=getattr(adapter,'clock',time.time))
    except KeyboardInterrupt:
        pass
    finally:
        client.close()
        if hasattr(adapter,'close'):
            adapter.close()


if __name__=='__main__':
    main()
