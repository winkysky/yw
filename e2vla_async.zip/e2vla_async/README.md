# 边执行上一段动作，边推理下一段

这是新增的异步服务端和客户端调度器。服务端用当前 iE2VLA3 推理函数，持续接收最新观测，在后台串行计算下一段动作；客户端控制循环从本地轨迹缓存取目标，不等待网络或模型计算。

原 `e2vla_compat` 服务、模型、训练代码、checkpoint 和 `/home/hq/code/e2vla` 客户端文件保持原样。这里无需重新训练，也不更改 `full_qwen_features`、采样时间间隔或预测步数。

**只更换服务端不能把旧客户端的串行循环自动变为并行。** 旧接口仍可同步调用；要让执行和推理重叠，需要使用本目录的 `PipelinedClient` 或 `run_client`，把现有客户端的观测采集、单步控制输出、等待处理三个函数接入。不可观测服务器上的客户端尚未自动修改或部署。

## 1. 文件

| 文件 | 用途 |
| --- | --- |
| `remote_service.py` | Pyro4 服务入口，保留原接口并增加异步接口 |
| `planner.py` | 后台推理、观测快照、最新结果缓存、过期会话结果丢弃 |
| `planner.json` | 默认 `recorded/raw`、URI `e2vla_async`、端口 9102 |
| `client.py` | 独立上传/接收线程、轨迹插值、无网络调用的控制取点 |
| `run_client.py` | 通过现有机器人适配器启动并行控制循环 |
| `replay_client.py` | 观测回放与模拟控制，不向机器人发送命令 |
| `probe.py` | 真实 checkpoint、独立客户端进程、TCP 通信验证 |

服务端无需导入原 e2vla 仓库。使用现有 `ie2vla3` 环境即可；客户端需要本目录和本库 `shm_transport` 的依赖，沿用已可用的 Pyro4 客户端环境。

## 2. 启动服务端

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3

# 先核对配置和 checkpoint 元数据
python -m e2vla_async.remote_service --check-config

# 本机测试：客户端将调用 set_prompt/start_async 启动后台推理
python -m e2vla_async.remote_service --device cuda:0 --start-ns
```

默认 checkpoint 是第一次训练的 100k：

```text
/home/hq/code/iE2VLA3/checkpoints/lerobot_original_full_reviewed_h32_20261116_021607/step_0100000
```

客户端在另一台机器时，例如推理服务器地址为 `10.15.194.98`：

```bash
cd /home/hq/code/iE2VLA3
conda activate ie2vla3
python -m e2vla_async.remote_service \
  --checkpoint /home/hq/code/iE2VLA3/checkpoints/lerobot_original_full_reviewed_h32_20261116_021607/step_0100000 \
  --device cuda:0 --task place_phone \
  --uri e2vla_async --host 10.15.194.98 --port 9102 \
  --ns-host 10.15.194.98 --ns-port 9090 --start-ns
```

请使用实际推理服务器 IP 和可用 GPU。`--start-ns` 会复用已有名称服务，不覆盖同名服务注册。新增默认名称和端口与旧服务不同；客户端连接新名称 `e2vla_async`。`--task` 仍只是兼容接口的任务路由，真正任务由 prompt 决定。

输入默认 `recorded/raw`：原始两臂记录位姿、原始夹爪值、三路 RGB、任务指令。单位、工具、左右基座转换继续由现有服务端代码完成。若现有客户端已经上传公共坐标系 TCP 和 openness，则在服务端显式增加：

```bash
--input-pose-format tcp_world --input-gripper-format openness
```

可选 `--max-inference-hz 10` 限制后台推理启动频率；默认 `0` 表示有新观测就尽快推理，不额外限频。没有新观测不会重复计算同一帧。希望服务启动后直接等待观测并自动计算，可同时指定 `--autostart --prompt "任务指令"`；使用新增客户端时不需要这两个参数。

## 3. 客户端如何接入

### 直接复用现有采集与控制函数

下面是对接示例，`robot` 代表现有客户端中的真实机器人接口对象，需要把三个方法对应到已有实现：

```python
from e2vla_async.client import PipelinedClient

client = PipelinedClient(
    uri="e2vla_async", ns_host="10.15.194.98", ns_port=9090,
    timeout_s=3.0, poll_interval_s=0.01,
)

try:
    info = client.start(
        "Pick up the phone with the left arm and place it into the box."
    )

    # 在开始运动前，用 info 核对现有控制器的坐标转换约定。
    client.run(
        capture_latest=robot.get_latest_observation,
        send_target=robot.send_one_target,
        on_wait=robot.hold_position,
        clock=robot.observation_clock,
        control_hz=50,
        capture_hz=30,
        lead_time_s=0.0,
    )
finally:
    client.close()
```

三个回调的合同：

| 回调 | 要求 |
| --- | --- |
| `capture_latest()` | 返回一帧现有 e2vla 观测字典，暂时没有新帧时返回 `None`；在独立采集线程调用。图像和状态仍需对齐，并且该函数应有有限等待时间。重复时间戳自动跳过。 |
| `send_target(target)` | 消费一个执行时刻的双臂 TCP 和夹爪目标。调用已有控制器的单点/伺服目标发送逻辑，应快速返回；不要在这里同步等待整段 MoveIt 轨迹执行结束。 |
| `on_wait()` | 初始等待、轨迹用尽、退出时调用已有保持/暂停逻辑。它需要确保控制器不继续执行已失效的旧队列。不会自动把夹爪改成打开。 |

`send_target` 收到：

```python
target = {
    "poses": ...,                 # [2,4,4]，左臂 base 下的双臂 TCP，米
    "grippers": ...,              # [2]，模型 openness；沿用现有执行范围处理
    "timestamp": ...,             # 本次执行目标的时间
    "sequence": ...,              # 所用预测结果编号
    "observation_timestamp": ..., # 该预测所依据观测的时间
}
```

客户端仍负责 TCP 到真实控制接口的转换、IK、执行器约束和发送；本模块不猜测具体机器人的 ROS topic、action 名称或控制 API。**若现有客户端只支持“发整段轨迹并等它结束”，需要让它支持可更新目标/可替换未来轨迹，才能获得这里的持续重规划效果。**

### 通过命令启动已有适配器

也可以新增一个自己的适配器模块，不改原有机器人库。工厂函数 `create(config_dict)` 返回带有上述 `capture_latest / send_target / on_wait` 方法的对象；可选 `clock()`、`configure(info)`、`close()`。`configure` 在控制开始前调用。

```bash
cd /home/hq/code/iE2VLA3
python -m e2vla_async.run_client \
  --adapter your_robot_adapter:create \
  --adapter-config /实际路径/robot.json \
  --uri e2vla_async --ns-host 10.15.194.98 --ns-port 9090 \
  --prompt "Pick up the phone with the left arm and place it into the box." \
  --control-hz 50 --capture-hz 30 --poll-interval 0.01
```

`your_robot_adapter` 是你现有客户端的对接模块名，需要实际提供，仓库没有伪装成真实机器人的默认驱动。若适配器不需要配置文件，可省略 `--adapter-config`。可用 `--duration 10` 限制本次循环时间。运行目录和 Python 搜索路径需能导入该模块。

已经有自己的实时控制循环时，不必使用 `run()`：相机线程调用 `client.submit_observation(frame)`；控制线程调用 `client.next_target(now)`，拿到 `None` 时执行已有保持策略。网络上传和结果轮询已经有各自线程和各自 Pyro 连接，控制线程不访问网络。

## 4. 时间戳与动作段衔接

模型仍输出 32 点，时间为 `观测时间 + arange(32)/30`，首末点跨度约 1.033 秒。这是模型轨迹间隔，不是后台推理或控制循环频率。`capture_hz`、`control_hz`、轮询间隔、后台推理限频各自独立；调整它们不改变模型训练频率。

**观测 timestamp 和传给客户端控制循环的 clock 必须属于同一个时间域。** 默认 clock 是 `time.time()`；若观测用 ROS 时间，则给适配器提供同一 ROS 时钟的 `clock()`，不可与墙钟或 `time.monotonic()` 混用。服务端不拿服务器墙钟重写轨迹时间，也不要求客户端与服务端系统时钟同步。

收到结果后按当前执行时间取点：

1. 继续执行本地已缓存轨迹，网络和模型计算不会阻塞控制取点。
2. 新结果到达后，使用覆盖当前执行时间的较新轨迹。若新轨迹尚未开始，保留旧轨迹到切换时间。
3. 平移和夹爪做线性插值，旋转做 SLERP。已经过去的动作点不重新执行，也不把整段轨迹重新从第 0 点播放。
4. 新旧两段都不覆盖执行时间时，返回 `None`，调用 `on_wait()`。不会外推或无限重复过期动作。
5. `lead_time_s`/`--lead-time` 默认为 0，可显式提供控制器需要的前瞻量；它只改变取点时间，不会平移模型轨迹的时间轴。

示例：观测时间是 100.000，结果到达时执行时钟是 100.180，就在该预测的约第 5～6 点之间插值，而不是播放第 0 点。若下一段还在计算，仍从上一段覆盖 100.180 的位置取目标。

这里没有额外跨轨迹平滑或速度/加速度约束；新旧段按时间衔接，最终可执行性继续由现有控制器处理。如果推理、传输和排队时间已经超过有效预测范围，异步调度不能凭空补足后续动作，客户端会进入等待。

## 5. 服务端接口与生命周期

旧接口 `add_obs_frame(s)`、`get_action`、`run_inference(_numpy)` 等仍保留原来的参数和返回语义。`get_action` 仍是同步调用，只是计算期间不再锁住观测接收。新增接口：

```python
proxy.reset()                 # 清除观测/结果，停止后台调度
proxy.set_prompt(prompt)
proxy.start_async()           # 开启后台调度，立即返回状态
proxy.add_obs_frame(frame)    # 推理期间仍可上传
envelope = proxy.get_latest_action(after_sequence=last_sequence)
proxy.pause_async()           # 停止继续调度，当前计算的结果作废
```

`get_latest_action` 立即返回一个字典，不等待模型：

```python
{
    "stream_id": "本次服务进程ID",
    "generation": 3,          # reset / 改配置或 prompt / pause 后变化
    "enabled": True,
    "error": None,
    "result": None,           # 无更新时为 None，否则如下
}
# result 内含：sequence、generation、stream_id、observation_sequence、
# observation_timestamp、inference_seconds、poses、grippers、times、image。
# 后台结果 image 为 None，避免在推理循环里额外绘图。
```

新客户端看到 generation 或 stream_id 变化会清除本地旧轨迹；推理错误会传播给客户端并停止下发目标。只更新观测不会让正在计算的结果作废，否则高频上传会使所有结果都来不及发布。当前结果计算完先发布，然后直接取那时最新的观测继续计算；不会累积待推理帧队列。当前 checkpoint 为 H=1，客户端也只保留尚未上传的最新一帧。

reset、改 prompt 或 pause 期间，无法强行中断已经提交给 GPU 的运算；运算可以完成，但旧 generation 的结果不会发布。退出时等待工作线程结束。

一个服务进程对应一个机器人会话。新客户端 `start()` 会 reset 该服务，`close()` 会 pause；独立机器人使用不同 URI/进程。客户端换任务应先退出当前控制循环并保持，再关闭旧客户端、建立新客户端并 `start(new_prompt)`，避免任务切换时继续使用之前的执行目标。

## 6. 测试与无机器人演示

单元与回归测试：

```bash
cd /home/hq/code/iE2VLA3
python -m pytest tests/test_e2vla_async.py tests/test_e2vla_compat.py -q
```

真实 100k 模型与独立客户端 TCP 验证：

```bash
python -m e2vla_async.probe \
  --checkpoint /home/hq/code/iE2VLA3/checkpoints/lerobot_original_full_reviewed_h32_20261116_021607/step_0100000 \
  --device cuda:0 \
  --output /home/hq/code/iE2VLA3/audits/e2vla_async_20261120/real_probe
```

验证会临时启动 localhost 名称服务与模型服务，结束后关闭。使用真实记录的一帧观测重复回放、更新时间戳，并由独立进程运行上传/收结果/模拟控制；不会连接机器人。检查异步输出与原推理结果一致、控制目标在推理进行时仍持续产生、结果更新和时间戳正确，以及不发送过期目标。它验证软件并行与接口，不代表机器人闭环效果。

验证生成的 `observation.npz` 也可对已启动的新服务单独回放：

```bash
python -m e2vla_async.replay_client \
  --observation /home/hq/code/iE2VLA3/audits/e2vla_async_20261120/real_probe/observation.npz \
  --output /home/hq/code/iE2VLA3/audits/e2vla_async_20261120/replay.json \
  --uri e2vla_async --ns-host 127.0.0.1 --ns-port 9090 \
  --duration 5 --capture-hz 30 --control-hz 50
```

测试记录保存在 `audits/e2vla_async_20261120`。生产服务需要按第 2 节手动启动，真实机器人客户端需要完成第 3 节的回调对接。

本次本地验证结果：27 项单元/回归测试通过。第一次训练的 100k checkpoint 经独立进程 TCP 回放验证，5 秒内上传 150 帧观测、进行 28 次推理，模拟控制输出 238 个目标，其中 230 个在下一次推理进行期间输出；异步预测与原入口的最大绝对差为 0，执行时间戳递增且无过期目标。没有人为增加推理延迟。这些是本机测试结果，不是其他服务器的性能保证。

原有服务、模型、数据读取代码与原 e2vla 客户端相关的 76 个已记录文件经 SHA-256 核对保持不变。详情见 `audits/e2vla_async_20261120/pytest.xml`、`real_probe/validation.json` 和 `original_files_sha256.json`。
