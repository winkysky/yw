"""Calibration fixture for ROS collection tests; Planner tests live at project root."""
import json
from pathlib import Path

def model_info(task="close_box"):
    root=Path(__file__).resolve().parents[2]
    config=json.loads((root/f"configs_lerobot_no_force/reviewed_{task}_15hz.json").read_text())
    return {"data_config":config["data"]}
