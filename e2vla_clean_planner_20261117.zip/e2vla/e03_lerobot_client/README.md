# E03 双臂推理客户端

两种模型和三个任务共用一个客户端、一份 `configs/robot.json` 硬件配置。客户端采集图像和双臂状态，发送给服务器 Planner；历史选取、图像缩放和模型预处理由服务器完成。任务和模型类型从服务自动识别，无需复制六份配置。

## 部署与配置

机器人服务器保留项目中的 `e03_lerobot_client/` 和同级 `shm_transport/`。在它们的父目录运行模块，不需要 PyTorch、CUDA、模型权重或训练数据。环境需要 ROS2、MoveIt2 消息、cv_bridge、NumPy、SciPy、OpenCV、Pyro4。

```bash
source /opt/ros/humble/setup.bash
source /实际机器人工作区/install/setup.bash
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install 'Pyro4>=4.82,<5'
cp e03_lerobot_client/configs/robot.json e03_lerobot_client/configs/robot.local.json
```

填写 `robot.local.json` 的实际硬件接口；模板中的 null/空列表表示尚未确认：

| 字段 | 内容 |
|---|---|
| server.ns_host / uri | 模型服务器地址和服务名，默认 uri 为 e2vla |
| reference_frame | 训练左臂 base 在 ROS TF 中的名称 |
| arms | 左、右顺序；各自 base/flange/tcp frame、六关节名 |
| cameras | 头、左腕、右腕的图像和 CameraInfo 话题 |
| planning_group | 同时包含双臂的 MoveIt2 group |
| arms[].workspace | 共同左臂 base 下的 TCP 目标范围，米 |
| arms[].gripper | 夹爪反馈端点和 GripperCommand action、指令端点、力限值 |
| capture_hz | ROS 观测采集频率，默认 30；独立于模型推理调用频率 |

`task` 和 `variant` 保持 null 即自动识别；需要防止连错模型时才填写预期值。切换任务或两种模型时，通常只需让服务加载另一个 checkpoint。

三个相机键分别是 `observation.images.head_image`、`observation.images.left_wrist_image`、`observation.images.right_wrist_image`。相机内参、图像分辨率、base/工具/相机 TF 要与训练标定相符。夹爪模型开度为 0=关、1=开，ROS 驱动端点按实际接口映射。SDK/Modbus 夹爪需在本体提供相应驱动桥接。

## 使用

先按项目根目录 `README_lerobot_pyro.md` 启动统一模型服务，再在机器人端检查连接：

```bash
python -m e03_lerobot_client.clients.check_server \
  --config e03_lerobot_client/configs/robot.local.json
```

一轮观测和推理：

```bash
python -m e03_lerobot_client.clients.e03_ros2 \
  --config e03_lerobot_client/configs/robot.local.json \
  --prompt '实际训练任务指令' --steps 1 --output-dir results
```

连续速度版追加 `--speed-mps 0.05`，或使用服务已设置的速度。无速度版不传速度参数。每轮输出保存 `(32,2,4,4)` TCP、`(32,2)` 夹爪和 `(32,)` 轨迹时间。

`--plan-only` 只规划；`--execute` 执行；默认只推理。`--steps 0 --execute` 持续闭环，Ctrl-C 取消本客户端待完成目标。

当前执行方式沿用原客户端：每轮选择 `--action-index` 指定的一个双臂目标（默认 0），MoveIt 完成运动后发送夹爪动作，再开始下一轮。这是按动作完成情况运行的闭环，推理没有固定 Hz。若要执行整段 32 点轨迹，需在本体接口中实现轨迹插值与跟踪。

## 坐标和时间

客户端通过 TF 取得共同左臂 base 下的 TCP，因此服务使用默认 `tcp_world`，不重复变换右臂或工具偏置。MoveIt 目标使用左臂 base 和两臂各自 TCP link。若改用要求右臂自身 base 的 SDK，需要将右臂输出转换到该坐标系。

采集频率、推理请求频率、机器人控制频率是独立概念。服务从实测缓存按训练时间间隔选取五步历史；轨迹时间反映训练动作点间隔。客户端不以 15 Hz / 30 Hz 调度推理。

机器人实际话题、TF、MoveIt 与夹爪端点仍需在本体填写和验证。代码检查使用模拟 ROS 消息/action 和本机 Pyro4；不代表完成了真实本体运行验证。
