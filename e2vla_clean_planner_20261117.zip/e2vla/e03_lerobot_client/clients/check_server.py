"""Check task/protocol/calibration metadata without ROS or robot motion."""
import argparse
import json
from pathlib import Path

from .lerobot_policy import connect_policy


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True, type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    policy = connect_policy(config['server'], config['cameras'], 2, config['task'], config.get('preprocessing'))
    try:
        print(json.dumps(policy.info, indent=2, ensure_ascii=False))
    finally:
        policy.close()


if __name__ == '__main__':
    main()
