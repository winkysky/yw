"""Thin NumPy client: observed frames go to the shared server-side Planner."""
import numpy as np
from .e03_protocol import Prediction, transform_matrix

TASKS = {
    "close_box": ["close_box_1112_2/success"],
    "open_box": ["open_the_box_1109_60/success"],
    "place_phone": ["place_phone_1111_60_2/success", "place_phone_1112_10/success"],
}
CAMERAS = ["observation.images.head_image", "observation.images.left_wrist_image",
           "observation.images.right_wrist_image"]

class HistoryNotReady(ValueError):
    pass

def check_transform(actual, expected, name, position_m, rotation_deg):
    actual = transform_matrix(actual, name)
    expected = transform_matrix(expected, name + " calibration")
    distance = np.linalg.norm(actual[:3, 3] - expected[:3, 3])
    # Calibrations contain rounded rotation entries; normalize the relative
    # rotation with SVD before measuring its angle.
    u, _, vt = np.linalg.svd(expected[:3, :3].T @ actual[:3, :3])
    relative = u @ vt
    angle = np.degrees(np.arccos(np.clip((np.trace(relative) - 1) / 2, -1, 1)))
    if distance > position_m or angle > rotation_deg:
        raise ValueError(f"{name} differs from checkpoint calibration: {distance:.6f} m, {angle:.3f} deg")


class RemotePolicy:
    def __init__(self, proxy, camera_names, num_arms, task, options=None):
        self.proxy = proxy
        self.info = proxy.get_info()
        info = self.info
        if info.get("planner_protocol") != "e2vla_lerobot_planner_v1":
            raise ValueError("Start the checkpoint-configured LeRobot Planner service")
        if num_arms != 2 or info.get("arm_order") != ["left", "right"]:
            raise ValueError("Expected two arms in left, right order")
        if info.get("world_frame") != "left_recorded_arm_base":
            raise ValueError("Expected TCPs in the left recorded arm base")
        self.config = info["data_config"]
        task = info.get("task") if task is None else task
        if task not in TASKS or info.get("task") != task or set(self.config["reviewed_datasets"]) != set(TASKS[task]):
            raise ValueError("Wrong task/checkpoint")
        if self.config["camera_keys"] != CAMERAS or set(camera_names) != set(CAMERAS):
            raise ValueError("Camera names/order must match the checkpoint")
        settings = info["planner_config"]
        if settings["input_pose_format"] != "tcp_world" or settings["input_gripper_format"] != "openness":
            raise ValueError("ROS TF client requires tcp_world poses and openness grippers")
        if options:
            raise ValueError("Configure preprocessing in the server Planner JSON")
        self.variant = info["variant"]
        if self.variant not in ("no_speed", "speed"):
            raise ValueError("Unsupported model variant")
        self.history_seconds = (self.config["num_history_states"]-1)/self.config["target_fps"]
        self.last_time = -np.inf
        self.started = False

    def start(self, prompt, speed_mps=None):
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("Supply a nonempty task instruction")
        if self.variant == "speed":
            value = self.info["planner_config"]["speed_mps"] if speed_mps is None else speed_mps
            if value is None or not np.isfinite(value) or value < 0:
                raise ValueError("Supply --speed-mps for the continuous-speed model")
        elif speed_mps is not None:
            raise ValueError("The no-speed model does not accept speed_mps")
        self.proxy.reset()
        self.proxy.set_prompt(prompt)
        if self.variant == "speed":
            self.proxy.set_speed(float(value))
        self.last_time = -np.inf
        self.started = True

    def infer(self, frames, seed=None):
        if not self.started:
            raise ValueError("Call start(prompt) first")
        if not frames:
            raise HistoryNotReady("No fresh observations")
        times = np.asarray([frame["timestamp"] for frame in frames])
        if not np.isfinite(times).all() or times[0] <= self.last_time or np.any(np.diff(times) <= 0):
            raise ValueError("Observation timestamps must increase")
        self.proxy.add_obs_frames(frames)
        self.last_time = float(times[-1])
        response = self.proxy.get_action(draw_traj=False, seed=seed)
        if response is None:
            raise HistoryNotReady("Server is collecting continuous measured history")
        prediction = Prediction.from_response(response, self.last_time, 2)
        expected = self.last_time + self.config["action_offset"]/self.config["source_fps"] + np.arange(32)/self.config["target_fps"]
        if prediction.poses.shape[0] != 32 or not np.allclose(prediction.times, expected, rtol=0, atol=1e-6):
            raise ValueError("Prediction timestamps differ from checkpoint sampling")
        return prediction

    def close(self):
        if self.proxy is not None:
            release_proxy(self.proxy)
            self.proxy = None


def release_proxy(proxy):
    # shm_transport registers a manager even in socket-only mode. Release it
    # while the server is alive, before closing the underlying Pyro connection.
    if proxy._shm_name_prefix is not None:
        from shm_transport.shm_mng import get_client_shm_managers
        get_client_shm_managers().del_proxy_mng(proxy._shm_name_prefix)
        proxy._shm_name_prefix = None
    proxy._pyro_proxy._pyroRelease()


def connect_policy(config, camera_names, num_arms, task, options=None):
    import Pyro4
    from shm_transport import get_shm_proxy
    Pyro4.config.COMMTIMEOUT = config["timeout_s"]
    proxy = get_shm_proxy(config["uri"], ns_host=config["ns_host"], ns_port=config["ns_port"],
                          force_use_socket=True, en_arg_sh_cuda=False, copy_ret_sh_cuda=False)
    proxy._pyro_proxy._pyroTimeout = config["timeout_s"]
    try:
        return RemotePolicy(proxy, camera_names, num_arms, task, options)
    except BaseException:
        release_proxy(proxy)
        raise
