"""Reviewed 15 Hz sampling, dataset mixing and pretrained initialization."""
from copy import deepcopy
from dataclasses import replace
import json
from multiprocessing.connection import Listener
from pathlib import Path
import pickle

import cv2
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch

from data_utils.lerobot_no_force import INPUT_KEYS, collate_lerobot_no_speed
import data_utils.lerobot_reviewed_no_force as reviewed
import train_lerobot_no_force as trainer
from train_lerobot_vel_no_force import TrainingStream

ROOT = Path(__file__).resolve().parents[1]


def rows_valid(segment, observations, actions):
    rows = list(observations) + list(actions)
    return all(segment['start_frame'] <= row < segment['stop_frame']
               and not any(a <= row < b for a, b in segment['excluded_intervals']) for row in rows)


@pytest.fixture
def reviewed_reader(tmp_path, monkeypatch):
    args = trainer.parse_args(['--config', str(ROOT / 'configs_lerobot_no_force/reviewed_place_phone_15hz.json')])
    original = trainer.load_data_config(args)
    camera = original.camera_keys[0]
    cfg = replace(original, root=str(tmp_path), reviewed_datasets=['A/success', 'B/success'],
                  image_size=[32, 32], camera_keys=[camera],
                  geometry=dict(cameras={camera: deepcopy(original.geometry['cameras'][camera])}))
    segments = []
    raw_actions = {}
    for number, name in enumerate(cfg.reviewed_datasets):
        root = tmp_path / name
        (root / 'meta').mkdir(parents=True)
        n = 240
        info = dict(codebase_version='v2.1', fps=30, chunks_size=1000,
                    data_path='episode_{episode_index:06d}.parquet',
                    video_path='{video_key}_{episode_index:06d}.mp4',
                    features={camera: dict(dtype='video')})
        (root / 'meta/info.json').write_text(json.dumps(info))
        (root / 'meta/episodes.jsonl').write_text(json.dumps(dict(episode_index=0, length=n)) + '\n')
        (root / 'meta/tasks.jsonl').write_text(json.dumps(dict(task_index=0, task='RAW TASK MUST NOT WIN')) + '\n')
        poses = np.zeros((n, 12))
        poses[:, 0] = np.arange(n) + number * 1000
        poses[:, 7] = np.arange(n) * 2
        commands = poses.copy()
        commands[:, 0] += 20
        raw_actions[name] = commands
        grips = np.zeros((n, 14))
        columns = {cfg.state_pose_key: poses.tolist(), cfg.action_pose_key: commands.tolist(),
                   cfg.state_gripper_key: grips.tolist(), cfg.action_gripper_key: grips.tolist(),
                   'timestamp': (np.arange(n) / 30).tolist(), 'frame_index': list(range(n)),
                   'episode_index': [0] * n, 'task_index': [0] * n, 'prompt': ['RAW PROMPT'] * n}
        original_path = root / 'episode_000000.parquet'
        pq.write_table(pa.table(columns), original_path)
        # Dataset A needs corrected values; B legitimately has no correction.
        path = original_path
        if number == 0:
            grips[:, 6] = 943
            columns[cfg.state_gripper_key] = grips.tolist()
            columns[cfg.action_gripper_key] = grips.tolist()
            path = tmp_path / 'corrected_A.parquet'
            pq.write_table(pa.table(columns), path)
        writer = cv2.VideoWriter(str(root / f'{camera}_000000.mp4'), cv2.VideoWriter_fourcc(*'mp4v'), 30, (32, 32))
        assert writer.isOpened()
        for _ in range(n):
            writer.write(np.full((32, 32, 3), 40 + number * 150, np.uint8))
        writer.release()
        segments.append(dict(dataset_name=name, dataset_id=str(number), source_root=str(root),
                             episode_index=0, parquet_path=str(path), segment_id=f'{number}:0:0',
                             start_frame=3, stop_frame=230, excluded_intervals=[[95, 96]] if number == 0 else [],
                             instruction=f'REVIEWED {number}', split_group=f'group_{number}',
                             action_relation='independent'))
    # Selection must not construct readers for another dataset.
    unselected = dict(segments[0], dataset_name='not_requested', source_root='/nonexistent')
    monkeypatch.setattr(reviewed, 'load_reviewed_snapshot', lambda _: (segments + [unselected], rows_valid))
    reader = reviewed.ReviewedNoForceDataset(cfg)
    yield reader, raw_actions
    reader.close()


def test_sampling_is_15hz_and_cannot_bridge_skipped_bad_frames(reviewed_reader):
    reader, _ = reviewed_reader
    assert reader.fps == 30 and reader.sample_fps == 15
    assert len(reader.episodes) == 2
    assert set(reader.sources) == {'A/success', 'B/success'}
    for segment_index, frame in reader.windows:
        segment = reader.segments[segment_index]
        assert frame % 2 == 0
        assert frame - 8 >= segment['start_frame'] and frame + 62 < segment['stop_frame']
        assert not any(frame - 8 < stop and frame + 62 >= start
                       for start, stop in segment['excluded_intervals'])
    # Frame 34 would not explicitly sample odd bad frame 95, but must be rejected.
    assert (0, 34) not in map(tuple, reader.windows)
    for index in [0, len(reader) - 1]:
        value = reader.numeric_sample(index)
        np.testing.assert_array_equal(np.diff(value['history_rows']), 2)
        np.testing.assert_array_equal(np.diff(value['action_rows']), 2)
        np.testing.assert_allclose(np.diff(value['history_timestamps']), 1 / 15)
        np.testing.assert_allclose(np.diff(value['action_timestamps']), 1 / 15)
        assert value['action_timestamps'][-1] - value['action_timestamps'][0] == pytest.approx(31 / 15)


def test_corrected_values_prompts_commands_and_video_routing(reviewed_reader):
    reader, commands = reviewed_reader
    from data_utils.lerobot_vel_no_force import decode_tcp
    for name in reader.config.reviewed_datasets:
        index = next(i for i in range(len(reader)) if reader.numeric_sample(i)['dataset_name'] == name)
        values, sample = reader.numeric_sample(index), reader[index]
        assert set(sample) == set(INPUT_KEYS)
        assert sample['prompt_text'] == ('REVIEWED 0' if name.startswith('A') else 'REVIEWED 1')
        expected = decode_tcp(commands[name][values['action_rows']], reader.config)
        np.testing.assert_allclose(sample['gt_future_ee_states'][..., :16].reshape(32, 2, 4, 4), expected)
        assert sample['history_ee_states'][-1, 0, -1] == (.5 if name.startswith('A') else 1.)
        assert sample['gt_future_ee_states'][0, 0, -1] == (.5 if name.startswith('A') else 1.)
        expected_brightness = 40 / 255 if name.startswith('A') else 190 / 255
        assert sample['obs_rgbs'].mean().item() == pytest.approx(expected_brightness, abs=.03)
        assert values['source_episode_index'] == 0  # Same raw ID in both datasets.


def test_spawn_workers_and_empty_decoder_caches_after_pickle(reviewed_reader):
    reader, _ = reviewed_reader
    reader[0]
    copied = pickle.loads(pickle.dumps(reader))
    assert all(not source._videos and not source._episodes for source in copied.sources.values())
    # Tensor transfer between torch workers requires local socket permissions.
    # Fail early in restricted sandboxes instead of hanging in a queue feeder.
    try:
        with Listener():
            pass
    except PermissionError:
        pytest.skip('Local multiprocessing sockets are forbidden in this environment')
    stream = TrainingStream(copied, collate_lerobot_no_speed, 2, 1, 42)
    try:
        batch = stream.next()
        assert batch['gt_future_ee_states'].shape == (2, 32, 2, 17)
        assert torch.isfinite(batch['current_ee_pose']).all()
    finally:
        stream.close()


def test_manifest_binding_and_frequency_errors(tmp_path):
    args = trainer.parse_args(['--config', str(ROOT / 'configs_lerobot_no_force/reviewed_close_box_15hz.json')])
    cfg = trainer.load_data_config(args)
    with pytest.raises(ValueError, match='target_fps'):
        replace(cfg, frame_stride=1).validate()
    with pytest.raises(ValueError, match='unique dataset'):
        replace(cfg, reviewed_datasets=[]).validate()
    (tmp_path / 'task_manifest.json').write_text('{}')
    with pytest.raises(ValueError, match='manifest changed'):
        reviewed.load_reviewed_snapshot(replace(cfg, root=str(tmp_path)))


@pytest.mark.parametrize('name,count', [('close_box', 1), ('open_box', 1), ('place_phone', 2)])
def test_recipe_defaults_cli_override_and_independent_outputs(name, count):
    path = ROOT / f'configs_lerobot_no_force/reviewed_{name}_15hz.json'
    args = trainer.parse_args(['--config', str(path), '--batch-size', '2'])
    cfg = trainer.load_data_config(args)
    assert args.batch_size == 2 and args.workers == 4
    assert args.pretrained == Path('/home/hq/code/e2vla/checkpoints/e2vla_pretrain_ckpt.pt')
    assert args.output == Path(f'/nas_data_new/hq/91e2vla/{name}_15hz_no_force_no_speed')
    assert cfg.target_fps == 15 and cfg.source_fps == 30 and cfg.frame_stride == 2
    assert cfg.num_future_actions == 32 and cfg.num_history_states == 5
    assert len(cfg.reviewed_datasets) == count
    with pytest.raises(SystemExit):
        trainer.parse_args(['--config', str(path), '--data-config', str(path)])


def test_pretrained_load_is_strict_and_weights_only(tmp_path):
    model = torch.nn.Module()
    model.actor = torch.nn.Linear(3, 2)
    source = {key: torch.full_like(value, .75) for key, value in model.actor.state_dict().items()}
    path = tmp_path / 'pretrain.pt'
    torch.save(dict(weights=source, current_iters=600000, optimizer={'old_state': 1}), path)
    result = trainer.load_pretrained_actor(model, path)
    assert result['pretrained_tensors'] == 2
    for key, value in model.actor.state_dict().items():
        torch.testing.assert_close(value, source[key])
    torch.save(dict(weights={'weight': torch.zeros(5, 3)}), path)
    with pytest.raises(RuntimeError):
        trainer.load_pretrained_actor(model, path)
    torch.save(dict(actor=source), path)
    with pytest.raises(ValueError, match='original E2VLA'):
        trainer.load_pretrained_actor(model, path)

