"""No-speed LeRobot interface, original model behavior and checkpoint isolation."""
from dataclasses import asdict, replace
import inspect
from types import SimpleNamespace

import pytest
import torch

from data_utils.lerobot_no_force import (
    INPUT_KEYS, LeRobotNoForceConfig, LeRobotNoForceDataset, collate_lerobot_no_speed,
)
from models.action_expert import ActionExpert
from models.vla import VLA
import train_lerobot_no_force as trainer
from test_lerobot_vel_no_force import dataset, inputs, small_cpu_pool  # noqa: F401


def config_from(reader):
    return LeRobotNoForceConfig(**{**asdict(reader.config), "history_mode": "observed"})


def test_original_factory_and_no_speed_or_force_parameters(monkeypatch):
    import models.vla as original
    calls = []
    monkeypatch.setattr(original, "vla_base", lambda **kwargs: calls.append(kwargs) or "original")
    assert trainer.build_model(inference_timesteps=3) == "original"
    assert calls == [dict(diffusion_timesteps=100, inference_timesteps=3)]
    assert set(INPUT_KEYS) == set(inspect.signature(VLA.forward).parameters) - {"self", "inference", "fp16"}
    model = ActionExpert(64, 4, 2, 2, diffusion_timesteps=10, inference_timesteps=2)
    assert model.act_dim == 10
    assert not any(any(word in name for word in ("velocity", "force", "contact", "success"))
                   for name, _ in model.named_parameters())


def test_reader_preserves_recorded_actions_and_gripper_without_auxiliary_inputs(dataset):
    reader = LeRobotNoForceDataset(config_from(dataset))
    try:
        assert reader.retime_index is None
        assert len(reader) == len(dataset)
        sample, baseline = reader[0], dataset[0]
        assert set(sample) == set(INPUT_KEYS)
        for key in INPUT_KEYS:
            if torch.is_tensor(sample[key]):
                torch.testing.assert_close(sample[key], baseline[key])
            else:
                assert sample[key] == baseline[key]
        assert sample['history_ee_states'][-1, :, -1].tolist() == [0., 1.]
        batch = collate_lerobot_no_speed([sample, reader[1]])
        assert batch['gt_future_ee_states'].shape == (2, 4, 2, 17)
        with pytest.raises(ValueError, match="input fields"):
            collate_lerobot_no_speed([baseline])
        with pytest.raises(ValueError, match="No-speed"):
            replace(reader.config, speed_factors=[1., 1.5, 2.]).validate()
    finally:
        reader.close()


def test_dual_arm_32_step_update_and_inference_without_future_truth():
    torch.manual_seed(4)
    model = ActionExpert(64, 4, 2, 2, diffusion_timesteps=10, inference_timesteps=2)
    batch = inputs()
    for key in ('success', 'guidance_scale', 'gt_speed_cond'):
        batch.pop(key)
    target = batch['gt_future_ee_states'][:, :1].repeat(1, 32, 1, 1)
    target[:, :, 0, 3] += torch.arange(32) * .001
    target[:, :, 1, 7] += torch.arange(32) * .002
    batch['gt_future_ee_states'] = target
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    before = model.dp_head.act_head[-1].weight.detach().clone()
    loss, metrics = model(**batch)
    assert torch.isfinite(loss)
    loss.backward()
    assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    optimizer.step()
    assert not torch.equal(before, model.dp_head.act_head[-1].weight)
    assert not any('velocity' in k or 'force' in k or 'contact' in k for k in metrics)
    model.eval()
    batch.update(inference=True, gt_future_ee_states=torch.zeros_like(target))
    with torch.no_grad():
        torch.manual_seed(42)
        output = model(**batch)
        batch['gt_future_ee_states'].fill_(float('nan'))
        torch.manual_seed(42)
        without_truth = model(**batch)
    assert output.shape == (2, 32, 2, 17) and torch.isfinite(output).all()
    torch.testing.assert_close(output, without_truth)


def test_checkpoint_roundtrip_and_speed_checkpoint_rejection(tmp_path, dataset):
    config = config_from(dataset)
    model = torch.nn.Module()
    model.actor = torch.nn.Linear(2, 2)
    optimizer = torch.optim.AdamW(model.parameters())
    model.actor(torch.ones(1, 2)).square().mean().backward()
    optimizer.step()
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda _: 1.)
    stream = SimpleNamespace(epoch=1, batch_in_epoch=2)
    model_config = dict(diffusion_timesteps=100, inference_timesteps=20)
    train_config = dict(batch_size=2)
    path = tmp_path / 'step.pt'
    trainer.save_checkpoint(path, model, optimizer, scheduler, 3, stream, config, model_config, train_config)
    saved = torch.load(path, weights_only=False)
    trainer.check_resume(saved, replace(config, root='/new/root'), model_config, train_config)
    restored = torch.nn.Linear(2, 2)
    restored.load_state_dict(saved['actor'], strict=True)
    torch.testing.assert_close(restored.weight, model.actor.weight)
    assert saved['epoch'] == 1 and saved['batch_in_epoch'] == 2
    with pytest.raises(ValueError, match='format'):
        trainer.check_resume({**saved, 'format': 'e2vla_lerobot_vel_no_force_retime32_v2'},
                             config, model_config, train_config)
    with pytest.raises(ValueError, match='conventions'):
        trainer.check_resume(saved, replace(config, gripper_open=[1886, 1886]), model_config, train_config)


def test_check_data_entry_uses_no_speed_reader(dataset, tmp_path, capsys):
    import json
    path = tmp_path / 'data.json'
    path.write_text(json.dumps(asdict(config_from(dataset))))
    trainer.main(['--data-config', str(path), '--check-data', '--threads', '2'])
    result = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert result[-1]['status'] == 'data_ok'
    assert result[-1]['speed_conditioning'] is False
    assert all('gt_speed_cond' not in row.get('shapes', {}) for row in result)
