"""32-step retiming, continuous conditioning and inference contracts."""
import json
from pathlib import Path
from types import SimpleNamespace
import cv2
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch
from scipy.spatial.transform import Rotation
from data_utils.trajectory_retime32 import retime_sample, RetimeIndex, FACTORS
from models.continuous_speed import ContinuousSpeedEmbedding

IS_E2 = (Path(__file__).resolve().parents[1] / "models/action_expert_vel_no_force.py").exists()

@pytest.fixture(autouse=True)
def cpu_threads():
    torch.set_num_threads(2)


def columns(n=130):
    t = np.arange(n, dtype=np.float64) / 30
    pose = np.broadcast_to(np.eye(4), (n, 2, 4, 4)).copy()
    pose[:, 0, 0, 3] = .1 * t
    pose[:, 1, 0, 3] = .05 * t
    pose[:, :, :3, :3] = Rotation.from_euler("z", 170 + 20 * t, degrees=True).as_matrix()[:, None]
    grip = np.zeros((n, 2), dtype=np.float32)
    grip[t >= 1.] = 1
    return dict(timestamp=t, action_pose=pose.astype(np.float32), state_pose=pose.astype(np.float32),
                action_gripper=grip, state_gripper=grip, task_index=np.zeros(n, dtype=int))


def test_all_three_factors_have_distinct_ground_truth_and_physical_labels():
    c = columns()
    values = [retime_sample(c, 10, factor, 5, history_mode="observed") for factor in FACTORS]
    np.testing.assert_allclose([v["speed_mps"] for v in values], [.1, .15, .2], atol=1e-7)
    for factor, value in zip(FACTORS, values):
        assert value["action_pose"].shape == (32, 2, 4, 4)
        assert value["target_times"][-1] == pytest.approx(31 / 30)
        assert value["source_times"][-1] - value["source_times"][0] == pytest.approx(factor * 31 / 30)
        np.testing.assert_allclose(value["action_pose"][:, 0, 0, 3], .1 * value["source_times"], atol=1e-7)
        rotations = value["action_pose"][..., :3, :3]
        np.testing.assert_allclose(np.linalg.det(rotations), 1., atol=1e-6)
        assert set(np.unique(value["action_gripper"])) <= {0., 1.}
        expected = (value["source_times"] >= 1. - 1e-6).astype(float)
        np.testing.assert_array_equal(value["action_gripper"][:, 0], expected)
        np.testing.assert_allclose(value["history_pose"], values[0]["history_pose"])
    np.testing.assert_allclose(values[0]["action_pose"], c["action_pose"][10:42], atol=1e-7)
    assert not np.allclose(values[0]["action_pose"], values[1]["action_pose"])
    assert not np.allclose(values[1]["action_pose"], values[2]["action_pose"])


def test_nonuniform_motion_uses_resampled_targets_not_old_speed_times_factor():
    c = columns()
    c["action_pose"][:, 0, 0, 3] = .1 * c["timestamp"] ** 2
    first = retime_sample(c, 10, 1., 1)
    second = retime_sample(c, 10, 2., 1)
    recomputed = np.linalg.norm(np.diff(second["action_pose"][..., :3, 3], axis=0), axis=-1).sum(0).max() / (31 / 30)
    assert second["speed_mps"] == pytest.approx(recomputed, rel=1e-6)
    assert second["speed_mps"] != pytest.approx(first["speed_mps"] * 2, rel=.01)


def test_history_clock_and_invalid_tail():
    c = columns()
    value = retime_sample(c, 20, 2., 5, history_mode="retimed")
    np.testing.assert_allclose(value["history_pose"], c["state_pose"][[12, 14, 16, 18, 20]], atol=1e-7)
    np.testing.assert_allclose(value["history_pose"][-1], c["state_pose"][20])
    with pytest.raises(ValueError, match="extrapolate"):
        retime_sample(c, 100, 2., 5)


def test_index_skips_invalid_tails_task_boundaries_and_stationary_acceleration():
    c = columns()
    c["task_index"][70:] = 1
    cfg = SimpleNamespace(speed_factors=list(FACTORS), num_future_actions=32,
                          num_history_states=5, frame_stride=1, action_offset=0,
                          target_fps=30., history_mode="mixed")
    source = SimpleNamespace(config=cfg, episodes=[dict(length=130)], _episode=lambda i:c)
    index = RetimeIndex(source)
    for i in range(len(index)):
        _, frame, factor = index.locate(i)
        value = retime_sample(c, frame, factor, 5)
        end = np.searchsorted(c["timestamp"], value["source_times"][-1] - 1e-9)
        assert c["task_index"][frame] == c["task_index"][end]
    c["action_pose"][..., :3, 3] = 0
    static = RetimeIndex(source)
    assert static.counts["1.0"] > 0 and static.counts["1.5"] == static.counts["2.0"] == 0


@pytest.fixture
def retimed_dataset(tmp_path):
    camera = "observation.images.head_image"
    (tmp_path / "meta").mkdir()
    (tmp_path / "data").mkdir()
    (tmp_path / "videos").mkdir()
    n=130
    info=dict(codebase_version="v2.1", fps=30, chunks_size=1000,
              data_path="data/episode_{episode_index:06d}.parquet",
              video_path="videos/{video_key}_{episode_index:06d}.mp4",
              features={camera:dict(dtype="video")})
    (tmp_path / "meta/info.json").write_text(json.dumps(info))
    (tmp_path / "meta/episodes.jsonl").write_text("\n".join(json.dumps(dict(episode_index=i,length=n)) for i in range(2)))
    (tmp_path / "meta/tasks.jsonl").write_text(json.dumps(dict(task_index=0,task="close box")))
    for ep in range(2):
        poses=np.zeros((n,12),dtype=np.float32)
        poses[:,0]=np.arange(n) * (1 if ep==0 else 0)
        poses[:,6]=np.arange(n) * (2 if ep==0 else 0)
        commands=poses.copy(); commands[:,[0,6]] += 10
        grip=np.zeros((n,14)); grip[:,6]=1886
        table=pa.table({"observation.tcp_pose":poses.tolist(),"action.tcp_pose_cmd":commands.tolist(),
            "observation.state":grip.tolist(),"action.joint":grip.tolist(),
            "timestamp":(np.arange(n)/30).astype(np.float32).tolist(),"frame_index":list(range(n)),
            "episode_index":[ep]*n,"task_index":[0]*n})
        pq.write_table(table,tmp_path / f"data/episode_{ep:06d}.parquet")
        writer=cv2.VideoWriter(str(tmp_path / f"videos/{camera}_{ep:06d}.mp4"),cv2.VideoWriter_fourcc(*"mp4v"),30,(64,64))
        assert writer.isOpened()
        for i in range(n): writer.write(np.full((64,64,3),i%255,np.uint8))
        writer.release()
    geometry=dict(cameras={camera:dict(K=[[50,0,31.5],[0,50,31.5],[0,0,1]],image_size=[64,64],
                                       parent="world",pose=np.eye(4).tolist())}, action_reference_cameras=[camera,camera])
    if IS_E2:
        from data_utils.lerobot_vel_no_force import LeRobotVelocityNoForceConfig as Config, LeRobotVelocityNoForceDataset as Dataset
    else:
        from dataset.lerobot_dual_velocity import LeRobotRetimedVelocityConfig as Config, LeRobotRetimedVelocityDataset as Dataset
    cfg=Config(root=str(tmp_path),camera_keys=[camera],image_size=[64,64],geometry=geometry,
               num_history_states=5,num_future_actions=32,speed_factors=list(FACTORS),history_mode="observed")
    reader=Dataset(cfg)
    yield reader
    reader.close()


def test_real_parquet_video_adapter_uses_retimed_actions(retimed_dataset):
    reader=retimed_dataset
    starts=[0]+reader.retime_index.ends[:-1]
    labels=[]
    actions=[]
    for start, (ep,factor,frames) in zip(starts,reader.retime_index.blocks):
        sample=reader[start]
        if IS_E2:
            values=reader.numeric_sample(start)
            action=sample["gt_future_ee_states"]
            assert action.shape == (32,2,17)
            # Commands are deliberately 10 mm ahead of observations.
            assert action[0,0,3]-sample["current_ee_pose"][0,0,3] == pytest.approx(.01, abs=1e-6)
        else:
            values=sample._retime_metadata
            action=sample.action
            assert action.shape == (2,32,73)
            assert sample.action_mask[:,:,:10].all()
            assert action[0,0,0]-sample.state[0,-1,0] == pytest.approx(.01, abs=1e-6)
        if ep==0:
            labels.append(float(values["speed_mps"]))
            actions.append(action)
    np.testing.assert_allclose(labels,[.06,.09,.12],atol=1e-6)
    assert not torch.allclose(actions[0],actions[1])
    assert not torch.allclose(actions[1],actions[2])
    reader[len(reader)-1]  # Last episode has only 1x windows: exercise base index mapping.


def test_continuous_speed_does_not_collapse_old_same_bin_values():
    encoder=ContinuousSpeedEmbedding(32)
    out=encoder(torch.tensor([.06,.09,.12]))
    assert not torch.allclose(out[0],out[1])
    assert not torch.allclose(out[1],out[2])
    out.sum().backward()
    assert encoder.net[0].weight.grad.abs().sum() > 0


def test_32_step_actor_training_and_conditioned_inference():
    torch.manual_seed(42)
    if IS_E2:
        from models.action_expert_vel_no_force import ActionExpertVelocityNoForce
        from test_lerobot_vel_no_force import inputs
        model=ActionExpertVelocityNoForce(64,4,5,2,2,diffusion_timesteps=10,inference_timesteps=2,
                                         continuous_speed=True,action_horizon=32)
        data=inputs()
        data["gt_future_ee_states"]=data["gt_future_ee_states"][:,:1].repeat(1,32,1,1)
        data["gt_future_ee_states"][:,:,0,3] += torch.arange(32) * .003
        data["success"]=None
        data["gt_speed_cond"]=torch.tensor([.06,.09])
        call=lambda: model(**data)
    else:
        from models.m0512_fm.vla_lerobot_dual_velocity import DualVelocityActionExpert
        from test_lerobot_dual import synthetic_batch
        model=DualVelocityActionExpert(32,64,1,2,inference_timesteps=2,action_horizon=32,velocity_dropout=0.)
        data,features=synthetic_batch(horizon=32)
        data._aux_data.update(speed_mps=torch.tensor([.06,.09]))
        call=lambda: model(data,features,inference=False,fp16=False)
    optimizer=torch.optim.AdamW(model.parameters(),lr=.002)
    for _ in range(3):
        optimizer.zero_grad(set_to_none=True)
        loss,metrics=call()
        assert torch.isfinite(loss)
        assert "velocity_loss" not in metrics and "velocity_head_loss" not in metrics
        loss.backward()
        optimizer.step()
    assert model.dp_head.velocity_enc.net[0].weight.grad.abs().sum() > 0
    model.eval()
    with torch.no_grad():
        if IS_E2:
            data.update(inference=True,initial_noise=torch.randn(4,32,10))
            data["gt_speed_cond"]=torch.full((2,),.06)
            slow=model(**data)
            data["gt_speed_cond"]=torch.full((2,),.12)
            fast=model(**data)
            assert slow.shape == (2,32,2,17)
            data["gt_future_ee_states"] = torch.randn_like(data["gt_future_ee_states"])
            torch.testing.assert_close(fast,model(**data))
        else:
            noise=torch.randn(2,2,32,80)
            slow=model(data,features,True,False,speed_mps=.06,initial_noise=noise)
            fast=model(data,features,True,False,speed_mps=.12,initial_noise=noise)
            assert slow.shape == (2,2,32,80)
            data.action=torch.randn_like(data.action)
            torch.testing.assert_close(fast,model(data,features,True,False,speed_mps=.12,initial_noise=noise))
    assert torch.isfinite(fast).all() and not torch.allclose(slow,fast)


def test_corrected_e2_mask():
    if not IS_E2:
        return
    from models.qformer_velocity_corrected import allowed_velocity_mask
    from models.layers.mha import MySimpleMHA
    mask=allowed_velocity_mask(2,1,1,None,1,"cpu")
    assert mask[0,0].tolist()==[True,True,False,True]
    assert mask[0,2].all()
    q=k=torch.ones(1,1,4,2)
    v=torch.tensor([1.,2.,4.,8.]).reshape(1,1,4,1).repeat(1,1,1,2)
    for method in (MySimpleMHA._attn_impl_eager,MySimpleMHA._attn_impl_sdpa):
        out,_=method(q,k,v,training=False,attn_mask=mask)
        torch.testing.assert_close(out[0,0,:,0],torch.tensor([11/3,11/3,15/4,11/3]))
