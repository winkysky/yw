from dataclasses import asdict
import pickle
from pathlib import Path

import numpy as np
import pytest
import torch

import data_utils.lerobot_reviewed_velocity as speed_data
from models.action_expert import ActionExpert
from models.action_expert_vel_no_force import ActionExpertVelocityNoForce
import train_lerobot_vel_no_force as trainer
from test_reviewed_no_speed import reviewed_reader, rows_valid  # noqa: F401

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def speed_reader(reviewed_reader, monkeypatch):
    observed, commands = reviewed_reader
    values = asdict(observed.config)
    values.update(frame_stride=1, target_fps=30., speed_factors=[1., 1.5, 2.], history_mode='observed')
    config = speed_data.ReviewedVelocityNoForceConfig(**values)
    monkeypatch.setattr(speed_data, 'load_reviewed_snapshot', lambda _: (observed.segments, rows_valid))
    reader = speed_data.ReviewedVelocityNoForceDataset(config)
    yield reader, commands
    reader.close()


def test_every_factor_respects_review_and_fractional_interpolation_support(speed_reader):
    reader, _ = speed_reader
    assert all(count > 0 for count in reader.retime_index.counts.values())
    for segment_index, factor, frames in reader.retime_index.blocks:
        segment = reader.segments[segment_index]
        for frame in frames:
            start, stop = frame-4, frame+int(np.ceil(factor*31))
            assert rows_valid(segment, range(start, frame+1), range(frame, stop+1))
        if segment_index == 0 and factor == 1.5:
            # t=49 ends at source row 95.5, so bad row 95 is interpolation
            # support and must be excluded, even though no query hits it exactly.
            assert 49 not in frames
    assert len(reader.episodes) == 2 and len(reader.sources) == 2


def test_one_x_is_exact_30hz_commands_and_all_factors_keep_observed_history(speed_reader):
    reader, _ = speed_reader
    starts = [0] + reader.retime_index.ends[:-1]
    for start, (segment_index, factor, frames) in zip(starts, reader.retime_index.blocks):
        value = reader.numeric_sample(start)
        frame = value['frame']
        original = reader.segment_columns(segment_index)
        np.testing.assert_array_equal(value['history_pose'], original['state_pose'][frame-4:frame+1])
        if factor == 1.:
            np.testing.assert_array_equal(value['action_pose'], original['action_pose'][frame:frame+32])
            np.testing.assert_array_equal(value['action_gripper'], original['action_gripper'][frame:frame+32])
        np.testing.assert_allclose(np.diff(value['source_times']), factor/30)
        np.testing.assert_allclose(value['target_times'], np.arange(32)/30)
        expected_speed = np.linalg.norm(np.diff(value['action_pose'][..., :3, 3].astype(float), axis=0), axis=-1).sum(0).max() / (31/30)
        assert float(value['gt_speed_cond']) == pytest.approx(expected_speed, rel=1e-6)
        # Reader must route corrected numeric columns and reviewed instructions.
        sample = reader[start]
        assert sample['prompt_text'] == f'REVIEWED {segment_index}'
        assert sample['success'] is None and 'gt_speed_cond' in sample
        assert sample['history_ee_states'][-1, 0, -1].item() == (.5 if segment_index == 0 else 1.)
        assert sample['gt_future_ee_states'].shape == (32, 2, 17)
    copied = pickle.loads(pickle.dumps(reader))
    assert all(not source._episodes and not source._videos for source in copied.sources.values())
    copied.close()


def test_pretraining_transfers_every_source_weight_and_only_expands_known_inputs():
    torch.set_num_threads(2)
    original = ActionExpert(64, 4, 2, 2)
    actor = ActionExpertVelocityNoForce(64, 4, 5, 2, 2, continuous_speed=True, action_horizon=32)
    saved = original.state_dict()
    report = trainer.adapt_pretrained_actor(actor, saved)
    actual = actor.state_dict()
    for key, value in saved.items():
        if key == 'context_encoder.qformer.queries':
            torch.testing.assert_close(actual[key][:, :64], value, rtol=0, atol=0)
        elif key == 'dp_head.hist_enc.0.weight':
            torch.testing.assert_close(actual[key][:, :9], value, rtol=0, atol=0)
            assert torch.count_nonzero(actual[key][:, 9]) == 0
        else:
            torch.testing.assert_close(actual[key], value, rtol=0, atol=0)
    assert report['pretrained_tensors'] == len(saved)
    assert torch.count_nonzero(actor.dp_head.velocity_enc.net[2].weight) == 0
    bad = dict(saved)
    bad.pop('dp_head.act_head.0.weight')
    with pytest.raises(ValueError, match='architecture'):
        trainer.adapt_pretrained_actor(actor, bad)
    bad = dict(saved)
    bad['dp_head.traj_enc.0.weight'] = bad['dp_head.traj_enc.0.weight'][:, :8]
    with pytest.raises(ValueError, match='Unsupported'):
        trainer.adapt_pretrained_actor(actor, bad)


@pytest.mark.parametrize('task', ['close_box', 'open_box', 'place_phone'])
def test_recipe_and_inference_read_checkpoint_geometry(task):
    import json
    from lerobot_inference import make_data_config
    old = json.loads((ROOT/f'configs_lerobot_no_force/reviewed_{task}_15hz.json').read_text())
    args = trainer.parse_args(['--config', str(ROOT/f'configs_lerobot_vel_no_force/reviewed_{task}_30hz_speed.json')])
    config = trainer.load_data_config(args)
    assert (args.max_steps, args.save_every, args.batch_size) == (50000, 10000, 32)
    assert str(args.pretrained) == old['training']['pretrained']
    for key in ['lr', 'weight_decay', 'warmup_steps', 'grad_clip', 'seed', 'workers', 'threads']:
        assert getattr(args, key) == old['training'][key]
    assert config.reviewed_datasets == old['data']['reviewed_datasets']
    assert config.base_to_world == old['data']['base_to_world']
    loaded = make_data_config(asdict(config))
    assert loaded.target_fps == 30
    assert loaded.review_manifest_sha256 == old['data']['review_manifest_sha256']

