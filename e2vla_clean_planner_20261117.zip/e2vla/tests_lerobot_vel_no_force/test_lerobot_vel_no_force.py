"""Check the architecture delta and LeRobot contract outside the ignored tests/ directory."""
from dataclasses import replace
import json

import cv2
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch

from data_utils.lerobot_vel_no_force import (
    LeRobotVelocityNoForceConfig, LeRobotVelocityNoForceDataset, collate_lerobot_no_force, decode_gripper,
)
from models.action_expert_vel_no_force import ActionExpertVelocityNoForce, DiffusionHeadVelocityNoForce


@pytest.fixture(autouse=True)
def small_cpu_pool():
    previous = torch.get_num_threads()
    torch.set_num_threads(2)
    yield
    torch.set_num_threads(previous)


def actor(cls):
    return cls(hdim=64, num_heads=4, nhist=5, num_context_layers=2,
               num_diffusion_layers=2, diffusion_timesteps=10, inference_timesteps=2)




def inputs():
    b, cams, ta = 2, 3, 4
    current = torch.eye(4).repeat(b, 2, 1, 1)
    current[:, 1, 0, 3] = .4
    states = torch.cat([current.reshape(b, 1, 2, 16).repeat(1, 5, 1, 1),
                        torch.ones(b, 5, 2, 1) * .6], dim=-1)
    future = states[:, :ta].clone()
    future[:, :, 0, 3] += torch.arange(ta) * .01
    future[:, :, 1, 7] += torch.arange(ta) * .02
    return dict(
        vl_obs=dict(rgb=torch.zeros(b, 1, cams, 3, 4, 4),
                    extrinsics=torch.eye(4).repeat(b, 1, cams, 1, 1)),
        vl_feature=dict(vision_embeds=[torch.randn(b, cams, 4, 768) for _ in range(2)],
                        lang_embeds=[torch.randn(b, 3, 768)], norm_xy_ds=torch.zeros(b, cams, 4, 2),
                        vision_mask=None, lang_mask=None),
        current_ee_pose=current, history_ee_states=states, gt_future_ee_states=future,
        valid_ee_mask=torch.ones(b, 2, dtype=torch.bool), inference=False, fp16=False,
        success=torch.tensor([0, 1]), guidance_scale=1., gt_speed_cond=torch.tensor([.1, .8]))








def test_dual_arm_training_without_success_and_inference():
    model, data = actor(ActionExpertVelocityNoForce), inputs()
    data["success"] = None
    loss, metrics = model(**data)
    assert torch.isfinite(loss)
    loss.backward()
    assert model.velocity_head.head[-1].weight.grad.abs().sum() > 0
    assert model.dp_head.act_head[-1].weight.grad.abs().sum() > 0
    assert metrics["total_loss"] == pytest.approx(
        30 * metrics["pos_loss"] + 10 * metrics["rot_loss"] + 10 * metrics["openness_loss"]
        + 5 * metrics["velocity_head_loss"], rel=1e-6)
    model.eval()
    data["inference"] = True
    # Exercise source CFG behavior and the automatic speed classifier.
    for speed, scale in ((data["gt_speed_cond"], 1.), (None, 1.5)):
        data["gt_speed_cond"], data["guidance_scale"] = speed, scale
        with torch.no_grad():
            output = model(**data)
        assert output.shape == (2, 4, 2, 17)
        assert torch.isfinite(output).all()
        torch.testing.assert_close(output[..., :16].reshape(2, 4, 2, 4, 4)[..., 3, :],
                                   torch.tensor([0., 0., 0., 1.]).expand(2, 4, 2, 4))


def test_base_factory_keeps_source_hyperparameters(monkeypatch):
    from models import vla_vel_no_force
    monkeypatch.setattr(vla_vel_no_force, "VLAVelocityNoForce", lambda **kwargs: kwargs)
    assert vla_vel_no_force.vla_velocity_no_force_base() == dict(
        hdim=768, num_heads=12, nhist=5, num_actor_context_layers=8,
        num_actor_diffusion_layers=4, diffusion_timesteps=100, inference_timesteps=20,
        continuous_speed=True, action_horizon=32)


@pytest.fixture
def dataset(tmp_path):
    (tmp_path / "meta").mkdir()
    (tmp_path / "data").mkdir()
    (tmp_path / "videos").mkdir()
    camera = "observation.images.head_image"
    n, fps = 12, 30
    info = dict(codebase_version="v2.1", fps=fps, chunks_size=1000,
                data_path="data/episode_{episode_index:06d}.parquet",
                video_path="videos/{video_key}_{episode_index:06d}.mp4",
                features={camera: dict(dtype="video")})
    (tmp_path / "meta/info.json").write_text(json.dumps(info))
    (tmp_path / "meta/episodes.jsonl").write_text(json.dumps(dict(episode_index=0, length=n)) + "\n")
    (tmp_path / "meta/tasks.jsonl").write_text(json.dumps(dict(task_index=0, task="close box")) + "\n")
    pose = np.zeros((n, 12), dtype=np.float32)
    pose[:, 0], pose[:, 6] = np.arange(n) * 1., np.arange(n) * 2.
    joints = np.zeros((n, 14), dtype=np.float32)
    joints[:, 6], joints[:, 13] = 1886, 0
    # Deliberately omit every force/contact field: neither loader nor model needs it.
    pq.write_table(pa.table({"observation.tcp_pose": pose.tolist(), "action.tcp_pose_cmd": pose.tolist(),
        "observation.state": joints.tolist(), "action.joint": joints.tolist(),
        "timestamp": (np.arange(n) / fps).tolist(), "frame_index": list(range(n)),
        "episode_index": [0] * n, "task_index": [0] * n}), tmp_path / "data/episode_000000.parquet")
    writer = cv2.VideoWriter(str(tmp_path / f"videos/{camera}_000000.mp4"),
                            cv2.VideoWriter_fourcc(*"mp4v"), fps, (64, 64))
    assert writer.isOpened()
    for i in range(n):
        writer.write(np.full((64, 64, 3), i * 10, np.uint8))
    writer.release()
    geometry = dict(cameras={camera: dict(K=[[50, 0, 31.5], [0, 50, 31.5], [0, 0, 1]],
                                           image_size=[64, 64], parent="world", pose=np.eye(4).tolist())})
    cfg = LeRobotVelocityNoForceConfig(root=str(tmp_path), camera_keys=[camera], image_size=[64, 64],
                                      num_future_actions=4, geometry=geometry)
    reader = LeRobotVelocityNoForceDataset(cfg)
    yield reader
    reader.close()


def test_reader_action_shapes_units_calibration_speed_and_boundaries(dataset):
    assert len(dataset) == 5  # 12 - (5 - 1) - (4 - 1)
    numeric = dataset.numeric_sample(0)
    assert numeric["frame"] == 4
    np.testing.assert_allclose(numeric["speed_per_arm"], [.03, .06], atol=1e-6)
    assert float(numeric["gt_speed_cond"]) == pytest.approx(.06)
    assert dataset.numeric_sample(len(dataset) - 1)["frame"] == 8
    sample = dataset[0]
    assert sample["history_ee_states"].shape == (5, 2, 17)
    assert sample["gt_future_ee_states"].shape == (4, 2, 17)
    assert sample["history_ee_states"][-1, :, -1].tolist() == [0., 1.]
    np.testing.assert_array_equal(sample["gt_future_ee_states"][..., -1], [[0., 1.]] * 4)
    raw = np.zeros((3, 14))
    raw[:, [6, 13]] = [[0, 1886], [943, 943], [1886, 0]]
    np.testing.assert_array_equal(decode_gripper(raw, dataset.config), [[1, 0], [.5, .5], [0, 1]])
    assert sample["current_ee_pose"][:, 0, 3].tolist() == pytest.approx([.004, .008])
    assert sample["obs_rgbs"].min() >= 0 and sample["obs_rgbs"].max() <= 1
    torch.testing.assert_close(sample["obs_norm_xys"][0, 0, :, 0, 0], torch.tensor([-.63, -.63]))
    assert not any("force" in key or "contact" in key for key in sample)
    batch = collate_lerobot_no_force([sample, dataset[-1 + len(dataset)]])
    assert batch["success"] is None
    assert batch["gt_future_ee_states"].shape == (2, 4, 2, 17)


def test_stride_and_no_padding(dataset):
    cfg = replace(dataset.config, frame_stride=2, num_history_states=3, num_future_actions=3)
    reader = LeRobotVelocityNoForceDataset(cfg)
    try:
        assert len(reader) == 4
        assert reader.numeric_sample(0)["gt_speed_cond"] == pytest.approx(.06)
        with pytest.raises(IndexError):
            reader[len(reader)]
    finally:
        reader.close()


def test_missing_calibration_is_rejected(dataset):
    with pytest.raises(ValueError, match="calibrated"):
        replace(dataset.config, geometry=None).validate()
