"""Regression tests for HW arm-local poses and all three camera frames."""
from dataclasses import replace
import json
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch
from scipy.spatial.transform import Rotation

from data_utils.lerobot_no_force import LeRobotNoForceConfig, LeRobotNoForceDataset
from data_utils.lerobot_vel_no_force import (
    LeRobotVelocityNoForceConfig, LeRobotVelocityNoForceDataset,
    camera_pose_in_world, decode_tcp,
)

ROOT = Path(__file__).resolve().parents[1]
# yw aa219ea: left recorded base <- right recorded base, translation in metres.
LEFT_T_RIGHT = np.array([
    [0.9999999754373268, -0.00019314102178815806, 0.00010872852182784586, 0.00022182998833978316],
    [-0.0001931473690101225, -0.9999999796435581, 0.00005836931566893233, -0.00003012134673285871],
    [0.00010871724610525069, -0.000058390314863006505, -0.9999999923855655, -0.23003485082559016],
    [0., 0., 0., 1.],
])


def config(speed):
    cls = LeRobotVelocityNoForceConfig if speed else LeRobotNoForceConfig
    folder = 'configs_lerobot_vel_no_force' if speed else 'configs_lerobot_no_force'
    return cls.load(ROOT / folder / 'huawei_close_box.json')


@pytest.mark.parametrize('speed', [False, True])
def test_shipped_configs_transform_full_pose_into_left_base(speed):
    cfg = config(speed)
    np.testing.assert_array_equal(cfg.base_to_world[0], np.eye(4))
    np.testing.assert_array_equal(cfg.base_to_world[1], LEFT_T_RIGHT)
    assert cfg.geometry['world_frame'] == 'left_recorded_arm_base'
    assert cfg.geometry['cameras'][cfg.camera_keys[0]]['parent'] == 'left_base'
    raw = np.array([[[110, 220, 330, 20, -35, 70], [430, 250, -120, -30, 45, 80]]], float)
    local_cfg = replace(cfg, base_to_world=[np.eye(4).tolist()] * 2)
    local = decode_tcp(raw, local_cfg)
    aligned = decode_tcp(raw, cfg)
    np.testing.assert_array_equal(aligned[:, 0], local[:, 0])
    np.testing.assert_allclose(aligned[:, 1], LEFT_T_RIGHT @ local[:, 1], atol=1e-7)
    np.testing.assert_allclose(np.linalg.inv(LEFT_T_RIGHT) @ aligned[:, 1], local[:, 1], atol=1e-7)
    assert not np.allclose(aligned[:, 1, :3, :3], local[:, 1, :3, :3])


@pytest.fixture(params=[False, True], ids=['no_speed', 'retimed_speed'])
def readers(tmp_path, request):
    """Real Parquet with distinct states/commands; images are irrelevant here."""
    speed = request.param
    cfg = replace(config(speed), root=str(tmp_path), image_size=[32, 32])
    n = 100
    raw = np.zeros((n, 2, 6), dtype=np.float64)
    raw[..., :3] = [[100., 200., 300.], [400., -250., -120.]]
    raw[:, 0, 0] += np.arange(n) * 2
    raw[:, 1, 1] += np.arange(n) * 3
    raw[..., 3:] = [[10., 20., 30.], [-40., 15., 60.]]
    raw[:, 1, 5] += np.arange(n) * .2
    commands = raw.copy()
    commands[..., :3] += [15., -25., 35.]
    commands[..., 3:] += [2., -3., 4.]
    joints = np.zeros((n, 14))
    joints[:, 6], joints[:, 13] = 1886, 943
    (tmp_path / 'meta').mkdir()
    info = dict(codebase_version='v2.1', fps=30, chunks_size=1000,
                data_path='episode_{episode_index:06d}.parquet',
                video_path='{video_key}_{episode_index:06d}.mp4',
                features={key: dict(dtype='video') for key in cfg.camera_keys})
    (tmp_path / 'meta/info.json').write_text(json.dumps(info))
    (tmp_path / 'meta/episodes.jsonl').write_text(json.dumps(dict(episode_index=0, length=n)) + '\n')
    (tmp_path / 'meta/tasks.jsonl').write_text(json.dumps(dict(task_index=0, task='close box')) + '\n')
    pq.write_table(pa.table({
        cfg.state_pose_key: raw.reshape(n, 12).tolist(),
        cfg.action_pose_key: commands.reshape(n, 12).tolist(),
        cfg.state_gripper_key: joints.tolist(), cfg.action_gripper_key: joints.tolist(),
        'timestamp': (np.arange(n) / 30).tolist(), 'frame_index': list(range(n)),
        'episode_index': [0] * n, 'task_index': [0] * n,
    }), tmp_path / 'episode_000000.parquet')
    for key in cfg.camera_keys:
        (tmp_path / f'{key}_000000.mp4').touch()
    cls = LeRobotVelocityNoForceDataset if speed else LeRobotNoForceDataset
    aligned = cls(cfg)
    local = cls(replace(cfg, base_to_world=[np.eye(4).tolist()] * 2))
    aligned._image = lambda *args: torch.zeros(1, 3, 32, 32, dtype=torch.uint8)
    try:
        yield aligned, local, raw, commands
    finally:
        aligned.close()
        local.close()


def test_current_history_commands_and_retiming_share_one_frame(readers):
    aligned, local, raw, commands = readers
    assert len(aligned) == len(local)
    if aligned.retime_index is None:
        indices = [0, len(aligned) - 1]
    else:
        indices = [0] + aligned.retime_index.ends[:-1] + [len(aligned) - 1]
        assert {float(aligned.numeric_sample(i)['speed_factor']) for i in indices} == {1., 1.5, 2.}
    for index in indices:
        a, b = aligned.numeric_sample(index), local.numeric_sample(index)
        assert a['frame'] == b['frame']
        np.testing.assert_allclose(a['current_ee_pose'][1], LEFT_T_RIGHT @ b['current_ee_pose'][1], atol=2e-7)
        for key in ['history_ee_states', 'gt_future_ee_states']:
            ap, bp = a[key][..., :16].reshape(-1, 2, 4, 4), b[key][..., :16].reshape(-1, 2, 4, 4)
            np.testing.assert_array_equal(ap[:, 0], bp[:, 0])
            np.testing.assert_allclose(ap[:, 1], LEFT_T_RIGHT @ bp[:, 1], atol=2e-6)
            np.testing.assert_array_equal(a[key][..., -1], b[key][..., -1])
        np.testing.assert_allclose(a['speed_per_arm'], b['speed_per_arm'], atol=2e-6)
        # Target zero is the command at t, not the observed pose at t.
        expected = decode_tcp(commands[a['frame']:a['frame'] + 1], aligned.config)[0]
        np.testing.assert_allclose(a['gt_future_ee_states'][0, :, :16].reshape(2, 4, 4), expected, atol=1e-6)


def test_three_camera_extrinsics_and_resized_projection(readers):
    reader, _, raw, _ = readers
    cfg = reader.config
    sample = reader[0]
    frame = reader.numeric_sample(0)['frame']
    flange = np.repeat(np.eye(4)[None], 2, axis=0)
    flange[:, :3, :3] = Rotation.from_euler('xyz', raw[frame, :, 3:], degrees=True).as_matrix()
    flange[:, :3, 3] = raw[frame, :, :3] / 1000
    world_flange = np.asarray(cfg.base_to_world) @ flange
    expected_cameras = []
    for i, key in enumerate(cfg.camera_keys):
        camera = cfg.geometry['cameras'][key]
        expected = np.asarray(camera['pose']) if i == 0 else world_flange[i - 1] @ camera['pose']
        expected_cameras.append(expected)
    np.testing.assert_allclose(sample['obs_extrinsics'][0], expected_cameras, atol=2e-7)
    h, w = cfg.image_size
    # Points on known positive-depth camera rays must project to the same
    # resized pixel using E2VLA's inverse(world_T_camera) convention.
    uv = np.array([[7., 9.], [15., 21.]])
    pixels = np.column_stack([uv, np.ones(2)])
    for i, key in enumerate(cfg.camera_keys):
        camera = cfg.geometry['cameras'][key]
        h0, w0 = camera['image_size']
        resize = np.array([[w/w0, 0, .5*w/w0-.5], [0, h/h0, .5*h/h0-.5], [0, 0, 1.]])
        k = resize @ camera['K']
        rays = np.linalg.solve(k, pixels.T).T
        world_points = expected_cameras[i] @ np.column_stack([rays * .5, np.ones(2)]).T
        actual_cam = np.linalg.inv(sample['obs_extrinsics'][0, i].numpy()) @ world_points
        projected = (k @ actual_cam[:3]).T
        np.testing.assert_allclose(projected[:, :2] / projected[:, 2:], uv, atol=1e-4)
        for j, (u, v) in enumerate(uv.astype(int)):
            np.testing.assert_allclose(sample['obs_norm_xys'][0, i, :, v, u], rays[j, :2], atol=1e-6)
    # The right wrist must receive the base transform exactly once.
    old_right_cam = flange[1] @ cfg.geometry['cameras'][cfg.camera_keys[2]]['pose']
    right_tcp_local = flange[1] @ cfg.pose_to_tcp[1]
    actual_relative = torch.linalg.inv(sample['obs_extrinsics'][0, 2]) @ sample['current_ee_pose'][1]
    np.testing.assert_allclose(actual_relative, np.linalg.inv(old_right_cam) @ right_tcp_local, atol=3e-7)


@pytest.mark.parametrize('parent', ['world', 'left_base', 'right_base', 'left_tcp', 'right_tcp', 'left_flange', 'right_flange'])
def test_camera_parent_frames_under_nonidentity_world(parent):
    cfg = config(False)
    world_T_left = np.eye(4)
    world_T_left[:3, :3] = Rotation.from_euler('z', 37, degrees=True).as_matrix()
    world_T_left[:3, 3] = [.2, -.3, .4]
    cfg = replace(cfg, base_to_world=[world_T_left.tolist(), (world_T_left @ LEFT_T_RIGHT).tolist()])
    tcp = torch.from_numpy(decode_tcp(np.zeros((1, 12)), cfg)[0])
    camera = dict(parent=parent, pose=np.eye(4).tolist())
    expected = np.eye(4)
    if parent != 'world':
        arm = 0 if parent.startswith('left_') else 1
        expected = np.asarray(cfg.base_to_world[arm])
        if parent.endswith('_tcp'):
            expected = expected @ cfg.pose_to_tcp[arm]
    np.testing.assert_allclose(camera_pose_in_world(tcp, cfg, camera), expected, atol=1e-7)
