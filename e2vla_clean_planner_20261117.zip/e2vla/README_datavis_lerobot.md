# LeRobot 双臂数据与推理可视化

`datavis.py` 使用对应 checkpoint 的无速度或连续速度训练读取器。
支持清洗后的 reviewed 数据与普通 LeRobot 数据，直接加载本地训练检查点。
可选 `--lerobot` 仅保留旧命令兼容；HDF5 入口已移除。连续速度版需增加 `--speed-mps 0.05`。

当前也支持 `python datavis.py --lerobot --uri e2vla --gui` 连接专用 Pyro4 服务。
统一模型服务的启动、跨机器调用和 Python API 见 `README_lerobot_pyro.md`。

## 桌面逐帧浏览

在 e2vla 项目目录和 e2vla conda 环境执行：

```bash
python datavis.py --lerobot \
  --config configs_lerobot_no_force/reviewed_close_box_15hz.json \
  --device cuda:0 --gui
```

配置会自动选择其训练输出目录中步数最大的 `step_*.pt`。
开盒、放手机分别换成 `reviewed_open_box_15hz.json`、`reviewed_place_phone_15hz.json`。
也可只指定 `--checkpoint /绝对路径/step_0050000.pt`，数据、标定及推理步数直接从检查点读取。
同时指定配置与检查点时，校验数据与标定完全一致，避免误配任务。

按键：

- `n` / `p`：下一个 / 上一个有效分组；速度数据按重采样窗口块分组。
- 右箭头或 `d` / 左箭头或 `h`：下一个 / 上一个有效样本。
- `a`：切换一次移动 1 或 10 个样本。
- `i`：开关模型预测叠加。
- `s`：保存当前 PNG、NPZ、JSON；`--output` 指定目录。
- `q` / Esc：退出。

浏览器只遍历训练读取器允许的完整窗口，不跨越过滤区间。`--indices 3607`
可从指定数据集样本开始；它不是原始视频帧号。界面同时显示原始 episode 和 frame。

## 无窗口导出

```bash
python datavis.py --lerobot \
  --checkpoint /nas_data_new/hq/91e2vla/close_box_15hz_no_force_no_speed/step_0050000.pt \
  --device cuda:0 --output visualizations/close_box_50k
```

默认导出第一个、中间、最后一个有效样本，生成可在浏览器直接打开的 `index.html`。
用 `--indices 0 3607 7214` 指定样本；`--device cpu --threads 4` 可在没有 GPU 的环境运行。
`--device auto` 默认优先 GPU，否则使用 CPU。默认 FP32；CUDA 可选 `--bf16`。
仅看数据使用 `--config ... --data-only`。推理默认使用检查点的 20 次 DDIM 去噪步数，
`--inference-timesteps` 可覆盖；不要与 32 个预测动作步混淆。

每个样本输出：

- PNG：三个相机上的轨迹投影、左右臂 3D 轨迹、夹爪开度。
- NPZ：`prediction` / `target` 均为 `(32, 2, 17)`，左右臂顺序固定；
  前 16 维为左臂 base 下的 4×4 TCP 位姿，最后一维为夹爪开度。
  同时包含当前/历史位姿、相机外参和与显示图像匹配的内参。
- JSON：样本来源、原始帧号、checkpoint、种子、推理配置以及逐臂误差。
- `manifest.json`、`data_config.json`：整次导出的样本清单及实际数据配置。

## 如何读图

实线是数据中的未来目标 TCP **指令**，虚线是模型预测，星号是当前观测 TCP。
左臂目标/预测分别为青色/橙色，右臂为绿色/粉色。所有位姿已统一在左臂 base，
可视化不再次应用右臂 base 变换。

相机画面使用模型实际读取的 256×256 图像，内参按同样的 OpenCV 半像素规则缩放。
三个相机画面和外参均固定在当前观测帧，因此腕部视角展示的是从当前相机看未来轨迹，
不是对未来移动相机画面的模拟。位于相机后方的轨迹点不会画到图像上。

模型预测 32 步，动作点时间依据 checkpoint 的训练取样间隔；这不规定推理调用频率。预测时真实未来动作被替换为
零占位张量，仅供模型取得输出形状；真实动作只用于画图和计算误差。
输出没有额外平滑、夹爪裁剪或坐标补偿。

误差中的位置是 32 步欧氏距离的平均值（mm），姿态是旋转测地角的平均值（度），
夹爪是开度绝对误差。小幅标定矩阵舍入通过测量角度时的旋转正交化处理，不更改预测。
这些样本来自训练数据，结果是离线指令预测比较，不是独立测试集成绩或真机闭环成功率。

默认随机种子为 `42 + 数据集样本索引`，同一设备和软件环境下便于复现。
GUI 需要桌面 DISPLAY；无桌面环境请使用 HTML / PNG 导出。
