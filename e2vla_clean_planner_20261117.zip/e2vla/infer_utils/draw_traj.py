"""Overlay the two predicted TCP paths on the current three RGB observations."""
import cv2
import numpy as np


def draw_prediction(batch, poses, compress=False):
    rgb = batch["obs_rgbs"][0, 0].detach().cpu().numpy()
    extrinsics = batch["obs_extrinsics"][0, 0].detach().cpu().numpy()
    rays = batch["obs_norm_xys"][0, 0].detach().cpu().numpy()
    panels = []
    for pixels, world_T_camera, ray in zip(rgb, extrinsics, rays):
        panel = (pixels.transpose(1, 2, 0)*255).clip(0, 255).astype(np.uint8)
        panel = cv2.cvtColor(panel, cv2.COLOR_RGB2BGR)
        fx, fy = 1/(ray[0, 0, 1]-ray[0, 0, 0]), 1/(ray[1, 1, 0]-ray[1, 0, 0])
        cx, cy = -ray[0, 0, 0]*fx, -ray[1, 0, 0]*fy
        camera_T_world = np.linalg.inv(world_T_camera)
        for arm, color in enumerate(((255, 220, 0), (0, 150, 255))):
            xyz = poses[:, arm, :3, 3] @ camera_T_world[:3, :3].T + camera_T_world[:3, 3]
            visible = xyz[:, 2] > 1e-5
            uv = xyz[:, :2]/np.maximum(xyz[:, 2:], 1e-5)
            uv = uv*np.array([fx, fy]) + [cx, cy]
            for i in range(1, len(uv)):
                if visible[i-1:i+1].all() and np.max(np.abs(uv[i-1:i+1])) < 1e6:
                    cv2.line(panel, tuple(np.rint(uv[i-1]).astype(int)), tuple(np.rint(uv[i]).astype(int)), color, 2)
        panels.append(panel)
    result = np.concatenate(panels, axis=1)
    return cv2.imencode(".jpg", result)[1] if compress else result
