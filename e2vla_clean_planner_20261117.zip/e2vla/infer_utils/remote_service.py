"""One Pyro4 Planner for no-speed and continuous-speed checkpoints."""
import argparse
from dataclasses import replace
import json
from pathlib import Path

import cv2
import torch

from shm_transport import expose, run_simple_server
from .planner import LeRobotTrajPlanner
from .planner_config import PlannerConfig


class Service(LeRobotTrajPlanner):
    def __init__(self, policy=None, config=None):
        super().__init__(config, policy=policy)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_info(self):
        return super().get_info()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_config(self):
        return super().get_config()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_planner_config(self):
        return super().get_planner_config()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_status(self):
        return super().get_status()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def set_config(self, config):
        return super().set_config(config)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def reset(self):
        return super().reset()

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def set_prompt(self, prompt_text):
        return super().set_prompt(prompt_text)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def set_speed(self, speed_mps, guidance_scale=1.):
        return super().set_speed(speed_mps, guidance_scale)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def add_obs_frame(self, obs_frame):
        return super().add_obs_frame(obs_frame)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def add_obs_frames(self, obs_frames):
        return super().add_obs_frames(obs_frames)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def get_action(self, draw_traj=False, compress_traj_img=False, seed=None, speed_mps=None):
        return super().get_action(draw_traj, compress_traj_img, seed, speed_mps)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def set_ensemble_nums(self, n):
        return super().set_ensemble_nums(n)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def ensemble_traj(self, future_ee_poses, future_grippers, future_time):
        return super().ensemble_traj(future_ee_poses, future_grippers, future_time)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        return super().run_inference(obs_data, seed, contract_sha256, speed_mps, guidance_scale)

    @expose(en_ret_shm=False, en_ret_sh_cuda=False)
    def run_inference_numpy(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        return super().run_inference_numpy(obs_data, seed, contract_sha256, speed_mps, guidance_scale)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--task", choices=("close_box", "open_box", "place_phone"))
    parser.add_argument("--variant", choices=("no_speed", "speed"))
    parser.add_argument("--checkpoint", "--ckpt", type=str)
    parser.add_argument("--device")
    parser.add_argument("--bf16", action="store_true", default=None)
    parser.add_argument("--inference-timesteps", type=int)
    parser.add_argument("--threads", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--speed-mps", type=float)
    parser.add_argument("--guidance-scale", type=float)
    parser.add_argument("--prompt")
    parser.add_argument("--uri")
    parser.add_argument("--host")
    parser.add_argument("--port", type=int)
    parser.add_argument("--ns-host", "--ns_host", dest="ns_host")
    parser.add_argument("--ns-port", "--ns_port", dest="ns_port", type=int)
    parser.add_argument("--check-config", action="store_true", help="Validate config/checkpoint path without loading weights")
    args = parser.parse_args(argv)
    path = args.config or Path(__file__).resolve().parents[1]/"configs_inference"/"planner.json"
    config = PlannerConfig.load(path)
    overrides = {key: value for key, value in vars(args).items() if key not in ("config", "check_config") and value is not None}
    config = replace(config, **overrides).validate()
    if config.checkpoint is None:
        if config.task is None:
            parser.error("Specify --checkpoint (or set checkpoint in planner.json)")
        suffix = '30hz_no_force_speed' if config.variant == 'speed' else '15hz_no_force_no_speed'
        config = replace(config, checkpoint=f'/nas_data_new/hq/91e2vla/{config.task}_{suffix}')
    if args.task is not None and args.uri is None:
        config = replace(config, uri=f'e2vla_{args.task}'+('_speed' if args.variant == 'speed' else ''))
    from lerobot_inference import resolve_checkpoint
    resolved = resolve_checkpoint(config.checkpoint)
    if args.check_config:
        print(json.dumps(dict(config=config.to_dict(), resolved_checkpoint=str(resolved)), ensure_ascii=False, indent=2))
        return
    torch.set_num_threads(config.threads)
    cv2.setNumThreads(1)
    service = Service(config=config)
    print(json.dumps(dict(status="model_loaded", **service.get_info()), ensure_ascii=False), flush=True)
    run_simple_server(service, uri_name=config.uri, daemon_host=config.host, daemon_port=config.port,
                      ns_host=config.ns_host, ns_port=config.ns_port, multiplex=False)


if __name__ == "__main__":
    main()
