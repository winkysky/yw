"""Stateful dual-arm Planner for the two LeRobot no-force checkpoint formats."""
from dataclasses import replace
import threading

import numpy as np

from data_utils.lerobot_observation import LeRobotDataSampler, HistoryNotReady
from data_utils.lerobot_vel_no_force import collate_lerobot_no_force
from lerobot_inference import LeRobotPolicy
from .ensemble import TrajEnsembler
from .planner_config import PlannerConfig


class LeRobotTrajPlanner:
    def __init__(self, config=None, *, policy=None):
        if isinstance(config, (str, bytes)) or hasattr(config, "__fspath__"):
            config = PlannerConfig.load(config)
        elif isinstance(config, dict):
            config = PlannerConfig(**config).validate()
        if config is None:
            if policy is None:
                raise ValueError("Supply a Planner config or a loaded policy")
            config = PlannerConfig(checkpoint=str(policy.path), variant=policy.variant,
                                   task=policy.task, device=str(policy.device)).validate()
        config.validate()
        if policy is None and config.checkpoint is None:
            raise ValueError("Specify the checkpoint to load")
        self.policy = policy or LeRobotPolicy(config.checkpoint, config.device, config.bf16,
                                             config.inference_timesteps, config.task)
        if ((config.variant is not None and self.policy.variant != config.variant)
                or (config.task is not None and self.policy.task != config.task)):
            raise ValueError("Planner task/variant does not match the checkpoint")
        config = replace(config, checkpoint=str(self.policy.path), variant=self.policy.variant, task=self.policy.task).validate()
        self.settings = config
        self.config = self.policy.config
        self.lock = threading.RLock()
        self.sampler = self._sampler(config)
        self.last_obs_data = None
        self.last_status = "waiting_for_observations"
        self.pos_ensembler = TrajEnsembler(config.ensemble)
        self.gripper_ensembler = TrajEnsembler(config.ensemble)

    def _sampler(self, settings):
        return LeRobotDataSampler(self.config, settings.input_pose_format, settings.input_gripper_format,
                                  settings.color_order, settings.history_tolerance_s)

    def get_info(self):
        return dict(self.policy.get_info(), planner_protocol="e2vla_lerobot_planner_v1",
                    numpy_endpoint="run_inference_numpy", stateful=True,
                    planner_config=self.get_planner_config())

    def get_config(self):
        return self.policy.get_info()["data_config"]

    def get_planner_config(self):
        with self.lock:
            return self.settings.to_dict()

    def get_status(self):
        with self.lock:
            return dict(status=self.last_status, observation_count=len(self.sampler.states),
                        last_timestamp=None if self.sampler.latest is None else self.sampler.latest["timestamp"])

    def reset(self):
        with self.lock:
            self.sampler.reset()
            self.pos_ensembler.reset()
            self.gripper_ensembler.reset()
            self.last_obs_data = None
            self.last_status = "waiting_for_observations"

    def set_config(self, values):
        allowed = {"prompt", "speed_mps", "guidance_scale", "seed", "ensemble", "input_pose_format",
                   "input_gripper_format", "color_order", "history_tolerance_s"}
        if not isinstance(values, dict) or set(values)-allowed:
            raise ValueError("Only runtime Planner settings may change; restart to switch task/checkpoint")
        with self.lock:
            settings = replace(self.settings, **values).validate()
            sampler = self._sampler(settings)  # Validate before committing any changes.
            changed = {key for key in values if getattr(settings, key) != getattr(self.settings, key)}
            if changed & {"input_pose_format", "input_gripper_format", "color_order", "history_tolerance_s"}:
                self.sampler = sampler
                self.last_obs_data = None
                self.last_status = "waiting_for_observations"
            if changed:
                self.pos_ensembler = TrajEnsembler(settings.ensemble)
                self.gripper_ensembler = TrajEnsembler(settings.ensemble)
            self.settings = settings

    def set_prompt(self, prompt_text):
        if not isinstance(prompt_text, str) or not prompt_text.strip():
            raise ValueError("Supply a nonempty task prompt")
        self.set_config({"prompt": prompt_text})

    def set_speed(self, speed_mps, guidance_scale=1.):
        if self.settings.variant != "speed":
            raise ValueError("This checkpoint has no speed condition")
        self.set_config({"speed_mps": speed_mps, "guidance_scale": guidance_scale})

    def set_ensemble_nums(self, n):
        self.set_config({"ensemble": n})

    def add_obs_frame(self, obs_frame):
        with self.lock:
            self.sampler.add_obs_frame(obs_frame)

    def add_obs_frames(self, obs_frames):
        if not isinstance(obs_frames, (list, tuple)) or not obs_frames or len(obs_frames) > 240:
            raise ValueError("Supply between 1 and 240 observation frames")
        with self.lock:
            previous, latest = self.sampler.states.copy(), self.sampler.latest
            try:
                for frame in obs_frames:
                    self.sampler.add_obs_frame(frame)
            except Exception:
                self.sampler.states, self.sampler.latest = previous, latest
                raise

    def _make_data_for_infer(self, obs_frames=None):
        sampler = self.sampler
        if obs_frames is not None:
            sampler = self._sampler(self.settings)
            for frame in obs_frames:
                sampler.add_obs_frame(frame)
        return collate_lerobot_no_force([sampler.sample_framedict(self.settings.prompt)])

    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        with self.lock:
            settings = self.settings
            return self.policy.run_inference(obs_data,
                seed=settings.seed if seed is None else seed, contract_sha256=contract_sha256,
                speed_mps=settings.speed_mps if speed_mps is None else speed_mps,
                guidance_scale=settings.guidance_scale if guidance_scale is None else guidance_scale)

    _run_inference = run_inference

    def run_inference_numpy(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=None):
        return self.run_inference(obs_data, seed, contract_sha256, speed_mps, guidance_scale).numpy()

    def get_action(self, draw_traj=False, compress_traj_img=False, seed=None, speed_mps=None):
        with self.lock:
            if not self.sampler.states:
                return None
            try:
                data = self._make_data_for_infer()
            except HistoryNotReady as exc:
                self.last_status = str(exc)
                return None
            prediction = self.run_inference(data, seed=seed, speed_mps=speed_mps)
            self.last_obs_data = data
            self.last_status = "ready"
            actions = prediction.detach().float().cpu().numpy()[0]
            poses = actions[..., :16].reshape(-1, 2, 4, 4)
            grippers = actions[..., 16]
            times = (self.sampler.latest["timestamp"] + self.config.action_offset/self.config.source_fps
                     + np.arange(len(actions))/self.config.target_fps)
            image = None
            if draw_traj:
                from .draw_traj import draw_prediction
                image = draw_prediction(data, poses, compress_traj_img)
            return poses, grippers, times, image

    def ensemble_traj(self, future_ee_poses, future_grippers, future_time):
        with self.lock:
            poses, grippers, times = (np.asarray(x).copy() for x in
                                     (future_ee_poses, future_grippers, future_time))
            if (times.ndim != 1 or len(times) < 2 or poses.shape != (len(times), 2, 4, 4)
                    or grippers.shape != (len(times), 2) or np.any(np.diff(times) <= 0)
                    or not all(np.isfinite(x).all() for x in (poses, grippers, times))):
                raise ValueError("Invalid dual-arm trajectory/timestamps")
            if self.settings.ensemble != 0:
                if self.pos_ensembler.history_time and times[0] < self.pos_ensembler.history_time[-1][0]:
                    raise ValueError("Ensemble trajectory time moved backwards; reset first")
                poses[..., :3, 3] = self.pos_ensembler.update(poses[..., :3, 3], times)
                grippers = self.gripper_ensembler.update(grippers, times)
            return poses, grippers


TrajPlanner = LeRobotTrajPlanner
