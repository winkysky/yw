"""Compatibility entry point for the unified no-force Planner service."""
from .remote_service import Service, main

if __name__ == "__main__":
    main()
