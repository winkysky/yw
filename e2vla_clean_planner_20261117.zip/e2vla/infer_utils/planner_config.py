"""Runtime configuration; calibration and sampling are owned by the checkpoint."""
from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path


@dataclass
class PlannerConfig:
    checkpoint: str | None = None
    variant: str | None = None
    task: str | None = None
    device: str = "auto"
    bf16: bool = False
    inference_timesteps: int | None = None
    prompt: str | None = None
    speed_mps: float | None = None
    guidance_scale: float = 1.
    seed: int | None = None
    input_pose_format: str = "tcp_world"
    input_gripper_format: str = "openness"
    color_order: str = "rgb"
    history_tolerance_s: float | None = None
    ensemble: int = 0
    uri: str = "e2vla"
    host: str = "127.0.0.1"
    port: int = 9101
    ns_host: str = "127.0.0.1"
    ns_port: int = 9090
    threads: int = 4

    def validate(self):
        if self.variant not in (None, "no_speed", "speed") or self.task not in (None, "close_box", "open_box", "place_phone"):
            raise ValueError("Select a supported variant and task")
        if not self.uri or not self.host or not self.ns_host:
            raise ValueError("Service addresses must be nonempty")
        if self.input_pose_format not in ("tcp_world", "recorded") or self.input_gripper_format not in ("openness", "raw"):
            raise ValueError("Invalid observation convention")
        if self.color_order not in ("rgb", "bgr"):
            raise ValueError("color_order must be rgb or bgr")
        if self.prompt is not None and (not isinstance(self.prompt, str) or not self.prompt.strip()):
            raise ValueError("prompt must be nonempty or null")
        if self.speed_mps is not None and (isinstance(self.speed_mps, bool) or not math.isfinite(self.speed_mps) or self.speed_mps < 0):
            raise ValueError("speed_mps must be a finite nonnegative physical speed")
        if not math.isfinite(self.guidance_scale) or self.guidance_scale < 0:
            raise ValueError("guidance_scale must be finite and nonnegative")
        if self.variant == "no_speed" and (self.speed_mps is not None or self.guidance_scale != 1.):
            raise ValueError("The no-speed model does not accept speed/guidance settings")
        if self.seed is not None and (type(self.seed) is not int or not 0 <= self.seed < 2**63):
            raise ValueError("seed must be a nonnegative integer below 2**63")
        if type(self.ensemble) is not int or self.ensemble < -1:
            raise ValueError("ensemble must be -1 (all), 0 (off), or a positive history count")
        if type(self.threads) is not int or self.threads < 1 or not 0 <= self.port < 65536 or not 0 < self.ns_port < 65536:
            raise ValueError("Invalid thread count or ports")
        if self.inference_timesteps is not None and (type(self.inference_timesteps) is not int or self.inference_timesteps < 1):
            raise ValueError("inference_timesteps must be a positive integer")
        if self.history_tolerance_s is not None and (not math.isfinite(self.history_tolerance_s) or self.history_tolerance_s <= 0):
            raise ValueError("history_tolerance_s must be positive")
        return self

    def to_dict(self):
        return asdict(self)

    @classmethod
    def load(cls, path):
        path = Path(path).expanduser().resolve()
        values = json.loads(path.read_text())
        if values.get("checkpoint") is not None:
            checkpoint = Path(values["checkpoint"]).expanduser()
            values["checkpoint"] = str(checkpoint if checkpoint.is_absolute() else (path.parent/checkpoint).resolve())
        return cls(**values).validate()
