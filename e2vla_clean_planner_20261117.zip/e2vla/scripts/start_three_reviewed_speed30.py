"""Launch three reviewed continuous-speed 30 Hz / 50k recipes; verify optimizer steps."""
import argparse
from datetime import datetime
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

PROJECT = Path(__file__).resolve().parents[1]
ROOT = Path('/nas_data_new/hq/91e2vla')
TASKS = ('close_box', 'open_box', 'place_phone')
PYTHON = Path('/home/hq/miniconda3/envs/e2vla/bin/python')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gpus', nargs=3, default=['0', '1', '2'])
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--startup-timeout', type=int, default=600)
    args = parser.parse_args()
    if len(set(args.gpus)) != 3:
        raise ValueError('Each training job needs a distinct GPU')
    recipes = []
    for task in TASKS:
        path = PROJECT / f'configs_lerobot_vel_no_force/reviewed_{task}_30hz_speed.json'
        recipe = json.loads(path.read_text())
        train, data = recipe['training'], recipe['data']
        assert train['max_steps'] == 50000 and train['save_every'] == 10000
        assert data['target_fps'] == data['source_fps'] == 30 and data['frame_stride'] == 1 and data['num_future_actions'] == 32
        assert data['speed_factors'] == [1., 1.5, 2.] and data['history_mode'] == 'observed'
        assert Path(train['pretrained']).is_file()
        output = Path(train['output'])
        if output.exists() and any(output.iterdir()):
            raise RuntimeError(f'Output is nonempty; inspect or resume the existing run: {output}')
        recipes.append((task, path, recipe))
    # Check actual CUDA allocation and BF16 separately on each requested device.
    probe = '''import json,torch
assert torch.cuda.is_available(), 'CUDA unavailable: NVIDIA devices must be accessible'
assert torch.cuda.is_bf16_supported(), 'BF16 is unavailable'
x=torch.ones((32,32),device='cuda',dtype=torch.bfloat16)
y=x@x
torch.cuda.synchronize()
free,total=torch.cuda.mem_get_info()
assert free >= 20*2**30, 'Less than 20 GiB GPU memory free; inspect current GPU workloads'
print(json.dumps(dict(gpu=torch.cuda.get_device_name(0),free_GiB=round(free/2**30,2),bf16=True)))
'''
    for gpu in args.gpus:
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=gpu, CUDA_DEVICE_ORDER='PCI_BUS_ID', PYTHONDONTWRITEBYTECODE='1')
        result = subprocess.run([str(PYTHON), '-c', probe], env=env, text=True, capture_output=True)
        if result.returncode:
            raise RuntimeError(f'GPU {gpu} preflight failed. No training was launched.\n{result.stdout}{result.stderr}')
        print(f'GPU {gpu}: {result.stdout.strip()}', flush=True)
    if args.check_only:
        print('All three recipes and GPUs are ready; no training launched.', flush=True)
        return
    ROOT.mkdir(parents=True, exist_ok=True)
    lock = (ROOT / '.launch_three_speed30.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    # The lock and output checks prevent duplicate launches while startup is pending.
    for _, _, recipe in recipes:
        output = Path(recipe['training']['output'])
        if output.exists() and any(output.iterdir()):
            raise RuntimeError(f'Another run populated {output}')
    run_dir = ROOT / 'logs' / datetime.now().strftime('speed30_%Y%m%d_%H%M%S_%f')
    run_dir.mkdir(parents=True)
    jobs = []
    for gpu, (task, path, recipe) in zip(args.gpus, recipes):
        log = run_dir / f'{task}.log'
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=gpu, CUDA_DEVICE_ORDER='PCI_BUS_ID', PYTHONUNBUFFERED='1',
                   PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1', TOKENIZERS_PARALLELISM='false',
                   OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', OPENBLAS_NUM_THREADS='1')
        command = [str(PYTHON), '-u', str(PROJECT / 'train_lerobot_vel_no_force.py'), '--config', str(path)]
        with log.open('x') as handle:
            process = subprocess.Popen(command, cwd=PROJECT, env=env, stdin=subprocess.DEVNULL,
                                       stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
        jobs.append(dict(task=task, gpu=gpu, pid=process.pid, log=str(log), output=recipe['training']['output'],
                         config=str(path), command=command, process=process))
        print(json.dumps({k: v for k, v in jobs[-1].items() if k != 'process'}), flush=True)
    receipt = run_dir / 'launch.json'
    receipt.write_text(json.dumps([{k: v for k, v in job.items() if k != 'process'} for job in jobs], indent=2) + '\n')
    print(f'Launch record: {receipt}', flush=True)
    deadline = time.monotonic() + args.startup_timeout
    waiting = {job['task'] for job in jobs}
    while waiting and time.monotonic() < deadline:
        for job in jobs:
            if job['task'] not in waiting:
                continue
            log_text = Path(job['log']).read_text(errors='replace')
            if job['process'].poll() is not None:
                print(f"FAILED {job['task']}: exit={job['process'].returncode}\n{log_text[-6000:]}", flush=True)
                waiting.remove(job['task'])
                job['startup'] = 'failed'
                continue
            for line in reversed(log_text.splitlines()):
                try:
                    value = json.loads(line)
                except (ValueError, TypeError):
                    continue
                if isinstance(value, dict) and value.get('step', 0) >= 1 and 'loss' in value:
                    job['startup'] = 'training'
                    job['first_observed_step'] = value
                    waiting.remove(job['task'])
                    print(json.dumps(dict(task=job['task'], status='training', **value)), flush=True)
                    break
        if waiting:
            time.sleep(3)
    for job in jobs:
        job.setdefault('startup', 'not_confirmed_before_timeout')
    receipt.write_text(json.dumps([{k: v for k, v in job.items() if k != 'process'} for job in jobs], indent=2) + '\n')
    if any(job['startup'] != 'training' for job in jobs):
        raise RuntimeError(f'Not all training jobs reached a verified step; inspect {receipt}. Other jobs may still be running.')
    print('All three training jobs completed at least one optimizer step and continue in the background.', flush=True)


if __name__ == '__main__':
    main()
