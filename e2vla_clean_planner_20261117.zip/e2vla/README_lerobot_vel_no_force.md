# 无力连续速度模型

模型使用 DINOv2/SigLIP、ContextEncoder/ProPE、64+1 个 QFormer query、DiT 和 DDIM。速度条件是连续物理速度 `speed_mps`，单位 m/s；没有力、接触或速度分类损失。success 条件始终为 None。为兼容已训练 checkpoint，保留所需模块和参数键。

三个任务的训练设置、数据增强、预训练迁移与启动方式见 `README_reviewed_speed30.md`。统一 Planner/Pyro4 接口见 `README_lerobot_pyro.md`。

输入五步真实双臂历史、当前三相机图像、任务指令及速度条件，输出 32 步双臂 TCP 指令。内部动作表示为位置 3、旋转 6、夹爪 1；模型解码输出 `(B,32,2,17)`，前 16 维是左臂 base 下 TCP 矩阵，最后一维是夹爪开度（0 关、1 开）。

1 / 1.5 / 2 只用于训练轨迹重采样，不能把 `speed_mps=1.5` 当成 1.5 倍速。当前 reviewed 配置始终使用实际观测历史，目标轨迹按倍率重采样；动作真值来自 `action.tcp_pose_cmd`，不以观测状态代替。

右臂观测与动作都使用与无速度模型相同的左右 base 变换，三相机位姿随相应手臂计算。在线输入已经是共同坐标 TCP 时不再次变换。
