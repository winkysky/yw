"""Shared local/Pyro inference contract for both no-force LeRobot policies."""
from contextlib import nullcontext
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import threading

os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')

import numpy as np
import torch

from data_utils.lerobot_no_force import LeRobotNoForceConfig
from data_utils.lerobot_reviewed_no_force import ReviewedNoForceConfig
from data_utils.lerobot_vel_no_force import camera_pose_in_world
from train_lerobot_no_force import FORMAT, build_model
from train_lerobot_vel_no_force import FORMAT as SPEED_FORMAT
from data_utils.lerobot_observation import camera_rays as observation_camera_rays


TASKS = {
    'close_box': dict(uri='e2vla_close_box', port=9101, datasets=['close_box_1112_2/success']),
    'open_box': dict(uri='e2vla_open_box', port=9102, datasets=['open_the_box_1109_60/success']),
    'place_phone': dict(uri='e2vla_place_phone', port=9103,
                       datasets=['place_phone_1111_60_2/success', 'place_phone_1112_10/success']),
}
OBSERVATION_KEYS = ('obs_rgbs', 'obs_masks', 'obs_norm_xys', 'obs_extrinsics',
                    'prompt_text', 'current_ee_pose', 'history_ee_states', 'valid_ee_mask')


def make_data_config(values):
    if values.get('speed_factors') is not None:
        from data_utils.lerobot_vel_no_force import LeRobotVelocityNoForceConfig
        from data_utils.lerobot_reviewed_velocity import ReviewedVelocityNoForceConfig
        cls = ReviewedVelocityNoForceConfig if 'reviewed_datasets' in values else LeRobotVelocityNoForceConfig
    else:
        cls = ReviewedNoForceConfig if 'reviewed_datasets' in values else LeRobotNoForceConfig
    config = cls(**values)
    config.validate()
    return config


def contract_signature(config):
    """Task and preprocessing must match; filesystem roots/caches may be local."""
    values = asdict(config)
    for key in ('root', 'cache_episodes', 'cache_videos'):
        values.pop(key, None)
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def default_checkpoint(task, variant='no_speed'):
    suffix = '15hz_no_force_no_speed' if variant == 'no_speed' else '30hz_no_force_speed'
    return Path('/nas_data_new/hq/91e2vla') / f'{task}_{suffix}/step_0050000.pt' 


def camera_rays(config):
    return observation_camera_rays(config)[None]


def validate_inputs(obs, config, expected_rays):
    if not isinstance(obs, dict):
        raise ValueError('obs_data must be a dict of batched model-ready observations')
    missing = set(OBSERVATION_KEYS) - set(obs)
    if missing:
        raise ValueError(f'Missing observation fields: {sorted(missing)}')
    data = {}
    for key in OBSERVATION_KEYS:
        if key == 'prompt_text':
            continue
        if not isinstance(obs[key], (torch.Tensor, np.ndarray)):
            raise ValueError(f'{key} must be a CPU tensor or NumPy array')
        value = torch.as_tensor(obs[key]).detach().cpu()
        if not torch.isfinite(value).all():
            raise ValueError(f'{key} contains NaN/Inf')
        if key in ('obs_masks', 'valid_ee_mask'):
            if value.dtype != torch.bool:
                raise ValueError(f'{key} must have bool dtype')
        else:
            value = value.float()
        data[key] = value.contiguous()
    if data['obs_rgbs'].ndim != 6:
        raise ValueError('obs_rgbs must have shape (B,1,3,3,H,W); add the batch dimension')
    b = data['obs_rgbs'].shape[0]
    if b < 1:
        raise ValueError('Empty batches are not supported')
    h, w = config.image_size
    nc = len(config.camera_keys)
    shapes = dict(obs_rgbs=(b,1,nc,3,h,w), obs_masks=(b,1,nc,h,w),
                  obs_norm_xys=(b,1,nc,2,h,w), obs_extrinsics=(b,1,nc,4,4),
                  current_ee_pose=(b,2,4,4), history_ee_states=(b,config.num_history_states,2,17),
                  valid_ee_mask=(b,2))
    for key, shape in shapes.items():
        if tuple(data[key].shape) != shape:
            raise ValueError(f'{key}: expected {shape}, got {tuple(data[key].shape)}')
    if not data['valid_ee_mask'].all():
        raise ValueError('This endpoint requires both arms: valid_ee_mask must be [True, True]')
    if data['obs_rgbs'].min() < 0 or data['obs_rgbs'].max() > 1:
        raise ValueError('obs_rgbs must be RGB floats normalized to [0,1]')
    prompts = obs['prompt_text']
    if not isinstance(prompts, (tuple, list)) or len(prompts) != b or any(not isinstance(p,str) or not p.strip() for p in prompts):
        raise ValueError('prompt_text must contain one nonempty string per batch item')
    data['prompt_text'] = list(prompts)
    history_pose = data['history_ee_states'][..., :16].reshape(b, config.num_history_states, 2, 4, 4)
    for name, pose in [('current_ee_pose', data['current_ee_pose']), ('history_ee_states', history_pose)]:
        if not torch.allclose(pose[...,3,:], torch.tensor([0.,0.,0.,1.]).expand_as(pose[...,3,:]), atol=1e-5):
            raise ValueError(f'{name} must contain homogeneous 4x4 TCP poses')
    if not torch.allclose(history_pose[:, -1], data['current_ee_pose'], atol=2e-5, rtol=1e-5):
        raise ValueError('The last observed history pose must equal current_ee_pose')
    if not torch.allclose(data['obs_norm_xys'], expected_rays.expand(b,-1,-1,-1,-1,-1), atol=2e-6, rtol=1e-5):
        raise ValueError('Camera rays do not match checkpoint intrinsics/image resize/order')
    for row in range(b):
        expected = torch.stack([camera_pose_in_world(data['current_ee_pose'][row], config, config.geometry['cameras'][key])
                                for key in config.camera_keys])
        if not torch.allclose(data['obs_extrinsics'][row,0], expected, atol=2e-5, rtol=1e-5):
            raise ValueError('Camera poses disagree with checkpoint calibration and TCPs in left-base world')
    # Real future values, even if present in legacy callers, are never read.
    data['gt_future_ee_states'] = torch.zeros(b, config.num_future_actions, 2, 17)
    return data


def resolve_checkpoint(path):
    path = Path(path).expanduser().resolve()
    if path.is_dir():
        candidates = [f for f in path.glob('step_*.pt') if f.stem[5:].isdigit()]
        if not candidates:
            raise FileNotFoundError(f'No completed step_*.pt checkpoints in {path}')
        path = max(candidates, key=lambda f: int(f.stem[5:]))
    if not path.is_file():
        raise FileNotFoundError(f'Checkpoint not found: {path}')
    return path


class LeRobotPolicy:
    """One immutable checkpoint per process. Serialize calls to the DDIM scheduler."""
    def __init__(self, checkpoint, device='auto', bf16=False, inference_timesteps=None, task=None):
        self.path = resolve_checkpoint(checkpoint)
        saved = torch.load(self.path, map_location='cpu', weights_only=False, mmap=True)
        if saved.get('format') not in (FORMAT, SPEED_FORMAT):
            raise ValueError('Expected a supported LeRobot no-force checkpoint')
        self.format = saved['format']
        self.variant = 'speed' if self.format == SPEED_FORMAT else 'no_speed'
        self.config = make_data_config(saved['data_config'])
        matches = [name for name, spec in TASKS.items() if set(spec['datasets']) == set(getattr(self.config, 'reviewed_datasets', []) or [])]
        self.task = matches[0] if matches else None
        if task is not None and self.task != task:
            raise ValueError(f'Checkpoint dataset belongs to {self.task!r}, not requested task {task!r}')
        self.model_config = dict(saved['model_config'])
        if (self.variant == 'speed') != (self.config.speed_factors is not None):
            raise ValueError('Checkpoint format and speed data configuration disagree')
        if self.variant == 'speed' and (self.model_config.get('continuous_speed') is not True
                                       or self.model_config.get('action_horizon') != 32):
            raise ValueError('Only the continuous-speed 32-step model is supported')
        if inference_timesteps is not None:
            if not 1 <= inference_timesteps <= self.model_config['diffusion_timesteps']:
                raise ValueError('Invalid inference_timesteps')
            self.model_config['inference_timesteps'] = inference_timesteps
        self.device = torch.device(('cuda:0' if torch.cuda.is_available() else 'cpu') if device == 'auto' else device)
        if self.device.type not in ('cpu', 'cuda') or (self.device.type == 'cuda' and not torch.cuda.is_available()):
            raise ValueError('Use an available cuda:N device, or cpu')
        if self.device.type == 'cuda':
            torch.cuda.set_device(self.device)
        if bf16 and (self.device.type != 'cuda' or not torch.cuda.is_bf16_supported()):
            raise ValueError('BF16 requires a supported CUDA device')
        self.bf16 = bf16
        self.step = int(saved['step'])
        self.signature = contract_signature(self.config)
        self.expected_rays = camera_rays(self.config)
        if self.variant == 'speed':
            from models.vla_vel_no_force import vla_velocity_no_force_base
            self.model = vla_velocity_no_force_base(**self.model_config)
        else:
            self.model = build_model(**self.model_config)
        self.model.actor.load_state_dict(saved['actor'], strict=True)
        self.model.to(self.device).eval()
        self.lock = threading.Lock()

    def get_info(self):
        return dict(protocol='e2vla_lerobot_pyro_v1', format=self.format, variant=self.variant, task=self.task,
                    checkpoint=str(self.path), checkpoint_step=self.step,
                    data_config=asdict(self.config), model_config=self.model_config,
                    contract_sha256=self.signature, device=str(self.device), bf16=self.bf16,
                    world_frame='left_recorded_arm_base', arm_order=['left','right'],
                    output_shape=['B',self.config.num_future_actions,2,17],
                    output='CPU float32 TCP matrices (metres) plus gripper openness; no joint commands')

    def run_inference(self, obs_data, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=1.):
        if contract_sha256 is not None and contract_sha256 != self.signature:
            raise ValueError('Client task/data/calibration contract differs from this checkpoint')
        if seed is not None and (type(seed) is not int or not 0 <= seed < 2**63):
            raise ValueError('seed must be an integer in [0, 2**63) or None')
        with self.lock:
            batch = validate_inputs(obs_data, self.config, self.expected_rays)
            if self.variant == 'speed':
                if speed_mps is None:
                    raise ValueError('Continuous-speed inference requires speed_mps (physical m/s)')
                speed = torch.as_tensor(speed_mps, dtype=torch.float32)
                if speed.numel() != 1 or not torch.isfinite(speed).all() or speed.item() < 0:
                    raise ValueError('speed_mps must be a finite nonnegative scalar')
                if not np.isfinite(guidance_scale) or guidance_scale < 0:
                    raise ValueError('guidance_scale must be finite and nonnegative')
                batch.update(success=None, gt_speed_cond=speed.reshape(1).expand(len(batch['current_ee_pose'])),
                             guidance_scale=float(guidance_scale))
            elif speed_mps is not None or guidance_scale != 1.:
                raise ValueError('The no-speed model does not accept speed conditioning')
            batch = {k: v.to(self.device) if torch.is_tensor(v) else v for k,v in batch.items()}
            devices = [self.device.index if self.device.index is not None else torch.cuda.current_device()] if self.device.type == 'cuda' else []
            context = torch.random.fork_rng(devices=devices) if seed is not None else nullcontext()
            with context, torch.inference_mode():
                if seed is not None:
                    torch.manual_seed(seed)
                result = self.model(**batch, inference=True, fp16=self.bf16)
            expected = (len(batch['current_ee_pose']), self.config.num_future_actions, 2, 17)
            if tuple(result.shape) != expected or not torch.isfinite(result).all():
                raise RuntimeError('Model returned invalid dual-arm predictions')
            return result.detach().float().cpu().contiguous()


class RemoteLeRobotPolicy:
    """CPU observation client; compatible with existing shm_transport proxies."""
    def __init__(self, uri, ns_host='127.0.0.1', ns_port=9090, timeout=120., shared_memory=False):
        import Pyro4
        from shm_transport import get_shm_proxy
        Pyro4.config.COMMTIMEOUT = timeout
        self.proxy = get_shm_proxy(uri, ns_host=ns_host, ns_port=ns_port,
                                   en_arg_sh_cuda=False, copy_ret_sh_cuda=False,
                                   force_use_socket=not shared_memory)
        try:
            self.info = self.proxy.get_info()
            if self.info.get('protocol') != 'e2vla_lerobot_pyro_v1' or self.info.get('format') not in (FORMAT, SPEED_FORMAT):
                raise ValueError('Remote endpoint is not a supported LeRobot no-force service')
            self.config = make_data_config(self.info['data_config'])
            if contract_signature(self.config) != self.info['contract_sha256']:
                raise ValueError('Invalid remote data contract')
        except BaseException:
            self.close()
            raise

    def check_config(self, config):
        if contract_signature(config) != self.info['contract_sha256']:
            raise ValueError('Selected dataset/task/calibration differs from remote model')

    def run_inference(self, obs_data, seed=None, speed_mps=None):
        batch = {key: (value.detach().cpu().contiguous().numpy() if torch.is_tensor(value) else value)
                 for key, value in obs_data.items() if key in OBSERVATION_KEYS}
        result = self.proxy.run_inference(batch, seed=seed, contract_sha256=self.info['contract_sha256'], speed_mps=speed_mps)
        result = torch.as_tensor(result).float().cpu()
        shape = (len(batch['current_ee_pose']), self.config.num_future_actions, 2, 17)
        if tuple(result.shape) != shape or not torch.isfinite(result).all():
            raise ValueError('Remote endpoint returned invalid predictions')
        return result

    def close(self):
        proxy = getattr(self, 'proxy', None)
        if proxy is not None:
            # Release shared resources before the underlying RPC connection.
            if proxy._shm_name_prefix is not None:
                from shm_transport.shm_mng import get_client_shm_managers
                get_client_shm_managers().del_proxy_mng(proxy._shm_name_prefix)
                proxy._shm_name_prefix = None
            proxy._pyro_proxy._pyroRelease()
            self.proxy = None
