"""Train the source E2VLA velocity model on LeRobot, predicting actions only."""
import argparse
from dataclasses import asdict
import json
import math
from pathlib import Path
import random
import time

import cv2
import numpy as np
import torch
from torch.utils.data import DataLoader, Sampler

from data_utils.lerobot_vel_no_force import (
    LeRobotVelocityNoForceConfig, LeRobotVelocityNoForceDataset, collate_lerobot_no_force,
)
DEFAULT_DATA_CONFIG = Path(__file__).with_name("configs_lerobot_vel_no_force") / "huawei_close_box.json"

FORMAT = "e2vla_lerobot_vel_no_force_retime32_v2"


def emit(**values):
    print(json.dumps(values, ensure_ascii=False), flush=True)


class EpochBatchSampler(Sampler):
    """Shuffle deterministically, resume by consumed batches, independent of prefetch."""
    def __init__(self, size, batch_size, seed, epoch, start_batch=0):
        self.size, self.batch_size = size, batch_size
        self.seed, self.epoch, self.start_batch = seed, epoch, start_batch
        self.stopped = False

    def __iter__(self):
        indices = torch.randperm(self.size, generator=torch.Generator().manual_seed(self.seed + self.epoch))
        for batch in range(self.start_batch, self.size // self.batch_size):
            if self.stopped:
                break
            start = batch * self.batch_size
            yield indices[start:start + self.batch_size].tolist()

    def __len__(self):
        return max(0, self.size // self.batch_size - self.start_batch)

def init_worker(worker_id):
    cv2.setNumThreads(1)
    torch.set_num_threads(1)
    seed = torch.initial_seed() % 2**32
    np.random.seed(seed)
    random.seed(seed)

class TrainingStream:
    def __init__(self, dataset, collator, batch_size, workers, seed, epoch=0, batch_in_epoch=0):
        if len(dataset) < batch_size:
            raise ValueError("Dataset must contain at least one full batch")
        self.dataset, self.collator = dataset, collator
        self.batch_size, self.workers, self.seed = batch_size, workers, seed
        self.epoch, self.batch_in_epoch = epoch, batch_in_epoch
        self.iterator = None

    def next(self):
        if self.batch_in_epoch == len(self.dataset) // self.batch_size:
            self.epoch += 1
            self.batch_in_epoch = 0
            self.iterator = None
        if self.iterator is None:
            self.sampler = EpochBatchSampler(len(self.dataset), self.batch_size, self.seed,
                                             self.epoch, self.batch_in_epoch)
            kwargs = dict(
                dataset=self.dataset, collate_fn=self.collator, num_workers=self.workers,
                batch_sampler=self.sampler,
                pin_memory=True, worker_init_fn=init_worker,
                generator=torch.Generator().manual_seed(self.seed + self.epoch),
            )
            if self.workers:
                kwargs.update(multiprocessing_context="spawn", prefetch_factor=2)
            self.iterator = iter(DataLoader(**kwargs))
        result = next(self.iterator)
        self.batch_in_epoch += 1
        return result

    def close(self):
        # Drain already-prefetched results before normal DataLoader shutdown.
        # Stopping with tensor transfers still queued can abort native worker
        # threads. The stopped sampler prevents scheduling any more batches.
        if self.iterator is not None:
            self.sampler.stopped = True
            for _ in self.iterator:
                pass
            self.iterator = None
        self.dataset.close()

def lr_multiplier(step, warmup, total):
    if step < warmup:
        return (step + 1) / max(1, warmup)
    progress = (step - warmup) / max(1, total - warmup)
    return 0.5 * (1 + math.cos(math.pi * min(progress, 1)))

def rng_state():
    return dict(python=random.getstate(), numpy=np.random.get_state(), torch=torch.get_rng_state(),
                cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None)

def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if state["cuda"] is not None:
        torch.cuda.set_rng_state_all(state["cuda"])


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    source = result.add_mutually_exclusive_group()
    source.add_argument("--config", type=Path, help="Reviewed task recipe with data/training sections")
    source.add_argument("--data-config", type=Path, default=DEFAULT_DATA_CONFIG)
    result.add_argument("--data-root")
    result.add_argument("--speed-scale-mps", type=float, default=.1)
    result.add_argument("--check-data", action="store_true")
    result.add_argument("--batch-size", type=int, default=32)
    result.add_argument("--workers", type=int, default=4)
    result.add_argument("--threads", type=int, default=4)
    result.add_argument("--max-steps", type=int, default=100000)
    result.add_argument("--lr", type=float, default=1e-4)
    result.add_argument("--weight-decay", type=float, default=1e-5)
    result.add_argument("--warmup-steps", type=int, default=2000)
    result.add_argument("--grad-clip", type=float, default=1.)
    result.add_argument("--seed", type=int, default=42)
    result.add_argument("--device", default="cuda:0")
    result.add_argument("--save-every", type=int, default=2000)
    result.add_argument("--log-every", type=int, default=10)
    result.add_argument("--output", type=Path, default=Path("checkpoints/lerobot_vel_no_force_retime32_close_box"))
    result.add_argument("--resume", type=Path)
    result.add_argument("--pretrained", type=Path)
    result.add_argument("--inference-timesteps", type=int, default=20)
    return result


def parse_args(argv=None):
    probe = argparse.ArgumentParser(add_help=False)
    probe.add_argument('--config', type=Path)
    selected, _ = probe.parse_known_args(argv)
    cli, recipe = parser(), None
    if selected.config is not None:
        recipe = json.loads(selected.config.read_text())
        if set(recipe) != {'data', 'training'} or not all(isinstance(v, dict) for v in recipe.values()):
            cli.error('Recipe must contain data and training objects')
        allowed = {'batch_size', 'workers', 'threads', 'max_steps', 'lr', 'weight_decay',
                   'warmup_steps', 'grad_clip', 'seed', 'device', 'inference_timesteps',
                   'save_every', 'log_every', 'output', 'pretrained', 'speed_scale_mps'}
        if set(recipe['training']) - allowed:
            cli.error('Unknown training recipe options')
        defaults = dict(recipe['training'])
        for name in ('output', 'pretrained'):
            if defaults.get(name) is not None:
                path = Path(defaults[name]).expanduser()
                defaults[name] = path if path.is_absolute() else (selected.config.parent / path).resolve()
        cli.set_defaults(**defaults)
    args = cli.parse_args(argv)
    args.recipe_data = None if recipe is None else recipe['data']
    return args


def load_data_config(args):
    values = dict(args.recipe_data) if args.recipe_data is not None else json.loads(args.data_config.read_text())
    if args.data_root is not None:
        values['root'] = args.data_root
    cls = LeRobotVelocityNoForceConfig
    if 'reviewed_datasets' in values:
        from data_utils.lerobot_reviewed_velocity import ReviewedVelocityNoForceConfig
        cls = ReviewedVelocityNoForceConfig
    config = cls(**values)
    config.validate()
    return config


def build_dataset(config):
    if getattr(config, 'reviewed_datasets', None) is not None:
        from data_utils.lerobot_reviewed_velocity import ReviewedVelocityNoForceDataset
        return ReviewedVelocityNoForceDataset(config)
    return LeRobotVelocityNoForceDataset(config)


def adapt_pretrained_actor(actor, weights):
    """Transfer every original tensor, with two explicitly supported expansions."""
    target = actor.state_dict()
    missing = set(target) - set(weights)
    unexpected = set(weights) - set(target)
    allowed_new = {key for key in target if key.startswith(('dp_head.velocity_enc.', 'dp_head.success_enc.'))}
    if unexpected or missing != allowed_new:
        raise ValueError(f'Unexpected pretrained architecture: missing={sorted(missing)}, extra={sorted(unexpected)}')
    adapted, expanded = dict(target), []
    for key, value in weights.items():
        desired = target[key]
        if desired.shape == value.shape:
            adapted[key] = value
        elif (key == 'context_encoder.qformer.queries' and value.ndim == 3 and
              desired.shape == (value.shape[0], value.shape[1]+1, value.shape[2])):
            new = desired.clone()
            new[:, :value.shape[1]] = value
            adapted[key] = new
            expanded.append(key)
        elif (key == 'dp_head.hist_enc.0.weight' and value.ndim == 2 and value.shape[1] == 9 and
              desired.shape == (value.shape[0], 10)):
            new = torch.zeros_like(desired)
            new[:, :9] = value
            adapted[key] = new
            expanded.append(key)
        else:
            raise ValueError(f'Unsupported pretrained shape: {key}: {tuple(value.shape)} -> {tuple(desired.shape)}')
    if set(expanded) != {'context_encoder.qformer.queries', 'dp_head.hist_enc.0.weight'}:
        raise ValueError('Expected the original no-speed E2VLA pretrained architecture')
    # Begin from pretrained action behavior; learn the new speed residual.
    for key in ('dp_head.velocity_enc.net.2.weight', 'dp_head.velocity_enc.net.2.bias'):
        adapted[key] = torch.zeros_like(target[key])
    actor.load_state_dict(adapted, strict=True)
    return dict(pretrained_tensors=len(weights), exact_shape_tensors=len(weights)-len(expanded),
                expanded_tensors=expanded, new_tensors=sorted(missing),
                new_history_gripper_column='zero', speed_output_initialization='zero')


def load_pretrained_actor(model, path):
    saved = torch.load(path, map_location='cpu', weights_only=False, mmap=True)
    if not isinstance(saved, dict) or 'weights' not in saved:
        raise ValueError('Expected original E2VLA pretrained checkpoint with weights')
    report = dict(pretrained=str(Path(path).resolve()), **adapt_pretrained_actor(model.actor, saved['weights']))
    emit(**report)
    return report


def comparable_data(config):
    return {key: value for key, value in config.items() if key not in {"root", "cache_episodes", "cache_videos"}}


def check_resume(checkpoint, data_config, model_config, train_config):
    if checkpoint.get("format") != FORMAT:
        raise ValueError("Only this action-only version's checkpoints can be resumed")
    if comparable_data(checkpoint["data_config"]) != comparable_data(asdict(data_config)):
        raise ValueError("Resume data/calibration conventions differ")
    if checkpoint["model_config"] != model_config or checkpoint["train_config"] != train_config:
        raise ValueError("Resume model, speed bins or training options differ")


def save_checkpoint(path, model, optimizer, scheduler, step, stream, data_config, model_config, train_config, initialization=None):
    payload = dict(format=FORMAT, actor=model.actor.state_dict(), optimizer=optimizer.state_dict(),
                   scheduler=scheduler.state_dict(), step=step, epoch=stream.epoch,
                   batch_in_epoch=stream.batch_in_epoch, rng=rng_state(),
                   data_config=asdict(data_config), model_config=model_config, train_config=train_config,
                   initialization=initialization)
    temporary = path.with_suffix(".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)
    emit(checkpoint=str(path), step=step)


def main(argv=None):
    args = parse_args(argv)
    if (min(args.batch_size, args.threads, args.max_steps, args.save_every, args.log_every) < 1
            or args.workers < 0 or args.warmup_steps < 0 or args.lr <= 0
            or args.weight_decay < 0 or args.grad_clip <= 0 or not 1 <= args.inference_timesteps <= 100):
        raise ValueError("Invalid training options")
    torch.set_num_threads(args.threads)
    cv2.setNumThreads(1)
    config = load_data_config(args)
    if config.num_history_states != 5:
        raise ValueError("Keep the source base architecture's five history states")
    if config.speed_factors is None:
        raise ValueError("Use the updated 32-step data config with speed_factors=[1, 1.5, 2]")
    dataset = build_dataset(config)
    model_config = dict(diffusion_timesteps=100, inference_timesteps=args.inference_timesteps, continuous_speed=True,
                        speed_scale_mps=args.speed_scale_mps, action_horizon=32)
    if args.check_data:
        try:
            starts = [0] + dataset.retime_index.ends[:-1]
            probes = {0, len(dataset) // 2, len(dataset) - 1}
            for factor in (1., 1.5, 2.):
                probes.add(next(start for start, block in zip(starts, dataset.retime_index.blocks) if block[1] == factor))
            for index in sorted(probes):
                sample = dataset[index]
                for value in sample.values():
                    if torch.is_tensor(value):
                        assert torch.isfinite(value).all()
                emit(index=index, shapes={key: list(value.shape) for key, value in sample.items()
                                          if torch.is_tensor(value)},
                     speed_mps=float(sample["gt_speed_cond"]),
                     speed_factor=float(dataset.numeric_sample(index)["speed_factor"]),
                     success=None if sample["success"] is None else int(sample["success"]))
            emit(status="data_ok", episodes=len(dataset.episodes), samples=len(dataset), fps=dataset.fps,
                 target_fps=config.target_fps, horizon=32, factors=dataset.retime_index.counts)
        finally:
            dataset.close()
        return
    if args.output.exists() and any(args.output.iterdir()) and args.resume is None:
        raise FileExistsError("Output is nonempty; use --resume or a new --output directory")
    device = torch.device(args.device)
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("Training requires CUDA; --check-data works on CPU")
    torch.cuda.set_device(device)
    if not torch.cuda.is_bf16_supported():
        raise RuntimeError("BF16 training requires an Ampere or newer GPU")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    train_config = {key: getattr(args, key) for key in (
        "batch_size", "max_steps", "lr", "weight_decay", "warmup_steps", "grad_clip", "seed")}
    checkpoint = None
    if args.resume:
        # Resume only trusted, locally generated training checkpoints.
        checkpoint = torch.load(args.resume, map_location="cpu", weights_only=False)
        check_resume(checkpoint, config, model_config, train_config)
        if checkpoint["step"] >= args.max_steps:
            emit(status="already_complete", step=checkpoint["step"])
            dataset.close()
            return
    # Validate real input before loading the frozen backbones.
    collate_lerobot_no_force([dataset[0]])
    dataset.close()
    from models.vla_vel_no_force import vla_velocity_no_force_base
    model = vla_velocity_no_force_base(**model_config)
    initialization = checkpoint.get('initialization') if checkpoint else None
    if checkpoint is None and args.pretrained is not None:
        initialization = load_pretrained_actor(model, args.pretrained)
    model.to(device).train()
    decay, no_decay = model.parameter_groups()
    optimizer = torch.optim.AdamW([{"params": decay, "weight_decay": args.weight_decay},
                                   {"params": no_decay, "weight_decay": 0.}], lr=args.lr)
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer, lambda step: lr_multiplier(step, args.warmup_steps, args.max_steps))
    start_step, epoch, batch_in_epoch = 0, 0, 0
    if checkpoint:
        model.actor.load_state_dict(checkpoint["actor"], strict=True)
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_step, epoch, batch_in_epoch = (checkpoint[key] for key in ("step", "epoch", "batch_in_epoch"))
        restore_rng(checkpoint["rng"])
        del checkpoint
    stream = TrainingStream(dataset, collate_lerobot_no_force, args.batch_size,
                            args.workers, args.seed, epoch, batch_in_epoch)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "config.json").write_text(json.dumps(
        dict(variant=FORMAT, data=asdict(config), model=model_config, train=train_config,
             initialization=initialization), ensure_ascii=False, indent=2))
    emit(status="training", variant=FORMAT, gpu=torch.cuda.get_device_name(device),
         trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
         frozen_parameters=sum(p.numel() for p in model.parameters() if not p.requires_grad),
         batch_size=args.batch_size, arms=2, action_dim_per_arm=10, samples=len(dataset),
         target_fps=config.target_fps, horizon=32, speed_conditioning=True,
         factors=dataset.retime_index.counts)
    torch.cuda.reset_peak_memory_stats(device)
    started = time.monotonic()
    try:
        for step in range(start_step + 1, args.max_steps + 1):
            step_started = time.monotonic()
            data = stream.next()
            data_wait = time.monotonic() - step_started
            data = {key: value.to(device, non_blocking=True) if torch.is_tensor(value) else value
                    for key, value in data.items()}
            optimizer.zero_grad(set_to_none=True)
            loss, metrics = model(**data, inference=False, fp16=True, guidance_scale=1.)
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Nonfinite loss at step {step}")
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(decay + no_decay, args.grad_clip, error_if_nonfinite=True)
            lr = optimizer.param_groups[0]["lr"]
            optimizer.step()
            scheduler.step()
            torch.cuda.synchronize(device)
            duration = time.monotonic() - step_started
            if step == start_step + 1 or step % args.log_every == 0:
                emit(step=step, epoch=stream.epoch, loss=float(loss.detach()), **metrics,
                     grad_norm=float(norm), lr=lr, step_seconds=round(duration, 3),
                     data_wait_seconds=round(data_wait, 3), compute_seconds=round(duration - data_wait, 3),
                     elapsed_seconds=round(time.monotonic() - started, 3),
                     peak_allocated_GiB=round(torch.cuda.max_memory_allocated(device) / 2**30, 3),
                     peak_reserved_GiB=round(torch.cuda.max_memory_reserved(device) / 2**30, 3))
            del data, loss, metrics
            if step % args.save_every == 0 or step == args.max_steps:
                save_checkpoint(args.output / f"step_{step:07d}.pt", model, optimizer, scheduler,
                                step, stream, config, model_config, train_config, initialization)
    finally:
        stream.close()


if __name__ == "__main__":
    main()
