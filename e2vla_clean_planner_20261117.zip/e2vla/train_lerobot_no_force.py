"""Train the unchanged original E2VLA on LeRobot, without force or speed.

The two trainers keep their respective model architectures and checkpoint
formats. Inference selects the architecture from checkpoint metadata.
"""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import random
import time

import cv2
import numpy as np
import torch

from data_utils.lerobot_no_force import (
    LeRobotNoForceConfig, LeRobotNoForceDataset, collate_lerobot_no_speed,
)
from train_lerobot_vel_no_force import (
    TrainingStream, comparable_data, emit, lr_multiplier, rng_state, restore_rng,
)


FORMAT = "e2vla_lerobot_no_force_no_speed_v1"
DEFAULT_DATA_CONFIG = Path(__file__).with_name("configs_lerobot_no_force") / "huawei_close_box.json"


def build_model(diffusion_timesteps=100, inference_timesteps=20):
    from models.vla import vla_base
    return vla_base(diffusion_timesteps=diffusion_timesteps,
                    inference_timesteps=inference_timesteps)


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    source = result.add_mutually_exclusive_group()
    source.add_argument("--config", type=Path, help="Training recipe JSON with data and training sections")
    source.add_argument("--data-config", type=Path, default=DEFAULT_DATA_CONFIG)
    result.add_argument("--data-root")
    result.add_argument("--check-data", action="store_true")
    result.add_argument("--batch-size", type=int, default=32)
    result.add_argument("--workers", type=int, default=4)
    result.add_argument("--threads", type=int, default=4)
    result.add_argument("--max-steps", type=int, default=100000)
    result.add_argument("--lr", type=float, default=1e-4)
    result.add_argument("--weight-decay", type=float, default=1e-5)
    result.add_argument("--warmup-steps", type=int, default=2000)
    result.add_argument("--grad-clip", type=float, default=1.)
    result.add_argument("--seed", type=int, default=42)
    result.add_argument("--device", default="cuda:0")
    result.add_argument("--inference-timesteps", type=int, default=20)
    result.add_argument("--save-every", type=int, default=2000)
    result.add_argument("--log-every", type=int, default=10)
    result.add_argument("--output", type=Path, default=Path("checkpoints/lerobot_no_force_no_speed_close_box"))
    result.add_argument("--resume", type=Path)
    result.add_argument("--pretrained", type=Path, help="Initialize actor weights only; --resume takes precedence")
    return result


def parse_args(argv=None):
    probe = argparse.ArgumentParser(add_help=False)
    probe.add_argument('--config', type=Path)
    selected, _ = probe.parse_known_args(argv)
    cli = parser()
    recipe = None
    if selected.config is not None:
        recipe = json.loads(selected.config.read_text())
        if set(recipe) != {'data', 'training'}:
            cli.error('Recipe must contain exactly data and training objects')
        allowed = {'batch_size', 'workers', 'threads', 'max_steps', 'lr', 'weight_decay',
                   'warmup_steps', 'grad_clip', 'seed', 'device', 'inference_timesteps',
                   'save_every', 'log_every', 'output', 'pretrained'}
        if not isinstance(recipe['data'], dict) or not isinstance(recipe['training'], dict):
            cli.error('Recipe data and training must be objects')
        if set(recipe['training']) - allowed:
            cli.error(f"Unknown training options: {sorted(set(recipe['training']) - allowed)}")
        defaults = dict(recipe['training'])
        for name in ('output', 'pretrained'):
            if defaults.get(name) is not None:
                path = Path(defaults[name]).expanduser()
                defaults[name] = path if path.is_absolute() else (selected.config.parent / path).resolve()
        cli.set_defaults(**defaults)
    args = cli.parse_args(argv)
    args.recipe_data = None if recipe is None else recipe['data']
    return args


def load_data_config(args):
    values = (dict(args.recipe_data) if args.recipe_data is not None
              else json.loads(args.data_config.read_text()))
    if args.data_root is not None:
        values['root'] = args.data_root
    cls = LeRobotNoForceConfig
    if 'reviewed_datasets' in values:
        from data_utils.lerobot_reviewed_no_force import ReviewedNoForceConfig
        cls = ReviewedNoForceConfig
    result = cls(**values)
    result.validate()
    return result


def build_dataset(config):
    if getattr(config, 'reviewed_datasets', None) is not None:
        from data_utils.lerobot_reviewed_no_force import ReviewedNoForceDataset
        return ReviewedNoForceDataset(config)
    return LeRobotNoForceDataset(config)


def load_pretrained_actor(model, path):
    """Strictly load the original E2VLA actor, without optimizer/step state."""
    # The user-specified local checkpoint is trusted and uses the original format.
    saved = torch.load(path, map_location='cpu', weights_only=False)
    if not isinstance(saved, dict) or 'weights' not in saved:
        raise ValueError('Expected an original E2VLA pretrained checkpoint with weights')
    model.actor.load_state_dict(saved['weights'], strict=True)
    result = dict(pretrained=str(Path(path).resolve()), pretrained_tensors=len(saved['weights']))
    emit(**result)
    return result


def check_resume(checkpoint, data_config, model_config, train_config):
    if checkpoint.get("format") != FORMAT:
        raise ValueError("Resume requires this no-force/no-speed checkpoint format")
    if comparable_data(checkpoint["data_config"]) != comparable_data(asdict(data_config)):
        raise ValueError("Resume data/calibration conventions differ")
    if checkpoint["model_config"] != model_config or checkpoint["train_config"] != train_config:
        raise ValueError("Resume model/training options differ")


def save_checkpoint(path, model, optimizer, scheduler, step, stream,
                    data_config, model_config, train_config):
    payload = dict(format=FORMAT, actor=model.actor.state_dict(), optimizer=optimizer.state_dict(),
                   scheduler=scheduler.state_dict(), step=step, epoch=stream.epoch,
                   batch_in_epoch=stream.batch_in_epoch, rng=rng_state(),
                   data_config=asdict(data_config), model_config=model_config, train_config=train_config)
    temporary = path.with_suffix(".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)
    emit(checkpoint=str(path), step=step)


def main(argv=None):
    args = parse_args(argv)
    positive = (args.batch_size, args.threads, args.max_steps, args.save_every,
                args.log_every, args.inference_timesteps)
    if (min(positive) < 1 or args.workers < 0 or args.warmup_steps < 0
            or not np.isfinite([args.lr, args.grad_clip, args.weight_decay]).all()
            or args.lr <= 0 or args.grad_clip <= 0 or args.weight_decay < 0):
        raise ValueError("Invalid training options")
    torch.set_num_threads(args.threads)
    cv2.setNumThreads(1)
    config = load_data_config(args)
    if args.pretrained is not None and args.resume is None and not args.pretrained.is_file():
        raise FileNotFoundError(f'Pretrained checkpoint not found: {args.pretrained}')
    dataset = build_dataset(config)
    stream = None
    try:
        model_config = dict(diffusion_timesteps=100, inference_timesteps=args.inference_timesteps)
        if args.check_data:
            for index in sorted({0, len(dataset) // 2, len(dataset) - 1}):
                sample = dataset[index]
                for value in sample.values():
                    if torch.is_tensor(value) and not torch.isfinite(value).all():
                        raise ValueError(f"Nonfinite sample at {index}")
                emit(index=index, shapes={key: list(value.shape) for key, value in sample.items()
                                         if torch.is_tensor(value)}, prompt=sample["prompt_text"])
            emit(status="data_ok", variant=FORMAT, episodes=len(dataset.episodes),
                 samples=len(dataset), fps=dataset.fps, horizon=config.num_future_actions,
                 sample_fps=dataset.fps / config.frame_stride,
                 reviewed_datasets=getattr(config, 'reviewed_datasets', None),
                 segments=len(dataset.segments) if hasattr(dataset, 'segments') else None,
                 pretrained=str(args.pretrained) if args.pretrained else None,
                 output=str(args.output), speed_conditioning=False, force_conditioning=False)
            return
        if args.output.exists() and any(args.output.iterdir()) and args.resume is None:
            raise FileExistsError("Output is nonempty; use --resume or a new --output directory")
        device = torch.device(args.device)
        if device.type != "cuda" or not torch.cuda.is_available():
            raise RuntimeError("Training requires CUDA; --check-data works on CPU")
        torch.cuda.set_device(device)
        if not torch.cuda.is_bf16_supported():
            raise RuntimeError("BF16 training requires an Ampere or newer GPU")
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)
        train_config = {key: getattr(args, key) for key in (
            "batch_size", "max_steps", "lr", "weight_decay", "warmup_steps", "grad_clip", "seed")}
        if args.pretrained is not None:
            train_config['pretrained'] = str(args.pretrained.resolve())
        checkpoint = None
        if args.resume:
            # Only load trusted local checkpoints, including their RNG states.
            checkpoint = torch.load(args.resume, map_location="cpu", weights_only=False)
            check_resume(checkpoint, config, model_config, train_config)
            if checkpoint["step"] >= args.max_steps:
                emit(status="already_complete", step=checkpoint["step"])
                return
        collate_lerobot_no_speed([dataset[0]])
        dataset.close()
        model = build_model(**model_config).to(device).train()
        if checkpoint is None and args.pretrained is not None:
            load_pretrained_actor(model, args.pretrained)
        decay, no_decay = model.parameter_groups()
        optimizer = torch.optim.AdamW([{"params": decay, "weight_decay": args.weight_decay},
                                       {"params": no_decay, "weight_decay": 0.}], lr=args.lr)
        scheduler = torch.optim.lr_scheduler.LambdaLR(
            optimizer, lambda step: lr_multiplier(step, args.warmup_steps, args.max_steps))
        start_step, epoch, batch_in_epoch = 0, 0, 0
        if checkpoint:
            model.actor.load_state_dict(checkpoint["actor"], strict=True)
            optimizer.load_state_dict(checkpoint["optimizer"])
            scheduler.load_state_dict(checkpoint["scheduler"])
            start_step, epoch, batch_in_epoch = (checkpoint[k] for k in ("step", "epoch", "batch_in_epoch"))
            restore_rng(checkpoint["rng"])
            del checkpoint
        stream = TrainingStream(dataset, collate_lerobot_no_speed, args.batch_size,
                                args.workers, args.seed, epoch, batch_in_epoch)
        args.output.mkdir(parents=True, exist_ok=True)
        (args.output / "config.json").write_text(json.dumps(
            dict(variant=FORMAT, data=asdict(config), model=model_config, train=train_config),
            ensure_ascii=False, indent=2))
        emit(status="training", variant=FORMAT, gpu=torch.cuda.get_device_name(device),
             trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
             frozen_parameters=sum(p.numel() for p in model.parameters() if not p.requires_grad),
             batch_size=args.batch_size, arms=2, action_dim_per_arm=10,
             samples=len(dataset), horizon=config.num_future_actions, speed_conditioning=False)
        torch.cuda.reset_peak_memory_stats(device)
        started = time.monotonic()
        for step in range(start_step + 1, args.max_steps + 1):
            step_started = time.monotonic()
            data = stream.next()
            data_wait = time.monotonic() - step_started
            data = {key: value.to(device, non_blocking=True) if torch.is_tensor(value) else value
                    for key, value in data.items()}
            optimizer.zero_grad(set_to_none=True)
            loss, metrics = model(**data, inference=False, fp16=True)
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Nonfinite loss at step {step}")
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(decay + no_decay, args.grad_clip, error_if_nonfinite=True)
            lr = optimizer.param_groups[0]["lr"]
            optimizer.step()
            scheduler.step()
            torch.cuda.synchronize(device)
            duration = time.monotonic() - step_started
            if step == start_step + 1 or step % args.log_every == 0:
                emit(step=step, epoch=stream.epoch, loss=float(loss.detach()), **metrics,
                     grad_norm=float(norm), lr=lr, step_seconds=round(duration, 3),
                     data_wait_seconds=round(data_wait, 3), compute_seconds=round(duration - data_wait, 3),
                     elapsed_seconds=round(time.monotonic() - started, 3),
                     peak_allocated_GiB=round(torch.cuda.max_memory_allocated(device) / 2**30, 3),
                     peak_reserved_GiB=round(torch.cuda.max_memory_reserved(device) / 2**30, 3))
            del data, loss, metrics
            if step % args.save_every == 0 or step == args.max_steps:
                save_checkpoint(args.output / f"step_{step:07d}.pt", model, optimizer, scheduler,
                                step, stream, config, model_config, train_config)
    finally:
        if stream is not None:
            stream.close()
        else:
            dataset.close()


if __name__ == "__main__":
    main()
