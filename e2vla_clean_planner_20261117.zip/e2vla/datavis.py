"""Visualize the supported LeRobot policies."""
import sys
from datavis_lerobot import main

if __name__ == "__main__":
    if "--lerobot" in sys.argv:
        sys.argv.remove("--lerobot")
    main()
