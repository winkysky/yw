# 统一 Planner / Pyro4 推理

`infer_utils.remote_service.Service` 继承统一 `LeRobotTrajPlanner`，由服务器的 `LeRobotDataSampler` 缓存历史观测、处理图像和相机几何，再调用模型。机器人客户端负责采集与执行。无速度版与连续速度版、关盒/开盒/放手机都使用 `configs_inference/planner.json`，从 checkpoint 自动识别任务和网络。

## 启动

在项目根目录，使用 e2vla Python 环境。先在一个终端启动 NameServer：

```bash
python -m Pyro4.naming -n 127.0.0.1 -p 9090
```

另一个终端启动所需模型。无速度版示例：

```bash
python -m infer_utils.remote_service --config configs_inference/planner.json \
  --checkpoint /nas_data_new/hq/91e2vla/close_box_15hz_no_force_no_speed \
  --device cuda:0
```

连续速度版使用同一入口和配置：

```bash
python -m infer_utils.remote_service --config configs_inference/planner.json \
  --checkpoint /nas_data_new/hq/91e2vla/close_box_30hz_no_force_speed \
  --device cuda:0 --speed-mps 0.05
```

checkpoint 可指定 `.pt` 文件，或目录中步数最大的已保存 `step_*.pt`；目录只在启动时解析，不自动热换权重。开盒/放手机换相应 checkpoint 路径即可。`speed_mps` 是条件速度，单位 m/s；不是倍率，也不是推理频率。

默认服务名 `e2vla`、端口 9101；同时开多个实例时显式指定各自的 `--uri` 和 `--port`。跨机器运行时，NameServer 使用 `-n SERVER_IP`，服务使用 `--host SERVER_IP --ns-host SERVER_IP`，客户端使用同一 NameServer 地址；需能访问 9090 和服务端口。

`--check-config` 只检查配置和 checkpoint 路径。`--device cpu --threads 4` 可用于 CPU 检查；默认 FP32，CUDA 可加 `--bf16`。去噪步数默认读取 checkpoint，`--inference-timesteps` 可覆盖；它与 32 个预测动作点无关。旧模块名 `infer_utils.lerobot_remote_service` 保留为同一入口的兼容别名。

## 配置

唯一配置 `configs_inference/planner.json` 可填写 checkpoint，也可每次通过命令行传入。

| 设置 | 含义 |
|---|---|
| checkpoint | checkpoint 文件或目录；必需 |
| device / bf16 / inference_timesteps | 推理设备、精度、去噪次数 |
| prompt | 默认任务指令，也可通过 `set_prompt` 设置 |
| speed_mps / guidance_scale | 连续速度条件及 guidance，后者默认 1 |
| input_pose_format | 默认 `tcp_world`；原始记录格式使用 `recorded` |
| input_gripper_format | 默认 `openness`；原始记录夹爪数值使用 `raw` |
| color_order | 默认 RGB；每帧也可显式指定 rgb/bgr |
| ensemble | 默认 0；调用 `ensemble_traj` 时才启用位置/夹爪融合 |
| host / port / uri / ns_host / ns_port | 监听及服务发现 |

没有 `inference_fps`，无需按训练频率另建配置。可选 `task` / `variant` 仅用于额外核对，不必填写。

## 与原 Planner 相同的调用流程

```python
from shm_transport import get_shm_proxy

proxy = get_shm_proxy('e2vla', ns_host='127.0.0.1', ns_port=9090,
                      force_use_socket=True)
proxy.reset()
proxy.set_prompt('与该任务训练一致的指令')
# 只有连续速度版需要：proxy.set_speed(0.05)
for frame in observed_frames:  # 来自机器人实际反馈和三相机
    proxy.add_obs_frame(frame)
result = proxy.get_action(draw_traj=False)
if result is not None:
    poses, grippers, times, image = result
    # poses: (32,2,4,4), grippers: (32,2), times: (32,)
```

历史不足时 `get_action()` 返回 None，`get_status()` 提供原因；不会用复制历史填充。一次观测格式：

```python
frame = {
    'timestamp': timestamp_seconds,
    'ee_pose': left_base_tcp_poses,  # float (2,4,4)，左、右；米
    'gripper': openness,            # float (2,)，0=关，1=开
    'observation.images.head_image': {
        'camera': {'K': original_camera_K},
        'data': {'color': image_hwc_uint8, 'encoding': 'rgb',
                 'timestep': image_timestamp_seconds,
                 'wcT': left_base_T_camera},
    },
    # 同样提供 observation.images.left_wrist_image、observation.images.right_wrist_image
}
```

`wcT` 可省略，由当前双臂 TCP 和 checkpoint 标定计算；提供时会核对。图像使用标定的原始分辨率，服务端按训练相同方式缩放。也支持 `data.color_jpeg` 字节。相机名和内参需匹配 checkpoint。时间戳严格递增，同一帧的相机和状态时间差不超过 35 ms。

- `tcp_world`：输入已经是左臂 base 下真实 TCP，右臂不再变换。
- `recorded`：输入为训练记录中的双臂打包位姿，复用训练 `decode_tcp`，统一单位、工具偏置及左右 base。
- `raw` 夹爪：每臂一个原始值，按 checkpoint 转换；当前数据为 1886=关、0=开。

输出固定左、右顺序，均为左臂 base 下 TCP；输出夹爪未裁剪。第一个目标对应当前观测时刻的 `action.tcp_pose_cmd`，后面是训练所定义的后续动作点。

## 时间语义和状态

服务按每次 `get_action()` 请求推理，调用频率由客户端决定。训练取样间隔仅用于从缓存中选取与训练一致的五步实测历史，并生成轨迹点时间；不限制请求频率。机器人执行接口自行决定插值、执行时钟和重规划周期。连续速度条件的 m/s 含义基于训练时间轴，改变执行时间会改变实际速度。

一个服务实例维护一条观测历史；新任务/新会话调用 `reset()`，再设置指令。不要让多个机器人向同一实例混写观测。`set_config()` 仅可改运行时指令、速度、随机种子、融合和输入格式；切换 checkpoint 重启服务。`get_config()` 返回 checkpoint 数据配置，`get_planner_config()` 返回运行时配置。

`run_inference(obs_data, ...)` 保留无历史缓存的批量接口，接收训练读取器构造的完整模型输入，输出 CPU Tensor `(B,32,2,17)`；`run_inference_numpy` 返回相同 NumPy 数组。前 16 维为 TCP 齐次矩阵，最后一维为夹爪。服务自行创建未来占位张量，不读取真实未来动作。

## 可视化

```bash
python datavis.py --uri e2vla --gui
# 连续速度模型：
python datavis.py --uri e2vla --speed-mps 0.05 --gui
```

可视化从客户端本地数据集读取观测；机器人在线观测不需要训练数据。使用说明见 `README_datavis_lerobot.md`；机器人客户端见 `e03_lerobot_client/README.md`。
