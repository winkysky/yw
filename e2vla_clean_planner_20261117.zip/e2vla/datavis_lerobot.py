"""Visualize LeRobot dual-arm E2VLA commands and local/Pyro4 predictions.

Uses the training reader and calibration, including reviewed segments and the
right-base alignment. Export PNG/HTML/NPZ offline, or use --gui to browse samples.
"""
import argparse
from bisect import bisect_right
from collections import OrderedDict
from dataclasses import asdict
import html
import json
import os
from pathlib import Path
import tempfile

os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'e2vla-datavis-mpl'))
os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')

import cv2
import numpy as np
import torch
from scipy.spatial.transform import Rotation

from data_utils.lerobot_no_force import INPUT_KEYS, collate_lerobot_no_speed
from data_utils.lerobot_reviewed_no_force import ReviewedNoForceConfig
from train_lerobot_no_force import FORMAT, build_dataset, build_model
from lerobot_inference import RemoteLeRobotPolicy, LeRobotPolicy, make_data_config, SPEED_FORMAT


COLORS = (('#00b8e6', '#ff9100'), ('#28c96f', '#f052cf'))
CAMERA_NAMES = {'head_image': 'Head camera', 'left_wrist_image': 'Left wrist camera',
                'right_wrist_image': 'Right wrist camera'}


def data_config(values):
    return make_data_config(values)


def resized_intrinsics(config, key):
    """Match the reader's OpenCV half-pixel resize convention exactly."""
    camera = config.geometry['cameras'][key]
    h, w = config.image_size
    h0, w0 = camera['image_size']
    scale = np.array([[w/w0, 0, .5*w/w0-.5], [0, h/h0, .5*h/h0-.5], [0, 0, 1.]])
    return scale @ np.asarray(camera['K'])


def project_points(points, world_T_camera, intrinsics):
    """Return image coordinates; never connect trajectories through/behind camera."""
    points = np.asarray(points, dtype=np.float64)
    camera_T_world = np.linalg.inv(np.asarray(world_T_camera, dtype=np.float64))
    camera_xyz = points @ camera_T_world[:3, :3].T + camera_T_world[:3, 3]
    projected = camera_xyz @ np.asarray(intrinsics).T
    valid = np.isfinite(projected).all(axis=-1) & (camera_xyz[..., 2] > 1e-4)
    uv = np.full(points.shape[:-1] + (2,), np.nan)
    np.divide(projected[..., :2], projected[..., 2:3], out=uv, where=valid[..., None])
    return uv, valid


def poses(states):
    return np.asarray(states)[..., :16].reshape(*states.shape[:-1], 4, 4)


def trajectory_metrics(prediction, target):
    pp, gp = poses(prediction), poses(target)
    result = {}
    for arm, name in enumerate(('left', 'right')):
        error_mm = np.linalg.norm(pp[:, arm, :3, 3] - gp[:, arm, :3, 3], axis=-1) * 1000
        # Rotation.from_matrix orthogonalizes the small rounding residual in
        # the supplied calibration; this does not alter exported trajectories.
        rel = Rotation.from_matrix(gp[:, arm, :3, :3]).inv() * Rotation.from_matrix(pp[:, arm, :3, :3])
        result[name] = dict(position_mean_error_mm=float(error_mm.mean()),
                            position_endpoint_error_mm=float(error_mm[-1]),
                            rotation_mean_error_deg=float(np.rad2deg(rel.magnitude()).mean()),
                            gripper_mean_abs_error=float(np.abs(prediction[:, arm, 16]-target[:, arm, 16]).mean()))
    return result


def inference_inputs(sample, device):
    # Dataset speed/success labels are training targets, never inference conditions.
    batch = collate_lerobot_no_speed([{key: sample[key] for key in INPUT_KEYS}])
    batch = {k: v.to(device) if torch.is_tensor(v) else v for k, v in batch.items()}
    # The original policy requires this argument only to obtain output shape.
    # Do not pass real future commands into the inference call.
    batch['gt_future_ee_states'] = torch.zeros_like(batch['gt_future_ee_states'])
    return batch


class Viewer:
    def __init__(self, args):
        self.args = args
        self.remote = None
        values = None
        recipe = None
        if args.config:
            recipe = json.loads(args.config.read_text())
            values = recipe.get('data', recipe)
        self.checkpoint_path = args.checkpoint
        if args.uri:
            if args.checkpoint or args.data_only or args.bf16 or args.inference_timesteps is not None or args.device != 'auto':
                raise ValueError('--uri selects a remote model; checkpoint/device/BF16/denoising steps are server options')
            self.remote = RemoteLeRobotPolicy(args.uri, args.ns_host, args.ns_port, args.timeout, args.shared_memory)
            if values is not None:
                try:
                    self.remote.check_config(data_config(values))
                except BaseException:
                    self.remote.close()
                    raise
            else:
                values = self.remote.info['data_config']
            self.checkpoint_path = Path(self.remote.info['checkpoint'])
        if self.remote is None and not args.data_only and self.checkpoint_path is None and recipe and 'training' in recipe:
            folder = Path(recipe['training']['output']).expanduser()
            if not folder.is_absolute():
                folder = args.config.parent / folder
            candidates = sorted(folder.glob('step_*.pt'))
            if candidates:
                self.checkpoint_path = candidates[-1]
        if not args.data_only and self.checkpoint_path is None:
            raise ValueError('Supply --checkpoint, or --config with a saved training checkpoint')
        checkpoint = None
        if self.checkpoint_path is not None and self.remote is None:
            checkpoint = torch.load(self.checkpoint_path, map_location='cpu', weights_only=False, mmap=True)
            if checkpoint.get('format') not in (FORMAT, SPEED_FORMAT):
                raise ValueError(f'Expected a {FORMAT} checkpoint')
            saved_values = checkpoint['data_config']
            if values is not None and asdict(data_config(values)) != asdict(data_config(saved_values)):
                raise ValueError('Config differs from checkpoint data/calibration; use its matching recipe')
            values = saved_values
        if values is None:
            raise ValueError('--data-only requires --config or --checkpoint')
        self.config = data_config(values)
        try:
            if self.config.speed_factors is not None:
                from train_lerobot_vel_no_force import build_dataset as build_speed_dataset
                if not args.data_only and getattr(args, 'speed_mps', None) is None:
                    raise ValueError('Supply --speed-mps when visualizing a speed model')
                self.dataset = build_speed_dataset(self.config)
            else:
                if getattr(args, 'speed_mps', None) is not None:
                    raise ValueError('--speed-mps applies only to a speed model')
                self.dataset = build_dataset(self.config)
        except BaseException:
            if self.remote is not None:
                self.remote.close()
            raise
        self.model = None
        self.cache = OrderedDict()
        try:
            self.device = torch.device('cpu' if self.remote is not None else
                                       (('cuda:0' if torch.cuda.is_available() else 'cpu') if args.device == 'auto' else args.device))
            if self.device.type == 'cuda' and not torch.cuda.is_available():
                raise RuntimeError('CUDA is unavailable here; use --device cpu')
            if args.bf16 and (self.device.type != 'cuda' or not torch.cuda.is_bf16_supported()):
                raise ValueError('--bf16 requires a CUDA device with BF16 support')
            self.checkpoint_step = None if checkpoint is None else int(checkpoint['step'])
            self.model_config = None
            if self.remote is not None:
                self.checkpoint_step = self.remote.info['checkpoint_step']
                self.model_config = self.remote.info['model_config']
            elif not args.data_only:
                self.local_policy = LeRobotPolicy(self.checkpoint_path, str(self.device), args.bf16,
                                                  args.inference_timesteps)
                self.model = self.local_policy.model
                self.model_config = self.local_policy.model_config
            self.episode_starts = [0]
            if hasattr(self.dataset, 'windows'):
                identities = [(self.dataset.segments[int(s)]['dataset_name'],
                               self.dataset.segments[int(s)]['episode_index']) for s in self.dataset.windows[:, 0]]
                self.episode_starts += [i for i in range(1, len(identities)) if identities[i] != identities[i-1]]
            elif getattr(self.dataset, 'retime_index', None) is not None:
                self.episode_starts += [int(i) for i in self.dataset.retime_index.ends[:-1]]
            else:
                self.episode_starts += [int(i) for i in self.dataset.ends[:-1]]
            print(json.dumps(dict(status='ready', samples=len(self.dataset), checkpoint=str(self.checkpoint_path),
                                  step=self.checkpoint_step, device=str(self.device))), flush=True)
        except BaseException:
            self.close()
            raise

    def sample(self, index, inference=True):
        if not 0 <= index < len(self.dataset):
            raise IndexError(f'Index {index} outside [0, {len(self.dataset)-1}]')
        sample = self.dataset[index]
        numeric = self.dataset.numeric_sample(index)
        prediction = None
        if inference and (self.model is not None or self.remote is not None):
            if index not in self.cache:
                policy = self.remote if self.remote is not None else self.local_policy
                pred = policy.run_inference(inference_inputs(sample, 'cpu'), seed=self.args.seed + index,
                                            speed_mps=getattr(self.args, 'speed_mps', None))
                if tuple(pred.shape) != (1, self.config.num_future_actions, 2, 17) or not torch.isfinite(pred).all():
                    raise ValueError('Invalid dual-arm inference output')
                self.cache[index] = pred[0].float().cpu().numpy()
                while len(self.cache) > 16:
                    self.cache.popitem(last=False)
            self.cache.move_to_end(index)
            prediction = self.cache[index]
        source_episode = numeric.get('source_episode_index', numeric['episode_index'])
        metadata = dict(index=index, dataset=numeric.get('dataset_name', Path(self.config.root).name),
                        episode=int(source_episode), frame=int(numeric['frame']),
                        prompt=numeric['prompt_text'], checkpoint=str(self.checkpoint_path),
                        checkpoint_step=self.checkpoint_step, seed=self.args.seed + index,
                        sample_fps=self.dataset.fps/self.config.frame_stride,
                        horizon=self.config.num_future_actions, world_frame='left_recorded_arm_base',
                        device=self.remote.info['device'] if self.remote is not None else str(self.device),
                        bf16=self.remote.info['bf16'] if self.remote is not None else self.args.bf16,
                        model_config=self.model_config, remote_uri=self.args.uri, speed_mps=getattr(self.args, 'speed_mps', None),
                        scope='Offline prediction on a training sample, not a held-out evaluation or closed-loop rollout')
        if prediction is not None:
            metadata['metrics'] = trajectory_metrics(prediction, sample['gt_future_ee_states'].numpy())
        return sample, prediction, metadata

    def close(self):
        self.dataset.close()
        if self.remote is not None:
            self.remote.close()


def render(sample, prediction, config, metadata):
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.lines import Line2D
    fig = Figure(figsize=(15, 10), dpi=110, facecolor='white')
    canvas = FigureCanvasAgg(fig)
    gt = sample['gt_future_ee_states'].numpy()
    current = sample['current_ee_pose'].numpy()
    trajectories = [poses(gt)] + ([] if prediction is None else [poses(prediction)])
    rgb = sample['obs_rgbs'][-1].permute(0, 2, 3, 1).numpy()
    extrinsics = sample['obs_extrinsics'][-1].numpy()
    for camera, key in enumerate(config.camera_keys):
        ax = fig.add_subplot(2, 3, camera + 1)
        ax.imshow(np.clip(rgb[camera], 0, 1))
        k = resized_intrinsics(config, key)
        for arm in range(2):
            for typ, trajectory in enumerate(trajectories):
                uv, _ = project_points(trajectory[:, arm, :3, 3], extrinsics[camera], k)
                ax.plot(uv[:, 0], uv[:, 1], '-' if typ == 0 else '--', color=COLORS[arm][typ],
                        lw=1.8, marker='o' if arm == 0 else 's', markersize=2.3, markevery=4)
            uv, _ = project_points(current[arm, :3, 3][None], extrinsics[camera], k)
            ax.plot(uv[:, 0], uv[:, 1], '*', color='white', markeredgecolor='black', markersize=10)
        h, w = config.image_size
        ax.set(xlim=(-.5, w-.5), ylim=(h-.5, -.5))
        ax.set_title(CAMERA_NAMES.get(key.split('.')[-1], key), fontsize=12)
        ax.set_axis_off()
    for arm, name in enumerate(('Left', 'Right')):
        ax = fig.add_subplot(2, 3, 4 + arm, projection='3d')
        all_points = [current[arm, :3, 3][None]]
        for typ, trajectory in enumerate(trajectories):
            xyz = trajectory[:, arm, :3, 3]
            all_points.append(xyz)
            ax.plot(*xyz.T, '-' if typ == 0 else '--', color=COLORS[arm][typ], lw=2)
            ax.scatter(*xyz[-1], color=COLORS[arm][typ], s=25)
        ax.scatter(*current[arm, :3, 3], color='black', marker='*', s=65)
        points = np.concatenate(all_points)
        center = (points.max(axis=0) + points.min(axis=0))/2
        radius = max(np.ptp(points, axis=0).max()/2*1.15, .015)
        ax.set(xlim=(center[0]-radius, center[0]+radius), ylim=(center[1]-radius, center[1]+radius),
               zlim=(center[2]-radius, center[2]+radius), xlabel='X (m)', ylabel='Y (m)', zlabel='Z (m)')
        ax.set_box_aspect((1, 1, 1))
        ax.tick_params(labelsize=8)
        title = f'{name} TCP | left-base frame'
        if prediction is not None:
            m = metadata['metrics'][name.lower()]
            title += f"\nMean error: {m['position_mean_error_mm']:.1f} mm / {m['rotation_mean_error_deg']:.1f} deg"
        ax.set_title(title, fontsize=11)
    ax = fig.add_subplot(2, 3, 6)
    times = np.arange(len(gt)) / metadata['sample_fps']
    for arm in range(2):
        ax.plot(times, gt[:, arm, 16], color=COLORS[arm][0], lw=2)
        if prediction is not None:
            ax.plot(times, prediction[:, arm, 16], '--', color=COLORS[arm][1], lw=2)
    ax.set(xlabel='Future time (s)', ylabel='Gripper openness', title='Gripper: 0 = closed, 1 = open')
    ax.grid(alpha=.2)
    low, high = ax.get_ylim()
    ax.set_ylim(min(low, -.05), max(high, 1.05))
    handles = [Line2D([0], [0], color=COLORS[arm][typ], ls='-' if typ == 0 else '--', lw=2,
                      label=f'{name} {label}') for arm, name in enumerate(('Left', 'Right'))
               for typ, label in enumerate(('GT command', 'prediction')) if typ == 0 or prediction is not None]
    fig.legend(handles=handles, ncol=len(handles), loc='upper center', bbox_to_anchor=(.5, .92), frameon=False)
    fig.suptitle(f"{metadata['dataset']} | episode {metadata['episode']} | frame {metadata['frame']} | sample {metadata['index']}",
                 fontsize=14, fontweight='bold', y=.99)
    fig.text(.5, .947, f"Checkpoint step {metadata['checkpoint_step']} | {metadata['horizon']} future commands at {metadata['sample_fps']:g} Hz | stars: current TCP", ha='center', fontsize=11)
    fig.text(.5, .018, 'Three views show the anchor observation. Wrist-camera poses are fixed at that anchor. Offline training-sample comparison.',
             ha='center', fontsize=10, color='#555555')
    fig.subplots_adjust(left=.05, right=.97, bottom=.10, top=.865, hspace=.32, wspace=.25)
    canvas.draw()
    rgb_output = np.asarray(canvas.buffer_rgba())[..., :3].copy()
    return rgb_output


def save_sample(output, sample, prediction, config, metadata, rendered):
    output.mkdir(parents=True, exist_ok=True)
    stem = f"sample_{metadata['index']:06d}"
    if not cv2.imwrite(str(output / f'{stem}.png'), cv2.cvtColor(rendered, cv2.COLOR_RGB2BGR)):
        raise OSError('Could not write visualization')
    arrays = dict(target=sample['gt_future_ee_states'].numpy(), current=sample['current_ee_pose'].numpy(),
                  history=sample['history_ee_states'].numpy(), world_T_cameras=sample['obs_extrinsics'][-1].numpy(),
                  K=np.stack([resized_intrinsics(config, key) for key in config.camera_keys]))
    if prediction is not None:
        arrays['prediction'] = prediction
    np.savez_compressed(output / f'{stem}.npz', **arrays)
    (output / f'{stem}.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n')
    return dict(metadata, image=f'{stem}.png', arrays=f'{stem}.npz', metadata=f'{stem}.json')


def write_gallery(output, records):
    (output / 'manifest.json').write_text(json.dumps(records, ensure_ascii=False, indent=2)+'\n')
    options = ''.join(f'<option value="{i}">{html.escape(r["dataset"])} / episode {r["episode"]} / frame {r["frame"]}</option>' for i, r in enumerate(records))
    cards = ''.join(f'<section id="sample-{i}" {"hidden" if i else ""}><p>{html.escape(r["prompt"])}</p>'
                    f'<img src="{r["image"]}" alt="Dual-arm trajectory comparison">'
                    f'<p><a href="{r["image"]}">PNG</a> · <a href="{r["arrays"]}">轨迹 NPZ</a> · '
                    f'<a href="{r["metadata"]}">样本信息 / 误差</a></p></section>' for i, r in enumerate(records))
    (output / 'index.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1"><title>LeRobot 双臂推理轨迹</title>'
        '<style>body{font:16px sans-serif;max-width:1650px;margin:24px auto;padding:0 16px;background:#f5f6f8;color:#18202b}'
        'img{width:100%;background:white}select,button{font:inherit;padding:8px;margin:4px}a{color:#1265b1}</style>'
        '<h1>LeRobot 双臂推理轨迹</h1><p>实线：数据中的目标 TCP 指令；虚线：模型预测；星号：当前 TCP。'
        '坐标统一在左臂 base。相机画面与外参固定在当前观测帧。这里展示训练样本上的离线预测，不代表闭环成功率。</p>'
        f'<button onclick="move(-1)">上一个</button><select id="choose" onchange="show()">{options}</select>'
        '<button onclick="move(1)">下一个</button>'+cards+
        '<script>const choose=document.getElementById("choose");function show(){document.querySelectorAll("section").forEach((s,i)=>s.hidden=i!==choose.selectedIndex)}'
        'function move(d){choose.selectedIndex=(choose.selectedIndex+d+choose.length)%choose.length;show()}</script></html>')


def browse(viewer, output, start):
    if not os.environ.get('DISPLAY'):
        raise RuntimeError('--gui requires a desktop DISPLAY; omit --gui to export HTML/PNG')
    index, stride, infer = start, 1, viewer.model is not None or getattr(viewer, 'remote', None) is not None
    print('Keys: n/p episode; right/d and left/h sample; a stride 1/10; i inference; s save; q quit', flush=True)
    cv2.namedWindow('LeRobot dual-arm trajectories', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('LeRobot dual-arm trajectories', 1320, 880)
    try:
        while True:
            sample, prediction, metadata = viewer.sample(index, infer)
            rendered = render(sample, prediction, viewer.config, metadata)
            cv2.imshow('LeRobot dual-arm trajectories', cv2.cvtColor(rendered, cv2.COLOR_RGB2BGR))
            key = cv2.waitKeyEx(0)
            if key in (ord('q'), 27, -1):
                break
            if key in (ord('d'), 83, 65363, 2555904):
                index = min(index + stride, len(viewer.dataset)-1)
            elif key in (ord('h'), 81, 65361, 2424832):
                index = max(index - stride, 0)
            elif key in (ord('n'), ord('p')):
                ep = bisect_right(viewer.episode_starts, index)-1
                index = viewer.episode_starts[(ep + (1 if key == ord('n') else -1)) % len(viewer.episode_starts)]
            elif key == ord('a'):
                stride = 10 if stride == 1 else 1
            elif key == ord('i'):
                infer = not infer and (viewer.model is not None or getattr(viewer, 'remote', None) is not None)
            elif key == ord('s'):
                save_sample(output, sample, prediction, viewer.config, metadata, rendered)
                print(f'Saved sample {index} to {output}', flush=True)
    finally:
        cv2.destroyAllWindows()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--config', type=Path, help='Matching training recipe, or data-only config')
    parser.add_argument('--uri', help='Remote LeRobot service alias, e.g. e2vla_close_box')
    parser.add_argument('--ns_host', '--ns-host', default='127.0.0.1')
    parser.add_argument('--ns_port', '--ns-port', type=int, default=9090)
    parser.add_argument('--timeout', type=float, default=120.)
    parser.add_argument('--shared-memory', action='store_true', help='Enable same-machine CPU shared memory instead of socket-only RPC')
    parser.add_argument('--data-only', action='store_true')
    parser.add_argument('--device', default='auto', help='auto, cpu or cuda:N')
    parser.add_argument('--bf16', action='store_true', help='Optional CUDA BF16 inference')
    parser.add_argument('--threads', type=int, default=4)
    parser.add_argument('--speed-mps', type=float, help='Required physical speed condition for speed-model visualization')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--inference-timesteps', type=int, help='Defaults to the checkpoint setting')
    parser.add_argument('--indices', type=int, nargs='+', help='Dataset indices; default: first, middle, last')
    parser.add_argument('--output', type=Path, default=Path('visualizations/lerobot'))
    parser.add_argument('--gui', action='store_true', help='Interactive desktop viewer, starting at first --indices value')
    args = parser.parse_args(argv)
    if args.threads < 1 or args.timeout <= 0 or not 0 < args.ns_port < 65536 or (args.inference_timesteps is not None and args.inference_timesteps < 1):
        parser.error('Thread and inference-step counts must be positive')
    torch.set_num_threads(args.threads)
    cv2.setNumThreads(1)
    viewer = Viewer(args)
    try:
        indices = args.indices if args.indices is not None else sorted({0, len(viewer.dataset)//2, len(viewer.dataset)-1})
        if args.gui:
            browse(viewer, args.output, indices[0])
        else:
            records = []
            for index in indices:
                sample, prediction, metadata = viewer.sample(index)
                rendered = render(sample, prediction, viewer.config, metadata)
                records.append(save_sample(args.output, sample, prediction, viewer.config, metadata, rendered))
                print(json.dumps(dict(status='exported', **metadata), ensure_ascii=False), flush=True)
            (args.output / 'data_config.json').write_text(json.dumps(asdict(viewer.config), ensure_ascii=False, indent=2)+'\n')
            write_gallery(args.output, records)
            print(f'Gallery: {(args.output / "index.html").resolve()}', flush=True)
    finally:
        viewer.close()


if __name__ == '__main__':
    main()
