# E2VLA 双臂 LeRobot

保留关盒、开盒、放手机任务的两种模型：无力无速度条件、无力连续速度条件。训练监督为 `action.tcp_pose_cmd` 和动作夹爪；双臂 TCP、历史状态、动作目标和三相机统一表达在左臂 base 下。

两种模型、三个任务共用 **一个 Planner、一份推理配置**：`infer_utils/planner.py` 和 `configs_inference/planner.json`。任务、网络类型、标定和预测长度从 checkpoint 自动读取，切换模型只需换 checkpoint；调速版另提供 `speed_mps`。

```text
机器人观测 → Pyro4 Service → Planner → LeRobotDataSampler → 模型
                                      ↓
                  32 个双臂 TCP 位姿、夹爪开度及轨迹时间
```

推理按请求执行，没有固定推理频率。15 Hz / 30 Hz 是训练取样设置；其时间间隔用于历史观测对齐和输出轨迹的时间含义，不规定 RPC 调用频率或机器人控制频率。

## 环境

本机使用 `/home/hq/miniconda3/envs/e2vla/bin/python`。新服务器可执行：

```bash
conda env create -f environment_lerobot_e2vla.yml
conda activate e2vla
```

冻结骨干 DINOv2 / SigLIP 使用本地 Hugging Face 缓存，训练和推理服务器还需要相应缓存及模型 checkpoint。数据、预训练权重和训练输出均在项目目录外。

## 入口

| 功能 | 入口或文档 |
|---|---|
| 无速度训练 | `train_lerobot_no_force.py`、`README_lerobot_no_force.md` |
| 连续速度训练 | `train_lerobot_vel_no_force.py`、`README_reviewed_speed30.md` |
| Planner / Pyro4 | `README_lerobot_pyro.md` |
| 本地、远程可视化 | `datavis.py`、`README_datavis_lerobot.md` |
| ROS2 观测与执行适配 | `e03_lerobot_client/README.md` |

每种模型保留三个任务训练配置，因为数据和输出目录不同；推理只有一份通用配置。旧 HDF5 数据读取、力/接触模型、RL、RTC、实验配置、重复传输代码及历史生成物已移出当前项目。

```bash
python -m pytest -q tests_lerobot_no_force tests_lerobot_vel_no_force e03_lerobot_client/tests
```
