# 三任务无力、连续调速训练（1 倍速 = 原始 30 Hz）

沿用此前清洗确认的数据、左右臂/相机标定和训练超参数，分别训练三个任务。
预训练：`/home/hq/code/e2vla/checkpoints/e2vla_pretrain_ckpt.pt`。
无力输入、无 success 条件；输入连续物理速度 m/s，预测双臂 TCP 命令及夹爪。

## 配置与时间定义

- 数据记录与训练取样均为 30 Hz；5 步实测状态历史，32 步动作预测。
- 1 倍：原始指令行 t、t+1、…、t+31，严格逐帧取点。
- 1.5 倍：原始轨迹 t、t+1.5、…、t+46.5；位置线性插值、旋转 Slerp、夹爪事件零阶保持。
- 2 倍：原始指令行 t、t+2、…、t+62。
- 三档目标轨迹的时间间隔都是 1/30 秒；32 点首尾跨度为 31/30≈1.0333 秒。
- 三档共享真实的 30 Hz 观测历史，不把状态历史也人为加速。
- 速度条件是重采样后的目标 TCP 路径长度除以 31/30 秒，取双臂较大值；不是把旧速度标签简单乘倍率。
- 1/1.5/2 是数据增强倍率，上线仍以 speed_mps 指定物理速度。静止/纯夹爪/纯旋转片段不生成无法用平移速度区分的加速标签。

所有原始行（含插值两端和中间经过的行）必须落在一个人工确认的片段内，不能跨过滤区间。
保持 corrected Parquet、reviewed instruction、两个放手机数据集的混合读取。
右臂 observation.tcp_pose 和 action.tcp_pose_cmd 都转换到左臂 base，三相机也使用共同坐标。

| 任务 | episode | 1×窗口 | 1.5×窗口 | 2×窗口 | 总窗口 |
|---|---:|---:|---:|---:|---:|
| close_box | 60 | 16558 | 15582 | 14674 | 46814 |
| open_box | 59 | 7595 | 6651 | 5766 | 20012 |
| place_phone | 60 | 10243 | 9283 | 8383 | 27909 |

三个任务均为 batch_size=32、lr=1e-4、weight_decay=1e-5、warmup_steps=2000、grad_clip=1、seed=42、
workers=4、threads=4、50,000 步；每 10,000 步保存一次（共 10k、20k、30k、40k、50k）。
损失仍为 30×pos_loss + 10×rot_loss + 10×openness_loss，不含速度分类或力损失。

## 预训练迁移

原始预训练共有 362 个张量：360 个同形状完整加载；QFormer 的原 64 个 query 加载到速度模型前 64 个位置；
历史编码器原 9 列完整加载，第 10 个夹爪输入列初始化为零。新增速度输出层初始化为零，随后学习速度条件。
新增 speed/success 模块是白名单项，其他缺失、额外键或尺寸变化均报错，不进行静默跳过。
success 始终传 None，其保留模块不作为条件使用。初始化详情写入日志、config.json 和训练检查点。

## 启动

在可访问 GPU 的服务器终端运行：

```bash
/home/hq/miniconda3/envs/e2vla/bin/python /home/hq/code/e2vla_lerobot_no_force_both_20261116_004102/e2vla/scripts/start_three_reviewed_speed30.py --gpus 0 1 2
```

脚本先验证三个任务配置、GPU BF16 和至少 20 GiB 空闲显存，然后分别启动后台训练，
等待每个任务出现第一个 optimizer step 后报告成功。启动记录保存在
`/nas_data_new/hq/91e2vla/logs/speed30_日期时间/launch.json`，同目录有三个任务日志。
输出目录非空时拒绝重复启动；需要继续已有任务时按具体 checkpoint 使用 --resume。

输出目录：

- `/nas_data_new/hq/91e2vla/close_box_30hz_no_force_speed`
- `/nas_data_new/hq/91e2vla/open_box_30hz_no_force_speed`
- `/nas_data_new/hq/91e2vla/place_phone_30hz_no_force_speed`

分别对应配置 `configs_lerobot_vel_no_force/reviewed_<task>_30hz_speed.json`。
可先使用启动脚本的 `--check-only`，仅验证配置与 GPU。
单独训练例子：

```bash
python train_lerobot_vel_no_force.py --config configs_lerobot_vel_no_force/reviewed_close_box_30hz_speed.json
```

只检查数据时追加 `--check-data`，此模式无需 GPU，不产生训练权重。
两种模型共用 `configs_inference/planner.json` 和统一 Pyro4 服务，见 `README_lerobot_pyro.md`。推理按请求执行，训练采样设置不规定推理调用频率。

## 已完成检查

通过 reviewed 数据边界、1×原始 30 Hz 指令逐元素一致、三倍率目标时钟、实际 Parquet/视频、
预训练参数迁移以及三个任务真实数据的 CPU 前向/反向和内存中优化器更新。
CPU 梯度检查关闭随机 dropout，以免 batch=1 时两臂的速度条件同时随机被丢弃；正式训练保持 model.train()。
这不替代实际 CUDA 启动检查；是否已经开始正式训练应以 launch.json 和任务日志为准。
