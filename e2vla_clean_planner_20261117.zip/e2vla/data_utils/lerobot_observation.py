"""Common image/geometry preprocessing for training and live Planner observations."""
from collections import deque

import cv2
import numpy as np
import torch
from scipy.spatial.transform import Rotation


class HistoryNotReady(ValueError):
    pass


def resize_rgb(image, image_size, encoding="rgb"):
    image = np.asarray(image)
    if image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("Images must be HWC uint8 RGB or BGR")
    if encoding not in ("rgb", "bgr"):
        raise ValueError("Image encoding must be rgb or bgr")
    h, w = image_size
    image = cv2.resize(image, (w, h), interpolation=cv2.INTER_AREA)
    if encoding == "bgr":
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(image.transpose(2, 0, 1))


def camera_rays(config):
    h, w = config.image_size
    v, u = torch.meshgrid(torch.arange(h), torch.arange(w), indexing="ij")
    pixels = torch.stack([u, v, torch.ones_like(u)]).float().reshape(3, -1)
    rays = []
    for key in config.camera_keys:
        cam = config.geometry["cameras"][key]
        h0, w0 = cam["image_size"]
        resize = torch.tensor([[w/w0, 0, .5*w/w0-.5], [0, h/h0, .5*h/h0-.5], [0, 0, 1.]])
        xyz = torch.linalg.solve(resize @ torch.tensor(cam["K"], dtype=torch.float32), pixels)
        rays.append((xyz[:2]/xyz[2:]).reshape(2, h, w))
    return torch.stack(rays)[None]  # (one image time, cameras, 2, H, W)


def build_observation(config, tcp, history, images, prompt):
    """Unbatched model input. Images are resized CHW uint8 in camera_keys order."""
    from .lerobot_vel_no_force import camera_pose_in_world
    tcp = torch.as_tensor(tcp, dtype=torch.float32)
    h, w = config.image_size
    poses = [camera_pose_in_world(tcp, config, config.geometry["cameras"][key])
             for key in config.camera_keys]
    return dict(obs_rgbs=torch.stack([torch.as_tensor(x) for x in images])[None].float()/255.,
                obs_masks=torch.ones(1, len(images), h, w, dtype=torch.bool),
                obs_norm_xys=camera_rays(config), obs_extrinsics=torch.stack(poses)[None],
                prompt_text=prompt, current_ee_pose=tcp,
                history_ee_states=torch.as_tensor(history, dtype=torch.float32),
                valid_ee_mask=torch.ones(2, dtype=torch.bool))


def check_poses(value, name):
    value = np.asarray(value, dtype=np.float32)
    if value.shape[-2:] != (4, 4) or not np.isfinite(value).all():
        raise ValueError(f"{name} must contain finite 4x4 transforms")
    r = value[..., :3, :3]
    if (not np.allclose(value[..., 3, :], [0, 0, 0, 1], atol=1e-5)
            or not np.allclose(r.swapaxes(-1, -2) @ r, np.eye(3), atol=2e-3)
            or not np.allclose(np.linalg.det(r), 1, atol=2e-3)):
        raise ValueError(f"{name} must contain rigid transforms")
    return value


class LeRobotDataSampler:
    """Planner's measured-history buffer. No HDF5/Parquet access at inference time.

    tcp_world: ee_pose=(2,4,4), metres, left-base TCPs, no further transform.
    recorded: ee_pose uses the training record format; decode_tcp aligns both arms.
    """
    def __init__(self, config, input_pose_format="tcp_world", input_gripper_format="openness",
                 color_order="rgb", history_tolerance_s=None):
        config.validate()
        if input_pose_format not in ("tcp_world", "recorded"):
            raise ValueError("input_pose_format must be tcp_world or recorded")
        if input_gripper_format not in ("openness", "raw") or color_order not in ("rgb", "bgr"):
            raise ValueError("Invalid gripper format or color order")
        self.config = config
        self.input_pose_format, self.input_gripper_format = input_pose_format, input_gripper_format
        self.color_order = color_order
        self.history_interval = 1. / config.target_fps
        self.tolerance = .4*self.history_interval if history_tolerance_s is None else history_tolerance_s
        if not np.isfinite(self.tolerance) or not 0 < self.tolerance < self.history_interval/2:
            raise ValueError("history_tolerance_s must be positive and below half the model interval")
        self.states = deque(maxlen=max(120, 4*config.num_history_states*config.frame_stride))
        self.latest = None

    def reset(self):
        self.states.clear()
        self.latest = None

    def _normalize(self, frame):
        from .lerobot_vel_no_force import decode_tcp, decode_gripper, camera_pose_in_world
        if not isinstance(frame, dict):
            raise ValueError("An observation frame must be a dict")
        timestamp = float(frame["timestamp"])
        if not np.isfinite(timestamp):
            raise ValueError("Observation timestamp must be finite")
        if self.states and timestamp <= self.states[-1]["timestamp"]:
            raise ValueError("Observation timestamps must increase; reset between episodes")
        cfg = self.config
        raw = np.asarray(frame["ee_pose"])
        tcp = decode_tcp(raw.reshape(1, -1), cfg)[0] if self.input_pose_format == "recorded" else raw
        if tcp.shape != (2, 4, 4):
            raise ValueError("Expected left and right TCPs with shape (2,4,4)")
        tcp = check_poses(tcp, "ee_pose").copy()
        gripper = np.asarray(frame["gripper"], dtype=np.float32)
        if gripper.shape != (2,):
            raise ValueError("gripper must contain left and right values")
        if self.input_gripper_format == "raw":
            # Reuse the training decoder, including endpoint and range checks.
            packed = np.zeros((1, max(cfg.gripper_indices)+1), dtype=np.float32)
            packed[0, cfg.gripper_indices] = gripper
            gripper = decode_gripper(packed, cfg)[0]
        if not np.isfinite(gripper).all() or np.any((gripper < 0) | (gripper > 1)):
            raise ValueError("gripper openness must be in [0,1]")
        images = []
        for key in cfg.camera_keys:
            camera, incoming = cfg.geometry["cameras"][key], frame[key]
            metadata, data = incoming["camera"], incoming["data"]
            k = np.asarray(metadata["K"], dtype=float).reshape(3, 3)
            if not np.allclose(k, camera["K"], atol=.05, rtol=0):
                raise ValueError(f"{key}: intrinsics differ from checkpoint")
            camera_time = float(data.get("timestep", timestamp))
            if not np.isfinite(camera_time) or abs(camera_time-timestamp) > .035:
                raise ValueError(f"{key}: image/state timestamps differ by more than 35 ms")
            if "wcT" in data:
                actual = check_poses(data["wcT"], key)
                expected = camera_pose_in_world(torch.from_numpy(tcp), cfg, camera).numpy()
                angle = Rotation.from_matrix(expected[:3, :3].T @ actual[:3, :3]).magnitude()
                if np.linalg.norm(actual[:3, 3]-expected[:3, 3]) > .01 or angle > np.deg2rad(2):
                    raise ValueError(f"{key}: camera pose differs from checkpoint calibration")
            encoding = data.get("encoding", self.color_order)
            if "color_jpeg" in data:
                image = cv2.imdecode(np.frombuffer(data["color_jpeg"], np.uint8), cv2.IMREAD_COLOR)
                encoding = "bgr"
                if image is None:
                    raise ValueError(f"{key}: invalid JPEG")
            else:
                image = np.asarray(data["color"])
            if image.shape != (*camera["image_size"], 3):
                raise ValueError(f"{key}: image resolution differs from checkpoint")
            images.append(resize_rgb(image, cfg.image_size, encoding))
        return dict(timestamp=timestamp, ee_pose=tcp, gripper=gripper.copy()), images

    def add_obs_frame(self, frame):
        state, images = self._normalize(frame)
        self.states.append(state)
        self.latest = dict(state, images=images)

    def sample_framedict(self, prompt):
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("Set a nonempty task prompt before inference")
        count = self.config.num_history_states
        if len(self.states) < count:
            raise HistoryNotReady("Collecting measured observation history")
        times = np.asarray([s["timestamp"] for s in self.states])
        wanted = times[-1] + np.arange(1-count, 1)*self.history_interval
        selected = np.abs(times[:, None]-wanted).argmin(axis=0)
        if np.any(np.diff(selected) <= 0) or np.any(np.abs(times[selected]-wanted) > self.tolerance):
            raise HistoryNotReady("Missing continuous measured history at the training history intervals")
        history = np.stack([np.concatenate([self.states[i]["ee_pose"].reshape(2, 16),
                                            self.states[i]["gripper"][:, None]], axis=-1)
                            for i in selected])
        return build_observation(self.config, self.latest["ee_pose"], history,
                                 self.latest["images"], prompt)
