"""LeRobot input adapter for the original action-only E2VLA, without speed.

Reuse the tested numeric/video/geometry reader. Only the original VLA's input
fields are exposed; auxiliary speed/success values never enter this policy.
"""
from dataclasses import dataclass

from .lerobot_vel_no_force import (
    LeRobotVelocityNoForceConfig, LeRobotVelocityNoForceDataset,
    collate_lerobot_no_force as _collate,
)


INPUT_KEYS = (
    "obs_rgbs", "obs_masks", "obs_norm_xys", "obs_extrinsics", "prompt_text",
    "current_ee_pose", "history_ee_states", "gt_future_ee_states", "valid_ee_mask",
)


@dataclass
class LeRobotNoForceConfig(LeRobotVelocityNoForceConfig):
    num_future_actions: int = 32
    history_mode: str = "observed"

    def validate(self):
        if self.speed_factors is not None or self.history_mode != "observed":
            raise ValueError("No-speed training requires speed_factors=null and observed history")
        if self.success_key is not None:
            raise ValueError("The original action-only VLA does not use success conditioning")
        super().validate()


class LeRobotNoForceDataset(LeRobotVelocityNoForceDataset):
    def __init__(self, config: LeRobotNoForceConfig):
        if not isinstance(config, LeRobotNoForceConfig):
            raise TypeError("Use the dedicated LeRobotNoForceConfig")
        super().__init__(config)

    def __getitem__(self, index):
        sample = super().__getitem__(index)
        return {key: sample[key] for key in INPUT_KEYS}


def collate_lerobot_no_speed(samples):
    if not samples or any(set(sample) != set(INPUT_KEYS) for sample in samples):
        raise ValueError("Expected only the original action-only VLA input fields")
    return _collate(samples)
