"""Confirmed review segments sampled on an episode-wide fixed-frequency grid.

The snapshot's reader verifies keep decisions, corrections, hashes and media.
Original frame IDs remain intact for numeric rows and video seeks. Even skipped
30 Hz rows must be valid: a 15 Hz chunk cannot bridge an excluded odd frame.
"""
from collections import OrderedDict
from dataclasses import asdict, dataclass
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np

from .lerobot_no_force import LeRobotNoForceConfig, LeRobotNoForceDataset


@dataclass
class ReviewedNoForceConfig(LeRobotNoForceConfig):
    reviewed_datasets: list[str] | None = None
    review_manifest_sha256: str = ""
    source_fps: float = 30.

    def validate(self):
        super().validate()
        if (not isinstance(self.reviewed_datasets, list) or not self.reviewed_datasets
                or any(not isinstance(name, str) or not name.strip() for name in self.reviewed_datasets)
                or len(set(self.reviewed_datasets)) != len(self.reviewed_datasets)):
            raise ValueError("reviewed_datasets must list unique dataset names from the snapshot")
        if (len(self.review_manifest_sha256) != 64
                or any(c not in '0123456789abcdef' for c in self.review_manifest_sha256)):
            raise ValueError("Pin the task_manifest.json SHA256 in review_manifest_sha256")
        if (not np.isfinite([self.source_fps, self.target_fps]).all()
                or min(self.source_fps, self.target_fps) <= 0
                or type(self.frame_stride) is not int
                or not np.isclose(self.source_fps / self.frame_stride, self.target_fps)):
            raise ValueError("source_fps / integer frame_stride must equal target_fps")
        if self.action_offset != 0:
            raise ValueError("Reviewed sampling currently requires action_offset=0")


def load_reviewed_snapshot(config):
    """Use the supplied, guarded partial-review loader; never scan raw episodes."""
    root = Path(config.root).expanduser().resolve()
    manifest = root / 'task_manifest.json'
    if hashlib.sha256(manifest.read_bytes()).hexdigest() != config.review_manifest_sha256:
        raise ValueError("Review manifest changed; use the configuration for this exact snapshot")
    path = root / 'read_training.py'
    spec = importlib.util.spec_from_file_location('_e2vla_review_handoff', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.load_reviewed_segments(root), module.sample_rows_valid


def sample_frames(segment, config, rows_valid):
    """Yield anchors on raw frame 0, stride, 2*stride, ... without any gap."""
    stride = config.frame_stride
    before = (config.num_history_states - 1) * stride
    after = (config.num_future_actions - 1) * stride
    first = ((segment['start_frame'] + before + stride - 1) // stride) * stride
    for frame in range(first, segment['stop_frame'] - after, stride):
        # Check the whole span, including rows omitted by temporal subsampling.
        if rows_valid(segment, range(frame - before, frame + 1), range(frame, frame + after + 1)):
            yield frame


class _ReviewedSource(LeRobotNoForceDataset):
    """Reuse numeric decoding/video geometry, with only verified episode paths."""
    def __init__(self, config, segments):
        root = segments[0]['source_root']
        plain = {key: value for key, value in asdict(config).items()
                 if key in LeRobotNoForceConfig.__dataclass_fields__}
        self.config = LeRobotNoForceConfig(**{**plain, 'root': root})
        self.root = Path(root)
        self.info = json.loads((self.root / 'meta/info.json').read_text())
        self.fps = float(self.info['fps'])
        if (not self.info.get('codebase_version', '').startswith('v2.')
                or not np.isclose(self.fps, config.source_fps)):
            raise ValueError(f"Expected LeRobot v2 at {config.source_fps} Hz: {root}")
        for key in config.camera_keys:
            if self.info['features'].get(key, {}).get('dtype') != 'video':
                raise ValueError(f"Missing video feature {key}: {root}")
        self.tasks = {int(x['task_index']): x['task'] for x in self._jsonl('tasks.jsonl')}
        metadata = {int(x['episode_index']): x for x in self._jsonl('episodes.jsonl')}
        self.parquet_paths = {}
        for segment in segments:
            ep = int(segment['episode_index'])
            path = Path(segment['parquet_path'])
            path = path if path.is_absolute() else self.root / path
            if ep in self.parquet_paths and self.parquet_paths[ep] != path:
                raise ValueError(f"Conflicting reviewed Parquet paths for {root}, episode {ep}")
            self.parquet_paths[ep] = path
        self.episodes = [metadata[ep] for ep in sorted(self.parquet_paths)]
        self.episode_indices = {int(ep['episode_index']): i for i, ep in enumerate(self.episodes)}
        for ep in self.episodes:
            for path in [self.parquet_paths[ep['episode_index']]] + [
                    self._path('video_path', ep['episode_index'], key) for key in config.camera_keys]:
                if not path.is_file():
                    raise FileNotFoundError(path)
        self._episodes, self._videos = OrderedDict(), OrderedDict()
        self.retime_index = None

    def _path(self, kind, ep_id, video_key=''):
        if kind == 'data_path':
            return self.parquet_paths[int(ep_id)]
        return super()._path(kind, ep_id, video_key)


class ReviewedNoForceDataset(LeRobotNoForceDataset):
    def __init__(self, config: ReviewedNoForceConfig):
        if not isinstance(config, ReviewedNoForceConfig):
            raise TypeError("Use ReviewedNoForceConfig for a review snapshot")
        config.validate()
        self.config = config
        all_segments, rows_valid = load_reviewed_snapshot(config)
        selected = set(config.reviewed_datasets)
        found = {s['dataset_name'] for s in all_segments}
        if selected - found:
            raise ValueError(f"Unknown/empty reviewed datasets: {sorted(selected - found)}")
        self.segments = [s for s in all_segments if s['dataset_name'] in selected]
        self.sources = {}
        for name in config.reviewed_datasets:
            segments = [s for s in self.segments if s['dataset_name'] == name]
            if len({s['source_root'] for s in segments}) != 1:
                raise ValueError(f"Dataset name has multiple source roots: {name}")
            self.sources[name] = _ReviewedSource(config, segments)
        self.fps = config.source_fps  # Original video clock, never relabel as 15 Hz.
        self.sample_fps = config.target_fps
        self.retime_index = None
        self.episodes, self.episode_tokens = [], {}
        self._token_sources = []
        for name, source in self.sources.items():
            for ep in source.episodes:
                token = len(self.episodes)
                self.episode_tokens[(name, ep['episode_index'])] = token
                self._token_sources.append((name, ep['episode_index']))
                self.episodes.append(dict(ep, dataset_name=name))
        windows = []
        self.segment_sample_counts = []
        for i, segment in enumerate(self.segments):
            source = self.sources[segment['dataset_name']]
            ep = source.episodes[source.episode_indices[segment['episode_index']]]
            if not (0 <= segment['start_frame'] < segment['stop_frame'] <= ep['length']):
                raise ValueError(f"Invalid reviewed segment bounds: {segment['segment_id']}")
            frames = list(sample_frames(segment, config, rows_valid))
            self.segment_sample_counts.append(len(frames))
            windows.extend((i, frame) for frame in frames)
        if not windows:
            raise ValueError("No complete reviewed history/action windows at the requested frequency")
        self.windows = np.asarray(windows, dtype=np.int64)

    def __len__(self):
        return len(self.windows)

    def numeric_sample(self, index):
        if index < 0 or index >= len(self):
            raise IndexError(index)
        segment_index, frame = map(int, self.windows[index])
        segment = self.segments[segment_index]
        name, ep_id = segment['dataset_name'], segment['episode_index']
        source = self.sources[name]
        columns = source._episode(source.episode_indices[ep_id])
        cfg = self.config
        hist = frame + np.arange(1 - cfg.num_history_states, 1) * cfg.frame_stride
        future = frame + np.arange(cfg.num_future_actions) * cfg.frame_stride
        history = np.concatenate([columns['state_pose'][hist].reshape(-1, 2, 16),
                                  columns['state_gripper'][hist, :, None]], axis=-1)
        actions = np.concatenate([columns['action_pose'][future].reshape(-1, 2, 16),
                                  columns['action_gripper'][future, :, None]], axis=-1)
        return dict(episode_index=self.episode_tokens[(name, ep_id)], frame=frame,
                    source_episode_index=ep_id, dataset_name=name,
                    segment_id=segment['segment_id'], split_group=segment['split_group'],
                    history_rows=hist, action_rows=future,
                    history_timestamps=columns['timestamp'][hist], action_timestamps=columns['timestamp'][future],
                    current_ee_pose=columns['state_pose'][frame], history_ee_states=history,
                    gt_future_ee_states=actions, prompt_text=segment['instruction'],
                    gt_speed_cond=np.float32(0.), success=None)

    def _image(self, episode_token, camera, frame):
        name, ep_id = self._token_sources[episode_token]
        return self.sources[name]._image(ep_id, camera, frame)

    def close(self):
        for source in self.sources.values():
            source.close()

    def __getstate__(self):
        # Nested source readers clear their own decoder/episode caches on pickle.
        return dict(self.__dict__)
