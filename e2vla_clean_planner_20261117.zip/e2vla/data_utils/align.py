"""Shared implementation retained for the two LeRobot no-force policies."""
import torch
import numpy as np
import pypose as pp


def interp_linear(q0: np.ndarray, q1: np.ndarray, t0, t1, t) -> np.ndarray:
    """
    Args:
        q0 (np.ndarray): (T, ...)
        q1 (np.ndarray): (T, ...)
        t0 (np.ndarray or float): (T,) or scalar
        t0 (np.ndarray or float): (T,) or scalar
        t (np.ndarray): (T,)
    
    Returns:
        q (np.ndarray): (T, ...)
    """
    delta = q1 - q0
    alpha = (t - t0) / (t1 - t0)
    if isinstance(alpha, np.ndarray) and isinstance(delta, np.ndarray):
        if alpha.ndim < delta.ndim:
            alpha.shape = alpha.shape + (1,) * (delta.ndim - alpha.ndim)
    update = alpha * delta
    q = q0 + update.astype(q0.dtype)
    return q



def interp_SO3(R0: np.ndarray, R1: np.ndarray, t0, t1, t) -> np.ndarray:
    """
    Args:
        R0 (np.ndarray): (T, ..., 3, 3)
        R1 (np.ndarray): (T, ..., 3, 3)
        t0 (np.ndarray or float): (T,) or scalar
        t0 (np.ndarray or float): (T,) or scalar
        t (np.ndarray): (T,)
    
    Returns:
        R (np.ndarray): (T, ..., 3, 3)
    """
    Log = pp.SO3_type.Log
    Exp = pp.so3_type.Exp
    Mul = pp.SO3_type.Mul
    Inv = pp.SO3_type.Inv
    
    R0 = pp.from_matrix(torch.from_numpy(R0), pp.SO3_type)
    R1 = pp.from_matrix(torch.from_numpy(R1), pp.SO3_type)
    delta = Log(Mul(Inv(R0), R1)).tensor()
    alpha = (t - t0) / (t1 - t0)
    
    if isinstance(alpha, np.ndarray):
        alpha = torch.from_numpy(alpha).to(delta)
        if alpha.ndim < delta.ndim:
            alpha = alpha.view(*alpha.shape, *([1] * (delta.ndim - alpha.ndim)))
    
    update = alpha * delta
    R = Mul(R0, Exp(update)).matrix()
    return R.numpy()

