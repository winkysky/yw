"""Shared 30 Hz, 32-target retiming (also vendored unchanged in iE2VLA3).

Only the reference trajectory is time-warped. Source timestamps are never used
as the denominator of the *target* speed. No padding or extrapolation is used.
"""
import bisect
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

FACTORS = (1.0, 1.5, 2.0)
HORIZON = 32


def validate_retime(config):
    if tuple(config.speed_factors) != FACTORS:
        raise ValueError("speed_factors must be [1.0, 1.5, 2.0], in that order")
    if config.num_future_actions != HORIZON:
        raise ValueError("Retimed training requires exactly 32 future targets")
    if config.frame_stride != 1 or config.action_offset != 0:
        raise ValueError("Retiming uses frame_stride=1 and action_offset=0")
    if config.target_fps != 30.0:
        raise ValueError("This training recipe uses a 30 Hz target clock")
    if config.history_mode not in {"observed", "retimed", "mixed"}:
        raise ValueError("history_mode must be observed, retimed or mixed")


def sample_poses(times, poses, query):
    """Linear TCP translation and shortest-arc rotation interpolation."""
    times = np.asarray(times, dtype=np.float64)
    query = np.asarray(query, dtype=np.float64)
    # LeRobot stores float32 timestamps: tolerate only rounding at endpoints.
    tol = 2e-6
    if query.min() < times[0] - tol or query.max() > times[-1] + tol:
        raise ValueError("Retiming would extrapolate beyond this episode")
    query = np.clip(query, times[0], times[-1])
    hi = np.searchsorted(times, query, side="left").clip(1, len(times) - 1)
    lo = hi - 1
    weight = (query - times[lo]) / (times[hi] - times[lo])
    result = np.broadcast_to(np.eye(4), (len(query), 2, 4, 4)).copy()
    result[..., :3, 3] = (poses[lo, :, :3, 3] * (1 - weight[:, None, None])
                            + poses[hi, :, :3, 3] * weight[:, None, None])
    # Restrict Slerp to the small source interval used by this chunk.
    first, last = int(lo.min()), int(hi.max()) + 1
    for arm in range(2):
        result[:, arm, :3, :3] = Slerp(
            times[first:last], Rotation.from_matrix(poses[first:last, arm, :3, :3]))(query).as_matrix()
    # Preserve exact source samples (including the current state).
    nearest = np.searchsorted(times, query).clip(0, len(times) - 1)
    previous = np.maximum(nearest - 1, 0)
    nearest = np.where(abs(times[previous] - query) < abs(times[nearest] - query), previous, nearest)
    exact = abs(times[nearest] - query) < tol
    result[exact] = poses[nearest[exact]]
    return result.astype(np.float32)


def sample_grippers(times, grippers, query):
    # Event commands are zero-order held; never interpolate open/close counts.
    index = np.searchsorted(times, np.asarray(query) + 2e-6, side="right") - 1
    return grippers[index.clip(0, len(times) - 1)].copy()


def retime_sample(columns, frame, factor, num_history, target_fps=30., history_mode="mixed"):
    if factor not in FACTORS:
        raise ValueError("Unknown speed factor")
    times = columns["timestamp"]
    dt = 1. / target_fps
    origin = times[frame]
    history_factor = factor if (history_mode == "retimed" or
                                (history_mode == "mixed" and frame % 2 == 1)) else 1.
    history_times = origin + history_factor * np.arange(1 - num_history, 1) * dt
    source_times = origin + factor * np.arange(HORIZON) * dt
    target_times = np.arange(HORIZON, dtype=np.float64) * dt
    history_pose = sample_poses(times, columns["state_pose"], history_times)
    action_pose = sample_poses(times, columns["action_pose"], source_times)
    history_gripper = sample_grippers(times, columns["state_gripper"], history_times)
    action_gripper = sample_grippers(times, columns["action_gripper"], source_times)
    per_arm = np.linalg.norm(np.diff(action_pose[..., :3, 3].astype(np.float64), axis=0), axis=-1).sum(0)
    per_arm /= target_times[-1] - target_times[0]
    return dict(history_pose=history_pose, action_pose=action_pose,
                history_gripper=history_gripper, action_gripper=action_gripper,
                speed_mps=np.float32(per_arm.max()), speed_per_arm=per_arm.astype(np.float32),
                speed_factor=np.float32(factor), history_factor=np.float32(history_factor),
                source_times=source_times, target_times=target_times, history_times=history_times)


class RetimeIndex:
    """Compact per-episode/factor index; invalid tails are omitted per factor.

    Accelerated pure-rotation/gripper/static windows are omitted because a
    translational m/s condition cannot distinguish their different timings.
    Original-speed windows, including true recorded holds, are retained.
    """
    def __init__(self, dataset):
        cfg = dataset.config
        validate_retime(cfg)
        self.blocks, self.ends = [], []
        self.counts = {str(x): 0 for x in FACTORS}
        count = 0
        for ep_index, ep in enumerate(dataset.episodes):
            columns = dataset._episode(ep_index)
            times = columns["timestamp"]
            history = (cfg.num_history_states - 1) / cfg.target_fps
            duration = (HORIZON - 1) / cfg.target_fps
            # Original path length is used only to reject motionless augmentation.
            distance = np.linalg.norm(np.diff(columns["action_pose"][..., :3, 3], axis=0), axis=-1)
            cumulative = np.concatenate([np.zeros((1, 2)), np.cumsum(distance, axis=0)], axis=0)
            for factor in FACTORS:
                frames = np.arange(len(times))
                hf = np.ones(len(times))
                if cfg.history_mode == "retimed":
                    hf[:] = factor
                elif cfg.history_mode == "mixed":
                    hf[frames % 2 == 1] = factor
                valid = ((times - history * hf >= times[0] - 2e-6)
                         & (times + duration * factor <= times[-1] + 2e-6))
                end = np.searchsorted(times, times + duration * factor).clip(0, len(times) - 1)
                # Keep a chunk within one task, including intermediate task switches.
                transitions = np.r_[0, np.cumsum(np.diff(columns["task_index"]) != 0)]
                valid &= transitions[frames] == transitions[end]
                if factor != 1.:
                    valid &= (cumulative[end] - cumulative[frames]).max(-1) > 1e-6
                frames = frames[valid].astype(np.int32)
                if len(frames):
                    self.blocks.append((ep_index, factor, frames))
                    count += len(frames)
                    self.ends.append(count)
                    self.counts[str(factor)] += len(frames)
        if not count:
            raise ValueError("No complete 32-step retimed windows in this dataset")

    def __len__(self):
        return self.ends[-1]

    def locate(self, index):
        if index < 0 or index >= len(self):
            raise IndexError(index)
        block = bisect.bisect_right(self.ends, index)
        ep, factor, frames = self.blocks[block]
        offset = index - (self.ends[block - 1] if block else 0)
        return ep, int(frames[offset]), factor
