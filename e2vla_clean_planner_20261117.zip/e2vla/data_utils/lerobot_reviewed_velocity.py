"""Continuous-speed training restricted to confirmed, corrected review segments."""
import bisect
from dataclasses import asdict, dataclass

import numpy as np

from .lerobot_vel_no_force import LeRobotVelocityNoForceConfig, LeRobotVelocityNoForceDataset
from .lerobot_reviewed_no_force import ReviewedNoForceConfig, _ReviewedSource, load_reviewed_snapshot
from .trajectory_retime32 import FACTORS, HORIZON, retime_sample


@dataclass
class ReviewedVelocityNoForceConfig(LeRobotVelocityNoForceConfig):
    reviewed_datasets: list[str] | None = None
    review_manifest_sha256: str = ""
    source_fps: float = 30.

    def validate(self):
        super().validate()
        # Reuse the review manifest/name validation, keeping the original
        # observed-history convention of the three no-speed runs.
        plain = asdict(self)
        plain.update(speed_factors=None, history_mode="observed")
        ReviewedNoForceConfig(**plain).validate()
        if (self.source_fps != 30. or self.target_fps != 30. or self.frame_stride != 1 or
                tuple(self.speed_factors or ()) != FACTORS or self.history_mode != "observed" or
                self.num_history_states != 5 or self.num_future_actions != 32 or self.success_key is not None):
            raise ValueError("Reviewed speed recipe requires 30 Hz, observed history=5, horizon=32, factors=[1,1.5,2], no success")


def support_bounds(times, frame, factor, cfg):
    """Include every original row supporting position/Slerp/event interpolation."""
    # The numeric reader verifies timestamps against the 30 Hz frame grid.
    # Index that grid directly: float32 timestamp rounding must never skip a
    # source frame or turn a 1x target into an interpolated pose.
    first = frame - cfg.num_history_states + 1
    last = frame + int(np.ceil(factor * (HORIZON - 1)))
    return first, last


class ReviewedRetimeIndex:
    def __init__(self, dataset, rows_valid):
        cfg = dataset.config
        self.blocks, self.ends = [], []
        self.counts = {str(factor): 0 for factor in FACTORS}
        self.segment_counts = []
        count = 0
        for segment_index, segment in enumerate(dataset.segments):
            columns = dataset.segment_columns(segment_index)
            times = columns["timestamp"]
            begin, stop = segment["start_frame"], segment["stop_frame"]
            if not 0 <= begin < stop <= len(times):
                raise ValueError(f"Invalid reviewed segment {segment['segment_id']}")
            distance = np.linalg.norm(np.diff(columns["action_pose"][..., :3, 3], axis=0), axis=-1)
            cumulative = np.concatenate([np.zeros((1, 2)), np.cumsum(distance, axis=0)], axis=0)
            transitions = np.r_[0, np.cumsum(np.diff(columns["task_index"]) != 0)]
            segment_counts = {}
            for factor in FACTORS:
                frames = []
                for frame in range(begin, stop):
                    first, last = support_bounds(times, frame, factor, cfg)
                    if first < begin or last >= stop or transitions[frame] != transitions[last]:
                        continue
                    # Validate intermediate rows too: no bridge across an excluded
                    # interval, even if all fractional sample endpoints are valid.
                    if not rows_valid(segment, range(first, frame + 1), range(frame, last + 1)):
                        continue
                    if factor != 1. and (cumulative[last] - cumulative[frame]).max() <= 1e-6:
                        continue
                    frames.append(frame)
                segment_counts[str(factor)] = len(frames)
                if frames:
                    self.blocks.append((segment_index, factor, np.asarray(frames, dtype=np.int32)))
                    count += len(frames)
                    self.ends.append(count)
                    self.counts[str(factor)] += len(frames)
            self.segment_counts.append(segment_counts)
        if not count:
            raise ValueError("No complete reviewed 30 Hz retimed windows")

    def __len__(self):
        return self.ends[-1]

    def locate(self, index):
        if not 0 <= index < len(self):
            raise IndexError(index)
        block = bisect.bisect_right(self.ends, index)
        segment, factor, frames = self.blocks[block]
        local = index - (self.ends[block - 1] if block else 0)
        return segment, int(frames[local]), factor


class ReviewedVelocityNoForceDataset(LeRobotVelocityNoForceDataset):
    def __init__(self, config):
        if not isinstance(config, ReviewedVelocityNoForceConfig):
            raise TypeError("Use ReviewedVelocityNoForceConfig")
        config.validate()
        self.config = config
        segments, rows_valid = load_reviewed_snapshot(config)
        selected = set(config.reviewed_datasets)
        if selected - {s["dataset_name"] for s in segments}:
            raise ValueError("Unknown or empty reviewed datasets")
        self.segments = [s for s in segments if s["dataset_name"] in selected]
        # These readers only provide verified Parquet decoding and video access;
        # the speed window index below owns all temporal augmentation.
        plain = asdict(config)
        plain["speed_factors"] = None
        source_config = ReviewedNoForceConfig(**plain)
        self.sources = {}
        for name in config.reviewed_datasets:
            rows = [s for s in self.segments if s["dataset_name"] == name]
            if len({s["source_root"] for s in rows}) != 1:
                raise ValueError(f"Multiple roots for {name}")
            self.sources[name] = _ReviewedSource(source_config, rows)
        self.episodes, self.episode_tokens, self._token_sources = [], {}, []
        for name, source in self.sources.items():
            for episode in source.episodes:
                self.episode_tokens[(name, episode["episode_index"])] = len(self.episodes)
                self._token_sources.append((name, episode["episode_index"]))
                self.episodes.append(dict(episode, dataset_name=name))
        self.fps = config.source_fps
        self.sample_fps = config.target_fps
        self.retime_index = ReviewedRetimeIndex(self, rows_valid)

    def segment_columns(self, segment_index):
        segment = self.segments[segment_index]
        source = self.sources[segment["dataset_name"]]
        return source._episode(source.episode_indices[segment["episode_index"]])

    def __len__(self):
        return len(self.retime_index)

    def numeric_sample(self, index):
        segment_index, frame, factor = self.retime_index.locate(index)
        segment = self.segments[segment_index]
        columns = self.segment_columns(segment_index)
        first, last = support_bounds(columns["timestamp"], frame, factor, self.config)
        # Slice before interpolation so no helper can read outside the reviewed
        # support, including Slerp's neighbor at an exact segment endpoint.
        keys = ("timestamp", "state_pose", "action_pose", "state_gripper", "action_gripper")
        window = {key: columns[key][first:last+1] for key in keys}
        window['timestamp'] = np.arange(first, last+1, dtype=np.float64) / self.fps
        values = retime_sample(window, frame-first, factor, self.config.num_history_states,
                               self.config.target_fps, self.config.history_mode)
        name, episode = segment["dataset_name"], segment["episode_index"]
        return dict(values, episode_index=self.episode_tokens[(name, episode)], frame=frame,
                    source_episode_index=episode, dataset_name=name, segment_id=segment["segment_id"],
                    split_group=segment["split_group"], support_first=first, support_last=last,
                    current_ee_pose=columns["state_pose"][frame],
                    history_ee_states=np.concatenate([values["history_pose"].reshape(-1, 2, 16),
                                                     values["history_gripper"][..., None]], axis=-1),
                    gt_future_ee_states=np.concatenate([values["action_pose"].reshape(32, 2, 16),
                                                       values["action_gripper"][..., None]], axis=-1),
                    gt_speed_cond=values["speed_mps"], prompt_text=segment["instruction"], success=None)

    def _image(self, episode_token, camera, frame):
        name, episode = self._token_sources[episode_token]
        return self.sources[name]._image(episode, camera, frame)

    def close(self):
        for source in self.sources.values():
            source.close()

    def __getstate__(self):
        return dict(self.__dict__)
