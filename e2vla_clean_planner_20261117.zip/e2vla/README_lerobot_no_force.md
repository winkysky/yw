# LeRobot 双臂 E2VLA：无力、无速度条件

训练入口直接调用 `models.vla.vla_base()`。清理保留该模型结构及 checkpoint 参数键；两版共用修正后的数据读取几何。
此版保留原始 DINOv2/SigLIP、QFormer、ProPE、DiT、DDIM 和原始动作损失；
不增加速度 query、速度编码器、速度预测头、力或接触预测头。
它是原始无速度 E2VLA 的 LeRobot 适配，不应被当作仅关闭一个开关的严格速度消融：
原始动作专家与现有调速动作专家还存在历史夹爪编码等已有结构差异。

## 两个版本

| 版本 | 训练入口 | 默认监督 |
|---|---|---|
| 本版：无力、无速度 | `train_lerobot_no_force.py` | 原始录制时序，32 步，无速度条件 |
| 现有：无力、连续调速 | `train_lerobot_vel_no_force.py` | 1/1.5/2 倍速增强，32 步，连续 m/s 条件 |

两版输入输出均支持双臂。不同结构、配置及检查点格式不能直接互相 `--resume`。
两版共用统一 Planner / Pyro4 服务，按 checkpoint 自动选择网络，见 `README_lerobot_pyro.md`。

## 数据与训练

不传 `--config` 时，默认配置 `configs_lerobot_no_force/huawei_close_box.json` 指向标准 LeRobot v2
数据 `hw_close_box_1111`。`data_utils/lerobot_no_force.py` 复用现有的数值、视频、
相机几何和夹爪转换，只向原版模型输出它实际接受的字段。
`gt_speed_cond`、`success`、力及接触标签均不进入模型；共享读取器内部计算的
辅助速度不用于本版训练。配置禁止倍速增强和重采样历史。

默认历史 5 步、未来指令 32 步，action_offset=0，按原始录制时序采样，
没有将同一状态下多个速度的动作真值混在一起。当前数据为 30 Hz。
夹爪 1886=关、0=开，连续开度为 `1-raw/1886`，0=关、1=开。
当前状态、历史状态、未来动作及三个相机均表达在左臂记录 base 下。
右臂通过 `base_to_world[1]` 同时旋转和平移，右腕相机跟随右臂法兰；
头部相机的 `parent=left_base`，不跟随左手运动。完整坐标约定见下节。
默认使用配置数据集全部 episodes，正式实验应另外划分独立验证轨迹。

## 已复核数据：三个 15 Hz 训练配置

三份配置均用于无力、无速度版，数据根目录为
`/home/hq/huawei_261112/reviewed_training_20261115`。它们通过快照自带的
`read_training.py` 校验人工 keep 决策、文件哈希、过滤结果、视频以及片段边界，
只选择下表的数据。数值使用校验后的 `parquet_path`（有修正时读取 filtered 数据，
无须修正时读取原始数据），语言使用人工确认的片段 instruction。

| 配置（位于 configs_lerobot_no_force） | 选择的数据 | 轨迹数 | 训练窗口 | 保存子目录 |
|---|---|---:|---:|---|
| reviewed_close_box_15hz.json | close_box_1112_2/success | 60 | 7,215 | close_box_15hz_no_force_no_speed |
| reviewed_open_box_15hz.json | open_the_box_1109_60/success | 59 | 2,777 | open_box_15hz_no_force_no_speed |
| reviewed_place_phone_15hz.json | place_phone_1111_60_2/success + place_phone_1112_10/success | 50 + 10 | 4,084 | place_phone_15hz_no_force_no_speed |

保存根目录均为 `/nas_data_new/hq/91e2vla`。每份配置独立保存，避免互相覆盖。
放手机数据按全部有效窗口合并、随机打乱，不额外平衡两来源的权重。
三份配置使用各自全部复核有效窗口，未另外划分验证集。

录制频率保持 30 Hz，训练取原始帧号 `0,2,4,...`：样本锚点、5 步状态历史和
32 步未来指令均以 15 Hz 采样，图像仍按原视频帧号定位。32 个动作从当前帧开始，
首尾相隔 `31/15 ≈ 2.067` 秒。完整窗口及其跳过的原始帧都必须有效，
不能跨子任务边界或坏帧；不补齐短片段，不做倍速增强。
两臂和三相机沿用下节的左 base 坐标约定。

共同训练参数：batch=32、workers=4、50,000 步、学习率 1e-4、warmup=2,000、
weight decay=1e-5、梯度裁剪=1、seed=42；每 10,000 步保存，每 10 步打印日志。
预训练权重为 `/home/hq/code/e2vla/checkpoints/e2vla_pretrain_ckpt.pt`，严格加载
`weights` 中的动作专家参数。优化器、调度器和训练步数重新初始化；视觉骨干从本地
Hugging Face 缓存加载并冻结。`--resume` 则恢复本次训练检查点，优先于预训练初始化。

```bash
conda activate e2vla
cd /home/hq/code/e2vla_lerobot_no_force_both_20261116_004102/e2vla

# 三条命令分别启动三个模型；按实际使用的 GPU 设置 CUDA_VISIBLE_DEVICES。
CUDA_VISIBLE_DEVICES=0 python train_lerobot_no_force.py --config configs_lerobot_no_force/reviewed_close_box_15hz.json
CUDA_VISIBLE_DEVICES=1 python train_lerobot_no_force.py --config configs_lerobot_no_force/reviewed_open_box_15hz.json
CUDA_VISIBLE_DEVICES=2 python train_lerobot_no_force.py --config configs_lerobot_no_force/reviewed_place_phone_15hz.json
```

追加 `--check-data` 可只检查数据。显式命令行参数覆盖 JSON 中的训练参数，
例如 `--batch-size 16`。`--config` 和旧接口 `--data-config` 互斥。
快照配置固定了 task_manifest 的 SHA256；更换复核快照时需重新核验并更新配置。
续训示例：

```bash
CUDA_VISIBLE_DEVICES=0 python train_lerobot_no_force.py \
  --config configs_lerobot_no_force/reviewed_close_box_15hz.json \
  --resume /nas_data_new/hq/91e2vla/close_box_15hz_no_force_no_speed/step_0010000.pt
```

## 双臂和相机坐标约定

两版配置同步采用 [yw 标定 aa219ea](https://github.com/winkysky/yw/blob/aa219ea6779a2b30101f2de80b2dfc499185ee3f/lerobot_hdf5_tools/camera_params.json)。
`world` 明确定义为左臂记录 base；`base_to_world=[I, left_base_T_right_base]`。
右基座变换约为 `Rx(pi)`，平移 `[0.000221830, -0.000030121, -0.230034851]` 米；
配置使用完整精度值，不能只加平移或改位置而不改姿态。

参考数据虽名为 `observation.tcp_pose` / `action.tcp_pose_cmd`，按 yw 的约定均为
各臂 base 下的法兰位姿（位置 mm、外禀 xyz 欧拉角 degree）。读取时执行：

```text
world_T_tcp = world_T_arm_base @ arm_base_T_flange @ flange_T_tcp
world_T_wrist_camera = world_T_tcp @ inverse(flange_T_tcp) @ flange_T_camera
world_T_head_camera = world_T_left_base @ left_base_T_head_camera
camera_T_tcp = inverse(world_T_camera) @ world_T_tcp
```

只将原始位置缩放一次；基座/相机配置的平移均为米，工具偏移已从 230 mm 转为 0.23 m。
三相机的 K 和法兰相机外参与参考一致；内参按 640×480 到模型图像尺寸缩放，保留像素中心修正。
左右臂在抽取历史、未来窗口以及调速插值之前统一坐标，在线速度版也共用相机变换函数。
模型输出同样是左 base 下的 TCP；发送机器人前需逆变换回各臂 base 和法兰，现有速度版
`ObservationCodec.output` 已执行此逆变换。

若使用已统一 base 的数据，应显式将两组 `base_to_world` 设为单位矩阵；若字段已为真实 TCP，
则将 `pose_to_tcp` 设为单位矩阵，并将腕相机外参改成对应 TCP 下的标定，避免重复工具偏移。
旧 checkpoint 保存了单位矩阵基座配置，不能直接用新配置续训；训练入口已有配置一致性检查。
新训练使用修正配置，推理使用其 checkpoint 内保存的同一配置。

参考基座关系由 URDF 与记录位姿拟合；头相机沿用原标定并做过视觉检查，未重新标定。
右工具偏移仍是左工具的暂定副本，基座对齐不等于完成右工具标定。

```bash
conda activate e2vla
cd /home/hq/code/e2vla_lerobot_no_force_both_20261116_004102/e2vla
python train_lerobot_no_force.py --check-data

CUDA_VISIBLE_DEVICES=0 python train_lerobot_no_force.py \
  --batch-size 32 --workers 4 --max-steps 100000 \
  --output checkpoints/lerobot_no_force_no_speed_close_box
```

使用 `--data-root /path/to/standard_lerobot_dataset` 可以覆盖根目录。
复核快照必须使用上节的专用配置，不能仅对旧标准数据配置覆盖 `--data-root`。

检查点格式为 `e2vla_lerobot_no_force_no_speed_v1`，保存动作专家、优化器、
调度器、随机状态、数据游标及配置。原模型视觉权重保持冻结，需单独提供缓存。
续训必须保持训练选项一致，`--max-steps` 表示原先约定的总更新步数：

```bash
CUDA_VISIBLE_DEVICES=0 python train_lerobot_no_force.py \
  --batch-size 32 --workers 4 --max-steps 100000 \
  --output checkpoints/lerobot_no_force_no_speed_close_box \
  --resume checkpoints/lerobot_no_force_no_speed_close_box/step_0002000.pt
```

## 模型推理

模型内部每臂 10 维动作：平移 3 + 旋转 6 + 夹爪 1。
输入历史 `(B,5,2,17)`，输出 `(B,32,2,17)`，17=位姿矩阵16+夹爪1。
复用原始模型的 Python 推理接口，不需要速度输入；尚未新增本版机器人通信服务。

```python
import torch
from data_utils.lerobot_no_force import LeRobotNoForceConfig, collate_lerobot_no_speed
from data_utils.lerobot_reviewed_no_force import ReviewedNoForceConfig
from train_lerobot_no_force import FORMAT, build_model, build_dataset

checkpoint = torch.load("BASE.pt", map_location="cpu", weights_only=False)
assert checkpoint["format"] == FORMAT
model = build_model(**checkpoint["model_config"]).cuda().eval()
model.actor.load_state_dict(checkpoint["actor"], strict=True)

# 以下用一个离线样本演示接口；部署时应提供同样的当前图像、状态历史和标定。
config_type = ReviewedNoForceConfig if "reviewed_datasets" in checkpoint["data_config"] else LeRobotNoForceConfig
dataset = build_dataset(config_type(**checkpoint["data_config"]))
batch = collate_lerobot_no_speed([dataset[0]])
dataset.close()
batch = {k: v.cuda() if torch.is_tensor(v) else v for k, v in batch.items()}
batch["gt_future_ee_states"] = torch.zeros_like(batch["gt_future_ee_states"])
with torch.inference_mode():
    prediction = model(**batch, inference=True, fp16=True)
```

未来张量只作为形状占位；推理不读取其真值。
模型预测夹爪没有硬范围保证，执行适配需要按原有约定裁剪至 [0,1] 后转换原始指令。

## 验证

```bash
python -m pytest tests_lerobot_vel_no_force/test_no_speed.py tests_lerobot_vel_no_force/test_reviewed_no_speed.py -q
```

测试覆盖原模型复用、无速度/力输入、原始动作和夹爪约定、双臂32步前后向、
无未来真值推理、检查点读写与版本隔离。链路验证不代表任务收敛或真机效果。
复核适配器另覆盖 15 Hz 取样、奇数坏帧阻断、修正数值、人工指令、同名 episode
跨来源视频路由、多进程读取、配置覆盖和预训练严格加载。
