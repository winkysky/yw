"""Regression checks for the visualization coordinate and inference boundaries."""
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from pathlib import Path

import numpy as np
import torch
from scipy.spatial.transform import Rotation

from datavis_lerobot import (inference_inputs, project_points, resized_intrinsics,
                             trajectory_metrics, browse)


class VisualizationGeometryTests(unittest.TestCase):
    def test_projection_uses_inverse_camera_pose(self):
        wc = np.eye(4)
        wc[:3, :3] = Rotation.from_euler('z', 90, degrees=True).as_matrix()
        wc[:3, 3] = [1., 2., 3.]
        camera_points = np.array([[.2, -.4, 2.], [0, 0, -1.], [0, 0, 0.]])
        world_points = camera_points @ wc[:3, :3].T + wc[:3, 3]
        uv, valid = project_points(world_points, wc, np.array([[100, 0, 50], [0, 200, 60], [0, 0, 1.]]))
        np.testing.assert_allclose(uv[0], [60, 20], atol=1e-10)
        np.testing.assert_array_equal(valid, [True, False, False])
        self.assertTrue(np.isnan(uv[1:]).all())

    def test_camera_resize_keeps_pixel_centers(self):
        cfg = SimpleNamespace(image_size=[256, 256], geometry={'cameras': {'head': {
            'image_size': [480, 640], 'K': [[400, 0, 320], [0, 390, 240], [0, 0, 1]]}}})
        k = resized_intrinsics(cfg, 'head')
        np.testing.assert_allclose(k, [[160, 0, 127.7], [0, 208, 127.7666666667], [0, 0, 1]])

    def test_pose_metrics_resolve_arms_and_units(self):
        gt = np.zeros((32, 2, 17), dtype=np.float64)
        gt[..., :16] = np.eye(4).reshape(16)
        pred = gt.copy()
        pose = pred[..., :16].reshape(32, 2, 4, 4)
        pose[:, 0, 0, 3] = .01
        pose[:, 1, :3, :3] = Rotation.from_euler('z', 30, degrees=True).as_matrix()
        pred[:, 1, 16] = .25
        metrics = trajectory_metrics(pred, gt)
        self.assertAlmostEqual(metrics['left']['position_mean_error_mm'], 10.)
        self.assertAlmostEqual(metrics['left']['rotation_mean_error_deg'], 0.)
        self.assertAlmostEqual(metrics['right']['position_mean_error_mm'], 0.)
        self.assertAlmostEqual(metrics['right']['rotation_mean_error_deg'], 30.)
        self.assertAlmostEqual(metrics['right']['gripper_mean_abs_error'], .25)

    def test_inference_receives_no_ground_truth_values(self):
        sample = dict(obs_rgbs=torch.zeros(1, 3, 3, 32, 32),
                      obs_masks=torch.ones(1, 3, 32, 32, dtype=torch.bool),
                      obs_norm_xys=torch.zeros(1, 3, 2, 32, 32),
                      obs_extrinsics=torch.eye(4).repeat(1, 3, 1, 1),
                      prompt_text='test', current_ee_pose=torch.eye(4).repeat(2, 1, 1),
                      history_ee_states=torch.ones(5, 2, 17),
                      gt_future_ee_states=torch.full((32, 2, 17), float('nan')),
                      valid_ee_mask=torch.tensor([True, True]))
        inputs = inference_inputs(sample, 'cpu')
        self.assertEqual(inputs['gt_future_ee_states'].shape, (1, 32, 2, 17))
        self.assertTrue((inputs['gt_future_ee_states'] == 0).all())
        self.assertTrue(torch.isnan(sample['gt_future_ee_states']).all())
        self.assertEqual(inputs['valid_ee_mask'].tolist(), [[True, True]])
        # A speed reader also emits labels. The selected runtime speed is passed
        # explicitly by Viewer, so labels must not leak into model observations.
        speed_sample = dict(sample, gt_speed_cond=torch.tensor(float('nan')), success=None)
        speed_inputs = inference_inputs(speed_sample, 'cpu')
        self.assertNotIn('gt_speed_cond', speed_inputs)
        self.assertNotIn('success', speed_inputs)
        for key, value in inputs.items():
            if torch.is_tensor(value):
                torch.testing.assert_close(value, speed_inputs[key], rtol=0, atol=0)
            else:
                self.assertEqual(value, speed_inputs[key])

    def test_browser_episode_sample_and_inference_controls(self):
        requests = []
        def get_sample(index, infer):
            requests.append((index, infer))
            return {}, None, {}
        viewer = SimpleNamespace(model=object(), dataset=list(range(30)),
                                 episode_starts=[0, 10, 20], config=None, sample=get_sample)
        # Next sample, next episode, previous episode, toggle inference, quit.
        with patch.dict('os.environ', {'DISPLAY': ':test'}), \
                patch('datavis_lerobot.cv2.namedWindow'), patch('datavis_lerobot.cv2.resizeWindow'), \
                patch('datavis_lerobot.cv2.imshow'), patch('datavis_lerobot.cv2.destroyAllWindows'), \
                patch('datavis_lerobot.render', return_value=np.zeros((10, 10, 3), np.uint8)), \
                patch('datavis_lerobot.cv2.waitKeyEx', side_effect=[ord(k) for k in 'dnpiq']):
            browse(viewer, Path('/tmp'), 0)
        self.assertEqual(requests, [(0, True), (1, True), (10, True), (0, True), (0, False)])


if __name__ == '__main__':
    unittest.main()
