import copy
import json
from pathlib import Path
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor

import torch

from data_utils.lerobot_vel_no_force import camera_pose_in_world
from lerobot_inference import LeRobotPolicy, make_data_config, contract_signature, camera_rays, validate_inputs


ROOT = Path(__file__).resolve().parents[1]
if not (ROOT / 'configs_lerobot_no_force').exists():
    ROOT = Path('/home/hq/code/e2vla_lerobot_no_force_both_20261116_004102/e2vla')


def fixture():
    cfg = make_data_config(json.loads((ROOT / 'configs_lerobot_no_force/reviewed_close_box_15hz.json').read_text())['data'])
    pose = torch.eye(4).repeat(2, 1, 1)
    pose[:, :3, 3] = torch.tensor([[-.4,-.2,-.1],[-.4,-.2,-.3]])
    history = torch.cat([pose.reshape(2,16), torch.ones(2,1)*.5], -1).repeat(5,1,1)
    extrinsics = torch.stack([camera_pose_in_world(pose, cfg, cfg.geometry['cameras'][key]) for key in cfg.camera_keys])
    rays = camera_rays(cfg)
    obs = dict(obs_rgbs=torch.zeros(1,1,3,3,256,256), obs_masks=torch.ones(1,1,3,256,256,dtype=torch.bool),
               obs_norm_xys=rays.clone(), obs_extrinsics=extrinsics[None,None],
               prompt_text=['close the box'], current_ee_pose=pose[None], history_ee_states=history[None],
               valid_ee_mask=torch.ones(1,2,dtype=torch.bool), gt_future_ee_states=torch.full((1,32,2,17),float('nan')))
    return cfg, rays, obs


class FakeModel:
    def __init__(self):
        self.active = 0
        self.max_active = 0
    def __call__(self, **batch):
        assert (batch['gt_future_ee_states'] == 0).all()
        assert batch['inference'] is True
        self.active += 1
        self.max_active = max(self.active, self.max_active)
        time.sleep(.01)
        result = torch.rand(batch['gt_future_ee_states'].shape)
        self.active -= 1
        return result


class InferenceContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        cls.cfg, cls.rays, cls.obs = fixture()

    def test_root_can_differ_but_task_cannot(self):
        cfg = copy.deepcopy(self.cfg)
        cfg.root = '/some/client/mount'
        self.assertEqual(contract_signature(cfg), contract_signature(self.cfg))
        cfg.reviewed_datasets = ['open_the_box_1109_60/success']
        self.assertNotEqual(contract_signature(cfg), contract_signature(self.cfg))

    def test_future_nan_is_ignored_and_shape_is_server_owned(self):
        obs = dict(self.obs, gt_future_ee_states=torch.full((1,999,1,2),float('nan')))
        batch = validate_inputs(obs, self.cfg, self.rays)
        self.assertEqual(batch['gt_future_ee_states'].shape, (1,32,2,17))
        self.assertTrue((batch['gt_future_ee_states'] == 0).all())

    def test_camera_frame_mismatch_is_rejected(self):
        obs = copy.deepcopy(self.obs)
        obs['obs_extrinsics'][0,0,2,0,3] += .23
        with self.assertRaisesRegex(ValueError, 'Camera poses'):
            validate_inputs(obs, self.cfg, self.rays)

    def test_wrong_intrinsics_and_missing_right_arm_are_rejected(self):
        obs = copy.deepcopy(self.obs)
        obs['obs_norm_xys'] *= 2
        with self.assertRaisesRegex(ValueError, 'Camera rays'):
            validate_inputs(obs, self.cfg, self.rays)
        obs = copy.deepcopy(self.obs)
        obs['valid_ee_mask'][0,1] = False
        with self.assertRaisesRegex(ValueError, 'both arms'):
            validate_inputs(obs, self.cfg, self.rays)

    def test_calls_are_serial_and_seeded_without_changing_process_rng(self):
        policy = object.__new__(LeRobotPolicy)
        policy.variant = "no_speed"
        policy.config, policy.expected_rays = self.cfg, self.rays
        policy.signature = contract_signature(self.cfg)
        policy.device, policy.bf16 = torch.device('cpu'), False
        policy.model, policy.lock = FakeModel(), threading.Lock()
        before = torch.get_rng_state().clone()
        with ThreadPoolExecutor(2) as pool:
            futures = [pool.submit(policy.run_inference, self.obs, 42, policy.signature) for _ in range(2)]
            outputs = [f.result() for f in futures]
        torch.testing.assert_close(outputs[0], outputs[1], rtol=0, atol=0)
        self.assertEqual(policy.model.max_active, 1)
        self.assertTrue(torch.equal(before, torch.get_rng_state()))
        with self.assertRaisesRegex(ValueError, 'contract differs'):
            policy.run_inference(self.obs, 42, 'wrong-task')


if __name__ == '__main__':
    unittest.main()
