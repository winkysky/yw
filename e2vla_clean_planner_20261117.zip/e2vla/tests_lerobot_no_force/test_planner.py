"""Planner sampling, coordinate ownership, state isolation and real Pyro4 calls."""
from dataclasses import replace
import copy
import json
from pathlib import Path
import signal
import threading
import uuid

import numpy as np
import pytest
import torch

from data_utils.lerobot_observation import LeRobotDataSampler, HistoryNotReady
from data_utils.lerobot_vel_no_force import camera_pose_in_world, decode_tcp
from infer_utils.planner import LeRobotTrajPlanner
from infer_utils.planner_config import PlannerConfig
from infer_utils.remote_service import Service
from lerobot_inference import make_data_config, contract_signature, camera_rays, validate_inputs
from e03_lerobot_client.clients.lerobot_policy import RemotePolicy, connect_policy

ROOT = Path(__file__).resolve().parents[1]


class FakePolicy:
    def __init__(self, variant):
        self.variant, self.task, self.device, self.path = variant, 'close_box', torch.device('cpu'), Path('fake.pt')
        recipe = (ROOT/'configs_lerobot_no_force/reviewed_close_box_15hz.json' if variant == 'no_speed'
                  else ROOT/'configs_lerobot_vel_no_force/reviewed_close_box_30hz_speed.json')
        self.config = make_data_config(json.loads(recipe.read_text())['data'])
        self.calls = []

    def get_info(self):
        from dataclasses import asdict
        return dict(variant=self.variant, task=self.task, data_config=asdict(self.config),
                    contract_sha256=contract_signature(self.config), arm_order=['left','right'],
                    world_frame='left_recorded_arm_base', checkpoint='fake.pt', checkpoint_step=0)

    def run_inference(self, obs, seed=None, contract_sha256=None, speed_mps=None, guidance_scale=1.):
        if self.variant == 'speed' and speed_mps is None:
            raise ValueError('speed_mps required')
        batch = validate_inputs(obs, self.config, camera_rays(self.config))
        self.calls.append(dict(batch=batch, speed_mps=speed_mps))
        result = batch['history_ee_states'][:, -1:].repeat(1, 32, 1, 1)
        result[..., 3] += torch.arange(32)[None, :, None]*(speed_mps or .01)/self.config.target_fps
        return result


def make_frames(config, count):
    frames = []
    image = np.zeros((480, 640, 3), np.uint8)
    image[..., 0] = np.arange(640, dtype=np.uint16)[None] % 256
    image[..., 1] = np.arange(480, dtype=np.uint16)[:, None] % 256
    for i in range(count):
        tcp = np.tile(np.eye(4, dtype=np.float32), (2,1,1))
        tcp[:, :3, 3] = [[-.4+i*.001,-.2,-.1],[-.4,-.2+i*.002,-.3]]
        frame = dict(timestamp=100+i/30, ee_pose=tcp, gripper=np.array([.2,.8], np.float32))
        for key in config.camera_keys:
            camera = config.geometry['cameras'][key]
            frame[key] = dict(camera=dict(K=camera['K']),
                              data=dict(color=image, encoding='rgb', timestep=frame['timestamp'],
                                        wcT=camera_pose_in_world(torch.from_numpy(tcp), config, camera).numpy()))
        frames.append(frame)
    return frames


@pytest.mark.parametrize('variant,count,stride', [('no_speed',9,2),('speed',5,1)])
def test_measured_history_output_timing_and_reset(variant, count, stride):
    policy = FakePolicy(variant)
    planner = LeRobotTrajPlanner(policy=policy)
    planner.set_prompt('close the box')
    if variant == 'speed':
        planner.set_speed(.05)
    assert planner.get_action() is None
    frames = make_frames(policy.config, count)
    planner.add_obs_frames(frames[:2])
    assert planner.get_action() is None
    planner.add_obs_frames(frames[2:])
    poses, grippers, times, image = planner.get_action(draw_traj=True)
    assert poses.shape == (32,2,4,4) and grippers.shape == (32,2)
    np.testing.assert_allclose(times, frames[-1]['timestamp']+np.arange(32)/policy.config.target_fps)
    history = policy.calls[-1]['batch']['history_ee_states'][0,:,:,:16].numpy().reshape(5,2,4,4)
    np.testing.assert_array_equal(history, np.stack([f['ee_pose'] for f in frames[::stride]]))
    assert image.shape == (256,768,3)
    assert policy.calls[-1]['speed_mps'] == (.05 if variant == 'speed' else None)
    planner.set_ensemble_nums(3)
    planner.ensemble_traj(poses, grippers, times)
    planner.reset()
    assert planner.get_action() is None
    assert len(planner.pos_ensembler.history_traj) == 0
    assert len(planner.pos_ensembler.history_time) == 0


def test_recorded_and_world_input_align_right_arm_exactly_once():
    cfg = FakePolicy('speed').config
    raw = np.array([[120,20,300,10,20,30], [120,20,300,10,20,30]], np.float32)
    expected = decode_tcp(raw.reshape(1,-1), cfg)[0]
    world = make_frames(cfg,5)
    for frame in world:
        frame['ee_pose'] = expected.copy()
        frame['gripper'] = np.array([0.,1.],np.float32)
        for key in cfg.camera_keys:
            frame[key]['data']['wcT'] = camera_pose_in_world(torch.from_numpy(expected), cfg, cfg.geometry['cameras'][key]).numpy()
    local = copy.deepcopy(world)
    for frame in local:
        frame['ee_pose'] = raw.copy()
        frame['gripper'] = np.array([1886,0])
    a, b = LeRobotDataSampler(cfg), LeRobotDataSampler(cfg, 'recorded', 'raw')
    for x,y in zip(world,local):
        a.add_obs_frame(x); b.add_obs_frame(y)
    for key,value in a.sample_framedict('task').items():
        if torch.is_tensor(value):
            torch.testing.assert_close(value,b.sample_framedict('task')[key],rtol=0,atol=0)
    np.testing.assert_array_equal(a.latest['ee_pose'],expected)


@pytest.mark.parametrize('fault',['gap','duplicate','intrinsics','extrinsics','image_time','rotation'])
def test_bad_observations_cannot_silently_produce_actions(fault):
    policy=FakePolicy('speed'); planner=LeRobotTrajPlanner(policy=policy)
    planner.set_prompt('task'); planner.set_speed(.05)
    frames=make_frames(policy.config,5); key=policy.config.camera_keys[0]
    if fault=='gap':
        frames.pop(2);planner.add_obs_frames(frames)
        assert planner.get_action() is None
        assert not policy.calls
        return
    if fault=='duplicate': frames[-1]['timestamp']=frames[-2]['timestamp']
    elif fault=='intrinsics': frames[-1][key]['camera']['K']=np.eye(3)
    elif fault=='extrinsics': frames[-1][key]['data']['wcT']=np.eye(4)
    elif fault=='image_time': frames[-1][key]['data']['timestep']-=1
    elif fault=='rotation': frames[-1]['ee_pose'][0,0,0]=-1
    with pytest.raises(ValueError): planner.add_obs_frames(frames)
    assert not planner.sampler.states  # batch upload is atomic


def test_configuration_does_not_change_checkpoint_geometry():
    p=LeRobotTrajPlanner(policy=FakePolicy('no_speed'))
    with pytest.raises(ValueError): p.set_speed(.1)
    with pytest.raises(ValueError): p.set_config({'base_to_world':np.eye(4)})
    with pytest.raises(ValueError): p.set_config({'history_tolerance_s':1.})
    assert p.settings.history_tolerance_s is None
    files = list((ROOT/'configs_inference').glob('*.json'))
    assert len(files) == 1 and files[0].name == 'planner.json'
    assert PlannerConfig.load(files[0]).task is None


@pytest.mark.parametrize('variant',['no_speed','speed'])
def test_thin_client_and_stateful_service_over_real_pyro(variant):
    import Pyro4
    import Pyro4.naming
    old_serializers=Pyro4.config.SERIALIZERS_ACCEPTED
    old_signals={s:signal.getsignal(s) for s in (signal.SIGINT,signal.SIGTERM)}
    Pyro4.config.SERIALIZERS_ACCEPTED=set(old_serializers)|{'pickle'}
    ns=daemon=client=None; threads=[]
    class LoopbackService(Service):
        @Pyro4.expose
        def get_machine_id_via_uuid(self): return str(uuid.getnode())
        @Pyro4.expose
        @Pyro4.oneway
        def request_closing_proxy(self,name): pass
    try:
        try:
            _,ns,_=Pyro4.naming.startNS(host='127.0.0.1',port=0,enableBroadcast=False)
        except PermissionError:
            pytest.skip('Loopback sockets unavailable in this sandbox')
        daemon=Pyro4.Daemon(host='127.0.0.1',port=0)
        policy=FakePolicy(variant); service=LoopbackService(policy=policy)
        ns.nameserver.register('planner_test',daemon.register(service))
        for server in (ns,daemon):
            thread=threading.Thread(target=server.requestLoop,daemon=True);thread.start();threads.append(thread)
        client=connect_policy(dict(uri='planner_test',ns_host='127.0.0.1',ns_port=ns.sock.getsockname()[1],timeout_s=10),
                              policy.config.camera_keys,2,'close_box')
        client.start('task',speed_mps=.05 if variant=='speed' else None)
        frames=make_frames(policy.config,5 if variant=='speed' else 9)
        result=client.infer(frames,seed=42)
        assert result.poses.shape==(32,2,4,4)
        np.testing.assert_allclose(result.times[0],frames[-1]['timestamp'])
        assert len(policy.calls)==1
        assert client.proxy._force_use_socket is True
    finally:
        if client is not None: client.close()
        for server in (daemon,ns):
            if server is not None:server.shutdown();server.close()
        for thread in threads:thread.join(timeout=3)
        Pyro4.config.SERIALIZERS_ACCEPTED=old_serializers
        for s,handler in old_signals.items():signal.signal(s,handler)
