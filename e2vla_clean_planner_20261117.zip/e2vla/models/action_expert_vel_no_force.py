"""Action-only E2VLA with external continuous speed and optional legacy bins.

The training entry selects continuous m/s conditioning and a 32-step horizon.
Continuous mode has no speed-classification loss and corrects the inherited
QFormer mask in a local adapter. Frozen backbones, geometry, DiT and DDIM remain.
"""
import torch
import torch.nn.functional as F
from torch import nn, Tensor
from diffusers import DDIMScheduler
from typing import Optional, Tuple, Dict, List

from .action_expert_vel import (
    ContextEncoder, states2action_wo_gripper_norm, action2states_wo_gripper_norm,
    get_target,
)
from .dit import DiT
from .velocity_head import VelocityHead
from .continuous_speed import ContinuousSpeedEmbedding, speed_tensor
from .layers.utils import simple_mlp
from .layers.pe import SinusoidalPosEmb
from .layers.rot_transforms import rotation_6d_to_matrix


class DiffusionHeadVelocityNoForce(nn.Module):
   
    def __init__(self, hdim: int, num_heads: int, nhist: int, act_dim: int, num_layers: int, num_velocity_bins: int = 5,
                 continuous_speed=False, speed_scale_mps=.1):
        super().__init__()
        self.hdim = hdim
        self.nhist = nhist
        self.act_dim = act_dim
        self.num_layers = num_layers
        self.num_velocity_bins = num_velocity_bins
        self.continuous_speed = continuous_speed
        self.hist_enc = simple_mlp([act_dim, hdim, hdim], ln=True)# 历史
        self.traj_enc = simple_mlp([act_dim, hdim, hdim], ln=True) # 预测
        self.abs_pos_enc = simple_mlp([3, hdim, hdim], ln=True)
        self.traj_time_embed = SinusoidalPosEmb(hdim)
        self.denoising_time_embed = nn.Sequential(
            SinusoidalPosEmb(hdim),
            simple_mlp([hdim, hdim, hdim], ln=True)
        )

        self.success_enc = nn.Sequential(
            nn.Embedding(2, hdim),           # 0=失败, 1=成功，各自学习独立的 hdim 维向量
            simple_mlp([hdim, hdim, hdim], ln=True)
        )


        self.velocity_enc = nn.Sequential(
            nn.Embedding(num_velocity_bins, hdim),
            simple_mlp([hdim, hdim, hdim], ln=True)
        )
        if continuous_speed:
            self.velocity_enc = ContinuousSpeedEmbedding(hdim, speed_scale_mps)

        ### traj self attn + traj-context cross attn
        self.traj_context_attn = DiT(hdim, num_heads, num_layers, use_adaln=True)

        ### final mlp
        self.act_head = simple_mlp([hdim, hdim, act_dim], ln=True)
        self.reset_parameters()
    
    def reset_parameters(self):
        nn.init.zeros_(self.abs_pos_enc[-1].weight)
        nn.init.zeros_(self.act_head[-1].weight)
    
    def pos_rel2abs(self, cur_wcT: Tensor, cur_weT: Tensor, t3r6: Tensor):
    
     
        ecT = torch.inverse(cur_weT) @ cur_wcT  # (B, 4, 4)
        ecR = ecT[:, :3, :3]  # (B, 3, 3)
        
        e1e2R = ecR[:, None] @ rotation_6d_to_matrix(t3r6[..., 3:]) @ ecR[:, None].transpose(-1, -2)
        e1e2t = (ecR[:, None] @ t3r6[..., :3].unsqueeze(-1)).squeeze(-1)
        
        e1e2T = e1e2t.new_zeros(*e1e2t.shape[:-1], 4, 4)
        e1e2T[..., :3, :3] = e1e2R
        e1e2T[..., :3, 3] = e1e2t
        e1e2T[..., 3, 3] = 1

        traj_ceT = (torch.inverse(cur_wcT) @ cur_weT)[:, None] @ e1e2T
        traj_cet = traj_ceT[..., :3, 3]  # (B, T, 3)
        return traj_cet

    def forward(
        self, 
        denoise_timestep: Tensor, 
        trajectory: Tensor, 
        cur_wcT: Tensor, 
        cur_weT: Tensor, 
        history: Tensor,
        conds: List[Tensor],
        cond_masks: Optional[List[Optional[Tensor]]],
        fp16: bool,
        success=None,
        velocity_bin_idx: Optional[Tensor] = None,
    ):
       
        denoise_time_embed = self.denoising_time_embed(denoise_timestep)  # (B, hdim)
        film = denoise_time_embed

        # noisy trajectory add temporal positional embeddings
        B, nhist, _ = history.shape
        B, Ta, _ = trajectory.shape
        hist_feats = self.hist_enc(history[..., :self.act_dim])  # (B, nhist, hdim)
        traj_feats = self.traj_enc(trajectory[:, :, :self.act_dim])  # (B, Ta, hdim)

        full_traj_feats = torch.cat([hist_feats, traj_feats], dim=1)  # (B, nhist+Ta, hdim)
        full_traj_time_pe = self.traj_time_embed(torch.arange(nhist + Ta).to(traj_feats))
        full_traj_feats = full_traj_feats + full_traj_time_pe[None].expand(B, -1, -1)  # (B, nhist+Ta, hdim)


        # get absolute pos under camera, add additional positional encoding
        with torch.no_grad():
            full_traj_t3r6 = torch.cat([history[..., :9], trajectory[..., :9]], dim=1)  # (B, nhist+Ta, 9)
            abs_pos = self.pos_rel2abs(cur_wcT, cur_weT, full_traj_t3r6)
        full_traj_feats[:, :nhist + Ta] = full_traj_feats[:, :nhist + Ta] + self.abs_pos_enc(abs_pos)

        # --- 修正点: meta_contrib 显式累加，不再用 film 减法反推 ---
        meta_contrib = torch.zeros_like(denoise_time_embed)

        if success is not None:
            success = success.reshape(B).long()
            success_feat = self.success_enc[0](success)       # Embedding, (B, hdim)
            success_feat = self.success_enc[1](success_feat) # MLP, (B, hdim)

            # 独立丢弃：10% 概率单独 mask
            if self.training:
                ind_mask = (torch.rand(B, device=success.device) >= 0.10).float().unsqueeze(-1)
                success_feat = success_feat * ind_mask

            meta_contrib = meta_contrib + success_feat

        if velocity_bin_idx is not None:
            if self.continuous_speed:
                velocity_bin_idx = velocity_bin_idx.reshape(B)
                velocity_feat = self.velocity_enc(velocity_bin_idx)
            else:
                velocity_bin_idx = velocity_bin_idx.reshape(B).long()
                velocity_feat = self.velocity_enc[0](velocity_bin_idx)
                velocity_feat = self.velocity_enc[1](velocity_feat)

            # 独立丢弃: 10% 概率单独 mask 掉 velocity 这一路信号
            # 修正点: 0.05 -> 0.10，和注释、和 success 保持一致的独立丢弃比例
            if self.training:
                ind_mask = (torch.rand(B, device=velocity_bin_idx.device) >= 0.10).float().unsqueeze(-1)
                velocity_feat = velocity_feat * ind_mask

            meta_contrib = meta_contrib + velocity_feat

        # 整体丢弃：15% 概率整个元数据块归零
        # 修正点: 触发条件改成检查 success 或 velocity_bin_idx 任一存在，
        # 不再只看 success is not None —— 否则 success=None 但
        # velocity_bin_idx 有值时，velocity 这一路会完全跳过整体丢弃
        if self.training and (success is not None or velocity_bin_idx is not None):
            global_mask = (torch.rand(B, device=denoise_timestep.device) >= 0.15).float().unsqueeze(-1)
            meta_contrib = meta_contrib * global_mask

        film = film + meta_contrib

        with torch.autocast(
            denoise_time_embed.device.type, 
            torch.bfloat16 if fp16 else torch.float32
        ):
            full_traj_feats = self.traj_context_attn(
                x=full_traj_feats, 
                x_pe=None, 
                x_mask=None,
                conds=conds,
                cond_masks=cond_masks, 
                films=[film]*len(conds)
            )

        traj_feats = full_traj_feats[:, nhist:nhist+Ta]  # (B, Ta, hdim)
        action = self.act_head(traj_feats)
        return action


class ActionExpertVelocityNoForce(nn.Module):
    def __init__(
        self, 
        hdim: int, 
        num_heads: int, 
        nhist: int,
        num_context_layers: int,
        num_diffusion_layers: int, 
        diffusion_timesteps: int = 100, 
        inference_timesteps: Optional[int] = None, 

        use_velocity_conditioning: bool = True,
        velocity_num_bins: int = 5,
        velocity_boundaries: Optional[List[float]] = None,
        velocity_bin_centers: Optional[List[float]] = None,
        velocity_speed_min: float = 0.0,
        velocity_speed_max: float = 1.0,
        velocity_input_is_normalized: bool = True,
        continuous_speed: bool = False,
        speed_scale_mps: float = .1,
        action_horizon: int | None = None,
    ):
        super().__init__()
        if velocity_num_bins != 5:
            raise ValueError("Keep the source model's five speed bins; task boundaries/centers remain configurable")
        num_velocity_queries = 1 if use_velocity_conditioning else 0
        self.use_velocity_conditioning = use_velocity_conditioning
        self.continuous_speed = continuous_speed
        self.action_horizon = action_horizon
        if continuous_speed and not use_velocity_conditioning:
            raise ValueError("Continuous-speed training requires velocity conditioning")

        self.context_encoder = ContextEncoder(hdim, num_heads, num_layers=num_context_layers,num_velocity_queries=num_velocity_queries)
        self.dp_head = DiffusionHeadVelocityNoForce(hdim, num_heads, nhist, self.act_dim, num_layers=num_diffusion_layers,
                                                  continuous_speed=continuous_speed, speed_scale_mps=speed_scale_mps)
        if continuous_speed:
            from .qformer_velocity_corrected import correct_context_mask
            correct_context_mask(self.context_encoder, hdim, num_heads)

        if use_velocity_conditioning and not continuous_speed:
            self.velocity_head = VelocityHead(
                hdim=hdim,
                num_bins=velocity_num_bins,
                boundaries=velocity_boundaries,
                bin_centers=velocity_bin_centers,
                speed_min=velocity_speed_min,
                speed_max=velocity_speed_max,
                input_is_normalized=velocity_input_is_normalized,
            )
        else:
            self.velocity_head = None

        self.noise_scheduler = DDIMScheduler(
            num_train_timesteps=diffusion_timesteps,
            beta_schedule="squaredcos_cap_v2",
            prediction_type="epsilon",
            clip_sample=False
        )

        self.diffusion_timesteps = diffusion_timesteps
        if inference_timesteps is None:
            inference_timesteps = max(diffusion_timesteps//5, 10)
        self.inference_timesteps = inference_timesteps
        self.inference_scheduler = self.noise_scheduler

    @property
    def act_dim(self):
        """dimension of action defined in camera frame"""
        return 10

    def iterative_denoise(
        self, 
        traj_shape: Tuple[int, int, int],
        fixed_inputs: Dict[str, Tensor],
        initial_noise: Optional[Tensor] = None,
        guidance_scale=1.0,
    ):
        """
        Args:
            trajectory_shape: (B, Ta, act_dim)
            fixed_inputs: inputs for diffusion head
            initial_noise: (B, Ta, act_dim) or None

        Returns:
            trajectory: (B, Ta, act_dim)
        """
        if initial_noise is None:
            B, Ta, _ = traj_shape
            device = next(iter(fixed_inputs.values())).device
            initial_noise = torch.randn(B, Ta, self.act_dim, device=device)
        
        self.inference_scheduler.set_timesteps(self.inference_timesteps)
        trajectory = initial_noise


        uncond_inputs = dict(fixed_inputs)
        uncond_inputs["success"] = None
        uncond_inputs["velocity_bin_idx"] = None

        for t in self.inference_scheduler.timesteps:
            t_batch = t * torch.ones(trajectory.shape[0], device=trajectory.device)

            if guidance_scale == 1.0:
                out = self.dp_head(t_batch, trajectory, **fixed_inputs)
                epsilon_pred = out[..., :self.act_dim]

            else:
                # 有条件：film = timestep_embed + success_feat + ep_len_feat
                out_cond = self.dp_head(t_batch, trajectory, **fixed_inputs)
                epsilon_cond = out_cond[..., :self.act_dim]

                # 无条件：film = timestep_embed 只有时间步
                out_uncond = self.dp_head(t_batch, trajectory, **uncond_inputs)
                epsilon_uncond = out_uncond[..., :self.act_dim]

                epsilon_pred = epsilon_cond + guidance_scale * (epsilon_cond - epsilon_uncond)

            trajectory = self.inference_scheduler.step(
                epsilon_pred, t, trajectory
            ).prev_sample

        return trajectory
        

    def forward(
        self, 
        vl_obs: Dict[str, Tensor],
        vl_feature: Dict[str, Tensor], 
        current_ee_pose: Tensor, 
        history_ee_states: Tensor,
        gt_future_ee_states: Tensor,
        valid_ee_mask: Tensor, 
        inference: bool, 
        fp16: bool,
        success: Tensor,
        guidance_scale: Tensor,
        gt_speed_cond=None,
        initial_noise=None,
    ):
        if self.action_horizon is not None and gt_future_ee_states.shape[1] != self.action_horizon:
            raise ValueError(f"Expected {self.action_horizon} future targets/placeholders")
        
        latest_cam_poses = vl_obs["extrinsics"][:, -1]  # (B, Ncam, 4, 4)
        current_cam_pose = latest_cam_poses[:, 0]  # first camera, (B, 4, 4)
        
        # patch features as current observation context in diffusion
        cond, cond_mask, velocity_query = self.context_encoder(
            vl_obs=vl_obs,
            vl_feature=vl_feature,
            fp16=fp16,
        )
        
        valid_ee_per_batch = valid_ee_mask.sum(dim=-1)  # (B,)
        sel_index = torch.cat([torch.empty(n, dtype=torch.long).fill_(b) 
                               for b, n in enumerate(valid_ee_per_batch.tolist())]
                              ).to(valid_ee_mask.device)
        B_expand = len(sel_index)  # B'

        # --- 计算 velocity_bin_idx ---
        # 新逻辑: 不再用 inference 这个布尔值二选一，而是直接看
        # gt_speed_cond 有没有被传入：
        #   - gt_speed_cond 不是 None -> 不管训练还是推理，都用这个值
        #     转成 bin_idx 来 condition（推理时这就是"手动指定速度"的入口，
        #     训练时这是 teacher forcing）
        #   - gt_speed_cond 是 None 且 inference=True -> 用 VelocityHead
        #     自己的预测（argmax），即"模型自己判断该用什么速度"
        #   - gt_speed_cond 是 None 且 inference=False -> 报错，训练阶段
        #     必须有监督信号才能训 VelocityHead，不能静默地什么都不做
        # The retained internal key holds physical m/s in continuous mode.
        velocity_bin_idx = None
        velocity_metrics = {}
        if self.continuous_speed:
            velocity_bin_idx = speed_tensor(gt_speed_cond, current_ee_pose.shape[0],
                                             current_ee_pose.device)[sel_index]
        elif self.use_velocity_conditioning:
            velocity_query_expand = velocity_query[sel_index]  # (B', 1, hdim)

            if gt_speed_cond is not None:
                gt_speed_cond_expand = gt_speed_cond[sel_index]  # (B',)
                velocity_bin_idx = self.velocity_head.speed_to_bin_idx(gt_speed_cond_expand)  # (B',)
                # 在算出 velocity_bin_idx 之后，喂给 fixed_inputs 之前加一行
                print(f"[DEBUG] gt_speed_cond={gt_speed_cond}, "
                    f"resolved velocity_bin_idx={velocity_bin_idx}")

                if not inference:
                    # 训练时依然要算 VelocityHead 自己的分类 loss，让它学会
                    # "从观测预测速度"这个能力 —— 即使这次 forward 走的是
                    # teacher forcing（velocity_bin_idx 直接来自 gt），
                    # VelocityHead 的监督信号不应该因此被跳过
                    velocity_loss, velocity_metrics = self.velocity_head.loss(
                        velocity_query_expand, gt_speed_cond_expand
                    )
                # inference=True 且传了 gt_speed_cond 时，不需要算 loss，
                # 也不需要跑 VelocityHead 的 forward，直接用传入值分档即可
                # (这是"手动指定速度做实物测试"这个场景，性能上也更省一次
                # VelocityHead 的前向计算)

            elif inference:
                # 没有手动指定速度，且是推理模式 -> 用 VelocityHead 自己的
                # 预测 (确定性 argmax)，即"模型自己判断该用什么速度"
                logits = self.velocity_head(velocity_query_expand)
                velocity_bin_idx = self.velocity_head.logits_to_bin_idx(logits, mode="argmax")  # (B',)
                print(f"[DEBUG] gt_speed_cond={gt_speed_cond}, "
                    f"resolved velocity_bin_idx={velocity_bin_idx}")

            else:
                # 训练模式下必须有监督信号，不能静默跳过 VelocityHead 的训练
                raise ValueError(
                    "训练时 (inference=False) 必须提供 gt_speed_cond 才能监督 "
                    "VelocityHead，以及构造 teacher-forcing 的 velocity_bin_idx。"
                    "如果确实想训练一个不带 velocity conditioning 的模型，"
                    "应该在构造 ActionExpertVelocityNoForce 时传 "
                    "use_velocity_conditioning=False，而不是训练时漏传 "
                    "gt_speed_cond。"
                )
        # --- 计算结束 ---
        
        history_action = states2action_wo_gripper_norm(
            current_cam_pose[sel_index], 
            current_ee_pose[valid_ee_mask], 
            history_ee_states.transpose(1, 2)[valid_ee_mask],
        )  # (B', nhist, 10)   相机视角下的相对运动

        B, Ta, Nee, _ = gt_future_ee_states.shape

        # 在 forward 里，sel_index 计算之后加上这两行
        if success is not None and not isinstance(success, torch.Tensor):
            success = torch.tensor([success], device=current_ee_pose.device).expand(B)

        if success is not None:
            success = success.reshape(B)
        success_expand = success[sel_index] if success is not None else None
       
    
        if not inference:
            gt_future_action = states2action_wo_gripper_norm(
                current_cam_pose[sel_index], 
                current_ee_pose[valid_ee_mask], 
                gt_future_ee_states.transpose(1, 2)[valid_ee_mask]
            )  # (B', Ta, 10)  相机视角下的相对运动

        fixed_inputs = dict(
            history=history_action,  
            conds=[cond[sel_index]],
            cond_masks=[cond_mask[sel_index] if cond_mask is not None else cond_mask],
            cur_wcT=current_cam_pose[sel_index],      # (B', 4, 4) 
            cur_weT=current_ee_pose[valid_ee_mask],   # (B', 4, 4)
            fp16=fp16,
            success=success_expand,
            velocity_bin_idx=velocity_bin_idx, 
        
        )

        ###################### Inference ######################
        if inference:
            
            pred_actions = self.iterative_denoise(
                traj_shape=(B_expand, Ta, self.act_dim),
                fixed_inputs=fixed_inputs,
                guidance_scale=guidance_scale,
                initial_noise=initial_noise,
            )  # (B', Ta, act_dim)
            pred_future_ee_states = action2states_wo_gripper_norm(
                current_cam_pose[sel_index],    # (B', 4, 4)
                current_ee_pose[valid_ee_mask], # (B', 4, 4)
                pred_actions[..., :self.act_dim]  # (B', Ta, act_dim)
            )  # (B', Ta, 4*4+1) 世界坐标系

            pred_future_actions = pred_future_ee_states

            # put the predition back
            pred_future_actions_full = pred_future_actions.new_zeros(B, Nee, Ta, 4*4+1)
            pred_future_actions_full[..., :16] = torch.eye(4).ravel().to(pred_future_actions)
            pred_future_actions_full[valid_ee_mask] = pred_future_actions
            return pred_future_actions_full.transpose(1, 2).contiguous()  # (B, Ta, Nee, 17)

        ###################### Training ######################
        # sample noise
        noise = torch.randn(B_expand, Ta, self.act_dim, 
                            device=gt_future_ee_states.device)

        # sample a random timestep
        timesteps = torch.randint(
            0,
            self.noise_scheduler.config.num_train_timesteps,
            size=(B_expand,), 
            device=noise.device
        )

        # add noise to the clean trajectory
        noisy_trajectory = self.noise_scheduler.add_noise(
            gt_future_action, noise,
            timesteps
        )

        # one step denoising
        pred = self.dp_head(timesteps, noisy_trajectory, **fixed_inputs)
        target = get_target(gt_future_action, noise, timesteps, self.noise_scheduler)

        # loss calculation
        pos_loss = F.l1_loss(pred[..., 0:3], target[..., 0:3], reduction="mean")
        rot_loss = F.l1_loss(pred[..., 3:9], target[..., 3:9], reduction="mean")
        openness_loss = F.l1_loss(pred[..., 9:10], target[..., 9:10], reduction="mean")
        total_loss = 30 * pos_loss + 10 * rot_loss + 10 * openness_loss

        # --- 新增: 把 VelocityHead 的 loss 加进总 loss，权重先给一个保守的
        # 初始值，建议作为超参单独调，不要默认和其他 loss 同量级 ---
        if self.use_velocity_conditioning and not self.continuous_speed and not inference:
            velocity_loss_weight = 5.0  # 待调超参，先给一个不主导总loss的量级
            total_loss = total_loss + velocity_loss_weight * velocity_loss
        
        metrics = {
            "pos_loss": pos_loss.item(),
            "rot_loss": rot_loss.item(),
            "openness_loss": openness_loss.item(),
            "total_loss": total_loss.item()
        }
        metrics.update(velocity_metrics)
        return total_loss, metrics
