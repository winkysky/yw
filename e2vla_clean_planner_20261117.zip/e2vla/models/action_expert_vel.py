"""Shared implementation retained for the two LeRobot no-force policies."""
import torch
from einops import rearrange
from torch import nn, Tensor
from diffusers import DDIMScheduler
from typing import Dict
from .dit import DiT
from .qformer_vel import QFormerITM
from .layers.utils import simple_mlp
from .layers.utils import concat_mask
from .layers.attn_dn import FFWSelfAttentionLayers, init_xncoder
from .layers.rot_transforms import matrix_to_rotation_6d, rotation_6d_to_matrix


class ContextEncoder(nn.Module):
    def __init__(
        self,
        hdim: int,
        num_heads: int,
        num_layers: int,
        num_velocity_queries: int = 1,
    ):
        """
        相对原版的改动:
            qformer 新增 num_velocity_queries 个专属 query slot
            (默认1个)，用来产出喂给 VelocityHead 的 velocity_query token。
            设为0时退化为原版行为(不产出velocity_query)。
        """
        super().__init__()
        self.proj_v = nn.ModuleList([
            simple_mlp([768, hdim, hdim], ln=True),  # for dinov2 vision embeds
            simple_mlp([768, hdim, hdim], ln=True),  # for siglip vision embeds
        ])
        self.proj_l = nn.ModuleList([
            simple_mlp([768, hdim, hdim], ln=True)  # for siglip language embeds
        ])
        self.proj_pe = simple_mlp([2, hdim, hdim], ln=True)  # for normalized coordinates

        self.main_cam_embed = nn.Parameter(torch.zeros(hdim))
        self.pre_attn = DiT(hdim, num_heads, num_layers//2, use_adaln=False, 
                            pe_type="prope")  # actually, it is not a DiT but self-cross attention module
        self.qformer = QFormerITM(
            hdim, num_heads, num_layers=1, num_queries=64,
            num_velocity_queries=num_velocity_queries,
        )
        self.post_attn = FFWSelfAttentionLayers(hdim, num_heads, num_layers//2, use_adaln=False,
                                                bias=True, qk_norm=True, ffn_expansion=2)
        self.reset_parameters()

    def reset_parameters(self):
        init_xncoder(self.post_attn.num_layers, self.post_attn)
        nn.init.zeros_(self.proj_pe[-1].weight)

    def forward(
        self,
        vl_obs: Dict[str, Tensor],
        vl_feature: Dict[str, Tensor], 
        fp16: bool
    ):
        """
        Args:
            vl_obs (Dict[str, Tensor]):
                - rgb: (B, To, ncam, 3, H, W)
                - mask: (B, To, ncam, H, W)
                - norm_xy: (B, To, ncam, 2, H, W), coordinates in normalized camera plane
                - text: List (length=B) of prompt
                - extrinsics: (B, To, ncam, 4, 4), ^{world}_{camera} T
            
            vl_feature (Dict[str, Tensor]):
                - norm_xy_ds: (B, Ncam, Lv, 2)
                - vision_embeds: List (length=num_layer) of (B, Ncam, Lv, C)
                - vision_mask: (B, Ncam, Lv) or None
                - lang_embeds: List (length=num_layer) of (B, La, C)
                - lang_mask: (B, La)
                - extrinsics: (B, Ncam, 4, 4)

            fp16: if True, use bfloat16
        
        Returns
        -------
            context: (B, Ncam*Lt, hdim)
            context_mask: (B, Ncam*Lt)
            velocity_query: (B, num_velocity_queries, hdim) or None
                (num_velocity_queries=0 时为 None；下游 ActionExpert 把
                这个 token 喂给 VelocityHead，不混入 context/context_mask，
                也不会被 post_attn 处理 —— 是否需要额外的 self-attn 精炼
                velocity_query，留给后续单独评估，目前先用 qformer 内部
                attention 跑完之后的"原始"输出，保持改动最小)
        """
        B, T, Ncam, _, H, W = vl_obs["rgb"].shape
        obs_extrinsics = vl_obs["extrinsics"]  # (B, To, Ncam, 4, 4)

        # get relative camera extrinsic referring to camera 0 at the latest timestep
        cam0_extr_ref = torch.inverse(obs_extrinsics[:, -1:, 0:1]) @ obs_extrinsics  # (B, To, Ncam, 4, 4)
        x_v: Tensor = self.proj_v[0](vl_feature["vision_embeds"][0]) + \
                      self.proj_v[1](vl_feature["vision_embeds"][1])  # (B, Ncam, Lv, C)
        x_l: Tensor = self.proj_l[0](vl_feature["lang_embeds"][0])    # (B, Ncam, La, C)
        norm_xy_ds = vl_feature["norm_xy_ds"]  # (B, Ncam, Lv, 2)
        mask_v = vl_feature["vision_mask"]  # (B, Ncam, Lv)
        mask_l = vl_feature["lang_mask"]  # (B, La)

        # camera pose as positional encoding
        extrinsic_pe = cam0_extr_ref[:, -1]  # (B, Ncam, 4, 4), select the latest frame
        extrinsic_pe = extrinsic_pe[:, :, None, :, :].expand(B, Ncam, x_v.shape[-2], 4, 4)
        extrinsic_pe = rearrange(extrinsic_pe, "b n l r c -> b (n l) r c")

        # get the latest frame and projection
        x_v = rearrange(x_v, "b n l c -> b (n l) c")
        pe2d = rearrange(self.proj_pe(norm_xy_ds), "b n l c -> b (n l) c")
        if mask_v is not None:
            mask_v = rearrange(mask_v, "b n l -> b (n l)")

        # SA before qformer
        with torch.autocast(
            x_v.device.type, 
            torch.bfloat16 if fp16 else torch.float32
        ):
            x_v: Tensor = self.pre_attn(
                x=x_v + pe2d,  # add positional encoding
                x_pe=extrinsic_pe, 
                x_mask=mask_v,
                conds=[x_l],
                cond_masks=[mask_l],
                films=None
            )

        x_v = x_v.clone()
        L = x_v.shape[1] // Ncam
        x_v[:, :L] = x_v[:, :L] + self.main_cam_embed  # the first camera as main camera

        with torch.autocast(
            x_v.device.type, 
            torch.bfloat16 if fp16 else torch.float32
        ):
            # qformer 现在多返回一个 velocity_query (num_velocity_queries=0 时为 None)
            query, velocity_query, x_l, _ = self.qformer(
                x_vision=x_v,
                mask_vision=mask_v,
                x_text=x_l,
                mask_text=mask_l,
            )

            # 注意: velocity_query 不经过 post_attn —— post_attn 是为原有
            # 64个语义/视觉-语言query设计的精炼层，velocity_query 走自己
            # 独立的路径（直接喂给 VelocityHead），不应该被这一层意外改写
            query = self.post_attn(
                query=query,
            )[-1]
        
        cond = torch.cat([query, x_l], dim=1)
        cond_mask = concat_mask(mask0=None, mask1=mask_l,
                                L0=query.shape[1], L1=x_l.shape[1])
        return cond, cond_mask, velocity_query



def space_ee2cam(cur_wcT: Tensor, cur_weT: Tensor, fut_weT: Tensor):
    """
    Args:
        cur_wcT (Tensor): (B, 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (B, 4, 4), ^{world} T _{ee}
        fut_weT (Tensor): (B, T, 4, 4), future ee pose in world frame
    
    Returns:
        t3r6 (Tensor): some repr of ^{cam} v _{ee} * dt, shape (B, T, 9)
    """
    e1e2T = torch.inverse(cur_weT[:, None]) @ fut_weT  # (B, T, 4, 4)
    e1e2R = e1e2T[:, :, :3, :3]  # (B, T, 3, 3)
    e1e2t = e1e2T[:, :, :3, 3]  # (B, T, 3)

    ceT = torch.inverse(cur_wcT) @ cur_weT  # (B, 4, 4)
    ceR = ceT[:, :3, :3]  # (B, 3, 3)
    
    r = matrix_to_rotation_6d(ceR[:, None] @ e1e2R @ ceR[:, None].transpose(-1, -2))
    t = (ceR[:, None] @ e1e2t.unsqueeze(-1)).squeeze(-1)
    t3r6 = torch.cat([t, r], dim=-1)
    return t3r6



def space_cam2ee(cur_wcT: Tensor, cur_weT: Tensor, t3r6: Tensor):
    """
    Args:
        cur_wcT (Tensor): (B, 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (B, 4, 4), ^{world} T _{ee}
        t3r6 (Tensor): (B, T, 9)
    
    Returns:
        fut_weT (Tensor), future ee pose in world frame, shape (B, T, 4, 4)
    """
    ecT = torch.inverse(cur_weT) @ cur_wcT  # (B, 4, 4)
    ecR = ecT[:, :3, :3]  # (B, 3, 3)
    
    e1e2R = ecR[:, None] @ rotation_6d_to_matrix(t3r6[..., 3:]) @ ecR[:, None].transpose(-1, -2)
    e1e2t = (ecR[:, None] @ t3r6[..., :3].unsqueeze(-1)).squeeze(-1)
    
    e1e2T = e1e2t.new_zeros(*e1e2t.shape[:-1], 4, 4)
    e1e2T[..., :3, :3] = e1e2R
    e1e2T[..., :3, 3] = e1e2t
    e1e2T[..., 3, 3] = 1

    fut_weT = cur_weT[:, None] @ e1e2T
    return fut_weT



def states2action_wo_gripper_norm(cur_wcT: Tensor, cur_weT: Tensor, ee_states: Tensor):
    """
    Args:
        cur_wcT (Tensor): (B, 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (B, 4, 4), ^{world} T _{ee}
        ee_states (Tensor): (B, T, 16 or 17)
    
    Returns:
        action (Tensor): (B, T, 9 or 10)
    """
    B, Ta, C = ee_states.shape
    weT = ee_states[:, :, :16].view(B, Ta, 4, 4)
    t3r6 = space_ee2cam(cur_wcT, cur_weT, weT)
    
    if C == 16:
        return t3r6
    else:
        return torch.cat([t3r6, ee_states[:, :, -1:]], dim=-1)



def action2states_wo_gripper_norm(cur_wcT: Tensor, cur_weT: Tensor, action: Tensor):
    """
    Args:
        cur_wcT (Tensor): (B, 4, 4), ^{world} T _{cam}
        cur_weT (Tensor): (B, 4, 4), ^{world} T _{ee}
        action (Tensor): (B, T, 9 or 10)
    
    Returns:
        ee_states (Tensor): (B, T, 16 or 17)
    """
    B, Ta, C = action.shape
    t3r6 = action[:, :, :9]
    weT = space_cam2ee(cur_wcT, cur_weT, t3r6).view(B, Ta, 16)
    
    if C == 9:
        return weT
    else:
        return torch.cat([weT, action[:, :, -1:]], dim=-1)



def get_target(traj: Tensor, noise: Tensor, timesteps: Tensor, scheduler: DDIMScheduler):
    """returns supervision depending on scheduler type"""
    pred_type = scheduler.config.prediction_type
    if pred_type == "epsilon":
        target = noise
    if pred_type == "sample":
        target = traj
    if pred_type == "v_prediction":
        target = scheduler.get_velocity(traj, noise, timesteps) 
    return target

