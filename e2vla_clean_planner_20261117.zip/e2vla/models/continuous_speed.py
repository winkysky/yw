"""Continuous physical-speed conditioning, with no binning or range clipping."""
import math
import torch
from torch import nn


def speed_tensor(value, batch_size, device):
    if value is None:
        raise ValueError("This version requires an externally specified speed_mps at inference")
    result = torch.as_tensor(value, dtype=torch.float32, device=device)
    if result.ndim == 0:
        result = result.expand(batch_size)
    if result.shape != (batch_size,) or not torch.isfinite(result).all() or (result < 0).any():
        raise ValueError("speed_mps must be finite, nonnegative, scalar or shape (B,)")
    return result


class ContinuousSpeedEmbedding(nn.Module):
    def __init__(self, hidden_dim, scale_mps=.1):
        super().__init__()
        if not math.isfinite(scale_mps) or scale_mps <= 0:
            raise ValueError("speed_scale_mps must be positive and finite")
        self.register_buffer("scale_mps", torch.tensor(float(scale_mps)))
        self.net = nn.Sequential(nn.Linear(1, hidden_dim), nn.SiLU(), nn.Linear(hidden_dim, hidden_dim))

    def forward(self, speed):
        return self.net(torch.log1p(speed.float() / self.scale_mps).unsqueeze(-1))
