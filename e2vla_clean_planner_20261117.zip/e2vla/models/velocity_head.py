
import torch
from typing import Optional, Sequence, Tuple
from torch import nn, Tensor


class VelocityHead(nn.Module):
    """
    输入: 从 QFormerITM 新增 query slot 中切出的 velocity token, (B, 1, hdim) 或 (B, hdim)
    输出: num_bins 档离散速度的 logits

    设计上不接收 force/history 等本体感知信号，只用视觉-语言上下文 token
    （这是当前版本的明确简化，后续如果要接 FASS 风格的力驱动调度，需要
    在 forward 里新增一路 force history 编码并与 velocity_query 融合）
    """

    def __init__(
        self,
        hdim: int,
        num_bins: int = 5,
        boundaries: Optional[Sequence[float]] = None,
        bin_centers: Optional[Sequence[float]] = None,
        speed_min: float = 0.0,
        speed_max: float = 1.0,
        input_is_normalized: bool = True,
    ):
        """
        Args:
            num_bins: 档位数
            boundaries: 长度 num_bins-1 的分界点序列（物理速度尺度, m/s），
                严格递增。speed_cond 落在 (boundaries[i-1], boundaries[i]]
                之间的样本归为第 i 档。不传则用 [speed_min, speed_max] 间
                等距划分（注意：根据真实数据分布，等距划分通常不是好选择，
                见模块顶部说明；建议优先用 from_quantiles() 构造）。
            bin_centers: 长度 num_bins 的每档代表值（物理速度尺度），用于
                推理时把档位映射回连续速度（logits_to_speed）。不传则自动
                取每档区间的中点（对开区间的首尾两档，用 speed_min/speed_max
                兜底）。
            speed_min, speed_max: 物理速度的全局范围，仅在 boundaries/
                bin_centers 留空时用于等距划分兜底，以及 clamp 输入范围。
            input_is_normalized: 若为 True，则 loss()/speed_to_bin_idx()
                的 gt_speed_cond 输入按 [0,1] 区间解释，内部先反归一化到
                [speed_min, speed_max] 再分档；若为 False，直接按物理速度
                值（m/s）解释。
        """
        super().__init__()
        assert num_bins >= 2, "num_bins 至少要2档才有意义"
        self.hdim = hdim
        self.num_bins = num_bins
        self.speed_min = speed_min
        self.speed_max = speed_max
        self.input_is_normalized = input_is_normalized

        # 分类头: hdim -> hdim -> num_bins
        self.head = nn.Sequential(
            nn.LayerNorm(hdim),
            nn.Linear(hdim, hdim),
            nn.GELU(),
            nn.LayerNorm(hdim),
            nn.Linear(hdim, num_bins),
        )

        boundaries_t, centers_t = self._build_boundaries_and_centers(
            num_bins, boundaries, bin_centers, speed_min, speed_max
        )
        self.register_buffer("boundaries", boundaries_t, persistent=False)
        self.register_buffer("bin_centers", centers_t, persistent=False)

        self.reset_parameters()

    @staticmethod
    def _build_boundaries_and_centers(
        num_bins: int,
        boundaries: Optional[Sequence[float]],
        bin_centers: Optional[Sequence[float]],
        speed_min: float,
        speed_max: float,
    ) -> Tuple[Tensor, Tensor]:
        if boundaries is None:
            # 等距划分兜底
            edges = torch.linspace(speed_min, speed_max, num_bins + 1)
            boundaries_t = edges[1:-1].clone()  # (num_bins - 1,)
        else:
            boundaries_t = torch.as_tensor(list(boundaries), dtype=torch.float32)
            assert boundaries_t.shape[0] == num_bins - 1, (
                f"boundaries 长度应为 num_bins-1={num_bins-1}, "
                f"实际得到 {boundaries_t.shape[0]}"
            )
            assert (boundaries_t[1:] > boundaries_t[:-1]).all(), (
                "boundaries 必须严格递增"
            )

        if bin_centers is None:
            # 默认取每档区间中点；首尾两档用 speed_min/speed_max 兜底封口
            full_edges = torch.cat([
                torch.tensor([speed_min]), boundaries_t, torch.tensor([speed_max])
            ])
            centers_t = (full_edges[:-1] + full_edges[1:]) / 2  # (num_bins,)
        else:
            centers_t = torch.as_tensor(list(bin_centers), dtype=torch.float32)
            assert centers_t.shape[0] == num_bins, (
                f"bin_centers 长度应为 num_bins={num_bins}, "
                f"实际得到 {centers_t.shape[0]}"
            )

        return boundaries_t, centers_t

    @classmethod
    def from_quantiles(
        cls,
        hdim: int,
        raw_speed_samples: Sequence[float],
        num_bins: int = 5,
        clip_quantile: float = 1.0,
        **kwargs,
    ) -> "VelocityHead":
        """
        从真实的原始 chunk_speed 样本（物理速度值, m/s, clip 之前）直接
        校准出按分位点等分的 boundaries/bin_centers，并据此构造 VelocityHead。

        这是推荐的构造方式：用 compute_raw_chunk_speed.py 跑出来的真实
        raw_speeds 数组（全量样本，不要用分桶后的近似直方图去重建，会有
        插值误差）传进来，保证 boundaries 是从真实数据严格算出来的，
        不是手抄/近似的数字。

        Args:
            raw_speed_samples: 1D 数组/列表，原始物理速度样本（clip前）
            num_bins: 档位数
            clip_quantile: 用多少分位点作为最后一档的上边界（即新的有效
                SPEED_MAX）。默认1.0用样本最大值；如果想把极端离群点排除
                在外（比如长尾里个别噪声样本），可以传 0.99 这种值，
                这样最后一档会涵盖 [80%分位点, 99%分位点] 的范围，
                99%分位点以上的极端值在 speed_to_bin_idx 时会被 clamp
                进最后一档，不会报错也不会丢样本，只是不再单独区分。
            **kwargs: 其余参数原样传给 __init__（比如 input_is_normalized）

        Returns:
            VelocityHead 实例
        """
        samples = torch.as_tensor(list(raw_speed_samples), dtype=torch.float32)
        assert samples.numel() > num_bins * 10, (
            f"样本数 {samples.numel()} 太少，不足以稳定估计 {num_bins} 档分位点，"
            f"建议至少有几千个样本"
        )

        speed_min = float(samples.min())
        speed_max = float(torch.quantile(samples, clip_quantile))

        # 0%, 1/num_bins, 2/num_bins, ..., 1.0 共 num_bins+1 个分位点作为边界
        quantile_points = torch.linspace(0, clip_quantile, num_bins + 1)
        edges = torch.quantile(samples, quantile_points)  # (num_bins+1,)

        boundaries = edges[1:-1].clone()  # 掐头去尾，中间 num_bins-1 个是分界点
        centers = (edges[:-1] + edges[1:]) / 2  # (num_bins,)

        return cls(
            hdim=hdim,
            num_bins=num_bins,
            boundaries=boundaries.tolist(),
            bin_centers=centers.tolist(),
            speed_min=speed_min,
            speed_max=speed_max,
            **kwargs,
        )

    def reset_parameters(self):
        # 最后一层 zero-init，训练初期让 logits 接近均匀分布
        # （避免一开始就偏向某个档位，给监督信号一个干净的起点）
        nn.init.zeros_(self.head[-1].weight)
        nn.init.zeros_(self.head[-1].bias)

    def forward(self, velocity_query: Tensor) -> Tensor:
        """
        Args:
            velocity_query (Tensor): (B, 1, hdim) 或 (B, hdim)

        Returns:
            logits (Tensor): (B, num_bins)
        """
        if velocity_query.dim() == 3:
            assert velocity_query.shape[1] == 1, (
                f"expect a single velocity token, got shape {velocity_query.shape}"
            )
            velocity_query = velocity_query.squeeze(1)  # (B, hdim)

        logits = self.head(velocity_query)  # (B, num_bins)
        return logits

    def _to_physical_speed(self, speed_cond: Tensor) -> Tensor:
        if self.input_is_normalized:
            speed_cond = speed_cond.clamp(0.0, 1.0)
            speed_cond = self.speed_min + speed_cond * (self.speed_max - self.speed_min)
        return speed_cond

    def speed_to_bin_idx(self, speed_cond: Tensor) -> Tensor:
        """
        训练时把连续的 gt speed_cond 离散化为档位标签，用于计算交叉熵 loss。

        是否按 [0,1] 归一化值解释，由 self.input_is_normalized 决定（构造
        VelocityHead 时传入），调用方不需要每次手动判断、手动转换。

        Args:
            speed_cond (Tensor): (B,)
                - 若 self.input_is_normalized=True: 取值范围 [0, 1]
                - 若 self.input_is_normalized=False: 物理速度值 (m/s)

        Returns:
            bin_idx (Tensor): (B,), long, 范围 [0, num_bins-1]
        """
        speed_cond = self._to_physical_speed(speed_cond)
        # 超出 [speed_min, speed_max] 的值会被 bucketize 自然地分到首/末档，
        # 不需要额外 clamp（bucketize 对超出 boundaries 范围的值，
        # 自动返回 0 或 len(boundaries)）
        bin_idx = torch.bucketize(speed_cond, self.boundaries)  # (B,), [0, num_bins-1]
        return bin_idx

    @torch.no_grad()
    def logits_to_speed(self, logits: Tensor, mode: str = "argmax") -> Tensor:
        """
        推理时把 logits 转成实际速度值（物理尺度, m/s，给下游 conditioning 用）

        Args:
            logits (Tensor): (B, num_bins)
            mode: "argmax" 取最高概率档位; "expectation" 取概率加权期望

        Returns:
            speed (Tensor): (B,)
        """
        if mode == "argmax":
            bin_idx = logits.argmax(dim=-1)  # (B,)
            speed = self.bin_centers[bin_idx]  # (B,)
        elif mode == "expectation":
            probs = torch.softmax(logits, dim=-1)  # (B, num_bins)
            speed = (probs * self.bin_centers[None, :]).sum(dim=-1)  # (B,)
        else:
            raise ValueError(f"unknown mode: {mode}")
        return speed

    @torch.no_grad()
    def logits_to_bin_idx(
        self, logits: Tensor, mode: str = "argmax", temperature: float = 1.0
    ) -> Tensor:
        """
        推理 / RL rollout 时把 logits 转成档位索引

        Args:
            logits (Tensor): (B, num_bins)
            mode: "argmax" 确定性取最大; "sample" 按 softmax 概率采样（RL 探索用）
            temperature: sample 模式下的温度系数，越大越随机

        Returns:
            bin_idx (Tensor): (B,), long
        """
        if mode == "argmax":
            bin_idx = logits.argmax(dim=-1)
        elif mode == "sample":
            probs = torch.softmax(logits / temperature, dim=-1)
            bin_idx = torch.multinomial(probs, num_samples=1).squeeze(-1)
        else:
            raise ValueError(f"unknown mode: {mode}")
        return bin_idx

    def loss(self, velocity_query: Tensor, gt_speed_cond: Tensor) -> Tuple[Tensor, dict]:
        """
        监督学习阶段的训练 loss

        Args:
            velocity_query (Tensor): (B, 1, hdim) 或 (B, hdim)
            gt_speed_cond (Tensor): (B,)，同 speed_to_bin_idx 的输入约定
                （受 self.input_is_normalized 控制是 [0,1] 还是物理速度值）

        Returns:
            loss (Tensor): scalar
            metrics (dict): 所有 value 都是标量 (float)，不含 list/array，
                兼容假设"每个 metric 都是标量、按 key 逐个累加求平均"的
                训练框架（比如 averages[key].sum += val 这种写法，遇到
                list 会直接因为 int += list 报 TypeError）。

                每档样本占比不再打包成一个 list 放在单个 key 下，而是
                拆成 num_bins 个独立 key:
                    velocity_head_bin0_frac, velocity_head_bin1_frac, ...
                训练时这几个 key 会各自被框架按 batch 累加求平均，效果上
                等价于之前打包成 list 时想要的"持续监控每档占比是否符合
                预期"，只是数据形状从一个 list 换成了多个标量 key。
        """
        logits = self.forward(velocity_query)  # (B, num_bins)
        gt_bin_idx = self.speed_to_bin_idx(gt_speed_cond)  # (B,)

        loss = torch.nn.functional.cross_entropy(logits, gt_bin_idx)

        with torch.no_grad():
            pred_bin_idx = logits.argmax(dim=-1)
            acc = (pred_bin_idx == gt_bin_idx).float().mean()
            bin_counts = torch.bincount(gt_bin_idx, minlength=self.num_bins).float()
            bin_fractions = (bin_counts / bin_counts.sum()).tolist()

        metrics = {
            "velocity_head_loss": loss.item(),
            "velocity_head_acc": acc.item(),
        }
        for i, frac in enumerate(bin_fractions):
            metrics[f"velocity_head_bin{i}_frac"] = frac
        return loss, metrics

    def extra_repr(self) -> str:
        b = self.boundaries.tolist()
        c = self.bin_centers.tolist()
        b_str = ", ".join(f"{x:.4f}" for x in b)
        c_str = ", ".join(f"{x:.4f}" for x in c)
        return (
            f"num_bins={self.num_bins}, input_is_normalized={self.input_is_normalized}\n"
            f"boundaries=[{b_str}]\n"
            f"bin_centers=[{c_str}]"
        )