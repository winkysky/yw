"""Original DINOv2/SigLIP VLA velocity architecture, without contact/wrench."""
from typing import Optional
from torch import nn, Tensor

from .vlm import VLM
from .action_expert_vel_no_force import ActionExpertVelocityNoForce

class VLAVelocityNoForce(nn.Module):
    def __init__(
        self, 
        hdim: int, 
        num_heads: int,
        nhist: int,
        num_actor_context_layers: int,
        num_actor_diffusion_layers: int, 

        diffusion_timesteps: int = 100, 
        inference_timesteps: int = 20, 
        **velocity_options,
    ):
        super().__init__()
        self.vlm = VLM()
        self.actor = ActionExpertVelocityNoForce(
            hdim=hdim,
            num_heads=num_heads,
            nhist=nhist,
            num_context_layers=num_actor_context_layers,
            num_diffusion_layers=num_actor_diffusion_layers, 
            diffusion_timesteps=diffusion_timesteps,
            inference_timesteps=inference_timesteps,
            **velocity_options,
        )
    
        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, (nn.Linear, nn.Conv2d)):
                if m.bias is not None and m.bias.requires_grad:
                    # Do not modify the bias in fronzen backbones!!!
                    nn.init.zeros_(m.bias)
    
    def parameter_groups(self):
        decay = []
        no_decay = []

        for name, param in self.named_parameters():
            if not param.requires_grad:
                continue

            if (
                name.endswith(".bias") or 
                "norm" in name.lower() or 
                "qformer.queries" in name
            ):
                no_decay.append(param)
            else:
                decay.append(param)
        
        return decay, no_decay
    
    def forward(
        self, 
        obs_rgbs: Tensor,
        obs_masks: Optional[Tensor], 
        obs_norm_xys: Tensor, 
        obs_extrinsics: Tensor, 
        prompt_text: Optional[Tensor], 

        current_ee_pose: Tensor, 
        history_ee_states: Tensor,
        gt_future_ee_states: Tensor, 
        valid_ee_mask: Tensor, 
        inference: bool, 
        fp16: bool,
        success: Tensor,
        # episode_length: Tensor,
        gt_speed_cond: Tensor,
        guidance_scale: Tensor,
        initial_noise: Optional[Tensor] = None,
    ):

        vl_obs, vl_feature = self.vlm(
            obs_rgbs=obs_rgbs,
            obs_masks=obs_masks,
            obs_norm_xys=obs_norm_xys,
            obs_extrinsics=obs_extrinsics,

            prompt_text=prompt_text,
            fp16=fp16
        )

        return self.actor(
            vl_obs=vl_obs,
            vl_feature=vl_feature,

            current_ee_pose=current_ee_pose,
            history_ee_states=history_ee_states,
            gt_future_ee_states=gt_future_ee_states,
            valid_ee_mask=valid_ee_mask, 
            inference=inference,
            fp16=fp16,
            success=success,
            # episode_length=episode_length,
            gt_speed_cond=gt_speed_cond,
            guidance_scale=guidance_scale,
            initial_noise=initial_noise,
        )
    

def vla_velocity_no_force_base(
    diffusion_timesteps: int = 100, 
    inference_timesteps: int = 20, 
    continuous_speed: bool = True,
    action_horizon: int | None = 32,
    **velocity_options,
):
    return VLAVelocityNoForce(
        hdim=768,
        num_heads=12,
        nhist=5,
        num_actor_context_layers=8,
        num_actor_diffusion_layers=4,
        diffusion_timesteps=diffusion_timesteps,
        inference_timesteps=inference_timesteps,
        continuous_speed=continuous_speed,
        action_horizon=action_horizon,
        **velocity_options,
    )

