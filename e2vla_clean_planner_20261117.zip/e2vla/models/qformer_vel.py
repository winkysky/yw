import torch
from typing import Optional
from torch import nn, Tensor
from .layers.utils import concat_mask
from .layers.attn_dn import SelfAttentionLayer, CrossAttentionLayer, FFN, init_xncoder


def build_velocity_isolation_attn_mask(
    num_main_query: int,
    num_velocity_query: int,
    num_text: int,
    padding_mask: Optional[Tensor],
    device,
    batch_size: Optional[int] = None,
) -> Optional[Tensor]:
    """
    构造非对称 attention mask，用于 self_attn_text 这一步，实现:
        - 原有 query (num_main_query 个) <-> text: 双向可见，行为不变
        - velocity query (num_velocity_query 个) -> 能看 (attend) 原有
          query 和 text，也能看自己
        - 原有 query / text -> 看不到 velocity query
        - velocity query 之间 (如果 num_velocity_query > 1): 互相可见

    序列拼接顺序固定为 [main_query, velocity_query, text]，与
    QFormerITM.forward 里 query = self.queries.expand(...) 后再
    torch.cat([query, x_text]) 的实际拼接顺序一致。

    == 语义对齐: 基于真实 attn_dn.py / mha.py 源码确认 ==
    MySimpleMHA._attn_impl_eager 里:
        corr.masked_fill_(attn_mask.logical_not(), float("-inf"))
    即 attn_mask 为 boolean 类型时, **True 表示"屏蔽"(填-inf)**,
    False 表示"允许attend"。这与很多直觉上"True=valid/允许"的mask
    约定相反，是这个项目自己的约定，必须严格对齐，否则隔离方向会反过来。

    Shape 按 MySimpleMHA.check_expand_attn_mask 的要求，self-attention
    场景下 Lx=Lc=L，用 (B, L, L) 这个 3D 形式（函数内部会自动 expand 到
    (B, H, L, L)，调用方不需要手动展开 head 维度）。

    padding_mask 参数沿用项目里 concat_mask 产出的约定 (True=valid/有效
    token，这是从 QFormerITM 原有代码路径里 mask_qt 的使用方式反推出的
    约定，如果实际不是这个约定，需要调整下面 pad_block 这一步的取反逻辑)。

    Args:
        num_main_query: 原有 query 数量 (比如64)
        num_velocity_query: 新增 velocity query 数量 (比如1，可以为0)
        num_text: text token 数量
        padding_mask: (B, L) bool, True=valid。None 表示全部有效。
        device: 构造 mask 所在的 device
        batch_size: padding_mask 为 None 时必须显式传入真实 batch size。

    Returns:
        attn_mask (Optional[Tensor]): (B, L, L) bool 或 None
            (num_velocity_query=0 时返回 None，调用方应直接退回到原来的
            1D padding_mask 路径，不构造这个2D mask)
            True 表示"屏蔽"(禁止attend)，False 表示"允许attend"
            —— 这个语义和 attn_dn.py/mha.py 的真实实现完全对齐，可以
            直接传给 SelfAttentionLayer.forward 的 query_mask 参数。
    """
    if num_velocity_query == 0:
        return None

    L = num_main_query + num_velocity_query + num_text

    if padding_mask is not None:
        B = padding_mask.shape[0]
    else:
        assert batch_size is not None, (
            "padding_mask 为 None 时必须显式传入 batch_size，不能隐式假设为1"
        )
        B = batch_size

    # 基础: 全部允许 (False = 不屏蔽)
    block = torch.zeros(L, L, dtype=torch.bool, device=device)

    # 屏蔽: [main_query, text] 这些行 看向 velocity_query 所在的列, 设为屏蔽(True)
    velocity_start = num_main_query
    velocity_end = num_main_query + num_velocity_query
    non_velocity_indices = torch.cat([
        torch.arange(0, velocity_start),
        torch.arange(velocity_end, L),
    ])
    block[non_velocity_indices.unsqueeze(1), velocity_start:velocity_end] = True
    # velocity_query 自己所在的行不受上面这行影响，保持 False(允许)，
    # 即 velocity_query 能看 main_query / text / 自己

    attn_mask = block.unsqueeze(0).expand(B, -1, -1).clone()  # (B, L, L)

    if padding_mask is not None:
        # padding_mask: (B, L), True=valid -> 取反得到 "True=invalid该被屏蔽"
        # 任何 key 列是 invalid 的，都要被屏蔽（不管哪一行在看）
        pad_block = ~padding_mask  # (B, L), True=invalid
        attn_mask = attn_mask | pad_block.unsqueeze(1)  # 广播到每一行

    return attn_mask


class QBlockITM(nn.Module):
    def __init__(self, hdim: int, num_heads: int):
        super().__init__()
        self.self_attn_text = SelfAttentionLayer(hdim, num_heads, bias=True, qk_norm=True)
        self.cross_attn_vision = CrossAttentionLayer(hdim, num_heads, bias=True, qk_norm=True)
        self.ffn_query = FFN(hdim, 2*hdim)
        self.ffn_text = FFN(hdim, 2*hdim)
    
    def forward(
        self, 
        query: Tensor, 
        x_vision: Tensor, 
        mask_vision: Optional[Tensor], 
        x_text: Tensor,
        mask_qt: Optional[Tensor],
        num_main_query: Optional[int] = None,
        num_velocity_query: int = 0,
    ):
        """
        Args:
            query (Tensor): (B, Lq, C), Lq = num_main_query + num_velocity_query
            x_vision (Tensor): (B, Lv, C)
            mask_vision (Optional[Tensor]): (B, Lv) or None
            x_text (Tensor): (B, Lt, C)
            mask_qt (Optional[Tensor]): (B, Lq+Lt) or None, 1D padding mask
            num_main_query: 原有 query 数量。仅在 num_velocity_query>0 时
                需要传，用于构造非对称 attn_mask 区分 main/velocity query。
            num_velocity_query: 新增 velocity query 数量，默认0（不隔离，
                完全复现原版行为，不传这两个新参数时函数签名向后兼容）。
        
        Returns
        -------
            query (Tensor): (B, Lq, C)
            x_text (Tensor): (B, Lt, C)
            mask_vision (Optional[Tensor]): (B, Lv) or None
            mask_qt (Optional[Tensor]): (B, Lq+Lt) or None
        """
        qt = torch.cat([query, x_text], dim=1)

        if num_velocity_query > 0:
            assert num_main_query is not None
            attn_mask = build_velocity_isolation_attn_mask(
                num_main_query=num_main_query,
                num_velocity_query=num_velocity_query,
                num_text=x_text.shape[1],
                padding_mask=mask_qt,
                device=qt.device,
                batch_size=qt.shape[0],
            )
            # 已用真实 attn_dn.py/mha.py 源码确认: SelfAttentionLayer.forward
            # 的 query_mask 参数直接透传给 MySimpleMHA.forward 的
            # attn_mask，后者的 check_expand_attn_mask 原生支持
            # (B, Lx, Lc) 这个 3D 形状（这里 Lx=Lc=L 自注意力场景），
            # 不需要手动展开 head 维度。
            # boolean mask 语义: True=屏蔽(填-inf)，False=允许attend，
            # build_velocity_isolation_attn_mask 的返回值已经按这个
            # 语义构造，可以直接传入，不需要取反。
            qt, mask_qt_out = self.self_attn_text(
                query=qt,
                query_mask=attn_mask,
            )
            # mask_qt 维持原始 1D padding mask 不变，往后传递
            # (因为后续步骤，如 cross_attn_vision、调用方拼接 cond_mask，
            # 用的都是 1D padding 语义，不应该被 2D attn_mask 污染)
        else:
            qt, mask_qt = self.self_attn_text(
                query=qt, 
                query_mask=mask_qt
            )
        
        query, x_text = torch.split(qt, [query.shape[1], x_text.shape[1]], dim=1)
        x_text = self.ffn_text(x_text)

        query, mask_vision = self.cross_attn_vision(
            query=query, 
            value=x_vision, 
            value_mask=mask_vision
        )
        query = self.ffn_query(query)
        return query, x_text, mask_vision, mask_qt


class QFormerITM(nn.Module):
    def __init__(
        self,
        hdim: int,
        num_heads: int,
        num_layers: int,
        num_queries: int,
        num_velocity_queries: int = 0,
    ):
        """
        Args:
            num_queries: 原有的语义/视觉-语言融合 query 数量（比如64）
            num_velocity_queries: 新增的、专门给 VelocityHead 用的 query
                数量（比如1）。这些 query 和原有 query 共享同一套
                self-attn(+text) / cross-attn(vision) 流程，只是在最终输出
                时被单独切分出来，不会被原本的 cond 路径继续使用
                （由调用方，即 ContextEncoder，负责切分和路由）。
                设为0时行为与改动前完全一致。
        """
        super().__init__()
        self.num_layers = num_layers
        self.num_queries = num_queries
        self.num_velocity_queries = num_velocity_queries
        total_queries = num_queries + num_velocity_queries
        self.queries = nn.Parameter(torch.randn(1, total_queries, hdim))
        self.layers = nn.ModuleList([QBlockITM(hdim, num_heads) 
                                     for _ in range(num_layers)])
        self.reset_parameters()
    
    def reset_parameters(self):
        ### init params
        nn.init.trunc_normal_(self.queries, std=0.02)
        init_xncoder(self.num_layers*2, self.layers)

    def forward(
        self, 
        x_vision: Tensor, 
        mask_vision: Optional[Tensor], 
        x_text: Tensor,
        mask_text: Optional[Tensor]
    ):
        """
        Args:
            x_vision (Tensor): (B, Lv, C)
            mask_vision (Optional[Tensor]): (B, Lv) or None
            x_text (Tensor): (B, Lt, C)
            mask_text (Optional[Tensor]): (B, Lt) or None
        
        Returns:
            query (Tensor): (B, Lq, C), Lq = num_queries (不含 velocity query)
            velocity_query (Tensor or None): (B, num_velocity_queries, C)，
                num_velocity_queries=0 时返回 None
            x_text (Tensor): (B, Lt, C)
            mask_qt (Optional[Tensor]): (B, Lq+Lvq+Lt) or None
                (注意: mask_qt 长度是 split 之前的总长度，调用方如果要切分
                mask，需要自己按 [num_queries, num_velocity_queries, Lt]
                做 split，这里不做隐式假设)
        """
        B = x_vision.shape[0]
        query = self.queries.expand(B, -1, -1)  # (B, num_queries+num_velocity_queries, C)
        mask_qt = concat_mask(mask0=None, mask1=mask_text,
                              L0=query.shape[1], L1=x_text.shape[1])
        
        for layer in self.layers:
            query, x_text, mask_vision, mask_qt = layer(
                query=query,
                x_vision=x_vision,
                mask_vision=mask_vision,
                x_text=x_text,
                mask_qt=mask_qt,
                num_main_query=self.num_queries,
                num_velocity_query=self.num_velocity_queries,
            )

        if self.num_velocity_queries > 0:
            query, velocity_query = torch.split(
                query, [self.num_queries, self.num_velocity_queries], dim=1
            )
        else:
            velocity_query = None

        return query, velocity_query, x_text, mask_qt