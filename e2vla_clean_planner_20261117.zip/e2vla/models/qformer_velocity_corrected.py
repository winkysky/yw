"""Correct mask semantics only for the action-only continuous-speed model.

The original qformer_vel.py is intentionally left intact for other models.
MySimpleMHA uses True=allowed for both eager and SDPA attention.
"""
import torch
from .qformer_vel import QBlockITM


def allowed_velocity_mask(main, velocity, text, padding, batch, device):
    length = main + velocity + text
    allowed = torch.ones(batch, length, length, dtype=torch.bool, device=device)
    allowed[:, :main, main:main + velocity] = False
    allowed[:, main + velocity:, main:main + velocity] = False
    if padding is not None:
        allowed &= padding[:, None, :]
    return allowed


class CorrectedQBlockITM(QBlockITM):
    def forward(self, query, x_vision, mask_vision, x_text, mask_qt,
                num_main_query=None, num_velocity_query=0):
        qt = torch.cat([query, x_text], dim=1)
        mask = (allowed_velocity_mask(num_main_query, num_velocity_query, x_text.shape[1],
                                      mask_qt, qt.shape[0], qt.device)
                if num_velocity_query else mask_qt)
        qt, _ = self.self_attn_text(query=qt, query_mask=mask)
        query, x_text = torch.split(qt, [query.shape[1], x_text.shape[1]], dim=1)
        x_text = self.ffn_text(x_text)
        query, mask_vision = self.cross_attn_vision(query=query, value=x_vision, value_mask=mask_vision)
        return self.ffn_query(query), x_text, mask_vision, mask_qt


def correct_context_mask(context, hidden_dim, num_heads):
    for index, old in enumerate(context.qformer.layers):
        replacement = CorrectedQBlockITM(hidden_dim, num_heads)
        replacement.load_state_dict(old.state_dict(), strict=True)
        context.qformer.layers[index] = replacement
